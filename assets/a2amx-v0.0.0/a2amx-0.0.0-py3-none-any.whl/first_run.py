"""Safe local infrastructure first run; no seat launch, migration or rule install."""
import hmac
import http.client
import os
from pathlib import Path
import pwd
import secrets
import stat
import subprocess
import sys
import tempfile
import time

import store
import product_identity
from service_lifecycle import (Refused, SOURCE, clean_empty_web_lease, lease,
                               private_file, readiness_proof, stop)

BASE_NAMES = ('HOME', 'USER', 'LOGNAME', 'PATH', 'LANG', 'TMPDIR', 'SHELL')
SWITCH_NAMES = ('ORCH_CODEX_IPC_ENABLED', 'ORCH_INAPP_SOCKET_ENABLED',
                'ORCH_AGY_DESKTOP_ENABLED')


def base_environment():
    user = pwd.getpwuid(os.getuid()).pw_name
    defaults = dict(HOME=str(Path.home()), USER=user, LOGNAME=user, PATH=os.defpath,
                    LANG='C.UTF-8', TMPDIR=tempfile.gettempdir(), SHELL='/bin/sh')
    return {name: os.environ.get(name) or defaults[name] for name in BASE_NAMES}


def switches():
    values = {name: os.environ.get(name, '0') for name in SWITCH_NAMES}
    if any(value not in {'0', '1'} for value in values.values()):
        raise Refused('dispatcher switches must be 0 or 1')
    return values


def private_directory(path):
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    info = path.lstat()
    if (not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid()
            or stat.S_IMODE(info.st_mode) & 0o077):
        raise Refused(f'{path}: expected an owned private directory (0700)')


def exclusive_write(path, value):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'w') as stream:
        stream.write(value)
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


lifecycle_lock = store.lifecycle_exclusion
prepare_store = store.prepare_first_run_store


def secret(path):
    try:
        fd = private_file(path)
    except FileNotFoundError:
        try:
            exclusive_write(path, secrets.token_urlsafe(32) + '\n')
        except FileExistsError:
            pass
        fd = private_file(path)
    with os.fdopen(fd) as stream:
        value = stream.read(4097).strip()
    if not value or len(value) > 4096 or any(char.isspace() for char in value):
        raise Refused(f'{path.name}: malformed credential; not overwritten')
    return value


def credentials():
    run = product_identity.state_root() / 'run'
    private_directory(run)
    # Reuse the observation credential on existing checkout installations, without
    # copying it or making a writable checkout a requirement for new installations.
    legacy = SOURCE / '.auth_token'
    auth_path = legacy if os.path.lexists(legacy) else run / '.auth_token'
    return secret(auth_path), secret(run / '.ui_token')


def service_environments(auth, ui):
    base = base_environment()
    # This is a validated registry identity, not a participant credential. Both
    # services need the same selection when an existing store has several humans.
    base['PSQR_OWNER'] = store.operator_identity()
    return ({**base, **switches(), 'PSQR_UI_TOKEN': ui},
            {**base, 'PSQR_UI_TOKEN': ui, 'PSQR_AUTH_TOKEN': auth})


def web_ready(port, token, owned):
    """Authenticate the peer before disclosing a bearer, on one TCP connection.

    Port ownership can change between probes. A fresh nonce/PID proof on the
    unauthenticated 401 identifies the verified server; automatic reconnection is
    disabled so its authenticated follow-up cannot reach a replacement listener.
    """
    connection = http.client.HTTPConnection('127.0.0.1', port, timeout=1)
    connection.auto_open = False
    try:
        connection.connect()  # the only connection; no proxy or redirect handling
        peer = connection.sock
        challenge = secrets.token_hex(32)
        connection.request('GET', '/state', headers={'X-Orch-Readiness': challenge})
        response = connection.getresponse()
        proof = response.getheader('X-Orch-Readiness-Proof', '')
        if (len(response.read(1048577)) > 1048576 or response.status != 401
                or len(proof) != 64 or any(c not in '0123456789abcdef' for c in proof)
                or not hmac.compare_digest(proof, readiness_proof(token, owned.record['pid'], challenge))
                or connection.sock is not peer or peer is None):
            return False
        owned.verify()
        connection.request('GET', '/app/unread', headers={'Authorization': 'Bearer ' + token})
        response = connection.getresponse()
        if (len(response.read(1048577)) > 1048576 or response.status != 200
                or response.getheader('Cache-Control') != 'no-store'):
            return False
        connection.request('GET', '/app')
        response = connection.getresponse()
        page = response.read(1048577)
        owned.verify()
        return response.status == 200 and len(page) <= 1048576 and b'<html' in page.lower()
    except (OSError, http.client.HTTPException):
        return False
    finally:
        connection.close()


def verify_operator(owned, selected):
    record = owned.verify()
    if record.get('operator') != selected:
        raise Refused(f'{owned.kind}: operator selection differs or was not recorded; ' +
                      product_identity.diagnostic(
                          f'run {product_identity.command()} down, then {product_identity.command()} up with the selected PSQR_OWNER',
                          f'stop it with {product_identity.command()} down before restarting'))
    return record


def ready(root, kind, port, auth, expected_pid=None, expected_owner=None):
    with lease(root, kind, observe=True) as owned:
        if owned is None or not owned.held():
            return False
        try:
            record = owned.verify()
        except Refused:
            if expected_pid is None:
                raise
            return False  # a just-started child may still be publishing its lock
        if expected_pid is not None and record['pid'] != expected_pid:
            raise Refused(f'{kind}: another process acquired the lease')
        if expected_owner is not None:
            verify_operator(owned, expected_owner)
        if kind == 'daemon':
            from daemon_heartbeat import snapshot
            observed = snapshot()
            runtime = root / 'runtime.json'
            return (observed['state'] == 'up' and observed['pid'] == record['pid']
                    and observed.get('heartbeat_age_seconds', 999) < 5
                    and runtime.exists() and 0 <= time.time() - runtime.stat().st_mtime < 5
                    and not list(root.glob('.daemon-heartbeat-*')))
        if int(owned.observed['command'].rsplit(' ', 1)[-1]) != port:
            raise Refused('web: owned service listens on a different port; not replaced')
        return web_ready(port, auth, owned)


def spawn(kind, environment, port, run):
    script = 'delivery.py' if kind == 'daemon' else 'psqr_orchestrator.py'
    command = [sys.executable, '-B', str(SOURCE / script)]
    if kind == 'web':
        command += ['serve', '--host', '127.0.0.1', '--port', str(port)]
    fd, path = tempfile.mkstemp(prefix=kind + '-', suffix='.log', dir=run)
    with os.fdopen(fd, 'w') as log:
        child = subprocess.Popen(command, cwd=SOURCE, env=environment,
                                 stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                 start_new_session=True, umask=0o077)
    print(f'{kind}: starting; log {path}', flush=True)
    return child


def start(root, port):
    bound = store.require_bound_store()
    if bound != root:
        raise Refused('store binding changed before service start')
    auth, ui = credentials()
    environments = dict(zip(('daemon', 'web'), service_environments(auth, ui)))
    run = root / 'run'
    private_directory(run)
    clean_empty_web_lease(root)
    # Check every retained service before spawning anything. In particular, a
    # retained web service must not cause a new daemon with a different operator.
    for kind in ('daemon', 'web'):
        with lease(root, kind, observe=True) as owned:
            if owned is not None and owned.held():
                verify_operator(owned, environments[kind]['PSQR_OWNER'])
    started = []
    try:
        for kind in ('daemon', 'web'):
            with lease(root, kind, observe=True) as owned:
                if owned is not None and owned.held():
                    verify_operator(owned, environments[kind]['PSQR_OWNER'])
                    deadline = time.monotonic() + 15
                    while not ready(root, kind, port, auth,
                                    expected_owner=environments[kind]['PSQR_OWNER']):
                        # A retained daemon may have published its lease before
                        # its first heartbeat. UNKNOWN is not readiness or death.
                        if kind != 'daemon' or time.monotonic() >= deadline:
                            raise Refused(f'{kind}: existing service is not ready; not replaced')
                        time.sleep(0.1)
                    print(f'{kind}: already ready', flush=True)
                    continue
                if owned is not None:
                    record = owned.read()
                    from service_lifecycle import process
                    if process(record['pid']) is not None:
                        raise Refused(f'{kind}: recorded process exists without its lease')
            child = spawn(kind, environments[kind], port, run)
            started.append((kind, child))
            deadline = time.monotonic() + 15
            while True:
                if child.poll() is not None:
                    raise Refused(f'{kind}: child exited {child.returncode}; see private log')
                if ready(root, kind, port, auth, child.pid,
                         expected_owner=environments[kind]['PSQR_OWNER']):
                    print(f'{kind}: ready', flush=True)
                    break
                if time.monotonic() >= deadline:
                    raise Refused(f'{kind}: readiness timed out; see private log')
                time.sleep(0.1)
    except BaseException:
        # Roll back only services this invocation launched, never a pre-existing one.
        for kind, child in reversed(started):
            if child.poll() is None:
                okay, detail = stop(root, kind, expected_pid=child.pid, reap=child.poll)
                print(detail, file=sys.stderr)
                if not okay:
                    print(f'{kind}: cleanup unverified; inspect the private log before retrying', file=sys.stderr)
            elif kind == 'web':
                try:
                    clean_empty_web_lease(root)
                except (OSError, Refused) as exc:
                    print(f'web: empty lease cleanup refused: {exc}', file=sys.stderr)
        raise
    # Readiness is the startup commit point. Diagnostic failure or interruption
    # after it must not enter the rollback of newly launched, ready services.
    print(f'console: http://127.0.0.1:{port}/app', flush=True)
    if not product_identity.is_public():
        print(f'console credential file: {product_identity.state_root() / "run" / ".ui_token"}', flush=True)
    import orch_cli
    orch_cli.SERVER_PORT = port
    doctor_status = orch_cli.cmd_doctor(None)
    if doctor_status:
        print(f'services ready; doctor reported issues (exit {doctor_status}); '
              f'run {product_identity.command()} doctor for diagnostics', flush=True)
    return 0


def up(args):
    try:
        switches()  # validate before creating anything
        port = getattr(args, 'port', 8020)
        if not 0 < port < 65536:
            raise Refused('port must be between 1 and 65535')
        with lifecycle_lock() as lifecycle_fd:
            root = prepare_store(getattr(args, 'store', None))
            # Store paths bind once at import. Use a new interpreter after registration,
            # never patch cached module globals to make an unbound process look bound.
            environment = {**base_environment(), **switches()}
            if not product_identity.is_public() and os.environ.get('PSQR_OWNER'):
                environment['PSQR_OWNER'] = os.environ['PSQR_OWNER']
            result = subprocess.run([sys.executable, '-B', str(SOURCE / 'first_run.py'),
                                     str(root), str(port), str(lifecycle_fd)],
                                    cwd=SOURCE, env=environment, pass_fds=(lifecycle_fd,))
            return result.returncode
    except (OSError, ValueError, Refused, store.StoreUnbound, store.StoreRegisteredWithoutReceipt) as exc:
        print(f'{product_identity.command()} up refused: {exc}', file=sys.stderr)
        return 1


def down(args):
    try:
        with lifecycle_lock(), store.registration_exclusion():
            root, _ = store.read_locator()
            if root != store.require_bound_store():
                raise Refused('store binding changed before stop')
            results = [stop(root, kind) for kind in ('web', 'daemon')]
            for _, detail in results:
                print(detail)
            print('seat sessions, store and history retained')
            return 0 if all(okay for okay, _ in results) else 1
    except (OSError, ValueError, Refused, store.StoreUnbound) as exc:
        print(f'{product_identity.command()} down refused: {exc}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    try:
        if len(sys.argv) != 4:
            raise Refused('startup delegate requires an inherited lifecycle descriptor')
        with lifecycle_lock(inherited_fd=int(sys.argv[3])):
            raise SystemExit(start(Path(sys.argv[1]), int(sys.argv[2])))
    except (OSError, ValueError, Refused, subprocess.SubprocessError) as exc:
        print(f'{product_identity.command()} up refused: {exc}', file=sys.stderr)
        raise SystemExit(1)
