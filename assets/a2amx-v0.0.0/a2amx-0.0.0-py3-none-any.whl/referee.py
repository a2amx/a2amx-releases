"""Semantic referee — SOFT norm rules: FLAG and route, never silent-block (META_HARNESS_PLAN
Stage 4, Appendix K "no silent censorship").

A NON-participant observer (separate from any agent / the chief-of-staff). Where the hard-rule
pipeline (norms.py) BLOCKS deterministic violations pre-fanout, the referee only ever FLAGS
soft/semantic concerns: the message is ALREADY delivered; a ``norm_check{verdict:flag}`` is recorded
and thereby routed to the operator (telemetry/ledger surface it). Dissent and restatements are
surfaced, never suppressed.

Commit 2 ships the flag-and-route framework + two DETERMINISTIC baseline heuristics
(substantive-delta, uncredited-restatement). The genuinely semantic rules (dissent-smoothing,
mandate-scope) plug into the same ``review()`` seam as an LLM evaluator later — they too may only
flag, never block. Read-only over the log; the only write is the ledger flag receipt.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from mirror_diagnostics import record_failure
import constitution
import ledger
import store

#: Soft-rule sensitivity (from the constitution — tunable via the governed mutation gate). A
#: message with >= this token-set overlap with a recent message is a candidate. Self-overlap in
#: [SIMILARITY_FLAG, 1.0) is a weak substantive delta (an EXACT self duplicate is the hard rule's
#: job, norms.py); overlap with ANOTHER author (incl. verbatim) with no attribution is a possible
#: uncredited restatement.
SIMILARITY_FLAG = constitution.value("referee.similarity_flag", 0.6)
MIN_TOKENS = constitution.value("referee.min_tokens", 6)   # below this, similarity is noise


def _tokens(text: str) -> set:
    return set((text or "").lower().split())


def _similarity(a: str, b: str) -> float:
    """Jaccard overlap of token sets (order-insensitive, deterministic). 0.0 for trivial input."""
    ta, tb = _tokens(a), _tokens(b)
    if len(ta) < MIN_TOKENS or len(tb) < MIN_TOKENS:
        return 0.0
    inter = len(ta & tb)
    union = len(ta | tb)
    return inter / union if union else 0.0


def _credits(msg: Dict[str, Any], author: str, recent: List[Dict[str, Any]]) -> bool:
    """True if ``msg`` credits ``author`` — its reply_to points at one of author's messages, or it
    mentions author by name. Attribution present => no uncredited-restatement flag."""
    ref = msg.get("reply_to")
    if ref:
        for r in recent:
            if r.get("id") == ref and r.get("from") == author:
                return True
    return author.lower() in (msg.get("text", "") or "").lower()


def review(msg: Dict[str, Any], recent: List[Dict[str, Any]]) -> List[Dict[str, str]]:
    """Soft-rule review of one delivered ``msg`` against the ``recent`` window. Returns zero+
    FLAGS (never a block) — ``{rule, reason}``. Pure: no I/O."""
    text = msg.get("text", "") or ""
    if len(_tokens(text)) < MIN_TOKENS:
        return []
    sender, mid = msg.get("from"), msg.get("id")
    flags: List[Dict[str, str]] = []
    for r in recent:
        if r.get("id") == mid or not r.get("text"):
            continue
        sim = _similarity(text, r["text"])
        if sim < SIMILARITY_FLAG:
            continue
        if r.get("from") == sender:
            if sim < 1.0:   # exact self-dup is the HARD rule (norms.delta); flag only weak deltas
                flags.append({"rule": "substantive-delta",
                              "reason": f"low substantive delta ({sim:.0%}) vs your recent "
                                        f"message {r.get('id')} — is this adding something new?"})
        elif not _credits(msg, r.get("from"), recent):
            flags.append({"rule": "uncredited-restatement",
                          "reason": f"{sim:.0%} overlap with {r.get('from')}'s message "
                                    f"{r.get('id')} without attribution — credit the source?"})
    # de-dupe by rule (one flag per rule per message; the strongest match already drove it)
    seen: set = set()
    return [f for f in flags if not (f["rule"] in seen or seen.add(f["rule"]))]


def record_flags(msg: Dict[str, Any], flags: List[Dict[str, str]]) -> None:
    """Route each flag to the operator as a ``norm_check{verdict:flag}`` ledger receipt (audit +
    telemetry surface it). Isolated — a ledger failure never affects the already-delivered message.
    The referee acts as system_governor; it flags, it does not censor."""
    for f in flags:
        try:
            ledger.emit("norm_check", actor_id="System", payload={
                "verdict": "flag", "rule": f["rule"], "reason": f["reason"],
                "msg_id": msg.get("id"), "subject": msg.get("from")})
        except Exception as exc:
            record_failure('referee', exc)


def review_message(msg: Dict[str, Any], recent: List[Dict[str, Any]]) -> List[Dict[str, str]]:
    """review() + record_flags() — the operable one-call entry."""
    flags = review(msg, recent)
    if flags:
        record_flags(msg, flags)
    return flags


def scan(limit: int = 50) -> List[Dict[str, Any]]:
    """Review the last ``limit`` room messages against the messages that preceded them (read-only
    over the log), recording flags. Returns ``[{msg_id, from, flags}]`` for flagged messages — an
    operator/loop entry point that needs no send-path wiring."""
    msgs = [m for m in store.tail_jsonl(store.LOG_FILE, limit) if m.get("kind") != "system"]
    out: List[Dict[str, Any]] = []
    for i, m in enumerate(msgs):
        flags = review_message(m, msgs[:i])
        if flags:
            out.append({"msg_id": m.get("id"), "from": m.get("from"), "flags": flags})
    return out


if __name__ == "__main__":
    import json
    print(json.dumps(scan(), indent=2, ensure_ascii=False))
