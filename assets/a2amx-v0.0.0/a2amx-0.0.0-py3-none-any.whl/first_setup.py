"""Stage 1's first run (B1 and B2's install side): `orch setup`, run once after the install line.

It refuses on a missing prerequisite, then starts the local infrastructure (`up`), and then, in a
fresh interpreter because the store binds at import, makes what a stranger's Mac needs:
- the store's operator credential, issued by the bootstrap and held in its seat folder, never
  shown; the fresh store is born in the credentials marker's state, in that same act;
- the delivery daemon's own credential, so it can wake seats;
- the Chief of Staff's seat, made by the one provisioning function the per-seat command shares
  (`seat_new.provision`), its token held in the seat's folder, never shown;
- the command made reachable for later shells, by the installer's own command;
and then opens the console and prints the one thing left for the person to do.

Every step is idempotent: a second run reports what already exists and changes nothing.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

import prerequisites
import product
import product_identity

OPERATOR = "local-operator"
CHIEF_DEFAULT = "Chief"
APPROVAL_ID = "first-run-01"
APPROVAL_FILE = "first-run-authorization.md"

# The fresh-store plan (D-CRED-6's marker records a plan's hash): a store born with no history
# needs no migration, so its plan is this fixed text, shipped in the wheel, and its hash is the
# marker's plan_sha256. Changing a byte changes the hash; tests pin both.
FRESH_STORE_PLAN = (
    "credentials_01 fresh-store plan, version 1.\n"
    "This store was created by the first run with an empty token table.\n"
    "It has no history to migrate: the marker is written with generation 1 for every row\n"
    "the registry has, in the same table write as the store's first token, the bootstrap\n"
    "invite. A store with any token record is refused this plan and keeps the migration.\n")
FRESH_STORE_PLAN_SHA256 = hashlib.sha256(FRESH_STORE_PLAN.encode()).hexdigest()

# The Chief's grounding until the onboarding skill and its templates land (the onboarding
# lane's, outside this build): neutral, one line, and replaced by the seat's own provisioning when they do.
class SetupRefused(RuntimeError):
    """One sentence for the person, naming what is missing and what to do."""


def _say(line: str) -> None:
    print(line, flush=True)


# --- the parent: prerequisites, then up, then the fresh interpreter -------------------------------

def setup(args) -> int:
    missing = prerequisites.first_missing(prerequisites.run())
    if missing is not None:
        print(f"{product.COMMAND} setup refused: {missing.missing}", file=sys.stderr)
        return 1
    import first_run
    rc = first_run.up(argparse.Namespace(store=getattr(args, "store", None), port=args.port))
    if rc:
        return rc
    params = {"chief": args.chief, "port": args.port, "open": not args.no_open}
    child = subprocess.run([sys.executable, "-B", str(Path(__file__).resolve()), "seats",
                            json.dumps(params)],
                           cwd=Path(__file__).resolve().parent,
                           env={**first_run.base_environment(),
                                **({"PSQR_OWNER": os.environ["PSQR_OWNER"]}
                                   if not product_identity.is_public() and os.environ.get("PSQR_OWNER") else {})})
    return child.returncode


# --- the child: everything that needs the bound store ----------------------------------------------

def _token_from(path: Path) -> str | None:
    """The plaintext token held at `path`, or None if absent; a loose or unreadable file refuses."""
    import store
    if not path.exists():
        return None
    found = store.find_presented_token(path)
    if found["error"]:
        raise SetupRefused(f"the credential file {path} is not usable ({found['error']}); "
                           "its permissions must be 0600 and owned by you")
    return found["token"]


def _verdict(token: str | None):
    import store
    if not token:
        return None
    return store.token_verdict(token)[0]


def _staged(path: Path) -> list[Path]:
    """The store's staged copies of a seat file (`<name>.next-*`), which a committed act leaves
    when its placement did not complete."""
    return sorted(path.parent.glob(f"{path.name}.next-*")) if path.parent.is_dir() else []


def _resume_placement(seat: str) -> bool:
    """A claim that committed but was not placed: the store's own locked repair places the seat's
    staged live session and removes dead staged copies. Nothing is placed blindly, nothing shown."""
    import store
    path = store.seat_token_path(seat)
    if path.exists() or not _staged(path):
        return False
    try:
        store.place_staged_token(seat)
    except ValueError:                      # no staged copy held a live session
        return False
    return True


def _claim_placed_invite(seat: str) -> bool:
    """Claim the invite the store placed for `seat`, or its staged copy when that placement did not
    complete (a claim consumes by value, so a dead copy is only refused), then remove it, as `token
    claim` does. A committed claim consumed its invite, so the file goes on every committed outcome;
    one committed but not placed is placed at once by the store's locked repair, and if that cannot
    run now, the next run resumes it. An invite whose claim's commit is unknown stays for that run."""
    import store
    invite = store.seat_invite_path(seat)
    source = invite if invite.exists() else max(_staged(invite), key=lambda f: f.stat().st_mtime,
                                                default=None)
    if source is None:
        return False
    plain = source.read_text(encoding="utf-8").strip()
    try:
        store.claim_seat_token(seat, plain)
    except (store.SeatTokenNotPlaced, store.SeatCredentialPlacementIndeterminate):
        source.unlink(missing_ok=True)
        try:
            resumed = _resume_placement(seat)
        except OSError:
            resumed = False
        if not resumed:
            raise
    except (store.SeatCredentialPlacedAfterCallbackError, store.SeatActWithoutReceipt,
            store.SeatCredentialPlacedAfterInterruption):
        source.unlink(missing_ok=True)
        raise
    else:
        source.unlink()
    return True


def committed_outcomes() -> tuple:
    """The store's committed-but-exceptional outcomes (B3's seat_new passes them on unchanged).
    None is a refusal: setup stops on one and, run again, resumes from what the store recorded."""
    import store
    return (store.SeatActWithoutReceipt, store.SeatTokenNotPlaced, store.SeatInviteNotPlaced,
            store.SeatCredentialCommitIndeterminate, store.SeatCredentialPlacementIndeterminate,
            store.SeatCredentialPlacedAfterCallbackError, store.SeatUncommittedStageNotRemoved,
            store.SeatActCleanupUnconfirmed, store.RegistryRoleIncomplete)


def stopped_line(exc: BaseException) -> str:
    """One sentence for a committed outcome, in setup's own words: no credential, no staged path and
    no token command, since running setup again is the whole repair."""
    seat = getattr(exc, "seat", None)
    return (f"{product.COMMAND} setup stopped: a step" + (f" for {seat}" if seat else "")
            + f" is recorded but did not finish ({type(exc).__name__}); run `{product.COMMAND} setup` "
            "again and it resumes from there")


def ensure_operator() -> str | None:
    """The operator's credential: issued once, on a fresh store, with the store born migrated."""
    import store
    path = store.seat_token_path(OPERATOR)
    issued = False
    if store.bootstrap_state()["open"]:
        issued = True
        store.issue_seat_invite(OPERATOR, issuer=OPERATOR, auth="bootstrap", bootstrap=True,
                                born_migrated_plan_sha256=FRESH_STORE_PLAN_SHA256)
        _claim_placed_invite(OPERATOR)
        _say(f"operator: credential issued and held in {path.parent} (never shown); "
             "this store was born with its credentials marker")
    elif not path.exists() and (_resume_placement(OPERATOR) or _claim_placed_invite(OPERATOR)):
        issued = True
        _say(f"operator: an interrupted first run's credential placed in {path.parent} (never shown)")
    token = _token_from(path)
    live = _verdict(token) is not None
    if live and not issued:
        _say("operator: already set up")
    elif not live:
        _say("operator: its session is no longer live; it is not needed once the Chief of Staff exists")
    return token if live else None


def provisioning_token(chief: str, operator_token: str | None) -> str:
    """The credential the remaining steps present: the Chief's own (untimed once it exists), else
    the operator's. Neither live means this store can no longer provision without the principal,
    which stage 1 does not offer: said, never worked around."""
    import store
    for token in (_token_from(store.seat_token_path(chief)), operator_token):
        rec = _verdict(token)
        if rec is not None and rec.get("role") in store.PROVISIONING_ROLES:
            return token
    raise SetupRefused(
        "this store holds no live credential that can make seats: neither the Chief of Staff's "
        "nor the operator's is usable, and stage 1 has no password to restore them")


def ensure_daemon(presented: str) -> None:
    import store
    seat = store.DAEMON_SEAT
    path = store.seat_token_path(seat)
    rec = _verdict(_token_from(path))
    if rec is not None and rec.get("role") == "daemon":
        _say("daemon: its credential already held")
        return
    if _resume_placement(seat) and (_verdict(_token_from(path)) or {}).get("role") == "daemon":
        _say(f"daemon: an interrupted run's credential placed in {path.parent} (never shown)")
        return
    # An invite an earlier run committed but did not place: claimed from its staged copy before another
    # is issued; a copy the store refuses by value is dead, nothing was consumed, and its file goes.
    invite = store.seat_invite_path(seat)
    while not invite.exists() and _staged(invite):
        try:
            if _claim_placed_invite(seat) and (_verdict(_token_from(path)) or {}).get("role") == "daemon":
                _say(f"daemon: an interrupted run's credential claimed into {path.parent} (never shown)")
                return
        except ValueError:
            max(_staged(invite), key=lambda f: f.stat().st_mtime).unlink(missing_ok=True)
    if seat not in store.load_participants():
        store.join_participant(seat, presented_token=presented, kind="system", channel="pull")
    issuer = _verdict(presented)["participant_id"]
    store.issue_seat_invite(seat, issuer=issuer, auth="token", presented_token=presented)
    _claim_placed_invite(seat)
    _say(f"daemon: credential issued and held in {path.parent} (never shown)")


def approval_record() -> tuple[str, str]:
    """The record a privileged role is set against: the person's own run of this command, written
    once beside the console credential, its hash taken from the file's bytes."""
    import store
    run = product_identity.state_root() / "run"
    path = run / APPROVAL_FILE
    if not path.exists():
        text = (f"The owner of this Mac ran `{product.COMMAND} setup` at "
                f"{datetime.now(timezone.utc).isoformat(timespec='seconds')} and asked for a "
                "Chief of Staff seat on this store.\n")
        store.write_secret_file(path, text)
    return APPROVAL_ID, hashlib.sha256(path.read_bytes()).hexdigest()


def ensure_chief(chief: str, presented: str) -> dict:
    try:
        import seat_new
    except ImportError:
        raise SetupRefused("this build does not include the desktop seat kit, so it cannot make "
                           "the Chief of Staff's seat") from None
    import store
    approval = approval_record()
    # The Chief's GROUNDING text (stage 1 B2), rendered by the seat command's own renderer; the seat
    # command writes the onboarding skill and its templates into the Chief's home with it.
    commission = seat_new.chief_commission(chief, product=product.COMMAND)
    if _resume_placement(chief):            # an earlier run stopped after the Chief's claim committed
        _say(f"chief of staff: an interrupted run's credential placed in "
             f"{store.seat_token_path(chief).parent} (never shown)")

    def provision() -> dict:
        return seat_new.provision(chief, kind="claude", role="chief_of_staff", approval=approval,
                                  presented_token=presented,
                                  commission_text=commission,
                                  product=product.COMMAND)
    try:
        return provision()
    except (store.SeatTokenNotPlaced, store.SeatCredentialPlacementIndeterminate):
        try:
            resumed = _resume_placement(chief)
        except OSError:
            resumed = False
        if not resumed:
            raise
        return provision()                  # the act resumes over its now-placed session


def installer() -> str | None:
    """Which installer put this interpreter in place, read from its own prefix."""
    prefix = Path(sys.prefix).resolve().as_posix()
    if "/uv/tools/" in prefix + "/":
        return "uv"
    if "/pipx/venvs/" in prefix + "/":
        return "pipx"
    return None


def ensure_path(run=subprocess.run) -> None:
    """Make the command reachable in later shells by the installer's own command, and say so.
    The install line reached this run by the command's exact path; nothing in this run needed
    the shell to find it, and the seats' hooks run the product by its interpreter path."""
    which = installer()
    command = {"uv": ["uv", "tool", "update-shell"], "pipx": ["pipx", "ensurepath"]}.get(which)
    if command is None or shutil.which(command[0]) is None:
        _say(f"command: not changed (this {product.COMMAND} was not installed by uv or pipx)")
        return
    result = run(command, capture_output=True, text=True)
    if result.returncode != 0:
        _say(f"command: `{' '.join(command)}` did not finish ({result.returncode}); "
             f"new terminals may not find `{product.COMMAND}`")
        return
    _say(f"command: `{' '.join(command)}` ran, so new terminals find `{product.COMMAND}`")


def console_link(port: int) -> str:
    """The console's local link with the view credential `up` wrote, in the URL fragment: a
    fragment never reaches a server or its log, the page takes it before any route reads the
    address and replaces the address at once, and the credential is the view-only surface
    credential bound to this Mac's loopback service, the same one the file chooser reads."""
    import store
    path = product_identity.state_root() / "run" / ".ui_token"
    return f"http://127.0.0.1:{port}/app#console_credential={store.read_secret_file(path)}"


def open_console(link: str, run=subprocess.run) -> None:
    run(["open", link], check=False)


def seats(params: dict) -> int:
    import store
    chief = params.get("chief") or CHIEF_DEFAULT
    try:
        operator_token = ensure_operator()
        presented = provisioning_token(chief, operator_token)
        ensure_daemon(presented)
        made = ensure_chief(chief, presented)
        ensure_path()
    except (SetupRefused, store.RegistryMutationRefused, store.BootstrapClosed,
            OSError, ValueError) as exc:
        print(f"{product.COMMAND} setup refused: {exc}", file=sys.stderr)
        return 1
    except committed_outcomes() as exc:
        print(stopped_line(exc), file=sys.stderr)
        return 74                            # as `token claim` and `login` exit on these
    home = made.get("home")
    _say(f"chief of staff: {chief} " + ("made" if made.get("made") else "already set up")
         + (f" at {home}" if home else ""))
    link = console_link(params["port"])
    _say(f"console: {link}" + (" (opened in your browser)" if params.get("open") else ""))
    if params.get("open"):
        open_console(link)
    act = made.get("human_act") or (f"open the folder {home} in the Claude desktop app and "
                                    "accept its trust prompt")
    _say(f"your one act: {act}")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 3 or sys.argv[1] != "seats":
        print(f"{product.COMMAND} setup: internal step called without its parameters", file=sys.stderr)
        raise SystemExit(2)
    raise SystemExit(seats(json.loads(sys.argv[2])))
