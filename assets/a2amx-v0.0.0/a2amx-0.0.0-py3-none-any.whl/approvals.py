"""G0 approval surface — the store-backed data layer (STAGE3 §2 G0.1–G0.4; app-shaped
per V2_MIGRATION_PLAN Phase 2c: this file IS the orch app's approvals data layer).

An ESCALATE at the adapter seam becomes a durable, server-minted APPROVAL ITEM here —
not free text, not only a ledger event. The envelope carries the RAW, unparsed tool-call
payload as the audited artifact (G0.1, reviewer: a summarizer must never be able to launder
a destructive argument out of what the operator approves); the human-readable summary is
a convenience. Items resolve by operator decision (G0.2), auto-DENY at expiry (G0.3,
fail closed — the sweep runs in the delivery daemon), and materially-identical re-asks
after a timeout-deny trip a circuit breaker (G0.4).

POLICY TIER (the operator directive 2026-07-12, msg-d87474469c): class-based auto-approval
rules, adopted as governed constitution config (the operator Z per rule; constitution.validate()
refuses rules that could silently authorize merges/pushes/credentials). An auto-approved
action never wakes the operator but ALWAYS writes a per-action ledger receipt —
"nothing unrecorded, only unprompted". This deliberately replaces vendor-CLI
"don't ask again" prefix allowlists, which are silent, unledgered, and over-broad.

APPROVE mints a SINGLE-USE authorization bound to (seat, session, raw_payload_sha256)
with its own expiry — G1.6-lite: the agent's bound retry redeems it exactly once; a
different payload, seat, or session does not resolve. The full per-adapter durable
APPROVE state machine (pend-through callbacks) is G1.6 and builds on this record.

Storage: store/approvals.json, flock-serialized like the token store (same crash and
corruption posture: a corrupt file fails loud, never reads as empty).
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shlex
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import constitution
import ledger
import store

APPROVALS_FILE = store.STORE_DIR / "approvals.json"
APPROVALS_LOCK = store.STORE_DIR / ".approvals.lock"

#: Statuses an item moves through. Terminal: approved_consumed, denied,
#: timeout_denied, refused_breaker, cancelled, superseded. approved is live
#: until consumed or expired. cancelled = the underlying turn/action was
#: cancelled (operator interrupt or agent withdrawal) — distinct from
#: superseded, where a FRESH item replaced this one (e.g. the fresh-item-after-
#: failed-cancel path, #52 reviewer r3) and links back via superseded_by.
STATUSES = ("pending", "approved", "approved_consumed", "denied",
            "timeout_denied", "authorization_expired", "refused_breaker",
            "cancelled", "superseded")


class StaleDecision(ValueError):
    """Typed rejection for deciding an item that is no longer pending — the UI
    renders {error: 'stale_decision', current_status} verbatim (reviewer Q4)."""
    def __init__(self, item_id: str, current_status: str):
        self.item_id = item_id
        self.current_status = current_status
        super().__init__(f"stale_decision: item {item_id!r} is {current_status!r}, not pending")

    def to_payload(self) -> Dict[str, Any]:
        return {"error": "stale_decision", "item_id": self.item_id,
                "current_status": self.current_status}

#: Shell metacharacters that disqualify a command from ANY prefix rule — a policy
#: auto-approval must never reason about compound/substituted commands.
_SHELL_META = re.compile(r"[;&|`$<>(){}\n\\]")


def _now_ts() -> float:
    return datetime.now(timezone.utc).timestamp()


def _iso_in(sec: float) -> str:
    dt = datetime.now(timezone.utc).astimezone()
    return dt.fromtimestamp(dt.timestamp() + sec, tz=dt.tzinfo).isoformat(timespec="seconds")


def payload_sha256(raw_payload: Any) -> str:
    """EXACT canonical hash of the raw tool-call payload — the authorization
    binding (G1.6-lite). Canonical JSON so dict ordering can't make identical
    payloads look different. Deliberately strict: an authorization redeems only
    the byte-identical action the operator saw."""
    blob = json.dumps(raw_payload, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def semantic_sha256(effect_kind: str, raw_payload: Any) -> str:
    """SEMANTIC hash for breaker/coalescing scope (reviewer #55 MED: the exact
    hash lets whitespace jitter — 'gh  api x', trailing spaces — mint unlimited
    fresh identities and evade the breaker). Commands are shlex-normalized so
    execution-equivalent spellings collide; everything else falls back to the
    canonical form. The effect kind is part of the identity (reviewer #55 HIGH:
    the same payload under a different adapter/effect is a different action)."""
    norm = raw_payload
    if isinstance(raw_payload, dict) and isinstance(raw_payload.get("command"), str):
        try:
            # the normalized form is the TOKEN LIST, never a re-joined string —
            # joining collides quoted-boundary variants (tool 'a b' vs tool a b
            # have different argv but the same join; reviewer #55 re-verdict MED)
            norm = {**raw_payload, "command": shlex.split(raw_payload["command"])}
        except ValueError:
            pass                      # unsplittable: keep the exact form
    blob = json.dumps([effect_kind, norm], sort_keys=True, ensure_ascii=False,
                      separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def _locked(fn):
    import fcntl
    store.ensure_store()
    with APPROVALS_LOCK.open("a") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        try:
            return fn()
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def _read_unlocked() -> Dict[str, Dict[str, Any]]:
    try:
        with APPROVALS_FILE.open("r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            # valid JSON of the wrong shape is as corrupt as a parse error
            # (Bugbot r4 MED: a top-level array would AttributeError every
            # caller instead of failing loud here)
            raise RuntimeError(
                f"approvals file {APPROVALS_FILE} is corrupt (top-level "
                f"{type(data).__name__}, expected object); refusing to read")
        return data
    except FileNotFoundError:
        return {}
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        # Same posture as the token store: a corrupt approvals file must fail LOUD.
        # Reading it as empty would let the next write erase every pending item —
        # including a pending deny the operator believes is blocking an action.
        raise RuntimeError(
            f"approvals file {APPROVALS_FILE} is corrupt ({e}); refusing to read as empty") from e


def _write_unlocked(items: Dict[str, Dict[str, Any]]) -> None:
    store.ensure_store()
    tmp = APPROVALS_FILE.with_suffix(".json.tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(items, f, indent=2, ensure_ascii=False)
        f.flush()
        os.fsync(f.fileno())
    # raw payloads can carry commands/bodies/paths/credentials — owner-only,
    # chmod BEFORE the atomic swap, same posture as tokens.json (reviewer #55 HIGH)
    os.chmod(tmp, 0o600)
    os.replace(tmp, APPROVALS_FILE)


def _knobs() -> Dict[str, Any]:
    # a null/garbled approvals SECTION reads as empty config, never a crash
    # (Bugbot r7 MED: .get(key, {}) returns None when the key exists as null)
    k = constitution.load().get("approvals")
    return k if isinstance(k, dict) else {}


def _ttl_sec() -> float:
    try:
        ttl = float(_knobs().get("ttl_sec", 1800))
    except (TypeError, ValueError):
        return 1800.0
    return ttl if 60 <= ttl <= 24 * 3600 else 1800.0   # governed range, fail to default


def _breaker_threshold() -> int:
    try:
        n = int(_knobs().get("breaker_threshold", 3))
    except (TypeError, ValueError):
        return 3
    return n if 1 <= n <= 20 else 3


# --- policy tier -------------------------------------------------------------

#: The ONLY characters an auto-approvable gh-api endpoint may contain: plain
#: path segments. No %, ?, #, = — percent-encoding, query strings, and fragments
#: are unreasoned-about surface and therefore refused (closed grammar).
_ENDPOINT_SAFE = re.compile(r"^[A-Za-z0-9_\-./]+$")


def _matches_gh_api_get(rule: Dict[str, Any], raw_payload: Any) -> bool:
    """CLOSED argv grammar for the gh_api_get rule type (reviewer #55 CRITICAL:
    a token-exact denylist let attached spellings through — ``--method=PUT``,
    ``-XDELETE``, ``-Fk=v`` — and one of those auto-approved a MERGE endpoint).

    A denylist cannot be safe against a flag surface we don't control, so this
    is an ALLOWLIST parser: the accepted shape is exactly
        gh api <endpoint> [method-flag GET in any spelling]
    - EVERY other option — known, unknown, attached, split — is refused;
    - the method flag is accepted only as -X GET / -XGET / --method GET /
      --method=GET (case-insensitive value);
    - exactly ONE endpoint token, matching a plain-path charset (no percent-
      encoding, query, fragment, or '='), no '..' segment, and it must start
      with an allowlisted path prefix.
    """
    cmd = (raw_payload or {}).get("command") if isinstance(raw_payload, dict) else None
    if not isinstance(cmd, str) or not cmd.strip():
        return False
    if _SHELL_META.search(cmd):
        return False
    try:
        toks = shlex.split(cmd)
    except ValueError:
        return False
    if len(toks) < 3 or toks[0] != "gh" or toks[1] != "api":
        return False
    endpoint = None
    i = 2
    while i < len(toks):
        t = toks[i]
        if t.startswith("-"):
            if t in ("-X", "--method"):
                if i + 1 >= len(toks) or toks[i + 1].upper() != "GET":
                    return False
                i += 2
                continue
            if t.upper() == "-XGET" or t.lower() == "--method=get":
                i += 1
                continue
            return False        # closed grammar: every other option refused
        if endpoint is not None:
            return False        # exactly one endpoint token
        endpoint = t
        i += 1
    if endpoint is None or not _ENDPOINT_SAFE.match(endpoint):
        return False
    if ".." in endpoint:
        return False
    # SEGMENT-BOUNDARY prefix match (Bugbot r7 MED: plain startswith lets
    # repos/psqr-ai-evil/... match a repos/psqr-ai prefix): the endpoint must
    # BE the prefix or continue it at a '/' boundary.
    # `or []` (not a .get default): an explicit "path_prefixes": null makes
    # .get return None, and iterating None crashes the matcher — so a single
    # malformed rule would throw instead of escalating and would block every
    # rule after it (Bugbot MED). Coerce null/missing/empty alike to no match,
    # the same fail-closed idiom the policy_rules list uses above.
    for p in (rule.get("path_prefixes") or []):
        if not isinstance(p, str) or not p:
            continue
        base = p.rstrip("/")
        if endpoint == base or endpoint.startswith(base + "/"):
            return True
    return False


def _policy_match(effect_kind: str, raw_payload: Any) -> Optional[Dict[str, Any]]:
    """PRIVATE rule matcher (reviewer #55 MED: only the atomic evaluate-and-record
    call may return an allow — a public matcher invites the unreceipted gap
    back). Enforces the same closed type/kind matrix as constitution.validate(),
    so even a mis-adopted rule that dodged validation cannot widen here."""
    rules = _knobs().get("policy_rules") or []      # null in config = tier disabled,
    if not isinstance(rules, list):                 # never a crash (Bugbot #55 MED)
        rules = []
    for rule in rules:
        if not isinstance(rule, dict):
            continue
        rtype = rule.get("type")
        allowed = constitution.POLICY_RULE_TYPE_MATRIX.get(rtype)
        if allowed is None:
            continue                                # unknown type never matches
        kinds = rule.get("effect_kinds")
        if not isinstance(kinds, list) or effect_kind not in kinds \
                or effect_kind not in allowed:
            continue                                # matrix enforced at runtime too
        if rtype == "effect_kind":
            return rule
        if rtype == "gh_api_get" and _matches_gh_api_get(rule, raw_payload):
            return rule
    return None


def _record_policy_approval(seat: str, session_id: str, effect_kind: str,
                            raw_payload: Any, rule: Dict[str, Any]) -> None:
    """The audit half of the policy tier. The receipt carries the HASH and a
    short command reference, never the full raw payload — approvals.json holds
    the verbatim artifact at 0600, but the general ledger is a broader surface
    (reviewer #55 HIGH: don't copy possibly-secret-bearing payloads into it)."""
    ref = None
    if isinstance(raw_payload, dict) and isinstance(raw_payload.get("command"), str):
        ref = raw_payload["command"][:120]
    ledger.emit("policy_auto_approval", actor_id=seat, payload={
        "session_id": session_id, "effect_kind": effect_kind,
        "rule_id": rule.get("id", "?"),
        "raw_payload_sha256": payload_sha256(raw_payload),
        "command_ref": ref,
    })


def policy_evaluate_and_record(*, seat: str, session_id: str, effect_kind: str,
                               raw_payload: Any) -> Optional[Dict[str, Any]]:
    """THE adapter callsite for the policy tier (reviewer #55: the match and the
    receipt must be one atomic evaluate-and-record — separate calls left a
    window where a crash between them executes an action with no ledger trace).

    The receipt is written BEFORE the allow is returned, and an unreceiptable
    action is NOT auto-approved: if the ledger write fails for any reason the
    call returns None and the action falls through to a normal escalation.
    "Nothing unrecorded, only unprompted" is structural, not best-effort —
    note this is the deliberate INVERSE of decision receipts elsewhere in the
    seam (which mirror and never decide): a policy auto-approval IS its receipt.
    """
    rule = _policy_match(effect_kind, raw_payload)
    if rule is None:
        return None
    try:
        _record_policy_approval(seat, session_id, effect_kind, raw_payload, rule)
    except Exception:
        return None   # unreceiptable ⇒ unapproved — escalate instead
    # a SNAPSHOT, never the cached constitution object (Bugbot r5 MED: an
    # in-place mutation of the returned rule — e.g. appending a path prefix —
    # would silently widen policy for the whole process without a governed
    # adoption)
    return json.loads(json.dumps(rule))


# --- items -------------------------------------------------------------------

#: The terminal expiry status for a live status. A pending item that ran out is
#: an unanswered TIMEOUT (feeds the breaker, needs a receipt); an approved-but-
#: unconsumed authorization is AUTHORIZATION_EXPIRED (the operator answered — it
#: never feeds the breaker). Shared by the settle-on-write helper AND the
#: compute-on-read view so the two can never disagree.
_EXPIRY_TERMINAL = {"pending": "timeout_denied", "approved": "authorization_expired"}
_EXPIRY_FIELD = {"pending": "expires_at", "approved": "authorization_expires_at"}


def _is_expired(row: Dict[str, Any], now: float) -> bool:
    """True if a live (pending/approved) row is past its expiry. Unparseable or
    missing expiry ⇒ expired (fail closed). A non-live status is never expired."""
    field = _EXPIRY_FIELD.get(row.get("status"))
    if field is None:
        return False
    try:
        return now > datetime.fromisoformat(row[field]).timestamp()
    except (KeyError, ValueError, TypeError):
        return True


def _effective_status(row: Dict[str, Any], now: float) -> str:
    """The status a row EFFECTIVELY has right now — its terminal expiry status if
    a live row has run out, else its stored status. The one source of truth for
    every consumer that must not be fooled by an unswept row: the breaker count,
    the read view, and any filter. (Bugbot r15 HIGH: the breaker counted only
    PERSISTED timeout_denied, so a re-ask loop of expired-but-unswept pendings
    slid under the threshold.)"""
    st = row.get("status")
    if st in _EXPIRY_TERMINAL and _is_expired(row, now):
        return _EXPIRY_TERMINAL[st]
    return st


def _settle_expired(row: Dict[str, Any], now: float, *, notify: bool,
                    superseded_by: Optional[str] = None,
                    note: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """THE single chokepoint (Operator's structural directive): every mutating site
    that meets an expired live row calls this — create-coalesce, supersede,
    consume, decide, the daemon sweep — so no code path can leave a zombie
    pending/approved row by construction. Mutates `row` in place to its terminal
    expiry status and returns a COPY for the caller's receipt list; returns None
    if the row is not a live-expired row. Must be called under the tokens lock
    (it mutates); the receipt is emitted by the caller AFTER the lock."""
    if not _is_expired(row, now):
        return None
    row["status"] = _EXPIRY_TERMINAL[row.get("status")]
    row["decided_at"] = store.now_iso()
    row["notify_pending"] = notify
    if superseded_by is not None:
        row["superseded_by"] = superseded_by
    if note is not None:
        row["note"] = note
    return dict(row)


def _emit_settlement_receipts(settled: List[Dict[str, Any]]) -> None:
    """The audit half of _settle_expired — one approval_timeout_denied receipt
    per settled row, emitted after the lock (receipts mirror, never decide)."""
    for st in settled:
        try:
            ledger.emit("approval_timeout_denied", actor_id=st.get("seat", "?"), payload={
                "item_id": st["item_id"], "session_id": st.get("session_id"),
                "status": st["status"], "superseded_by": st.get("superseded_by"),
                "raw_payload_sha256": st.get("raw_payload_sha256")})
        except Exception:
            pass


def create_item(*, seat: str, session_id: str, effect_kind: str, raw_payload: Any,
                summary: str, policy_reason: str,
                vendor_tool_id: Optional[str] = None,
                correlation_key: Optional[str] = None,
                generation: Optional[int] = None,
                supersedes: Optional[str] = None) -> Dict[str, Any]:
    """Mint a pending approval item (server-minted envelope, G0.1) — or trip the
    G0.4 circuit breaker if this session keeps re-asking a materially-identical
    action after a timeout-deny. Returns the item (status pending or
    refused_breaker); the caller routes the operator notification."""
    sha = payload_sha256(raw_payload)
    sem = semantic_sha256(effect_kind, raw_payload)
    item_id = store.new_id("apv")
    stale_settled: List[Dict[str, Any]] = []

    def _create():
        items = _read_unlocked()
        # COALESCE duplicate asks: one pending item per (seat, session, effect
        # kind, EXACT payload hash). Exact — not semantic — because the item's
        # stored raw_payload is what the operator approves AND what redemption
        # binds to; coalescing a jittered spelling onto a different stored
        # payload would strand its authorization (Bugbot r4 HIGH). Jittered
        # near-duplicates mint separate items (each honestly approvable), while
        # the SEMANTIC hash still unifies them for breaker counting. An
        # expired-but-unswept pending row never coalesces (Bugbot r4 HIGH: the
        # seat would stall on a StaleDecision until the sweep) — the fresh item
        # replaces it and the sweep settles the old one.
        _bnow = _now_ts()
        # G0.4 breaker is evaluated FIRST — BEFORE any coalesce-return (Bugbot
        # r16 HIGH: a duplicate coalescing onto a live pending returned early and
        # skipped the breaker, so a runaway seat with a live pending was never
        # force-paused). It counts UNANSWERED timeouts only, by EFFECTIVE status
        # and SEMANTIC identity: operator denials are human answers (r2),
        # authorization-expired items were approved (r3), whitespace jitter can't
        # mint fresh identities (reviewer), and an expired-but-unswept pending
        # already counts (r15). A tripped breaker force-pauses regardless of any
        # live pending — the seat gets refused_breaker, and the existing pending
        # is left for the operator.
        prior_timeouts = [it for it in items.values()
                          if it.get("seat") == seat
                          and it.get("session_id") == session_id
                          and it.get("effect_kind") == effect_kind
                          and it.get("semantic_sha256") == sem
                          and _effective_status(it, _bnow) == "timeout_denied"]
        session_timeouts = [it for it in items.values()
                            if it.get("session_id") == session_id
                            and _effective_status(it, _bnow) == "timeout_denied"]
        tripped = len(prior_timeouts) >= _breaker_threshold() \
            or len(session_timeouts) >= _breaker_threshold() * 3

        if not tripped:
            # COALESCE onto a live duplicate (one pending per exact binding) —
            # only when the breaker is clear.
            for it in items.values():
                if (it.get("status") == "pending"
                        and it.get("seat") == seat
                        and it.get("session_id") == session_id
                        and it.get("effect_kind") == effect_kind
                        and it.get("raw_payload_sha256") == sha):
                    if not _is_expired(it, _bnow):
                        # refresh the FULL metadata tuple to the latest ask as ONE
                        # coherent unit (reviewer r11): presentation (summary,
                        # policy_reason) AND identity (vendor_tool_id,
                        # correlation_key) all move to the latest values — a retry
                        # with no vendor id CLEARS the stale identity rather than
                        # keeping the first ask's call id. raw_payload is NOT
                        # refreshed (the authorization binding, identical by hash).
                        it["summary"] = summary
                        it["policy_reason"] = policy_reason
                        it["vendor_tool_id"] = vendor_tool_id
                        it["correlation_key"] = (
                            correlation_key if correlation_key is not None
                            else (f"{session_id}\x1f{vendor_tool_id}"
                                  if vendor_tool_id is not None else None))
                        _write_unlocked(items)
                        return it
                    # expired stale row: settle via the shared chokepoint. notify
                    # False — a "DENIED on timeout" message about the old row while
                    # its replacement is live would mislead the seat (Bugbot r5).
                    st = _settle_expired(it, _bnow, notify=False, superseded_by=item_id,
                                         note="expired unswept; superseded by fresh re-ask")
                    if st:
                        stale_settled.append(st)
        item = {
            "item_id": item_id, "seat": seat, "session_id": session_id,
            "effect_kind": effect_kind,
            "raw_payload": raw_payload,             # the audited artifact — verbatim
            "raw_payload_sha256": sha,
            "semantic_sha256": sem,
            "summary": summary, "policy_reason": policy_reason,
            "created": store.now_iso(), "expires_at": _iso_in(_ttl_sec()),
            "status": "refused_breaker" if tripped else "pending",
            "decided_by": None, "decided_at": None,
            "vendor_tool_id": vendor_tool_id,
            # derive correlation_key on FIRST mint too, exactly as the coalesce
            # path does (Bugbot r18 MED: a first escalation shipped a null
            # correlation_key while later retries were namespaced — asymmetric).
            "correlation_key": (correlation_key if correlation_key is not None
                                else (f"{session_id}\x1f{vendor_tool_id}"
                                      if vendor_tool_id is not None else None)),
            # nullable until G1.1 makes runtime generation real (reviewer Q5 —
            # first-class from day one so the UI never needs a schema migration)
            "generation": generation,
        }
        # fresh-item-after-failed-cancel (#52 reviewer r3, reviewer Q4): the new
        # item supersedes the old one, and the old one links forward. But an
        # EXPIRED pending target is a timeout first (Bugbot r12 MED: marking it
        # plain 'superseded' skipped its timeout_denied settlement, so it fell
        # out of the breaker count and lost its audit receipt) — settle it as a
        # timeout that also carries the superseded_by link, same settle-on-read
        # rule every other expiry path uses.
        if supersedes and supersedes in items:
            target = items[supersedes]
            # supersedes is the fresh-item-after-failed-cancel path (reviewer Q4):
            # a seat re-asks and supersedes its OWN prior item. The target MUST
            # belong to the same seat + session — otherwise a caller passing an
            # arbitrary id could terminate ANOTHER seat's pending approval (mark
            # it superseded/timeout_denied) while minting its own (Bugbot MED,
            # cross-seat interference). Fail closed: refuse the mismatched
            # supersede rather than touch a foreign row. The coalesce loop above
            # is already seat/session-scoped, so any row it linked passes here.
            if target.get("seat") != seat or target.get("session_id") != session_id:
                raise PermissionError(
                    f"supersedes {supersedes!r} belongs to a different "
                    f"seat/session; a seat may only supersede its own approval")
            if target.get("superseded_by") == item_id:
                # the coalesce loop above already settled this same-payload
                # expired row and linked it forward to us (Bugbot r19 MED: the
                # supersedes block's pending-only guard then skipped, so the old
                # row kept superseded_by while the new item silently lost its
                # supersedes backlink — an asymmetric link). Record the backlink
                # so both halves agree; the settlement receipt already queued.
                item["supersedes"] = supersedes
            elif target.get("status") == "pending":
                # an EXPIRED target is a timeout first (via the shared chokepoint
                # — it must feed the breaker + get a receipt); a LIVE target is a
                # plain superseded. Either way it links forward.
                st = _settle_expired(target, _now_ts(), notify=False, superseded_by=item_id,
                                     note="expired before supersede; timed out")
                if st:
                    stale_settled.append(st)
                else:
                    target["status"] = "superseded"
                    target["superseded_by"] = item_id
                    target["decided_at"] = store.now_iso()
                item["supersedes"] = supersedes
        items[item_id] = item
        _write_unlocked(items)
        return item

    item = _locked(_create)
    _emit_settlement_receipts(stale_settled)   # shared audit half of _settle_expired
    if item["item_id"] != item_id:
        return item          # coalesced onto an existing pending item — no new receipts
    try:
        if item["status"] == "refused_breaker":
            ledger.emit("circuit_breaker", actor_id=seat, payload={
                "session_id": session_id, "raw_payload_sha256": sha,
                "item_id": item_id, "threshold": _breaker_threshold(),
                "action": "seat force-pause requested; operator notified"})
        else:
            ledger.emit("approval_item_created", actor_id=seat, payload={
                "item_id": item_id, "session_id": session_id,
                "effect_kind": effect_kind, "raw_payload_sha256": sha,
                "expires_at": item["expires_at"]})
    except Exception:
        pass  # receipts mirror, never decide
    return item


def _effective_view(item: Dict[str, Any]) -> Dict[str, Any]:
    """A read-time COPY whose status reflects expiry, without mutating the store
    (Bugbot r13 MED: reads must not advertise a stale live status). A GET that
    wrote — taking the lock and emitting receipts on every poll — is the wrong
    fix; instead reads present the EFFECTIVE status (expired pending →
    timeout_denied, expired approved → authorization_expired), while the DURABLE
    settlement + receipt + breaker stay with the mutating paths and the daemon
    sweep (guaranteed within one sweep interval). The view carries
    `settlement_pending: True` so a caller can tell a computed-expiry row from a
    persisted one."""
    st = item.get("status")
    if st not in _EXPIRY_TERMINAL or not _is_expired(item, _now_ts()):
        return item
    view = dict(item)
    view["status"] = _EXPIRY_TERMINAL[st]       # same map the write path uses
    view["settlement_pending"] = True           # store row still {pending|approved}
    return view


def list_items(status: Optional[str] = None) -> List[Dict[str, Any]]:
    items = _locked(_read_unlocked)
    # filter by EFFECTIVE status so an expired-but-unswept row never appears in
    # the 'pending'/'approved' listing a status-poller relies on
    out = (_effective_view(it) for it in
           sorted(items.values(), key=lambda it: it.get("created", "")))
    return [it for it in out if status is None or it.get("status") == status]


def get_item(item_id: str) -> Optional[Dict[str, Any]]:
    item = _locked(_read_unlocked).get(item_id)
    return _effective_view(item) if item is not None else None


def decide(item_id: str, decision: str, *, decided_by: str, auth_source: str) -> Dict[str, Any]:
    """Operator decision on a pending item. APPROVE turns the item into a live
    SINGLE-USE authorization bound to (seat, session, raw_payload_sha256) with a
    fresh expiry (G1.6-lite); DENY is terminal. Only an operator/UI-authenticated
    caller may decide. This non-mint approval surface retains its existing caller contract."""
    if decision not in ("approve", "deny"):
        raise ValueError(f"decision must be approve|deny, got {decision!r}")
    if auth_source not in {"operator_token", "ui_token"}:
        raise PermissionError(
            f"deciding an approval requires an operator/UI terminal, not {auth_source!r}")

    settled_here: List[Dict[str, Any]] = []

    def _decide():
        items = _read_unlocked()
        item = items.get(item_id)
        if item is None:
            raise KeyError(f"approval item {item_id!r} not found")
        if item.get("status") != "pending":
            # report the EFFECTIVE status so a caller deciding an expired-but-
            # unswept 'approved' row sees 'authorization_expired' — the same
            # value get_item/list_items present via _effective_view (Bugbot r19
            # MED: raising raw 'approved' here contradicted the read APIs). No
            # mutation on this rejected path; the daemon sweep is the durable
            # settler, exactly as the read side computes-on-read without writing.
            raise StaleDecision(item_id, _effective_status(item, _now_ts()))
        # deciding an expired item SETTLES it via the shared chokepoint (Bugbot
        # r10 MED: leaving it 'pending' let status-pollers treat timed-out work
        # as still awaiting a human) and the operator sees the typed rejection
        # (reviewer Q4). Fails closed on unparseable expiry.
        st = _settle_expired(item, _now_ts(), notify=True)
        if st is not None:
            settled_here.append(st)
            _write_unlocked(items)
            raise StaleDecision(item_id, "timeout_denied")
        item["status"] = "approved" if decision == "approve" else "denied"
        item["decided_by"] = decided_by
        item["decided_at"] = store.now_iso()
        if decision == "approve":
            item["authorization_expires_at"] = _iso_in(_ttl_sec())
            # AT MOST ONE live authorization per (seat, session, payload hash) —
            # an approve SUPERSEDES any other unconsumed approval with the same
            # binding, so one human intent can never be redeemed twice via
            # duplicate items (Bugbot #55 HIGH; approval-token remint pattern).
            _dnow = _now_ts()
            for other in items.values():
                if (other is not item and other.get("status") == "approved"
                        and other.get("seat") == item.get("seat")
                        and other.get("session_id") == item.get("session_id")
                        and other.get("effect_kind") == item.get("effect_kind")
                        and other.get("raw_payload_sha256") == item.get("raw_payload_sha256")):
                    # an EXPIRED other authorization settles through the shared
                    # chokepoint (Bugbot r17 MED: I wrongly called this path
                    # benign at r13 — an expired approval superseded silently lost
                    # its authorization_expired receipt + notification). A LIVE
                    # other is a plain supersede. The last expiry-blind write is
                    # now closed; the class is genuinely exhausted.
                    st = _settle_expired(other, _dnow, notify=True,
                                         superseded_by=item["item_id"])
                    if st is not None:
                        settled_here.append(st)
                    else:
                        other["status"] = "superseded"
                        other["superseded_by"] = item["item_id"]
                        other["decided_at"] = store.now_iso()
        _write_unlocked(items)
        return item

    try:
        item = _locked(_decide)
    except StaleDecision:
        _emit_settlement_receipts(settled_here)   # timeout receipt before the raise
        raise
    _emit_settlement_receipts(settled_here)  # an approve may settle an expired other
    try:
        # the human_approval ledger enum is Allow/Deny (ledger.emit_human_approval
        # contract), NOT approve/deny — the approval-items path must speak the
        # SAME vocabulary as the zgate merge path or replay/inbox consumers
        # mishandle it (Bugbot r18 MED).
        ledger.emit("human_approval", actor_id=decided_by, payload={
            "item_id": item_id,
            "decision": "Allow" if decision == "approve" else "Deny",
            "auth_source": auth_source,
            "seat": item["seat"], "session_id": item["session_id"],
            "raw_payload_sha256": item["raw_payload_sha256"]})
    except Exception:
        pass
    return item


def consume_authorization(*, seat: str, session_id: str, effect_kind: str,
                          raw_payload: Any) -> bool:
    """Single-use redeem of an approved item for a MATERIALLY-IDENTICAL retry.
    Takes the RAW PAYLOAD THAT WILL EXECUTE — the digest is computed INSIDE the
    data layer, never accepted from the caller (reviewer #55 HIGH: a caller-
    asserted hash lets an adapter redeem an approval for a payload other than
    the one it is about to run). Binding = seat + session + effect kind + exact
    payload hash; anything else — or an expired/consumed authorization — does
    not resolve (fail closed). True exactly once per approval."""
    raw_payload_sha256 = payload_sha256(raw_payload)

    expired_here: List[Dict[str, Any]] = []

    def _consume():
        items = _read_unlocked()
        dirty = False
        matched = None
        for item in items.values():
            if (item.get("status") == "approved"
                    and item.get("seat") == seat
                    and item.get("session_id") == session_id
                    and item.get("effect_kind") == effect_kind
                    and item.get("raw_payload_sha256") == raw_payload_sha256):
                # SETTLE an expired authorization via the shared chokepoint
                # instead of leaving it 'approved' until the daemon sweep (Bugbot
                # r9 MED), then keep scanning — a later VALID approval may resolve.
                st = _settle_expired(item, _now_ts(), notify=True)
                if st is not None:
                    expired_here.append(st)
                    dirty = True
                    continue
                item["status"] = "approved_consumed"
                item["consumed_at"] = store.now_iso()
                matched = item
                dirty = True
                break
        if dirty:
            _write_unlocked(items)
        return matched

    item = _locked(_consume)
    _emit_settlement_receipts(expired_here)   # shared audit half
    if item:
        try:
            ledger.emit("approval_consumed", actor_id=seat, payload={
                "item_id": item["item_id"], "session_id": session_id,
                "raw_payload_sha256": raw_payload_sha256})
        except Exception:
            pass
        return True
    return False


def sweep_expired() -> List[Dict[str, Any]]:
    """G0.3 fail-closed timeout: settle every pending item past its expiry as
    timeout_denied, and expire stale unconsumed authorizations as
    authorization_expired (a DISTINCT terminal state — the operator DID answer;
    Bugbot r3 HIGH: these must not feed the breaker or read as unanswered).
    Settled items carry notify_pending=True until the daemon DURABLY delivers
    the seat notification (reviewer #55 HIGH: a one-shot notify that fails is a
    permanently stranded agent — see unnotified_settlements/mark_notified).
    Idempotent."""
    now = _now_ts()

    def _sweep():
        items = _read_unlocked()
        # the daemon backstop routes through the SAME chokepoint as every inline
        # path — it can never settle a row differently than create/decide/consume
        settled = [st for st in (_settle_expired(it, now, notify=True)
                                 for it in list(items.values())) if st is not None]
        if settled:
            _write_unlocked(items)
        return settled

    settled = _locked(_sweep)
    _emit_settlement_receipts(settled)
    return settled


def unnotified_settlements() -> List[Dict[str, Any]]:
    """Settled items whose seat notification has not durably succeeded yet.
    The daemon retries these every sweep until mark_notified — a duplicate
    notification after a crash is preferable to a stranded agent."""
    return [it for it in _locked(_read_unlocked).values() if it.get("notify_pending")]


def mark_notified(item_id: str) -> None:
    def _mark():
        items = _read_unlocked()
        if item_id in items and items[item_id].get("notify_pending"):
            items[item_id]["notify_pending"] = False
            items[item_id]["timeout_notified_at"] = store.now_iso()
            _write_unlocked(items)
    _locked(_mark)
