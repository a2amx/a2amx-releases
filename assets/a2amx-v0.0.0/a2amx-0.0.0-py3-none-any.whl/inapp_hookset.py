"""Opt-in Claude hook-set qualification; hashes never prove native invocation.

Provisioning uses the existing current-role registry gate. All public callers
hold token/registry locks before the nudge lock. Records and routes live in the
same atomic registry; their receipts are separate durable acts. An unreceipted
record or stale qualification cannot dispatch. No new store root is introduced.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import uuid

import receipts
import store
import claude_hook_interface as interface

FIELD = 'inapp_hookset'
SCHEMA = 'orch.claude-hookset.v1'
SCHEMA_V2 = 'orch.claude-hookset.v2'
QUALIFICATION_FIELDS = {'digest', 'generation', 'source'}
INTERFACE_QUALIFICATION_FIELDS = QUALIFICATION_FIELDS | {'interface_version', 'interface_digest'}
PRODUCTION_HOOKS = frozenset({'wake_hook_claude.py', 'wake_hook_client.py', 'wake_hook_core.py'})
MAX_FILE_BYTES = 4 * 1024 * 1024
MAX_SPEC_BYTES = 65536


class Refused(ValueError):
    pass


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     ensure_ascii=True, allow_nan=False).encode()).hexdigest()


def is_digest(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def read_file(path, limit=MAX_FILE_BYTES):
    p = Path(path)
    if not p.is_absolute() or str(p) != path or p.resolve() != p:
        raise Refused('hookset_noncanonical_path')
    fd = os.open(p, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as f:
        info = os.fstat(f.fileno())
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                or info.st_mode & 0o022 or info.st_size > limit):
            raise Refused('hookset_file_type_owner_or_bound')
        data = f.read(limit + 1)
        if len(data) > limit:
            raise Refused('hookset_file_bound')
        return data


def _home(seat, row):
    if row.get('kind') != 'agent' or store.normalize_family(row.get('family')) != 'claude':
        raise Refused('hookset_claude_seat_required')
    return store.seat_home(seat, override=row.get('workspace_dir')).resolve()


import product_identity

_command_name = product_identity.command()
DEFAULT_LOCAL_HOOK_NAMES = (_command_name+'_session_start.py', _command_name+'-runtime-pins.json')
if product_identity.is_public():
    DEFAULT_LOCAL_HOOK_NAMES += (_command_name+'_prompt_hook.py',)


def local_hook_names(row, home):
    """Preserve the named local sources of an existing qualified install.

    No environment-selected compatibility contract. The registry carries the
    installed paths; digest and generation checks remain mandatory.
    """
    record = row.get(FIELD)
    if record is None:
        return DEFAULT_LOCAL_HOOK_NAMES
    if not isinstance(record, dict) or not isinstance(record.get('spec'), dict):
        raise Refused('hookset_record_missing_or_invalid')
    spec = record['spec']
    if spec.get('schema') not in {SCHEMA, SCHEMA_V2}:
        raise Refused('hookset_schema')
    if (record.get('digest') != digest(spec) or record.get('generation') !=
            digest({k: v for k, v in record.items() if k != 'generation'})):
        raise Refused('hookset_record_generation_mismatch')
    names = []
    sources = spec.get('hook_sources')
    if not isinstance(sources, list) or not 2 <= len(sources) <= 16:
        raise Refused('hookset_sources_required')
    for item in sources:
        if (not isinstance(item, dict) or set(item) != {'path', 'sha256'}
                or not isinstance(item['path'], str) or not is_digest(item['sha256'])):
            raise Refused('hookset_source_schema')
        path = Path(item['path'])
        if path.parent == home/'.claude' and path.suffix in {'.py', '.json'}:
            names.append(path.name)
    # A v1 install may predate the local pins file; retain its startup name and
    # require the new pins filename only when none was recorded previously.
    if spec['schema'] == SCHEMA and not any(n.endswith('.json') for n in names):
        names.extend(n for n in DEFAULT_LOCAL_HOOK_NAMES if n.endswith('.json'))
    if (len(names) != len(set(names)) or not any(n.endswith('.py') for n in names)
            or not any(n.endswith('.json') for n in names)):
        raise Refused('hookset_interface_local_pins_incomplete')
    return tuple(names)


def validate_spec(spec, seat, row, *, measure=True, check_policy=True):
    v2 = isinstance(spec, dict) and spec.get('schema') == SCHEMA_V2
    fields = {'schema', 'seat', 'home', 'hook_sources', 'settings', 'installer_receipt'}
    if (not isinstance(spec, dict) or set(spec) != (fields | {'interface'} if v2 else fields)
            or spec.get('schema') not in {SCHEMA, SCHEMA_V2} or spec.get('seat') != seat):
        raise Refused('hookset_schema')
    if len(json.dumps(spec, allow_nan=False).encode()) > MAX_SPEC_BYTES:
        raise Refused('hookset_spec_bound')
    home = _home(seat, row)
    if spec.get('home') != str(home):
        raise Refused('hookset_home_mismatch')
    sources = spec.get('hook_sources')
    if not isinstance(sources, list) or not 2 <= len(sources) <= 16:
        raise Refused('hookset_sources_required')
    production = Path(__file__).resolve().parent
    if v2:
        interface.validate_descriptor(spec['interface'])
        if measure:
            catalog = interface.deployed()
            if spec['interface']['sources'] != catalog['sources']:
                raise interface.Refused('hook_interface_stale_sources')
            if spec['interface']['version'] not in {catalog['version'], catalog['version'] - 1}:
                raise interface.Refused('hook_interface_version_refused')
            if check_policy:
                interface.check(spec['interface'])
    seen = set()
    local = False
    for item in sources:
        if not isinstance(item, dict) or set(item) != {'path', 'sha256'} or not is_digest(item['sha256']):
            raise Refused('hookset_source_schema')
        path = item['path']
        if not isinstance(path, str):
            raise Refused('hookset_source_path')
        p = Path(path)
        local_source = p.parent == home/'.claude' and p.suffix in {'.py', '.json'}
        production_source = p.parent == production and p.name in (interface.CLIENT_SOURCES if v2 else PRODUCTION_HOOKS)
        if path in seen or not (local_source or production_source):
            raise Refused('hookset_source_scope')
        seen.add(path); local |= local_source and p.suffix == '.py'
        if measure and hashlib.sha256(read_file(path)).hexdigest() != item['sha256']:
            raise Refused('hookset_source_changed')
        if v2 and production_source and item['sha256'] != spec['interface']['sources'][p.name]:
            raise Refused('hookset_interface_source_binding')
    if not local or str(production/'wake_hook_claude.py') not in seen:
        raise Refused('hookset_source_incomplete')
    if v2 and not {str(production/name) for name in interface.CLIENT_SOURCES} <= seen:
        raise Refused('hookset_interface_sources_incomplete')
    if v2 and not {str(home/'.claude'/name) for name in
                   local_hook_names(row, home)} <= seen:
        raise Refused('hookset_interface_local_pins_incomplete')
    settings = spec.get('settings')
    if (not isinstance(settings, dict) or set(settings) != {'path', 'sha256', 'entries'}
            or settings['path'] != str(home/'.claude/settings.json')
            or not is_digest(settings['sha256'])
            or not isinstance(settings['entries'], dict)
            or not {'SessionStart', 'UserPromptSubmit'} <= set(settings['entries'])):
        raise Refused('hookset_settings_schema')
    if measure:
        data = read_file(settings['path'], MAX_SPEC_BYTES)
        if hashlib.sha256(data).hexdigest() != settings['sha256']:
            raise Refused('hookset_settings_changed')
        decoded = json.loads(data)
        if not isinstance(decoded, dict) or decoded.get('hooks') != settings['entries']:
            raise Refused('hookset_settings_entries_mismatch')
    receipt = spec.get('installer_receipt')
    if (not isinstance(receipt, dict) or set(receipt) != {'reference', 'sha256'}
            or not isinstance(receipt['reference'], str) or not 1 <= len(receipt['reference']) <= 512
            or any(ord(c) < 32 for c in receipt['reference']) or not is_digest(receipt['sha256'])):
        raise Refused('hookset_installer_receipt_required')


def validate_record(record, seat, row, *, measure=True):
    if (not isinstance(record, dict) or set(record) !=
            {'spec', 'digest', 'generation', 'record_id', 'recorded_at', 'provisioner'}):
        raise Refused('hookset_record_missing_or_invalid')
    validate_spec(record['spec'], seat, row, measure=measure)
    if record['digest'] != digest(record['spec']):
        raise Refused('hookset_digest_mismatch')
    if record['generation'] != digest({k: v for k, v in record.items() if k != 'generation'}):
        raise Refused('hookset_record_generation_mismatch')


def validate_removal_record(record, seat, row):
    """Bind retirement to the recorded seat/home without executing an old runtime.

    Callers also require its original provisioned receipt. This permits cleanup
    after a runtime relocation; it never qualifies a record for dispatch.
    """
    if (not isinstance(record, dict) or set(record) !=
            {'spec','digest','generation','record_id','recorded_at','provisioner'}):
        raise Refused('hookset_record_missing_or_invalid')
    spec = record.get('spec')
    home = _home(seat, row)
    if (not isinstance(spec, dict) or spec.get('schema') not in {SCHEMA, SCHEMA_V2}
            or spec.get('seat') != seat or spec.get('home') != str(home)
            or record['digest'] != digest(spec)
            or record['generation'] != digest({k:v for k,v in record.items() if k!='generation'})):
        raise Refused('hookset_record_generation_mismatch')
    settings = spec.get('settings')
    if (not isinstance(settings, dict) or settings.get('path') != str(home/'.claude/settings.json')
            or not is_digest(settings.get('sha256')) or not isinstance(settings.get('entries'), dict)):
        raise Refused('hookset_settings_schema')
    local_hook_names({**row, FIELD:record}, home)


def retired_record(seat, row, history):
    """Return only the latest completed, previously provisioned retirement."""
    latest = next((r for r in reversed(history) if r.get('kind') == 'inapp-hookset'
                   and r.get('seat') == seat and r.get('event') in {'provisioned', 'removed'}), None)
    if latest is None:
        return None
    if latest.get('event') != 'removed':
        raise Refused('hookset_retirement_unconfirmed')
    record = latest.get('record')
    validate_removal_record(record, seat, row)
    if not any(r.get('kind') == 'inapp-hookset' and r.get('event') == 'provisioned'
               and r.get('seat') == seat and r.get('record') == record for r in history):
        raise Refused('hookset_record_unreceipted')
    return record


def check_registry_change(seat, actor, before, after):
    # Existing privileged whole-identity succession may remove the old record.
    # It may not transfer the identity-bound qualification to its successor.
    if (before.get(seat) is not None and after.get(seat) is None
            and getattr(store._registry_actor_local, 'hookset_retiring', None) == seat):
        store._require_current_provisioner(actor, before)
        return
    if getattr(store._registry_actor_local, 'inapp_hookset_act', None) != seat:
        raise store.RegistryMutationRefused('hookset_provision_command_required', 'use wake-hookset-record')
    store._require_current_provisioner(actor, before)
    old, new = before.get(seat), after.get(seat)
    if (not isinstance(old, dict) or not isinstance(new, dict)
            or not {k for k in old.keys() | new.keys() if old.get(k) != new.get(k)} <= {FIELD, 'last_update'}):
        raise Refused('hookset_provision_scope')
    if new.get(FIELD) is None and getattr(store._registry_actor_local, 'hookset_retiring', None) == seat:
        validate_removal_record(old.get(FIELD), seat, old)
        return
    validate_record(new.get(FIELD), seat, new)


def retire(seat, record, *, presented_token):
    """Retire an exact qualification, keeping the old record as receipt evidence."""
    def apply(actor):
        parts = store._read_participants_unlocked()
        row = parts.get(seat) or {}
        validate_removal_record(record, seat, row)
        current = row.get(FIELD)
        history = receipts.rows()
        if current is not None and current != record:
            raise Refused('hookset_stale_provision_generation')
        if not any(r.get('kind') == 'inapp-hookset' and r.get('event') == 'provisioned'
                   and r.get('seat') == seat and r.get('record') == record for r in history):
            raise Refused('hookset_record_unreceipted')
        existing = next((r for r in reversed(history) if r.get('kind') == 'inapp-hookset'
                         and r.get('event') == 'removed' and r.get('seat') == seat
                         and r.get('record') == record), None)
        if current is None and existing is not None:
            return existing
        prior = getattr(store._registry_actor_local, 'inapp_hookset_act', None)
        retiring = getattr(store._registry_actor_local, 'hookset_retiring', None)
        store._registry_actor_local.inapp_hookset_act = seat
        store._registry_actor_local.hookset_retiring = seat
        try:
            with receipts._nudge_lock():
                if current is not None:
                    updated = {k: dict(v) for k, v in parts.items()}
                    updated[seat].pop(FIELD)
                    updated[seat]['last_update'] = store.now_iso()
                    store._write_participants_unlocked(updated)
                try:
                    return receipts._append({'kind':'inapp-hookset','event':'removed',
                        'seat':seat,'requester':actor,'record':record,'ts':store.now_iso()})
                except Exception as exc:
                    raise store.SeatActWithoutReceipt('wake_hookset_remove',seat,
                        'qualification removed; completion receipt uncertain') from exc
        finally:
            store._registry_actor_local.inapp_hookset_act = prior
            store._registry_actor_local.hookset_retiring = retiring
    return store.authenticated_registry_act(presented_token, apply, provisioning=True)


def provision(seat, spec, *, presented_token, expected_generation):
    if expected_generation != 'none' and not is_digest(expected_generation):
        raise Refused('hookset_expected_generation_required')

    def apply(actor):
        parts = store._read_participants_unlocked()
        row = parts.get(seat) or {}
        previous = row.get(FIELD)
        current = previous.get('generation') if isinstance(previous, dict) else 'none'
        if expected_generation != current:
            raise Refused('hookset_stale_provision_generation')
        retired = retired_record(seat, row, receipts.rows()) if previous is None else None
        names_row = {**row, FIELD: retired} if retired else row
        validate_spec(spec, seat, names_row, check_policy=False)
        record = {'spec': spec, 'digest': digest(spec), 'record_id': 'hookset-'+uuid.uuid4().hex,
                  'recorded_at': store.now_iso(), 'provisioner': actor}
        record['generation'] = digest(record)
        updated = {k: dict(v) for k, v in parts.items()}
        updated[seat].update({FIELD: record, 'last_update': store.now_iso()})
        prior = getattr(store._registry_actor_local, 'inapp_hookset_act', None)
        store._registry_actor_local.inapp_hookset_act = seat
        try:
            with receipts._nudge_lock():
                if spec['schema'] == SCHEMA_V2:
                    interface.ensure_policy(interface.deployed(), actor)
                    validate_spec(spec, seat, names_row)
                store._write_participants_unlocked(updated)
                try:
                    receipt = receipts._append({'kind': 'inapp-hookset', 'event': 'provisioned',
                        'seat': seat, 'requester': actor, 'record': record, 'ts': store.now_iso()})
                except Exception as exc:
                    raise store.SeatActWithoutReceipt('wake_hookset_record', seat,
                        'hook set is unreceipted; qualified dispatch disabled') from exc
        finally:
            store._registry_actor_local.inapp_hookset_act = prior
        return {'record': record, 'receipt': receipt}
    return store.authenticated_registry_act(presented_token, apply, provisioning=True)


def validate_qualification(qualification):
    if (not isinstance(qualification, dict)
            or set(qualification) not in (QUALIFICATION_FIELDS, INTERFACE_QUALIFICATION_FIELDS)
            or not is_digest(qualification.get('digest')) or not is_digest(qualification.get('generation'))
            or qualification.get('source') not in {'startup', 'resume'}):
        raise Refused('hookset_qualification_schema')
    if 'interface_version' in qualification and (
            type(qualification['interface_version']) is not int or qualification['interface_version'] < 1
            or not is_digest(qualification['interface_digest'])):
        raise Refused('hookset_interface_qualification_schema')


def record_qualification(record, source):
    value = {'digest': record.get('digest'), 'generation': record.get('generation'), 'source': source}
    if record.get('spec', {}).get('schema') == SCHEMA_V2:
        value.update(interface_version=record['spec']['interface']['version'],
                     interface_digest=interface.digest(record['spec']['interface']))
    return value


def qualified_record(seat, row, qualification, *, rows=None):
    validate_qualification(qualification)
    record = row.get(FIELD)
    validate_record(record, seat, row)
    if qualification['digest'] != record['digest']:
        raise Refused('hookset_digest_mismatch')
    if qualification['generation'] != record['generation']:
        raise Refused('hookset_stale_record_generation')
    if qualification != record_qualification(record, qualification['source']):
        raise Refused('hookset_qualification_binding')
    rows = receipts.rows() if rows is None else rows
    if not any(r.get('kind') == 'inapp-hookset' and r.get('event') == 'provisioned'
               and r.get('seat') == seat and r.get('requester') == record['provisioner']
               and r.get('record') == record for r in rows):
        raise Refused('hookset_unreceipted_record')
    return record


def inspect_own(seat, *, presented_token):
    def apply(actor):
        row = store._read_participants_unlocked().get(seat) or {}
        _home(seat, row)
        record = row.get(FIELD)
        if record is None:
            return {'record': None, 'previous_generation': _route_generation(row)}
        with receipts._nudge_lock():
            qualified_record(seat, row, record_qualification(record, 'startup'))
            result = {'record': record, 'previous_generation': _route_generation(row)}
            if record['spec']['schema'] == SCHEMA_V2:
                result['interface'] = interface.check(record['spec']['interface'])
        return result
    return store.authenticated_registry_act(presented_token, apply, expected_actor=seat)


def _route_generation(row):
    route = row.get('wake_route')
    return digest(route) if route is not None else 'none'


def check_declaration(seat, row, qualification, home, previous_generation):
    if home != str(_home(seat, row)):
        raise Refused('hookset_declaration_home_mismatch')
    if previous_generation != _route_generation(row):
        raise Refused('hookset_stale_route_generation')
    qualified_record(seat, row, qualification)
