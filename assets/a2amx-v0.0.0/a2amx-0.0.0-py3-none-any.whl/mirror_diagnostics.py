"""Bounded operator diagnostics for best-effort audit mirror failures.

No payload, message/task identifier, credential or exception text is logged. Counts are
process-local diagnostics, not durable proof that a mirror did or did not land.
"""
from datetime import datetime, timezone
import os
import sys
import threading
import time

INTERVAL_SECONDS = 60.0
SOURCES = frozenset({'referee', 'norms', 'convergence'})
_lock = threading.Lock()
_counts = {}
_last = {}
_reported = {}


def record_failure(source, error):
    """Count every failure; emit at most once/minute/source without escaping."""
    try:
        if source not in SOURCES:
            return
        with _lock:
            count = _counts[source] = _counts.get(source, 0) + 1
            now = time.monotonic()
            if source in _last and now - _last[source] < INTERVAL_SECONDS:
                return
            suppressed = count - _reported.get(source, 0) - 1
            _last[source], _reported[source] = now, count
        timestamp = datetime.now(timezone.utc).isoformat()
        # The exception class is useful; its text may contain private work.
        print(f'{timestamp} audit_mirror_failure source={source} pid={os.getpid()} '
              f'process_total={count} suppressed_since_last={suppressed} '
              f'error_type={type(error).__name__}', file=sys.stderr, flush=True)
    except Exception:
        # Reporting must not turn an already-handled mirror failure into a
        # failure of the canonical message, quarantine or review transition.
        pass
