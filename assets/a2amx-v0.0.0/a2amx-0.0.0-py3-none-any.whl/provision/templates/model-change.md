# Model change — $seat

STOP on a harness model change or a safety refusal: one store message to the
operator naming the event, then await direction in that session; the
restart is the operator's decision. Present the token per command with `--token-file`;
never export, print or move it. A generated home does not attest a runtime model.
