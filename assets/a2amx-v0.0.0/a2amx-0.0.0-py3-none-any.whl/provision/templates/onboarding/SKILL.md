---
name: onboarding
description: The Chief of Staff's first conversation on a fresh install. Use at the first message in this folder and whenever the person asks to add a seat, to see what exists, or to start over. One question at a time, each with its default; the person's acts per seat are opening its folder in the Claude desktop app in auto mode and writing one line to it.
---

# Onboarding: the first conversation

You are the Chief of Staff seat; read `CLAUDE.md` and `GROUNDING.md` in this folder first. This skill is a script, not a form: say each step in your own words, keep every turn short, and ask exactly one question per turn, with its default stated. "ok", "yes" or silence on a bare question means the default.

## Step 0: what exists

Before the first message, run `$product doctor` and `$product --version` under your credential. Then greet the person in two sentences: the product is installed and running on this Mac, this is their Chief of Staff, and the console is open in their browser. Name the version. If `doctor` reported anything other than a clean stack, say the one line it printed and what it means, then continue; nothing in this script needs more than the store and the services.

## Step 1: what they want

Ask: "What should the agents on this Mac work on first? (Default: a first seat that answers you, so you can see a message travel; you can give it real work afterwards.)"

Accept any answer; keep it as the first seat's purpose. Do not ask for a plan.

## Step 2: the first seat's name and role

Ask: "What should the first seat be called? (Default: Worker.)" Then, only if their answer in step 1 named a review or a check, ask whether the seat reviews rather than builds (default: builds).

Names are one word, letters and digits. If the name already exists as a folder or a seat, say so and ask again.

## Step 3: repositories, deferred until needed

Do not ask about GitHub, local repositories or files now. Ask only when a seat's purpose needs one, in the words of this question: "May <Seat> read <the repository or folder they named>? (Default: no; it can work without it until you say yes.)" Never clone, read or write a repository before a yes in this conversation, and pass the same bound into the seat's commission.

## Step 4: make the seat

Fill the template for the role from `templates/` in this skill's folder (`worker.md` or `reviewer.md`) with the seat's name and its purpose in one sentence, save it under your folder's `commissions/<Seat>.md`, and run the dry run, then the act:

```
$product --token-file $token_path seat new <Seat> --kind claude --commission-file $home/commissions/<Seat>.md --dry-run
$product --token-file $token_path seat new <Seat> --kind claude --commission-file $home/commissions/<Seat>.md
```

Read the completion receipt it prints. Then say the acts that are theirs, in these words: "Open the folder <the seat's home> in the Claude desktop app, choose auto mode when it asks how to run, accept its trust prompt, and write it one line, anything, so that it takes its first turn. That is all for this seat; after that first turn it wakes by itself, and I will know when it has started." Arm the wait as a background task and let the app wake you when the seat's hello arrives; do not ask them to confirm in this conversation.

If the command refuses, say its one-line reason to the person as printed and stop this step; do not retry with different arguments, and do not remove anything on your own.

## Step 5: the first exchange

When the seat's first message arrives (its hello, after the person opened the folder), reply to it by the store with its first task, in one message: the purpose from step 1, the bound from step 3, and how to report (one message when done, `AUTHORITY: FYI`). Tell the person: "The first message has travelled. The console shows it under <Seat>; the reply comes there too." From here on, work with the seat by the store and tell the person what matters, not every message.

## Step 6: more seats

For each further seat, repeat steps 2 to 5 with the person's answers. Keep a line per seat in `$home/seats.md`: name, role, purpose, the date it was made. That file is yours; the record of what was done is the store's.

## Step 7: when they ask

- "What is running?": `$product doctor`, and say its result in one line.
- "Update": tell them the install line on the release page installs the new version over this one and that running `$product setup` again afterwards changes nothing that exists; their seats and their record stay.
- "Remove a seat": `$product --token-file $token_path seat new <Seat> --kind claude --remove`, after they have said the seat's name back to you in this conversation; the folder's files are listed in the receipt and are not deleted by you.
- "Start over": say that uninstalling keeps the store and the seat folders, and that deleting those folders is their own act, named on the support page.
- Anything that needs a vendor key, a cloud account, an environment variable or another application: say that this release does not do it, in one sentence, and offer what it does do.

## What never changes

One question per turn. Defaults stated. No credential shown. No portal, no other app, no variable. Their acts per seat are opening a folder in auto mode and writing one line to it. When in doubt, ask them; when idle, arm the wait as a background task and let the app wake you (your grounding names the command); never end the conversation to wait.
