"""Machine rule candidates, non-overwriting seat homes, and receipt-only onboarding.

No rule installation, task creation, route declaration, or native wake here.
The daemon's ordinary dispatcher delivers the one onboarding notice.
"""
from __future__ import annotations

from contextlib import contextmanager
import fcntl
import hashlib
import json
import product_identity
import os
from pathlib import Path
import re
import stat
from string import Template

from desktop_support import optional
codex_dispatch = optional('codex_dispatch')
codex_wake_route = optional('codex_wake_route')
import receipts
import store

TEMPLATES = Path(__file__).resolve().parent / "templates"
STANDARD_SHA256 = "a7e1a93800ae303a5d8ace5c218b52557c1717696591cc46620ade64d0a6e692"
RULE_NAME = "orch-seat-prefix.rules"
LEGACY_RULES = ("orch-seat-send.rules", "orch-seat-declare.rules")
COMMANDS = (("send",), ("inbox",), ("hook-fetch",), ("token", "status"),
            ("seat", "wake-declare"), ("seat", "wake-clear"))


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_path(value) -> Path:
    p = Path(value)
    if not p.is_absolute() or str(p) != str(value) or p.resolve() != p:
        raise ValueError("path must be canonical, absolute and free of symlinks")
    if any(ord(c) < 32 for c in str(p)):
        raise ValueError("path contains control characters")
    return p


def codex_home() -> Path:
    return canonical_path(os.environ.get("CODEX_HOME", str(Path.home() / ".codex")))


def rule_path() -> Path:
    return codex_home() / "rules" / RULE_NAME


def roster(parts: dict) -> dict[str, str]:
    """Never guess an existing seat's token path from its label/case."""
    result = {}
    for seat, row in sorted(parts.items()):
        if (row.get("kind") != "agent" or store.normalize_family(row.get("family")) != "codex"
                or store.inactive_participant(row)):
            continue
        home = row.get("provisioned_home")
        if not home:
            raise ValueError(f"{seat}: canonical home unregistered; provision --seat-home-map first")
        result[seat] = str(canonical_path(home) / ".orch" / "token")
    if len(set(result.values())) != len(result):
        raise ValueError("two seats cannot share a token path")
    return result


def render_rules(homes: dict[str, str]) -> bytes:
    lines = ["# Generated from the registered machine roster. Install by verified hash.",
             "# Narrow argv prefixes only; store authentication still enforces seat identity."]
    for seat, token in sorted(homes.items()):
        if not store.PARTICIPANT_ID_RE.fullmatch(seat):
            raise ValueError("invalid seat id")
        absolute = canonical_path(token)
        # A tilde names this machine user's home, never a seat-name convention.
        # Refuse an unrepresentable alias rather than grant a guessed path.
        try:
            relative = absolute.relative_to(Path.home().resolve())
        except ValueError:
            raise ValueError(f"{seat}: token path is outside the machine user's home") from None
        forms = (token, "~/" + relative.as_posix())
        lines.append(f"# {seat}")
        for form in forms:
            for command in COMMANDS:
                pattern = [product_identity.command(), "--token-file", form, *command]
                lines.append("prefix_rule(pattern = " + json.dumps(pattern) + ', decision = "allow")')
    return ("\n".join(lines) + "\n").encode()


def _read_regular(path: Path) -> bytes:
    canonical_path(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as f:
        if not stat.S_ISREG(os.fstat(f.fileno()).st_mode):
            raise ValueError("expected a regular file")
        return f.read()


def _create(path: Path, data: bytes) -> bool:
    """Create without replacing even a dangling link. Callers preflight content."""
    canonical_path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    except FileExistsError:
        return False
    with os.fdopen(fd, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    fd = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    return True


@contextmanager
def _lock():
    directory = canonical_path(store.STORE_DIR / "provision")
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    fd = os.open(directory / "machine.lock", os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "a") as stream:
        fcntl.flock(stream, fcntl.LOCK_EX)
        yield directory


def _append_once(row, identity):
    with receipts._nudge_lock():
        rows = receipts.strict_rows()
        if not any(all(r.get(k) == row.get(k) for k in identity) for r in rows):
            receipts.append_durable({**row, "ts": store.now_iso()})


def generate_rules(parts=None, *, dry_run=False) -> dict:
    homes = roster(store.load_participants() if parts is None else parts)
    data = render_rules(homes)
    sha = digest(data)
    path = store.STORE_DIR / "provision" / "rules" / (sha + ".rules")
    if not dry_run:
        if not _create(path, data) and _read_regular(path) != data:
            raise ValueError("immutable rule candidate changed")
    return {"sha256": sha, "candidate": str(path), "destination": str(rule_path()),
            "roster": homes, "install": "the operator installs this both-form hash; the two legacy seat rules are then retired"}


def seat_homes(seats):
    """One read-only registry snapshot; never infer homes or models from names."""
    parts = store.load_participants()
    result = []
    for seat in seats:
        row = parts.get(seat)
        if not isinstance(row, dict) or row.get("kind") != "agent":
            raise ValueError(f"{seat}: requires a registered agent")
        result.append({"seat": seat, "family": store.normalize_family(row.get("family")),
                       "active": not store.inactive_participant(row),
                       "provisioned_home": row.get("provisioned_home"),
                       "recorded_model": row.get("recorded_model")})
    return result


def validate_model(model):
    """A recorded model identifier, not evidence of the running harness model."""
    if not isinstance(model, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}", model):
        raise ValueError("model must be a model identifier of 1–128 characters")
    return model


def model_fields(row, model, actor):
    validate_model(model)
    if row.get("recorded_model") == model and row.get("model_record"):
        return {key: row[key] for key in ("recorded_model", "model_record")}
    return {"recorded_model": model, "model_record": {
        "actor": actor, "at": store.now_iso(), "previous": row.get("recorded_model")}}


def record_model(seat, model, *, token):
    """Record a provisioner's declared model atomically with its attribution."""
    validate_model(model)
    def apply(actor):
        row = store._read_participants_unlocked().get(seat, {})
        if row.get("kind") != "agent" or store.inactive_participant(row):
            raise ValueError("model recording requires an active registered agent")
        fields = model_fields(row, model, actor)
        store._upsert_participant_unlocked(seat, **fields)
        return {"seat": seat, **fields, "source": "DECLARED; not runtime verification"}
    return store.authenticated_registry_act(token, apply, provisioning=True)


def bind_homes(mapping: dict, *, token: str, dry_run=False):
    """CoS import of canonical paths for existing seats; no credentials are read."""
    if not isinstance(mapping, dict) or not mapping:
        raise ValueError("seat-home map must be a nonempty object")
    def apply(actor):
        parts = store._read_participants_unlocked()
        candidate = {s: dict(r) for s, r in parts.items()}
        for seat, home in mapping.items():
            if seat not in parts or parts[seat].get("kind") != "agent" or store.inactive_participant(parts[seat]):
                raise ValueError(f"{seat}: requires an active registered agent")
            p = canonical_path(home)
            if not p.is_dir():
                raise ValueError(f"{seat}: imported home does not exist")
            old = parts[seat].get("provisioned_home")
            if old and old != str(p):
                raise ValueError(f"{seat}: cannot replace an existing home binding")
            candidate[seat]["provisioned_home"] = str(p)
        paths = [r["provisioned_home"] for r in candidate.values() if r.get("provisioned_home")]
        if len(paths) != len(set(paths)):
            raise ValueError("two seats cannot share a home")
        if not dry_run:
            with _lock():
                store._write_participants_unlocked(candidate)
                _append_once({"kind": "seat-home-bindings", "actor": actor, "homes": mapping},
                             ("kind", "homes"))
        return mapping
    return store.authenticated_registry_act(token, apply, provisioning=True)


def provision_home(seat, home, commission: Path, lifecycle_authority: str, *,
                   cycle="registration", token: str, dry_run=False, recorded_model=None):
    """Retry the same cycle safely; a rebirth names a new immutable cycle."""
    home = canonical_path(home)
    if recorded_model is not None:
        validate_model(recorded_model)
    if not re.fullmatch(r"[a-zA-Z0-9_-]{1,64}", cycle):
        raise ValueError("cycle must be a simple name of at most 64 characters")
    if not lifecycle_authority.strip():
        raise ValueError("recorded lifecycle authority is required")
    standard = _read_regular(TEMPLATES / "agent-communication.md")
    if digest(standard) != STANDARD_SHA256:
        raise ValueError("seat standard template hash mismatch")
    commission_bytes = _read_regular(commission)
    if not commission_bytes.strip():
        raise ValueError("commission is empty")

    def apply(actor):
        parts = store._read_participants_unlocked()
        row = parts.get(seat, {})
        if row.get("kind") != "agent" or store.inactive_participant(row):
            raise ValueError("provision an active registered agent; registration comes first")
        family = store.normalize_family(row.get("family"))
        filenames = {"codex": "AGENTS.md", "claude": "CLAUDE.md", "gemini": "GEMINI.md"}
        if family not in filenames:
            raise ValueError("no seat-file template for this harness family")
        if row.get("provisioned_home") not in (None, str(home)):
            raise ValueError("cannot replace an existing home binding")
        if any(s != seat and r.get("provisioned_home") == str(home) for s, r in parts.items()):
            raise ValueError("home already belongs to another seat")
        values = dict(command=product_identity.command(), seat=seat, home=str(home), token_path=str(home / ".orch" / "token"),
                      standard=standard.decode(), lifecycle_authority=lifecycle_authority)
        def render(name):
            return Template(_read_regular(TEMPLATES / name).decode()).substitute(values).encode()
        seat_file = filenames[family]
        addendum = f"GROUNDING_ADDENDUM_PROVISION_{cycle}.md"
        outputs = {seat_file: render("seat.md"),
                   "GROUNDING.md": commission_bytes + b"\n\n" + standard,
                   addendum: commission_bytes + b"\n\n" + standard,
                   f"MODEL_CHANGE_{cycle}.md": render("model-change.md")}
        if family == "codex":
            outputs[f"LIFECYCLE_{cycle}.md"] = render("lifecycle.md")
        # Preserve existing seat/grounding files; cycle-specific files are immutable
        # and must agree on a retry. Preflight every path before creating any bytes.
        files = {}
        for name, data in outputs.items():
            path = home / name
            exists = path.exists() or path.is_symlink()
            old = _read_regular(path) if exists else data
            if exists and name not in {seat_file, "GROUNDING.md"} and old != data:
                raise ValueError(f"{name}: exists with different bytes; use a new rebirth cycle")
            files[name] = {"sha256": digest(old), "preserved": exists}
        receipt_path = home / ".orch" / "provisioning" / (cycle + ".json")
        immutable = {"seat": seat, "home": str(home), "cycle": cycle, "standard_sha256": digest(standard),
                     "commission_sha256": digest(commission_bytes), "lifecycle_authority": lifecycle_authority,
                     "files": {name: info["sha256"] for name, info in files.items()}}
        if recorded_model is not None:
            immutable["recorded_model"] = recorded_model
        registry_before = {key: row.get(key)
                           for key in ("provisioning", "recorded_model", "model_record")}
        # Durable application evidence survives loss of the home receipt. Check
        # it before choosing the fresh path, including a registry-only commit.
        committed = [r for r in receipts.strict_rows()
                     if r.get("kind") == "seat-provisioned" and r.get("seat") == seat
                     and r.get("cycle") == cycle]
        receipt_exists = receipt_path.exists() or receipt_path.is_symlink()
        if not receipt_exists and (committed or row.get("provisioning", {}).get("cycle") == cycle):
            raise ValueError("applied provisioning receipt is missing; refusing retry")
        cycle_paths = [home / name for name in outputs if name not in {seat_file, "GROUNDING.md"}]
        cycle_paths.append(receipt_path.with_name(cycle + "-hello.txt"))
        if (recorded_model is not None and not receipt_exists
                and any(path.exists() or path.is_symlink() for path in cycle_paths)):
            raise ValueError("unreceipted model cycle files; use a new cycle")
        if receipt_exists:
            prior_bytes = _read_regular(receipt_path)
            prior = json.loads(prior_bytes)
            if prior["inputs"] != immutable:
                raise ValueError("provisioning receipt differs; use a new cycle")
            # An artifact receipt precedes the registry/journal commit, so it
            # alone cannot distinguish an interrupted rebirth from an old replay.
            prior_sha = digest(prior_bytes)
            if any(r.get("sha256") != prior_sha for r in committed):
                raise ValueError("committed provisioning receipt changed; refusing retry")
            if committed and row.get("provisioning", {}).get("cycle") != cycle:
                raise ValueError("completed provisioning cycle was superseded; use a new cycle")
            if (recorded_model is not None and not committed
                    and row.get("provisioning", {}).get("cycle") != cycle):
                if "registry_before" not in prior:
                    raise ValueError("incomplete model provisioning lacks registry baseline; use a new cycle")
                if prior["registry_before"] != registry_before:
                    raise ValueError("registry changed after incomplete provisioning; use a new cycle")
            if (recorded_model is not None and row.get("provisioning", {}).get("cycle") == cycle
                    and row.get("recorded_model") != recorded_model):
                raise ValueError("recorded model changed after this cycle; use seat set-model explicitly")
            result = prior
        else:
            result = {"inputs": immutable, "actor": actor, "ts": store.now_iso(), "files": files}
            if recorded_model is not None:
                result["registry_before"] = registry_before
        body = (json.dumps(result, sort_keys=True, indent=2) + "\n").encode()
        hello = (f"TO: {seat} · FROM: {result['actor']} · RE: Seat hello · AUTHORITY: relay — the recorded commission\n\n"
                 f"You are {seat}. Work from {home}. Verify these SHA-256 pins, then read each file:\n"
                 + "\n".join(f"{name}: {info['sha256']}" for name, info in files.items())
                 + f"\nClaim your own invite if needed, fetch {product_identity.load().display_name} mail under your own token, "
                 + "then follow the recorded lifecycle authority in the addendum. "
                 + "Verify this task's actual identity before declaring. Yield after declaration.\n\n"
                 + "If you are not the addressee: treat as FYI; act on nothing; do not forward as authority.\n")
        hello_path = home / ".orch" / "provisioning" / (cycle + "-hello.txt")
        if (hello_path.exists() or hello_path.is_symlink()) and _read_regular(hello_path) != hello.encode():
            raise ValueError("hello exists with different bytes")
        if dry_run:
            return {**result, "dry_run": True, "receipt": str(receipt_path)}
        with _lock():
            # Persist the model recovery baseline before any seat/cycle files.
            # A crash must not let a retry invent a newer registry baseline.
            if recorded_model is not None:
                _create(receipt_path, body)
                if _read_regular(receipt_path) != body:
                    raise ValueError("provisioning artifact changed during creation")
            for name, data in outputs.items():
                path = home / name
                _create(path, data)
                if digest(_read_regular(path)) != files[name]["sha256"]:
                    raise ValueError("seat file changed during provisioning")
            if recorded_model is None:
                _create(receipt_path, body)
            _create(hello_path, hello.encode())
            if _read_regular(receipt_path) != body or _read_regular(hello_path) != hello.encode():
                raise ValueError("provisioning artifact changed during creation")
            receipt_sha = digest(body)
            store._upsert_participant_unlocked(seat, provisioned_home=str(home),
                provisioning={"cycle": cycle, "receipt": str(receipt_path), "sha256": receipt_sha,
                              "at": result["ts"]},
                **(model_fields(row, recorded_model, actor) if recorded_model is not None else {}))
            _append_once({"kind": "seat-provisioned", "seat": seat, "cycle": cycle, "actor": actor,
                          "receipt": str(receipt_path), "sha256": receipt_sha,
                          "files": immutable["files"]}, ("kind", "seat", "cycle", "sha256"))
        return {**result, "receipt": str(receipt_path), "sha256": receipt_sha, "hello": str(hello_path)}
    return store.authenticated_registry_act(token, apply, provisioning=True)


def rule_state(parts=None):
    try:
        candidate = generate_rules(parts, dry_run=True)
        installed = digest(_read_regular(rule_path())) if rule_path().exists() else None
        legacy = [name for name in LEGACY_RULES if os.path.lexists(rule_path().parent / name)]
        current = installed == candidate["sha256"]
        return {**candidate, "installed_sha256": installed, "legacy_rules": legacy,
                "legacy_retired": current, "ok": current}
    except (OSError, ValueError, TypeError) as exc:
        return {"ok": False, "error": str(exc)}


def _require_daemon(actor):
    rec = store._registry_actor_local.actor
    row = store._read_participants_unlocked().get(actor, {})
    if (actor != store.DAEMON_SEAT or rec.get("role") != "daemon"
            or row.get("kind") != "system" or row.get("role") != "system_governor"):
        raise ValueError("machine observation requires the current daemon credential")


def observe_rules(token):
    def apply(actor):
        _require_daemon(actor)
        with _lock():
            parts = store._read_participants_unlocked()
            state = rule_state(parts)
            if "error" not in state:
                generate_rules(parts)
            with receipts._nudge_lock():
                prior = [r for r in receipts.strict_rows() if r.get("kind") == "machine-seat-rules"]
                if not prior or prior[-1].get("state") != state:
                    receipts.append_durable({"kind": "machine-seat-rules", "actor": actor,
                                            "state": state, "ts": store.now_iso()})
            return state
    return store.authenticated_registry_act(token, apply)


def onboarding_chain(seat, row, rows):
    """Project real receipts. Acceptance alone is never a committed fetch."""
    if codex_wake_route is None:
        return {'state': 'not-offered'}
    provision = row.get("provisioning") or {}
    boundaries = [i for i, r in enumerate(rows)
                  if r.get("kind") == "seat-provisioned" and r.get("seat") == seat
                  and all(r.get(k) == provision.get(k) for k in ("cycle", "receipt", "sha256"))]
    if not boundaries:
        return {"state": "provision-unreceipted"}
    route = row.get("wake_route") or {}
    if route.get("kind") != "codex-ipc":
        return {"state": "awaiting-declaration"}
    generation = codex_wake_route.generation(route, check_path=False)
    # The fsynced provisioning receipt is the committed boundary, including on
    # retry after partial file/registry writes. Timestamp precision or clock
    # movement cannot make an earlier declaration qualify a later cycle.
    declared = any(r.get("kind") == "wake-route" and r.get("event") == "declared"
                   and r.get("seat") == seat and r.get("requester") == seat
                   and r.get("generation") == generation for r in rows[boundaries[-1] + 1:])
    if not declared:
        return {"state": "awaiting-declaration"}
    refused = [r for r in rows if r.get("kind") == "seat-onboarding" and r.get("event") == "notice-refused"
               and r.get("seat") == seat and r.get("provision_sha256") == provision.get("sha256")]
    if refused:
        return {"state": "notice-refused", "generation": generation,
                **{k: refused[-1][k] for k in ("msg-id", "verdict", "reason")}}
    requests = [r for r in rows if r.get("kind") == "seat-onboarding" and r.get("event") == "requested"
                and r.get("seat") == seat and r.get("provision_sha256") == provision.get("sha256")]
    result = {"state": "awaiting-acceptance", "generation": generation}
    if not requests:
        if any(r.get("kind") == "seat-onboarding" and r.get("event") == "notice-intent"
               and r.get("seat") == seat and r.get("provision_sha256") == provision.get("sha256") for r in rows):
            result["state"] = "notice-unresolved"
        return result
    request = requests[-1]
    if request["generation"] != generation:
        return {**result, "state": "declaration-changed"}
    mid = request["msg-id"]
    result["msg-id"] = mid
    if any(r.get("kind") == "wake_route_dead" and r.get("seat") == seat
           and r.get("generation") == generation and r.get("terminal") for r in rows):
        return {**result, "state": "dead"}
    pres = [r for r in rows if r.get("kind") == "nudge" and r.get("phase") == "pre"
            and r.get("target seat") == seat and r.get("msg-id") == mid and r.get("generation") == generation]
    posts = {r.get("event-id"): r for r in rows if r.get("kind") == "nudge" and r.get("phase") == "post"}
    for pre in pres:
        post = posts.get(pre["event-id"], {})
        if post.get("result") != "accepted" or not post.get("turn-id"):
            continue
        poked = any(r.get("kind") == "delivery" and r.get("event") == "POKED" and r.get("seat") == seat
                    and r.get("msg-id") == mid and r.get("nudge-event-id") == pre["event-id"] for r in rows)
        fetched = [r for _, r in store.valid_fetched_deliveries(rows)
                   if r.get("seat") == seat and r.get("msg-id") == mid]
        if poked and fetched:
            return {**result, "state": "reachable", "nudge-event-id": pre["event-id"],
                    "request-id": post.get("request-id"), "turn-id": post["turn-id"],
                    "fetch-txn-id": fetched[-1]["txn-id"], "provision_sha256": provision["sha256"]}
    return result


def observe_onboarding(token):
    def snapshot(actor):
        _require_daemon(actor)
        return actor, store._read_participants_unlocked()

    def reserve(actor, seat, provision, generation):
        _require_daemon(actor)
        # Recheck under short locks: concurrent observers can reserve only once,
        # and a rebirth/redeclaration cannot inherit an obsolete reservation.
        with _lock():
            row = store._read_participants_unlocked().get(seat, {})
            if (row.get("provisioning") != provision or store.inactive_participant(row)
                    or store.normalize_family(row.get("family")) != "codex" or not codex_dispatch.enabled()):
                return False
            chain = onboarding_chain(seat, row, receipts.strict_rows())
            if (chain["state"] != "awaiting-acceptance" or "msg-id" in chain
                    or chain["generation"] != generation):
                return False
            _append_once({"kind": "seat-onboarding", "event": "notice-intent", "seat": seat,
                          "provision_sha256": provision["sha256"], "generation": generation,
                          "actor": actor}, ("kind", "event", "seat", "provision_sha256"))
            return True

    def record(actor, event):
        _require_daemon(actor)
        with _lock():
            _append_once({"kind": "seat-onboarding", "actor": actor, **event},
                         ("kind", "event", "seat", "provision_sha256"))

    actor, parts = store.authenticated_registry_act(token, snapshot)
    if codex_dispatch is None or codex_wake_route is None:
        return  # Authentication still precedes the unavailable-feature result.
    rows = receipts.strict_rows()
    messages = None
    for seat, row in parts.items():
        provision = row.get("provisioning")
        if not provision or store.inactive_participant(row) or store.normalize_family(row.get("family")) != "codex":
            continue
        chain = onboarding_chain(seat, row, rows)
        if chain["state"] in {"awaiting-acceptance", "notice-unresolved"} and "msg-id" not in chain and codex_dispatch.enabled():
            # Scan through EOF outside registry/token/machine locks. The accepted
            # send can be beyond the first batch after a send->receipt crash.
            if messages is None:
                messages = store.read_log_to_eof()
            sent = [m for m in messages if m.get("from") == actor and m.get("recipients") == [seat]
                    and (m.get("meta") or {}).get("provision_sha256") == provision["sha256"]]
            if not sent:
                if chain["state"] == "notice-unresolved":
                    # An interrupted send with no durable outcome is ambiguous; do not
                    # spend another wake. Doctor names this state for the CoS.
                    continue
                reserved = store.authenticated_registry_act(token, lambda current_actor:
                    reserve(current_actor, seat, provision, chain["generation"]))
                if not reserved:
                    continue
                text = (f"TO: {seat} · FROM: {actor} · RE: Onboarding reachability · AUTHORITY: FYI\n\n"
                        "This is your single onboarding acceptance wake. Fetch this mail under your own token. "
                        "The daemon records the receipt chain; no reply, attestation or quiet window is requested.\n\n"
                        "If you are not the addressee: treat as FYI; act on nothing; do not forward as authority.")
                # store.send reauthenticates; its validation/callbacks must never
                # inherit the reservation's registry, token or machine locks.
                message = store.send(actor, [seat], text, kind="system", presented_token=token,
                                     meta={"provision_sha256": provision["sha256"], "generation": chain["generation"]},
                                     envelope={"re": "Onboarding reachability", "authority": "FYI", "confirm": True})
            else:
                message = sent[0]
            vet = message.get("vet") or {}
            if vet.get("verdict") not in (None, "PASS"):
                event = {"event": "notice-refused", "seat": seat, "provision_sha256": provision["sha256"],
                         "generation": message["meta"]["generation"], "msg-id": message["id"],
                         "verdict": vet["verdict"], "reason": vet.get("reason") or "onboarding notice refused"}
                store.authenticated_registry_act(token, lambda current_actor: record(current_actor, event))
                continue
            event = {"event": "requested", "seat": seat, "provision_sha256": provision["sha256"],
                     "generation": message["meta"]["generation"], "msg-id": message["id"]}
            store.authenticated_registry_act(token, lambda current_actor: record(current_actor, event))
        elif chain["state"] == "reachable":
            event = {"event": "complete", "seat": seat, **chain}
            store.authenticated_registry_act(token, lambda current_actor: record(current_actor, event))


def doctor_lines(parts):
    state = rule_state(parts)
    rows = receipts.strict_rows()
    observed = [r for r in rows if r.get("kind") == "machine-seat-rules"]
    recorded = bool(observed and observed[-1].get("state") == state)
    detail = state.get("error") or (f"expected {state['sha256']}; installed {state['installed_sha256']}; "
                                   f"legacy {state['legacy_rules']} "
                                   f"({'retired' if state['legacy_retired'] else 'not retired'}); "
                                   f"daemon hash recorded={recorded}")
    yield state["ok"] and recorded, "Codex command permissions: " + detail
    if codex_dispatch is None or codex_wake_route is None:
        yield True, 'Desktop onboarding: not offered in this installation'
        return
    for seat, row in parts.items():
        if row.get("provisioning") and not store.inactive_participant(row) and store.normalize_family(row.get("family")) == "codex":
            chain = onboarding_chain(seat, row, rows)
            if chain["state"] == "reachable" and not any(
                    r.get("kind") == "seat-onboarding" and r.get("event") == "complete" and r.get("seat") == seat
                    and all(r.get(k) == v for k, v in chain.items()) for r in rows):
                chain = {**chain, "state": "reachable-unrecorded"}
            detail = f"; {chain['verdict']}: {chain['reason']}" if chain["state"] == "notice-refused" else ""
            yield chain["state"] == "reachable", f"{seat} onboarding: {chain['state']}{detail} (receipt evidence; current native liveness unknown)"
