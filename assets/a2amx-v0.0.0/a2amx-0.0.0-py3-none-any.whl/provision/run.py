#!/usr/bin/env python3
"""Deterministic provisioning runner — executes provision/manifest.toml in order.

The onboarding agent (later) narrates and retries around this, but the fetch /
accept / probe / wire sequence is a plain script with explicit exit codes, so a
governed install is reproducible and testable without an LLM in the loop
(design §2.2). Fail-closed: a step's failure aborts the run (a half-governed box
is never "done").

WS1 (this PR) implements the spine — manifest parse, ordered dispatch, fail-closed
exit, and the real `ensure_uv` / `install_orch` / `run_doctor` steps. The
`bootstrap_sdks` (WS2) and `write_config` (WS3) handlers
are explicit, loud stubs that return PENDING so the sequence runs end-to-end and
`orch doctor` reports what is not yet wired — they are filled in on their own PRs.

    python3 provision/run.py            # run the whole manifest
    python3 provision/run.py --only doctor
    python3 provision/run.py --dry-run
"""
from __future__ import annotations

import argparse
import json
import product_identity
import os
import re
import secrets
import shlex
import shutil
import stat
import subprocess
import sys
import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, List, Optional

import reviewer_hub_policy
import store
from harness.sdk_versions import SDK_VERSIONS

_ROOT = Path(__file__).resolve().parent.parent
MANIFEST = Path(__file__).resolve().parent / "manifest.toml"
CODEX_REVIEWER_RULE_SOURCE = Path(__file__).resolve().parent / "codex-reviewer-hub.rules"
_CODEX_REVIEWER_EMPTY_HOST_PATHS = "    paths = [],"

#: the ONLY accepted operator-token shape (the token_urlsafe alphabet). Enforced
#: symmetrically at write time, in token_configured, and by cmd_doctor's env check
#: (reviewer #44: asymmetric enforcement let a malformed pre-existing assignment be
#: accepted, skip repair, and get profile-sourced).
TOKEN_SHAPE = re.compile(r"[A-Za-z0-9_\-]+")

# --- status vocabulary -------------------------------------------------------
OK = "ok"
PENDING = "pending"   # a not-yet-wired handler (WS2/WS3) — loud, never silent
WARN = "warn"         # a WIRED step ran but flagged something to review (e.g. a
                      # non-green `orch doctor`) — never conflated with PENDING
FAILED = "failed"


def _c(code: str, s: str) -> str:
    return s if os.environ.get("NO_COLOR") else f"\033[{code}m{s}\033[0m"


def _step(msg: str) -> None:
    print(_c("1;36", f"  ▸ {msg}"))


def _ok(msg: str) -> None:
    print(_c("1;32", f"    ✓ {msg}"))


def _pending(msg: str) -> None:
    print(_c("1;33", f"    … {msg}  (not wired yet — later E1 PR)"))


def _warn(msg: str) -> None:
    print(_c("1;33", f"    ! {msg}"))


def _fail(msg: str) -> None:
    print(_c("1;31", f"    ✗ {msg}"), file=sys.stderr)


@dataclass
class StepResult:
    step_id: str
    status: str
    detail: str = ""


# --- handlers ----------------------------------------------------------------
# Each returns a StepResult. A FAILED result aborts the run (unless the step is
# marked optional in the manifest). Handlers must be idempotent where the manifest
# says so — re-running the installer is the upgrade path.

def ensure_uv(ctx: "Context") -> StepResult:
    """uv is the whole toolchain (Python + lockfile + tool install). If absent,
    install it via the official standalone script — the one dependency the
    bootstrap is allowed to fetch before orch itself exists."""
    if shutil.which("uv"):
        return StepResult("fetch-uv", OK, "uv already present")
    if ctx.dry_run:
        return StepResult("fetch-uv", OK, "would install uv (astral standalone script)")
    # Deliberately not piped straight to sh here — the runner is invoked BY
    # install.sh, which is the one place a curl|sh is auditable; inside Python we
    # shell out to the same official installer with an explicit argv.
    try:
        script = subprocess.run(["curl", "-fsSL", "https://astral.sh/uv/install.sh"],
                                capture_output=True, text=True, timeout=60)
    except subprocess.TimeoutExpired:
        return StepResult("fetch-uv", FAILED, "fetching the uv installer timed out (>60s)")
    except FileNotFoundError:
        return StepResult("fetch-uv", FAILED, "curl not found — cannot fetch uv installer")
    if script.returncode != 0:
        return StepResult("fetch-uv", FAILED, "could not fetch uv installer")
    try:
        r = subprocess.run(["sh"], input=script.stdout, text=True, timeout=120)
    except subprocess.TimeoutExpired:
        return StepResult("fetch-uv", FAILED, "uv install script timed out (>120s)")
    if r.returncode != 0:
        return StepResult("fetch-uv", FAILED, "uv install script failed")
    # The installer drops uv in ~/.local/bin or ~/.cargo/bin — prepend those to
    # THIS process's PATH so the which("uv") re-check below (and any later step)
    # sees the fresh binary instead of falsely re-installing (Bugbot #42).
    for d in (Path.home() / ".local" / "bin", Path.home() / ".cargo" / "bin"):
        if (d / "uv").exists():
            os.environ["PATH"] = f"{d}{os.pathsep}{os.environ.get('PATH', '')}"
    if not shutil.which("uv"):
        return StepResult("fetch-uv", FAILED, "uv installed but not on PATH")
    return StepResult("fetch-uv", OK, "installed uv")


def install_orch(ctx: "Context") -> StepResult:
    """Ensure `orch` is on PATH. In a PACKAGED install (`uv tool install`) the
    [project.scripts] console entrypoint ALREADY created `orch`, and there is no
    `bin/orch` shim to symlink — running `orch install` there would clobber that
    good entrypoint with a dangling symlink to a file the wheel never ships
    (Bugbot #42 High). So symlink ONLY in a source checkout (bin/orch present);
    in a packaged install this is a verified no-op."""
    command = product_identity.command()
    shim = _ROOT / "bin" / command
    if not shim.exists():
        # Packaged layout: the uv entrypoint must ALREADY provide `orch` — VERIFY,
        # don't assume (Bugbot #42 MED: a broken packaged install sailed through
        # this step because the no-op reported success unconditionally).
        found = shutil.which(command)
        if found:
            return StepResult("install-orch", OK,
                              f"{command} on PATH via the packaged entrypoint ({found})")
        return StepResult("install-orch", FAILED,
                          f"no bin/{command} shim AND no `{command}` on PATH — the packaged "
                          "entrypoint is missing (broken install)")
    if ctx.dry_run:
        return StepResult("install-orch", OK, f"would run `{command} install` (~/.local/bin symlink)")
    r = subprocess.run([sys.executable, str(_ROOT / "orch_cli.py"), "install"],
                       capture_output=True, text=True)
    return (StepResult("install-orch", OK, f"{command} on PATH (~/.local/bin)") if r.returncode == 0
            else StepResult("install-orch", FAILED, r.stderr.strip()[-300:]))


def codex_reviewer_rule_path() -> Path:
    """Active user-layer destination for the shipped Codex exec-policy rule."""
    return reviewer_hub_policy.reviewer_codex_home() / "rules" / "orch-reviewer-hub.rules"


def codex_reviewer_command_path() -> Path:
    """Isolated command whose absolute path is the only reviewer rule target."""
    return reviewer_hub_policy.reviewer_command_path()


def _codex_reviewer_store_path() -> Path:
    """The store the launcher pins — through the ONE resolver (ORCH_SPEC_01 D-STO-1).
    Raises ``store.StoreUnbound`` when no active store is registered: provisioning cannot
    pin a store nobody has named, and it never falls back to the checkout."""
    return store.resolve_store_dir()


def codex_reviewer_command_bytes() -> bytes:
    """Render the environment-isolating reviewer launcher.

    A model can alter the environment of an inner exec even though the command
    itself is path-bound.  Enter Python in isolated mode through an absolute
    interpreter, pin the hub store chosen during trusted provisioning, and
    discard import/store/tmux policy overrides before any orch module loads.
    """
    python = Path(sys.executable).resolve(strict=True)
    cli = (_ROOT / "orch_cli.py").resolve(strict=True)
    root = cli.parent
    account_home = Path.home().resolve()
    store_dir = _codex_reviewer_store_path()
    bootstrap = (
        f"import runpy,sys;sys.path.insert(0,{str(root)!r});"
        f"runpy.run_path({str(cli)!r},run_name='__main__')"
    )
    script = "\n".join((
        # -p prevents non-interactive shell startup hooks (for example
        # BASH_ENV) from running before this launcher can clear the caller's
        # environment. /bin/sh is the protected system shell on deployed macOS.
        "#!/bin/sh -p",
        "set -eu",
        "IFS=' \t\n'",
        "export IFS",
        "unset BASH_ENV ENV CDPATH",
        "unset LD_PRELOAD LD_LIBRARY_PATH",
        "unset DYLD_INSERT_LIBRARIES DYLD_LIBRARY_PATH DYLD_FRAMEWORK_PATH",
        "unset PYTHONHOME PYTHONPATH PYTHONSTARTUP PYTHONINSPECT PYTHONWARNINGS",
        "unset PSQR_OWNER PSQR_BURN_MAX_CONSECUTIVE PSQR_BURN_MAX_PER_WINDOW PSQR_BURN_WINDOW_SEC",
        "unset PUSH_ORCHESTRATOR_TMUX_BIN TMUX_TMPDIR",
        f"export HOME={shlex.quote(str(account_home))}",
        f"export PSQR_STORE_DIR={shlex.quote(str(store_dir))}",
        "export PATH=/usr/bin:/bin:/usr/sbin:/sbin",
        "export PYTHONNOUSERSITE=1",
        f"exec {shlex.quote(str(python))} -I -c {shlex.quote(bootstrap)} \"$@\"",
        "",
    ))
    return script.encode("utf-8")


def codex_reviewer_rule_bytes() -> bytes:
    """Render the reviewed rule with exactly one absolute launcher path."""
    source = CODEX_REVIEWER_RULE_SOURCE.read_text(encoding="utf-8")
    if source.count(_CODEX_REVIEWER_EMPTY_HOST_PATHS) != 1:
        raise ValueError("reviewer rule must contain one fail-closed host path marker")
    command = codex_reviewer_command_path()
    if not command.is_absolute() or command.name != "orch":
        raise ValueError(f"invalid reviewer command path: {command}")
    rendered = source.replace(
        _CODEX_REVIEWER_EMPTY_HOST_PATHS,
        f"    paths = [{json.dumps(str(command))}],",
    )
    return rendered.encode("utf-8")


def _atomic_install(path: Path, content: bytes, mode: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.parent / f".{path.name}.{os.getpid()}.tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, mode)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
        os.chmod(path, mode)
    except Exception:
        tmp.unlink(missing_ok=True)
        raise


def codex_reviewer_rule_state() -> tuple[bool, str]:
    """Verify the isolated command and its path-bound rule exactly."""
    destination = codex_reviewer_rule_path()
    command = codex_reviewer_command_path()
    if not CODEX_REVIEWER_RULE_SOURCE.is_file():
        return False, f"shipped rule missing: {CODEX_REVIEWER_RULE_SOURCE}"
    try:
        expected_command = codex_reviewer_command_bytes()
        expected_rule = codex_reviewer_rule_bytes()
    except (OSError, ValueError, store.StoreUnbound) as exc:
        return False, f"cannot render reviewer command policy: {exc}"
    if command.is_symlink() or not command.is_file():
        return False, f"reviewer command missing or not a regular file: {command}"
    if destination.is_symlink() or not destination.is_file():
        return False, f"rule missing or not a regular file: {destination}"
    try:
        if command.read_bytes() != expected_command:
            return False, f"reviewer command content drift: {command}"
        command_mode = command.stat().st_mode
        if destination.read_bytes() != expected_rule:
            return False, f"rule content drift: {destination}"
        rule_mode = destination.stat().st_mode
    except OSError as exc:
        return False, f"reviewer command/rule unreadable: {exc}"
    if stat.S_IMODE(command_mode) != 0o700:
        return False, f"reviewer command mode is not 0700: {command}"
    if stat.S_IMODE(rule_mode) != 0o600:
        return False, f"reviewer rule mode is not 0600: {destination}"
    return True, (f"isolated reviewer command {command} is the only host executable "
                  f"allowed by {destination}")


def install_codex_reviewer_hub_rule(ctx: "Context") -> StepResult:
    """Install the isolated command and exact rules used by Codex reviewers.

    The legacy rule is empty by default. An explicitly adopted rule uses the installed
    absolute launcher. ``orch_cli`` independently binds that claimed identity
    to process ancestry. Both files are replaced atomically and owner-only.
    """
    destination = codex_reviewer_rule_path()
    command = codex_reviewer_command_path()
    if not CODEX_REVIEWER_RULE_SOURCE.is_file():
        return StepResult("install-codex-reviewer-hub-rule", FAILED,
                          f"shipped rule missing: {CODEX_REVIEWER_RULE_SOURCE}")
    if ctx.dry_run:
        return StepResult("install-codex-reviewer-hub-rule", OK,
                          f"would install isolated reviewer command {command} and rule {destination}")
    try:
        command_bytes = codex_reviewer_command_bytes()
        rule_bytes = codex_reviewer_rule_bytes()
        _atomic_install(command, command_bytes, 0o700)
        _atomic_install(destination, rule_bytes, 0o600)
    except (OSError, ValueError, store.StoreUnbound) as exc:
        return StepResult("install-codex-reviewer-hub-rule", FAILED,
                          f"could not install reviewer command/rule: {exc}")
    installed, detail = codex_reviewer_rule_state()
    return StepResult("install-codex-reviewer-hub-rule", OK if installed else FAILED,
                      detail + ("; restart Codex reviewer seats to load it" if installed else ""))


def bootstrap_sdks(ctx: "Context") -> StepResult:
    """WS2 (PSQ-258): first-run bootstrap of the vendor SDKs at meta.sdk_pins —
    exact versions are validated against harness.sdk_versions before dispatch
    (bootstrap-don't-bundle: PyPI fetch on the user's machine + ToS-acceptance
    ledger event + Gate-1 probe verify). Not wired in WS1."""
    _pending(f"bootstrap SDKs at pins {ctx.sdk_pins}")
    return StepResult("bootstrap-sdks", PENDING, "WS2 / PSQ-258")


def governed_repos(ctx: "Context") -> List[Path]:
    """The repos whose merges are z-gate governed: the orch root itself (when it is
    a git clone) + manifest ``meta.governed_repos`` + ``PSQR_GOVERNED_REPOS`` (path-
    separator-joined). Resolved physically and deduped, order preserved."""
    candidates: List[Path] = []
    if (_ROOT / ".git").exists():
        candidates.append(_ROOT)
    candidates += [Path(p).expanduser() for p in ctx.governed_repos]
    candidates += [Path(p).expanduser()
                   for p in os.environ.get("PSQR_GOVERNED_REPOS", "").split(os.pathsep)
                   if p.strip()]
    seen, out = set(), []
    for c in candidates:
        try:
            rp = c.resolve()
        except OSError as e:
            # a governed repo that cannot even be resolved must fail LOUD — silently
            # dropping it leaves that repo ungoverned (Bugbot #44 MED)
            raise ValueError(f"governed repo path unresolvable: {c} ({e})")
        if rp not in seen:
            seen.add(rp)
            out.append(rp)
    return out


def install_zgate_hooks(ctx: "Context") -> StepResult:
    """Rule A: record retirement in the runner's result; never inspect/write hooks."""
    return StepResult("install-hooks", OK,
                      "retired no-op: GC-7 removed the mint seam; merge control is principal Z, "
                      "CoS exact-head FIT gate, guarded merge and sealed receipt; existing hooks untouched")


def token_file_state(env_file: Path) -> tuple:
    """Tri-state of the operator-credential file — the ONE shared truth for
    write_config, token_configured and cmd_doctor (Bugbot #44 r4: split checks
    diverged — a valid env var masked a poisoned file that every future shell
    would source):
      ("ok", ...)       >=1 valid assignment, zero poison
      ("poisoned", why) ANY empty or malformed PSQR_AUTH_TOKEN assignment
      ("absent", ...)   no file / no assignment lines"""
    if not env_file.exists():
        return ("absent", "no credential file")
    saw_valid = False
    for raw in env_file.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if line.startswith("export PSQR_AUTH_TOKEN="):
            # validate the RAW right-hand side — the shell does NOT strip it:
            # `export PSQR_AUTH_TOKEN= good` sources as an EMPTY variable (and
            # runs `good` as a command), so a stripped parse was a false green
            # for a file future shells source broken (reviewer #44 r4)
            value = line.split("=", 1)[1]
            if not value.strip():
                return ("poisoned", "empty PSQR_AUTH_TOKEN assignment")
            if value != value.strip() or not TOKEN_SHAPE.fullmatch(value):
                return ("poisoned", "malformed PSQR_AUTH_TOKEN assignment "
                                    "(whitespace or invalid characters)")
            saw_valid = True
    return ("ok", "valid token present") if saw_valid else ("absent", "no token assignment")


def token_configured(env_file: Path) -> bool:
    """True iff the credential file is in the 'ok' state (see token_file_state)."""
    return token_file_state(env_file)[0] == "ok"


#: operator-credential file written by write_config; sourced from the shell profile.
def config_env_file() -> Path:
    base = Path(os.environ.get("XDG_CONFIG_HOME") or (Path.home() / ".config"))
    return base / "orch" / "orch.env"


def write_config(ctx: "Context") -> StepResult:
    """WS3 (PSQ-257): make the credential-bound mint work out of the box (audit #1's
    install-time half — the authenticated HTTP seam is already on main).

    - Generate the operator token if none is configured; write it to
      ``~/.config/orch/orch.env`` with 0600 set BEFORE the secret hits disk.
      Idempotent: an existing configured token is NEVER rotated by a re-run
      (rotation is an explicit operator action, not an upgrade side effect).
    - Wire one idempotent source line into the user's shell profile so new
      shells carry ``PSQR_AUTH_TOKEN`` (packaged installs ship with the token
      configured, always — the localhost-trusted dev fallback stays OFF).
    - Constitution: verify the shipped ``constitution.json`` loads at its
      effective path (it is not a user knob; changes go through the Z-gated
      mutation path). The token value is NEVER printed or logged."""
    env_file = config_env_file()
    if ctx.dry_run:
        return StepResult("write-config", OK,
                          f"would generate the operator token → {env_file} (0600) + wire the shell profile")
    # Constitution FIRST — before any secret hits disk (Bugbot #44 r3: verifying
    # after the writes left credentials + profile wiring behind on a FAILED step).
    # And verify the FILE, not constitution.load() — load() silently falls back to
    # in-memory defaults, so it never fails (the old check was vacuous).
    import json as _json
    import constitution as C
    cpath = C._effective_path()
    if not cpath.exists():
        return StepResult("write-config", FAILED,
                          f"constitution missing at {cpath} — broken install artifact")
    try:
        cdata = _json.loads(cpath.read_text(encoding="utf-8"))
    except (OSError, _json.JSONDecodeError) as e:
        return StepResult("write-config", FAILED, f"constitution unreadable/unparseable: {e}")
    violations = C.validate(cdata)
    if violations:
        return StepResult("write-config", FAILED,
                          "constitution violates invariants: " + "; ".join(violations))
    const_note = f"constitution OK ({cpath.name} v{cdata.get('version')})"

    env_file.parent.mkdir(parents=True, exist_ok=True)
    # A pre-existing poison assignment (empty OR malformed — the SAME tri-state the
    # parser and doctor use) must stop the install before append/profile wiring
    # (reviewer #44 r3, Bugbot r4).
    fstate, fdetail = token_file_state(env_file)
    if fstate == "poisoned":
        return StepResult("write-config", FAILED,
                          f"{env_file}: {fdetail} — refusing to proceed; fix or remove that line")
    if fstate != "ok":
        token = os.environ.get("PSQR_AUTH_TOKEN") or secrets.token_urlsafe(24)
        # The env file is SOURCED by the shell — an inherited token containing
        # quotes/spaces/metacharacters would inject into every future shell
        # (reviewer #44 MED). Enforce the token_urlsafe alphabet; refuse anything
        # else rather than attempt quoting (the strict parser stays simple).
        if not TOKEN_SHAPE.fullmatch(token):
            return StepResult("write-config", FAILED,
                              "inherited PSQR_AUTH_TOKEN contains characters outside "
                              "[A-Za-z0-9_-] — refusing to write it into a sourced shell "
                              "file; unset it or use a urlsafe token")
        # 0600 BEFORE the secret hits disk — including the PRE-EXISTING-file case:
        # the mode arg to os.open applies only at creation, so a loose-permission
        # existing file must be tightened first (Bugbot #44 r4: append-then-chmod
        # briefly exposed the credential).
        if env_file.exists():
            os.chmod(env_file, 0o600)
        fd = os.open(env_file, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        with os.fdopen(fd, "a", encoding="utf-8") as f:
            f.write(f"export PSQR_AUTH_TOKEN={token}\n")
    os.chmod(env_file, 0o600)                  # normalize even on the keep path
    # one idempotent source line in the profile ($SHELL decides which)
    shell = os.environ.get("SHELL", "")
    profile = Path.home() / (".zshrc" if shell.endswith("zsh") else ".bashrc")
    src_line = f'[ -f "{env_file}" ] && . "{env_file}"  # {product_identity.command()} operator credentials'
    existing = profile.read_text(encoding="utf-8") if profile.exists() else ""
    # EXACT-line idempotency check — a substring match let an unrelated comment
    # mentioning the path block the wiring while the step reported OK (Bugbot r4)
    if not any(line.strip() == src_line for line in existing.splitlines()):
        with profile.open("a", encoding="utf-8") as f:
            f.write(f"\n{src_line}\n")
    return StepResult("write-config", OK,
                      f"operator credentials at {env_file} (0600), profile wired; {const_note}")


def run_doctor(ctx: "Context") -> StepResult:
    """Delegate to `orch doctor` — the single health check (WS4 extends it with
    hook/adapter/pin-drift checks). A non-green doctor is surfaced but does not
    itself abort the install spine (the install already ran; doctor reports)."""
    if ctx.dry_run:
        return StepResult("doctor", OK, f"would run `{product_identity.command()} doctor`")
    r = subprocess.run([sys.executable, str(_ROOT / "orch_cli.py"), "doctor"])
    # A non-green doctor is a WIRED step flagging a real health issue (e.g. daemon
    # not up yet) — WARN, never PENDING. PENDING means "not built yet"; conflating
    # the two let a broken stack read as an incomplete-but-OK spine (Bugbot #42).
    return (StepResult("doctor", OK, f"{product_identity.command()} doctor green") if r.returncode == 0
            else StepResult("doctor", WARN, f"{product_identity.command()} doctor flagged issues — review `{product_identity.command()} doctor`"))


def generate_seat_rules(ctx: "Context") -> StepResult:
    from provision import machine
    try:
        result = machine.generate_rules(dry_run=ctx.dry_run)
    except (store.StoreUnbound, ValueError, OSError) as exc:
        return StepResult("seat-rules", WARN, str(exc))
    return StepResult("seat-rules", OK,
                      f"candidate {result['candidate']} sha256={result['sha256']}; "
                      f"the operator installs by hash at {result['destination']}")


HANDLERS: Dict[str, Callable[["Context"], StepResult]] = {
    "ensure_uv": ensure_uv,
    "install_orch": install_orch,
    "install_codex_reviewer_hub_rule": install_codex_reviewer_hub_rule,
    "bootstrap_sdks": bootstrap_sdks,
    "install_zgate_hooks": install_zgate_hooks,
    "write_config": write_config,
    "run_doctor": run_doctor,
    "generate_seat_rules": generate_seat_rules,
}


@dataclass
class Context:
    dry_run: bool
    sdk_pins: Dict[str, str]
    governed_repos: List[str] = None  # manifest meta.governed_repos (paths)

    def __post_init__(self):
        if self.governed_repos is None:
            self.governed_repos = []


def load_manifest(path: Path = MANIFEST) -> dict:
    with path.open("rb") as f:
        m = tomllib.load(f)
    if m.get("schema_version") != 1:
        raise ValueError(f"unsupported manifest schema_version={m.get('schema_version')!r}")
    for step in m.get("step", []):
        if not step.get("id"):
            raise ValueError(f"manifest step missing required 'id': {step!r}")
        if step.get("handler") not in HANDLERS:
            raise ValueError(f"step {step.get('id')!r}: unknown handler {step.get('handler')!r}")
    # The shipped manifest is a reviewed compatibility surface and must mirror the
    # canonical versions. Tests/operators may pass a purpose-built manifest to exercise
    # an isolated step vocabulary without restating unrelated project metadata.
    if path.resolve() == MANIFEST.resolve():
        sdk_pins_from_manifest(m)
    return m


def sdk_pins_from_manifest(manifest: dict) -> Dict[str, str]:
    """Return canonical pins, refusing a stale or incomplete manifest mirror."""
    configured = dict(manifest.get("meta", {}).get("sdk_pins", {}))
    expected = dict(SDK_VERSIONS)
    if configured != expected:
        raise ValueError(
            f"manifest meta.sdk_pins drift: expected {expected!r}, observed {configured!r}"
        )
    return expected


def run(manifest: dict, *, only: Optional[str] = None, dry_run: bool = False) -> List[StepResult]:
    meta = manifest.get("meta", {})
    # load_manifest() validates the serialized mirror on production paths. Dispatch always
    # consumes the canonical mapping directly; unit tests may supply synthetic step-only
    # manifests, and no caller can make a stale manifest value reach a handler.
    ctx = Context(dry_run=dry_run, sdk_pins=dict(SDK_VERSIONS),
                  governed_repos=list(meta.get("governed_repos", [])))
    results: List[StepResult] = []
    for step in manifest.get("step", []):
        if only and step["id"] != only:
            continue
        _step(step["id"])
        try:
            res = HANDLERS[step["handler"]](ctx)
        except Exception as e:  # noqa: BLE001 — the exit contract is the interface:
            # a handler bug must surface as a FAILED step (fail-closed, exit 1),
            # never a Python traceback automation can't parse (Bugbot #44 r2).
            res = StepResult(step["id"], FAILED, f"handler crashed: {e}")
        # The MANIFEST id is the source of truth for correlation — handlers hardcode
        # their own step_id and a manifest rename would silently break the
        # optional/required-pending attribution in main() (the same correlation-drift
        # class as the false-green findings). Stamp it.
        res.step_id = step["id"]
        results.append(res)
        if res.status == OK:
            _ok(res.detail or "done")
        elif res.status == WARN:
            _warn(res.detail or "flagged an issue to review")
        elif res.status == FAILED:
            if step.get("optional"):
                # optional = warn-and-continue: downgrade to WARN so it neither
                # aborts here NOR makes main() exit 1 (Bugbot #42 — a "continued"
                # optional failure still tripped install.sh's set -e before).
                _warn(f"optional step {step['id']!r} failed: {res.detail or 'failed'} — continuing")
                res.status = WARN
            else:
                _fail(res.detail or "failed")
                _fail(f"aborting: required step {step['id']!r} failed")
                break
        # PENDING handlers print their own `…` line; nothing more to say here.
    return results


# --- exit codes (machine-readable — reviewer PR#42 HIGH: no false green) --------
EXIT_OK = 0            # everything wired ran; complete (or pending explicitly acked)
EXIT_FAILED = 1        # a required step FAILED
EXIT_USAGE = 2         # bad invocation (e.g. --only names no step)
EXIT_PENDING = 3       # required steps are PENDING (not wired) and NOT --allow-pending
EXIT_WARN = 4          # wired steps ran but one flagged a WARN (e.g. non-green doctor) — review


def add_machine_arguments(parser):
    parser.add_argument("--seat", help="provision an already registered seat (CoS credential required)")
    parser.add_argument("--seat-home", help="canonical absolute seat home")
    parser.add_argument("--recorded-model", help="CoS-declared model identifier for this provisioning cycle")
    parser.add_argument("--commission-file", type=Path, help="authorized grounding text to preserve")
    parser.add_argument("--lifecycle-authority", help="recorded authority for the seat's own declarations")
    parser.add_argument("--cycle", default="registration", help="immutable registration/rebirth cycle name")
    parser.add_argument("--seat-home-map", type=Path, help="CoS import: JSON seat-to-canonical-home map")


def machine_action(args, token):
    from provision import machine
    if args.only or (args.seat and args.seat_home_map):
        raise ValueError("use one home action at a time, without --only")
    if args.seat_home_map and (args.seat_home or args.commission_file or args.lifecycle_authority
                               or args.cycle != "registration" or args.recorded_model):
        raise ValueError("seat-home-map cannot be combined with seat generation options")
    if args.seat:
        if not all((args.seat_home, args.commission_file, args.lifecycle_authority)):
            raise ValueError("--seat requires --seat-home, --commission-file and --lifecycle-authority")
        result = machine.provision_home(args.seat, args.seat_home, args.commission_file,
                                        args.lifecycle_authority, cycle=args.cycle,
                                        token=token, dry_run=args.dry_run, recorded_model=args.recorded_model)
    else:
        result = machine.bind_homes(json.loads(machine._read_regular(args.seat_home_map)),
                                    token=token, dry_run=args.dry_run)
    print(json.dumps(result, indent=2, sort_keys=True))
    if args.dry_run:
        return EXIT_OK
    # Home creation is already receipted if another legacy row still needs mapping.
    try:
        print(json.dumps(machine.generate_rules(), indent=2, sort_keys=True))
    except (ValueError, OSError) as exc:
        _warn(f"home action complete; rule generation pending: {exc}")
        return EXIT_WARN
    return EXIT_OK


def main(argv: List[str], *, presented_token=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--only", help="run just this step id")
    ap.add_argument("--dry-run", action="store_true", help="print what each step would do")
    ap.add_argument("--allow-pending", "--spine-only", dest="allow_pending",
                    action="store_true",
                    help="accept not-yet-wired (PENDING) required steps as OK (alpha spine "
                         "install) — otherwise a required PENDING step exits non-zero so CI/agents "
                         "never read a half-governed box as complete")
    ap.add_argument("--manifest", type=Path, default=MANIFEST)
    add_machine_arguments(ap)
    args = ap.parse_args(argv)
    if args.seat or args.seat_home_map:
        try:
            store.require_bound_store()
            return machine_action(args, presented_token)
        except (ValueError, OSError, store.StoreUnbound) as exc:
            _fail(str(exc))
            return EXIT_FAILED
    if args.seat_home or args.commission_file or args.lifecycle_authority or args.cycle != "registration" or args.recorded_model:
        _fail("seat options require --seat")
        return EXIT_USAGE
    try:
        manifest = load_manifest(args.manifest)
    except (ValueError, tomllib.TOMLDecodeError, OSError) as e:
        # a bad/missing manifest must speak the documented exit-code contract, not
        # a Python traceback (Bugbot #42 LOW) — automation reads codes, not stacks.
        _fail(f"cannot load manifest {args.manifest}: {e}")
        return EXIT_USAGE
    if args.only and args.only not in {s["id"] for s in manifest.get("step", [])}:
        # a typo'd --only ran nothing but would otherwise report "complete" — a
        # false green (Bugbot #42). Fail loudly with the valid ids.
        _fail(f"--only {args.only!r}: no such step (have: "
              f"{', '.join(s['id'] for s in manifest.get('step', []))})")
        return EXIT_USAGE
    optional_ids = {s["id"] for s in manifest.get("step", []) if s.get("optional")}
    results = run(manifest, only=args.only, dry_run=args.dry_run)
    failed = [r for r in results if r.status == FAILED]
    pending = [r for r in results if r.status == PENDING]
    warned = [r for r in results if r.status == WARN]
    # a REQUIRED pending step means the box is NOT fully provisioned (governance
    # not installed) — that must be a distinct non-zero unless the caller explicitly
    # accepts the spine-only state (reviewer PR#42 HIGH ×2 + MED: exit codes, not a
    # flattened "done", are the machine-readable truth install.sh/CI/agents read).
    required_pending = [r for r in pending if r.step_id not in optional_ids]
    print()
    if failed:
        _fail(f"provision INCOMPLETE — {len(failed)} step(s) failed")
        return EXIT_FAILED
    if warned:
        # distinct from PENDING: these steps ARE wired and ran — they flagged a
        # real issue to look at (e.g. a non-green doctor), not deferred work.
        print(_c("1;33", f"  ! {len(warned)} step(s) flagged issues to review: "
                          f"{', '.join(r.step_id for r in warned)}"))
    if required_pending and not args.allow_pending:
        _fail(f"provision INCOMPLETE — {len(required_pending)} required step(s) not yet wired "
              f"({', '.join(r.step_id for r in required_pending)}); this box is NOT fully "
              f"governed. Re-run with --spine-only to accept the alpha spine deliberately.")
        return EXIT_PENDING
    if pending:
        ack = " (--spine-only: accepted)" if args.allow_pending else ""
        print(_c("1;33", f"  provision spine OK{ack} — {len(pending)} step(s) pending "
                          f"(later E1 PRs): {', '.join(r.step_id for r in pending)}"))
    elif not warned:
        _ok("provision complete")
    # A WARN (e.g. a non-green doctor) is not a failure, but it must NOT read as a
    # clean success either — a distinct exit code lets install.sh/CI say "installed,
    # review warnings" instead of an unconditional green (Bugbot #42 MED).
    return EXIT_WARN if warned else EXIT_OK


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
