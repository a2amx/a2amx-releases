"""orch provisioning — the deterministic install/upgrade sequence (design §2.5)."""
