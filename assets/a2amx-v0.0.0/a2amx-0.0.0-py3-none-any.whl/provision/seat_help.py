"""Bounded seat-local help signals, observed by the authenticated daemon.

The receipt is the durable decision; System notices have deterministic IDs and
are recovered from the canonical log after an interrupted append/fan-out. No
seat credential, token file, native adapter or unregistered directory is read.
"""
from __future__ import annotations

from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat

import receipts
import store

MAX_BYTES = 4096
_delivered: set[tuple[str, str]] = set()


def _digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _single_line(value, limit):
    return (isinstance(value, str) and bool(value.strip()) and len(value) <= limit
            and all(c.isprintable() for c in value))


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate field")
        result[key] = value
    return result


def _validate(raw: bytes, seat: str) -> dict:
    data = json.loads(raw, object_pairs_hook=_object)
    required = {"seat", "ts", "kind", "reason"}
    if not isinstance(data, dict) or not required <= data.keys() or data.keys() - required - {"held_re"}:
        raise ValueError("invalid fields")
    if data["seat"] != seat:
        raise ValueError("seat does not match registered home")
    if (not _single_line(data["ts"], 64) or "T" not in data["ts"]
            or datetime.fromisoformat(data["ts"].replace("Z", "+00:00")).utcoffset() is None):
        raise ValueError("ts must be an ISO datetime with an offset")
    if (not _single_line(data["kind"], 64)
            or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]*(?: [A-Za-z0-9_-]+){0,3}", data["kind"])):
        raise ValueError("invalid command kind")
    if not _single_line(data["reason"], 1024):
        raise ValueError("reason must be one bounded line")
    if "held_re" in data and not _single_line(data["held_re"], 512):
        raise ValueError("held_re must be one bounded line")
    return data


def _read(seat: str, row: dict, parts: dict) -> dict:
    """Open each directory without following links; read at most 4 KiB + 1.

    Never resolve a help symlink, open a device/FIFO, or read a hard-linked token.
    Invalid content is hashed but never copied into receipts/error messages.
    """
    home = row.get("provisioned_home")
    result = {"home": home, "sha256": None, "state": "refused"}
    def refused(reason, identity=""):
        return {**result, "reason": reason,
                "observation": _digest(json.dumps([home, reason, identity], sort_keys=True).encode())}
    if not isinstance(home, str) or not home.startswith("/") or str(Path(home)) != home or ".." in Path(home).parts:
        return refused("canonical seat home is not registered")
    if sum(p.get("provisioned_home") == home for p in parts.values()) != 1:
        return refused("seat home is registered more than once")
    fd = None
    try:
        fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY)
        for component in (*Path(home).parts[1:], ".orch"):
            nxt = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = nxt
        try:
            info = os.stat("help.json", dir_fd=fd, follow_symlinks=False)
        except FileNotFoundError:
            return {**result, "state": "absent", "observation": "absent", "reason": "help file removed"}
        identity = [info.st_dev, info.st_ino, info.st_mode, info.st_nlink, info.st_size, info.st_mtime_ns]
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            return refused("help file must be a single-link regular file, not a symlink", identity)
        if stat.S_IMODE(info.st_mode) != 0o600:
            return refused("help file permissions must be 0600", identity)
        if info.st_size > MAX_BYTES:
            return refused("help file exceeds 4096 bytes", identity)
        file_fd = os.open("help.json", os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=fd)
        with os.fdopen(file_fd, "rb") as stream:
            opened = os.fstat(stream.fileno())
            if (opened.st_dev, opened.st_ino, opened.st_mode, opened.st_nlink) != (
                    info.st_dev, info.st_ino, info.st_mode, info.st_nlink):
                return refused("help file changed while opening", identity)
            raw = stream.read(MAX_BYTES + 1)
            after = os.fstat(stream.fileno())
            linked = os.stat("help.json", dir_fd=fd, follow_symlinks=False)
            if (after.st_size != len(raw) or after.st_mtime_ns != opened.st_mtime_ns
                    or (linked.st_dev, linked.st_ino) != (opened.st_dev, opened.st_ino)):
                return refused("help file changed while reading", identity)
        if len(raw) > MAX_BYTES:
            return refused("help file exceeds 4096 bytes", identity)
        result["sha256"] = _digest(raw)
        try:
            data = _validate(raw, seat)
        except (ValueError, TypeError, UnicodeError, RecursionError):
            return refused("invalid help JSON, fields, seat, or timestamp", result["sha256"])
        return {**result, "state": "help-requested", "observation": result["sha256"], "data": data,
                "reason": data["reason"]}
    except FileNotFoundError:
        # An absent .orch/home is not equivalent to a deliberate help-file removal.
        return refused("registered home or .orch directory is unavailable")
    except OSError as exc:
        return refused("help path cannot be opened safely", str(exc.errno))
    finally:
        if fd is not None:
            os.close(fd)


def _latest(rows, seat):
    return next((r for r in reversed(rows) if r.get("kind") == "seat-help" and r.get("seat") == seat), None)


def panel_state(rows, seat):
    """Project receipts only; panel requests never access a seat's filesystem."""
    row = _latest(rows, seat)
    if row is None:
        return {"state": "unobserved", "reason": "no help observation", "ts": None}
    return {"state": row["state"], "reason": row["reason"], "ts": row["ts"],
            "remedy": "CoS to act" if row["state"] == "help-requested" else None}


def _notice_unlocked(row, parts):
    """Recover one System notice/inbox append; caller holds registry+nudge locks."""
    chief, mid = row.get("recipient"), row.get("msg-id")
    if not chief or not mid:
        return None
    cache_key = (str(store.STORE_DIR), mid)
    if cache_key in _delivered:
        return None
    current = parts.get(chief, {})
    if current.get("role") != "chief_of_staff" or store.inactive_participant(current):
        return None
    message = next((m for m in store.read_log_to_eof() if m.get("id") == mid), None)
    created = message is None
    if created:
        subject = f"HELP {row['seat']}: {row['command_kind']}"
        text = (f"TO: {chief} · FROM: System · RE: {subject} · AUTHORITY: FYI — seat-local help signal\n\n"
                f"{row['reason']}\n" + (f"Held RE: {row['held_re']}\n" if row.get("held_re") else "")
                + "\nCoS to act. This is a reported blockage, not authority to retry the command.\n\n"
                "If you are not the addressee: treat as FYI; act on nothing; do not forward as authority.")
        message = store._prepare_message_record({
            "id": mid, "ts": store.now_iso(), "from": "System", "to": [chief], "recipients": [chief],
            "kind": "system", "text": text, "vet": {"verdict": "PASS", "reason": "authenticated daemon help signal"},
            "meta": {"seat_help": row["seat"], "sha256": row["sha256"],
                                                       "observer": row["actor"]},
        }, {"re": subject, "authority": "FYI"})
        store._append_message_log(message)
    # Normal adapters consume the delivery journal, not inbox membership alone.
    # Never resurrect a fetched/dropped notice when recovering after restart.
    journal = receipts.strict_rows()
    if not any(r.get("kind") == "delivery" and r.get("seat") == chief
               and r.get("msg-id") == mid for r in journal):
        receipts.journal(mid, chief, "QUEUED")
    present = any(m.get("id") == mid for m in receipts._read_all(store.inbox_path(chief)))
    if not present:
        store.append_jsonl(store.inbox_path(chief), message)
    _delivered.add(cache_key)
    return message if created or not present else None


def _address_pending(row, rows, chiefs):
    """Recover the latest address until canonical publication fixes it.

    A receipt alone is not publication. Under the registry/delivery fences an
    unpublished request may follow a replacement CoS; a committed notice never
    does. Every new address is durable before attempting canonical publication.
    """
    if row["state"] != "help-requested":
        return row
    bound = next((r for r in reversed(rows) if r.get("kind") == "seat-help"
                  and r.get("seat") == row["seat"] and r.get("sha256") == row["sha256"]
                  and r.get("msg-id")), None)
    if bound:
        mid = bound["msg-id"]
        if ((str(store.STORE_DIR), mid) in _delivered
                or chiefs == [bound.get("recipient")]):
            return bound
        # Only canonical publication (or its completed-publication cache) makes
        # the original recipient permanent, including after fetch or turnover.
        if any(message.get("id") == mid for message in store.read_log_to_eof()):
            return bound
    if len(chiefs) != 1:
        # Keep the durable prior address for audit, but do not publish it while
        # there is no unique eligible recipient. Reconsider on the next pass.
        return {**row, "recipient": None, "msg-id": None}
    addressed = {**row, "event": "notice-readdressed" if bound else "notice-addressed",
                 "ts": store.now_iso(),
                 "recipient": chiefs[0], "notice_state": "addressed",
                 "msg-id": "msg-help-" + _digest((row["seat"] + ":" + row["sha256"]).encode())}
    if bound:
        addressed["previous_recipient"] = bound["recipient"]
    receipts.append_durable(addressed)
    rows.append(addressed)
    return addressed


def observe(token):
    """Observe only registered agent homes under the current daemon credential."""
    def apply(actor):
        from provision.machine import _require_daemon
        _require_daemon(actor)
        parts = store._read_participants_unlocked()
        chiefs = [s for s, p in parts.items() if p.get("kind") == "agent"
                  and p.get("role") == "chief_of_staff" and not store.inactive_participant(p)]
        notices = []
        with receipts._nudge_lock():
            rows = receipts.strict_rows()
            for seat, part in sorted(parts.items()):
                if part.get("kind") != "agent" or store.inactive_participant(part):
                    continue
                value = _read(seat, part, parts)
                previous = _latest(rows, seat)
                if previous and previous.get("observation") == value["observation"] and previous.get("home") == value["home"]:
                    if previous["state"] == "help-requested":
                        notice = _notice_unlocked(_address_pending(previous, rows, chiefs), parts)
                        if notice:
                            notices.append(notice)
                    continue
                if value["state"] == "absent" and previous is None:
                    continue
                state = "clear" if value["state"] == "absent" else value["state"]
                entry = {"kind": "seat-help", "event": "cleared" if state == "clear" else state,
                         "actor": actor, "seat": seat, "ts": store.now_iso(), "state": state,
                         **{k: value[k] for k in ("home", "sha256", "observation", "reason")}}
                if state == "help-requested":
                    data = value["data"]
                    entry.update(command_kind=data["kind"], reported_at=data["ts"], held_re=data.get("held_re"))
                    prior = next((r for r in rows if r.get("kind") == "seat-help" and r.get("seat") == seat
                                  and r.get("state") == "help-requested" and r.get("sha256") == value["sha256"]), None)
                    if prior is None and len(chiefs) == 1:
                        entry.update(recipient=chiefs[0], **{"msg-id": "msg-help-" + _digest(
                            (seat + ":" + value["sha256"]).encode())})
                    elif prior is None:
                        entry["notice_state"] = "chief_of_staff missing or ambiguous"
                    else:
                        entry["notice_state"] = "identical content already recorded"
                receipts.append_durable(entry)
                rows.append(entry)
                notice = _notice_unlocked(_address_pending(entry, rows, chiefs), parts)
                if notice:
                    notices.append(notice)
        return notices
    notices = store.authenticated_registry_act(token, apply)
    # Ledger/display callbacks must never inherit registry or delivery locks.
    for message in notices:
        store._run_post_send_hooks(message, authenticated_actor=store.DAEMON_SEAT)
    return {"notices": len(notices)}


def clear(seat, *, token):
    """CoS/human acknowledges the current bytes; never removes a seat's file."""
    def apply(actor):
        parts = store._read_participants_unlocked()
        row = parts.get(seat, {})
        if row.get("kind") != "agent" or store.inactive_participant(row):
            raise ValueError("help-clear requires a current registered agent")
        value = _read(seat, row, parts)
        with receipts._nudge_lock():
            prior = _latest(receipts.strict_rows(), seat)
            if prior and prior.get("state") == "clear" and prior.get("observation") == value["observation"]:
                return prior
            return receipts.append_durable({"kind": "seat-help", "event": "cleared", "actor": actor, "seat": seat,
                "ts": store.now_iso(), "state": "clear", "reason": "help cleared by authorized operator",
                **{k: value[k] for k in ("home", "sha256", "observation")}})
    return store.authenticated_registry_act(token, apply, provisioning=True)
