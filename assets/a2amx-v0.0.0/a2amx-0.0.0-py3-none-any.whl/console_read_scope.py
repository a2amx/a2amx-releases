"""D-CON-15 response projections for an authenticated ordinary seat.

Surface credentials keep their existing observation view. Guest projections
remain in the HTTP handlers. These allowlists do not grant either credential.
"""

PUBLIC_PARTICIPANT_FIELDS = frozenset({
    "id", "label", "family", "kind", "is_daemon", "model", "effort",
    "channel", "online",
})
PUBLIC_PANEL_FIELDS = frozenset({
    "seat", "label", "vendor_family", "model", "effort", "context_window",
    "role", "channel", "hosting_kind", "liveness",
})


def participants(view, identity):
    return {seat: dict(row) if seat == identity else
            {key: value for key, value in row.items()
             if key in PUBLIC_PARTICIPANT_FIELDS}
            for seat, row in view.items()}


def delivery(view, identity):
    # Sending a message does not grant its other recipients' delivery history.
    return {mid: [row for row in rows if row.get("seat") == identity]
            for mid, rows in view.items()}


def state(view, identity):
    """Allow own observations and public roster facts, never unknown additions."""
    result = {key: view[key] for key in ("version", "mode", "role") if key in view}
    result["participants"] = participants(view.get("participants", {}), identity)
    result["panel"] = {"seats": [
        row if row.get("seat", {}).get("value") == identity else {
            key: {part: value for part, value in field.items()
                  if part in {"value", "source", "measured_at"}}
            for key, field in row.items()
            if key in PUBLIC_PANEL_FIELDS and isinstance(field, dict)}
        for row in view.get("panel", {}).get("seats", [])]}
    # Broadcasts have already been selected by canonical addressing, before
    # tailing. The legacy name does not widen the seat's dialogue scope.
    result["broadcasts"] = view.get("broadcasts", [])
    for key in ("tmux_sessions", "tmux_runtime", "harness_facts", "harness_sources"):
        result[key] = {identity: view[key][identity]} if identity in view.get(key, {}) else {}
    # Preserve legacy collection shapes without exposing the global task board
    # or future operational state through this ordinary-seat read surface.
    for key in ("channel_messages", "channel_replies", "send_events", "tasks"):
        result[key] = []
    result["locks"], result["assignments"] = {}, {}
    return result
