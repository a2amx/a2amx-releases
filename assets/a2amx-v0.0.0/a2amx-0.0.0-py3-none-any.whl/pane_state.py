"""Bounded classification and ephemeral terminal-state history, row 633.

No native adapter, disk I/O, store import, logger or thread at import time.
Screen text is transient; only a closed class and parsed reset timing come back.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import math
import re
import threading

from pane_state_patterns import PATTERNS, MENU_CONTINUATIONS, UNANCHORED_HOLD_SECONDS

CLASSES = frozenset({"idle", "in_turn", "dialog", "limit", "unknown", "dead"})
TAIL_LINES = 20
MAX_SCREEN_CHARS = 16384
MAX_LINE_CHARS = 512
# Only standard display-control sequences are stripped. An unfinished/unknown
# escape fails closed instead of letting a control payload become a UI marker.
_ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]|\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)")
_COMPILED = {vendor: {state: tuple(tuple(re.compile(p, re.IGNORECASE) for p in group)
                                     for group in groups)
                     for state, groups in states.items()}
             for vendor, states in PATTERNS.items()}
_MENU_TAIL = tuple(re.compile(p, re.IGNORECASE) for p in MENU_CONTINUATIONS)


def input_allowed(state: str) -> bool:
    """One pointer policy shared by pre-receipt and final keystroke guards."""
    return state in {"idle", "in_turn", "unknown"}


@dataclass(frozen=True)
class ScreenState:
    state: str
    input_region_found: bool = False
    reset_time: dict[str, str] | None = None


def valid_reset_time(value):
    if value is None:
        return True
    if not isinstance(value, dict) or set(value) != {"kind", "value"} or not isinstance(value["value"], str):
        return False
    kind, text = value["kind"], value["value"]
    if kind == "clock":
        return re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", text) is not None
    if kind == "delay":
        return re.fullmatch(r"\d{1,6}", text) is not None and 0 < int(text) <= 604800
    if kind == "instant" and len(text) <= 40:
        try:
            stamp = datetime.fromisoformat(text)
            return stamp.utcoffset() is not None and stamp.astimezone(timezone.utc).isoformat() == text
        except (ValueError, OverflowError):
            pass
    return False


def _reset_time(lines):
    """Parse timing data only; never guess a clock-only notice's date/zone."""
    for line in reversed(lines):
        stamp = re.search(r"(?:resets?|try again at|retry at)\s*[:·]?\s*(\d{4}-\d{2}-\d{2}T[0-9:.]+(?:Z|[+-]\d{2}:\d{2}))", line, re.I)
        if stamp:
            try:
                value = datetime.fromisoformat(stamp[1]).astimezone(timezone.utc).isoformat()
                return {"kind": "instant", "value": value}
            except (ValueError, OverflowError):
                continue
        clock = re.search(r"(?:resets?|try again at|retry at)\s*[:·]?\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b", line, re.I)
        if clock and 1 <= int(clock[1]) <= 12 and int(clock[2] or 0) < 60:
            hour = int(clock[1]) % 12 + (12 if clock[3].lower() == "pm" else 0)
            return {"kind": "clock", "value": f"{hour:02}:{int(clock[2] or 0):02}"}
        clock = re.search(r"(?:resets?|try again at|retry at)\s*[:·]?\s*((?:[01]\d|2[0-3]):[0-5]\d)\b", line, re.I)
        if clock:
            return {"kind": "clock", "value": clock[1]}
        delay = re.search(r"(?:retry|try again)\s+(?:in|after)\s+(\d{1,6})\s*(seconds?|secs?|s|minutes?|mins?|m|hours?|h)\b", line, re.I)
        if delay:
            seconds = int(delay[1]) * {"s": 1, "m": 60, "h": 3600}[delay[2][0].lower()]
            if 0 < seconds <= 604800:
                return {"kind": "delay", "value": str(seconds)}
    return None


def reset_description(value):
    if not valid_reset_time(value) or value is None:
        return ""
    if value["kind"] == "clock":
        return "reported reset " + value["value"] + " (date/time zone unspecified)"
    if value["kind"] == "delay":
        return "reported retry delay " + value["value"] + "s (not a countdown)"
    return "reported reset " + value["value"]


def analyze(vendor: str, screen: str) -> ScreenState:
    """Cut blocking history, retaining a turn indicator beside the composer."""
    states = _COMPILED.get(vendor)
    if not states or not isinstance(screen, str) or len(screen) > MAX_SCREEN_CHARS:
        return ScreenState("unknown")
    text = _ANSI.sub("", screen)
    if "\x1b" in text or "\x00" in text:
        return ScreenState("unknown")
    lines = [line.strip() for line in text.splitlines() if line.strip()][-TAIL_LINES:]
    if not lines or any(len(line) > MAX_LINE_CHARS for line in lines):
        return ScreenState("unknown")
    # A blank composer prompt is distinct from a selected menu choice. The last
    # input marker wins: notices/menus above a newer ready prompt are history.
    ready = [i for i, line in enumerate(lines) if any(g[0].fullmatch(line) for g in states["idle"])]
    menus = [i for i, line in enumerate(lines) if any(g[-1].fullmatch(line) for g in states["dialog"])]
    last_is_menu = bool(menus and (not ready or menus[-1] > ready[-1]))
    known_menu = last_is_menu and all(any(pattern.fullmatch(line) for pattern in _MENU_TAIL)
                                    for line in lines[menus[-1] + 1:])
    turn_above_composer = False
    if last_is_menu:
        # The menu's question precedes its selected choice. Keep that bounded
        # region, but drop any earlier user-input region and its history.
        lines = lines[ready[-1] + 1 if ready else 0:]
    elif ready:
        # A live turn indicator can sit below the last output and immediately
        # above a blank composer. Keep only that adjacent indicator, not busy
        # text above later output; limit/dialog history is still cut below.
        if ready[-1] > 0:
            turn_above_composer = any(all(pattern.fullmatch(lines[ready[-1] - 1])
                                         for pattern in group)
                                      for group in states["in_turn"])
        lines = lines[ready[-1]:]
    for state in ("dialog", "limit", "in_turn", "idle"):
        if ((state == "in_turn" and turn_above_composer)
                or any(all(any(pattern.fullmatch(line) for line in lines) for pattern in group)
                       for group in states[state])):
            found = (state == "dialog" and known_menu) or state in {"idle", "in_turn"}
            return ScreenState(state, found, _reset_time(lines) if state == "limit" else None)
    return ScreenState("unknown")


def classify(vendor: str, screen: str) -> str:
    return analyze(vendor, screen).state


@dataclass(frozen=True)
class Observation:
    state: str
    changed_at: float
    measured_at: float
    episode: int
    reset_time: dict[str, str] | None = None


class StateMemory:
    """One daemon incarnation's state/episode memory; never restored from disk.

The owner supplies a stable registry-binding digest and a monotonic clock. A
changed binding starts a new episode even when the visible class is unchanged.
An observation contains no input text, environment, transcript or credentials.
"""
    def __init__(self, on_change=None):
        self._rows: dict[str, tuple[str, Observation]] = {}
        self._reported: dict[str, int] = {}
        self._serial = 0
        self._unanchored: dict[str, tuple[str, str, float]] = {}
        self._on_change = on_change
        self._lock = threading.RLock()

    def observe(self, seat: str, binding: str, state: str, now: float, *,
                input_region_found=True, reset_time=None) -> Observation:
        if state not in CLASSES or not math.isfinite(now) or not valid_reset_time(reset_time):
            raise ValueError("invalid pane observation")
        with self._lock:
            if state in {"dialog", "limit"} and not input_region_found:
                hold = self._unanchored.get(seat)
                if hold is None or hold[:2] != (binding, state) or now < hold[2]:
                    hold = self._unanchored[seat] = (binding, state, now)
                if now - hold[2] >= UNANCHORED_HOLD_SECONDS:
                    state = "unknown"
            else:
                self._unanchored.pop(seat, None)
            old = self._rows.get(seat)
            previous = old[1] if old and old[0] == binding else None
            changed = previous is None or previous.state != state or now < previous.measured_at
            reset = dict(reset_time) if reset_time is not None else None
            if changed:
                self._serial += 1
                current = Observation(state, now, now, self._serial, reset)
                self._reported.pop(seat, None)
            else:
                current = Observation(state, previous.changed_at, now, previous.episode, reset)
            self._rows[seat] = (binding, current)
            if changed and self._on_change is not None:
                try:
                    self._on_change(seat, state)
                except OSError:
                    pass  # A failed log write cannot turn a blocked state into permission.
            return current

    def current(self, seat: str, binding: str) -> Observation | None:
        with self._lock:
            row = self._rows.get(seat)
            return row[1] if row and row[0] == binding else None

    def limit_notice_due(self, seat: str, binding: str) -> int | None:
        with self._lock:
            current = self.current(seat, binding)
            if current and current.state == "limit" and self._reported.get(seat) != current.episode:
                return current.episode
            return None

    def mark_reported(self, seat: str, binding: str, episode: int) -> None:
        with self._lock:
            current = self.current(seat, binding)
            if current and current.state == "limit" and current.episode == episode:
                self._reported[seat] = episode

    def retain(self, seats: set[str]) -> None:
        with self._lock:
            self._rows = {seat: row for seat, row in self._rows.items() if seat in seats}
            self._reported = {seat: n for seat, n in self._reported.items() if seat in seats}
            self._unanchored = {seat: h for seat, h in self._unanchored.items() if seat in seats}
