"""Ephemeral, one-use Ed25519 verification for the launched core owner.

No private key is generated, accepted or stored here. The launch service enrolls
only a public key received from its actual child's private bootstrap channel.
This module does not establish process or tool isolation: unqualified profiles
must not be enrolled. Its in-memory lock supplements, never replaces, the
launch/token/registry mutation locks held by its caller through admission.
"""
from __future__ import annotations

import base64
import binascii
import secrets
import threading
import time
from collections import OrderedDict

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

import launched_protocol as wire

DOMAIN = "orch-launched-host-origin/v1"
TTL = 10
MAX_CHALLENGES = 1024
MAX_CHALLENGES_PER_ORIGIN = 32


def encode(value):
    """Canonical unpadded base64url, used for keys, nonces and signatures."""
    return base64.urlsafe_b64encode(value).decode("ascii").rstrip("=")


def decode(value, size):
    if type(value) is not str or len(value) != (size * 8 + 5) // 6:
        raise wire.Refused("origin_invalid")
    try:
        raw = base64.b64decode(value + "=" * (-len(value) % 4), altchars=b"-_", validate=True)
    except (ValueError, binascii.Error, UnicodeError):
        raise wire.Refused("origin_invalid") from None
    if len(raw) != size or encode(raw) != value:
        raise wire.Refused("origin_invalid")
    return raw


class Challenges:
    """One instance per gateway core process, invalidated on owner replacement.

Origin records are supplied by the authenticated launch service at *each*
operation, not accepted from the wire. `admit` performs the protected action
inside the same lock as consumption. A raised action still spends the proof:
the caller reconciles the business operation with a new proof, never replays
possibly delivered authority. Crashes discard the whole incarnation.
"""

    def __init__(self, *, clock=time.time, monotonic=time.monotonic):
        self.incarnation = "core-" + secrets.token_hex(16)
        self._clock, self._monotonic = clock, monotonic
        self._lock = threading.RLock()
        self._pending = {}
        self._spent = OrderedDict()

    @staticmethod
    def _record(record, seat, request):
        # Mandatory exact enrollment state is independently rechecked by the
        # gateway before passing a record. This check prevents tuple mixups.
        if not record or record.get("seat") != seat or record.get("state") != "enrolled":
            raise wire.Refused("origin_unqualified", "unavailable")
        if record.get("binding") != request["params"].get("binding"):
            raise wire.Refused("binding_mismatch")
        wire.text(record.get("origin_ref"))
        decode(record.get("public_key"), 32)
        return record

    def issue(self, record, seat, value):
        request = wire.request(value)
        if request["method"] not in wire.PROTECTED:
            raise wire.Refused()
        self._record(record, seat, request)
        with self._lock:
            now, tick = self._clock(), self._monotonic()
            wire.timestamp(now)
            # Clock reversal cannot resurrect expired challenges.
            self._pending = {k: v for k, v in self._pending.items()
                             if now < v["object"]["expires_at"] and tick < v["deadline"]}
            self._spent = OrderedDict((k, v) for k, v in self._spent.items()
                if now < v["object"]["expires_at"] and tick < v["deadline"])
            if len(self._pending) >= MAX_CHALLENGES:
                raise wire.Refused("origin_capacity")
            count = sum(v["object"]["seat"] == seat and
                        v["object"]["origin_ref"] == record["origin_ref"] for v in self._pending.values())
            if count >= MAX_CHALLENGES_PER_ORIGIN:
                raise wire.Refused("origin_capacity")
            challenge_id = "challenge-" + secrets.token_hex(16)
            signed = {"domain": DOMAIN, "origin_ref": record["origin_ref"],
                      "seat": seat, **record["binding"], "core_incarnation": self.incarnation,
                      "challenge_id": challenge_id, "nonce": encode(secrets.token_bytes(32)),
                      "expires_at": now + TTL, "method": request["method"],
                      "call_id": request["call_id"], "request_sha256": wire.fingerprint(request)}
            self._pending[challenge_id] = {"object": signed, "deadline": tick + TTL,
                                           "record_sha256": wire.fingerprint(record), "used": False}
            return wire.decode(wire.canonical(signed))

    def admit(self, record, seat, value, proof, action):
        request = wire.request(value)
        self._record(record, seat, request)
        if proof is None:
            raise wire.Refused("origin_required")
        try:
            wire.exact(proof, {"origin_ref", "challenge_id", "signature"})
            wire.text(proof["origin_ref"])
            wire.text(proof["challenge_id"])
            signature = decode(proof["signature"], 64)
        except wire.Refused:
            raise wire.Refused("origin_invalid") from None
        with self._lock:
            item = self._pending.get(proof["challenge_id"]) or self._spent.get(proof["challenge_id"])
            if item is None:
                raise wire.Refused("origin_invalid")
            obj = item["object"]
            if (proof["origin_ref"] != record["origin_ref"] or obj["seat"] != seat
                    or item["record_sha256"] != wire.fingerprint(record)
                    or obj["request_sha256"] != wire.fingerprint(request)):
                raise wire.Refused("origin_invalid")
            if self._clock() >= obj["expires_at"] or self._monotonic() >= item["deadline"]:
                raise wire.Refused("origin_expired")
            if item["used"]:
                raise wire.Refused("origin_replayed")
            try:
                Ed25519PublicKey.from_public_bytes(decode(record["public_key"], 32)).verify(
                    signature, wire.canonical(obj))
            except (InvalidSignature, ValueError):
                raise wire.Refused("origin_invalid") from None
            # No persistent nonce replay is possible after a core restart:
            # all old challenges vanish and the incarnation changes.
            item["used"] = True
            self._pending.pop(proof["challenge_id"])
            # Tombstones retain the existing replay diagnostic without charging
            # active capacity. Eviction changes only the diagnostic to invalid.
            self._spent[proof["challenge_id"]] = item
            while len(self._spent) > MAX_CHALLENGES:
                self._spent.popitem(last=False)
            return action()
