"""Append-only nudge receipts and delivery journal for Phase A.

The receipt rows are the evidence for bytes presented to an adapter.  Pane
output is deliberately not treated as evidence of pane input.
"""

from __future__ import annotations

import json
import hashlib
import fcntl
import os
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Callable, Dict

import store


def reference(row: Dict[str, Any]) -> Dict[str, Any]:
    """Read-only identity of one complete stored row, without its private data."""
    route = row.get("route")
    return {"sha256": hashlib.sha256(json.dumps(row, sort_keys=True,
                separators=(",", ":")).encode()).hexdigest(),
            "route_kind": row.get("route_kind") or (route.get("kind") if isinstance(route, dict) else None),
            "generation": row.get("generation")}


def path() -> Path:
    return store.STORE_DIR / "receipts.jsonl"


def _append(row: Dict[str, Any]) -> Dict[str, Any]:
    store.append_jsonl(path(), row)
    return row


def append_durable(row: Dict[str, Any]) -> Dict[str, Any]:
    """Append and fsync the journal, then persist its directory entry.

    Shared provisioning/help receipts require the same durability as native
    dispatch receipts without importing a native adapter to obtain it.
    """
    result = _append(row)
    fd = os.open(str(path().parent), os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    return result


def strict_rows() -> list[Dict[str, Any]]:
    """Read authoritative receipt history, rejecting torn or corrupt records."""
    journal_path = path()
    if not journal_path.exists():
        return []
    if journal_path.is_symlink():
        raise ValueError('receipt journal is a symlink')
    from console_read_cache import strict_rows as cached_rows
    cached = cached_rows(journal_path)
    if cached is not None:
        return cached
    with journal_path.open('rb') as stream:
        fcntl.flock(stream.fileno(), fcntl.LOCK_SH)
        try:
            data = stream.read()
        finally:
            fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
    if data and not data.endswith(b'\n'):
        raise ValueError('receipt journal has an incomplete record')
    result = [json.loads(line) for line in data.splitlines() if line.strip()]
    if any(not isinstance(row, dict) for row in result):
        raise ValueError('receipt journal has a non-object record')
    return result


def journal(msg_id: str, seat: str, event: str, *, adapter: str | None = None,
            detail: str | None = None) -> Dict[str, Any]:
    row: Dict[str, Any] = {
        "kind": "delivery", "msg-id": msg_id, "seat": seat,
        "event": event, "ts": store.now_iso(),
    }
    if adapter is not None:
        row["adapter"] = adapter
    if detail is not None:
        row["detail"] = detail
    return _append(row)


def _journal_fetched_batch(msg_ids: list[str], seat: str, *, adapter: str, metadata=None) -> None:
    """Commit singular FETCHED rows through an append-only transaction."""
    if metadata is not None:
        if (not isinstance(metadata, dict)
                or set(metadata) not in ({'via', 'session_ref'}, {'via', 'session_ref', 'launched'})
                or metadata.get('via') != 'hook'):
            raise ValueError('invalid hook fetch metadata')
        if 'launched' in metadata:
            from launched_protocol import exact, text
            exact(metadata['launched'], {'verification_ref', 'batch_ref', 'host_generation', 'route_generation'})
            for item in metadata['launched'].values():
                text(item)
    if not msg_ids:
        return
    txn_id = "fetch-" + uuid.uuid4().hex
    _append({"kind": "delivery-transaction", "phase": "prepare", "txn-id": txn_id,
             "msg-ids": list(msg_ids), "seat": seat, "event": "FETCHED",
             "adapter": adapter, **(metadata or {}), "ts": store.now_iso()})
    try:
        _append({"kind": "delivery-transaction", "phase": "commit", "txn-id": txn_id,
                 "ts": store.now_iso()})
    except Exception:
        try:
            _append({"kind": "delivery-transaction", "phase": "abort", "txn-id": txn_id,
                     "ts": store.now_iso()})
        except Exception:
            pass
        raise
    try:
        _materialize_fetched_unlocked(txn_id, msg_ids, seat, adapter, set(), metadata)
    except Exception:
        try:
            _append({"kind": "delivery-transaction", "phase": "abort", "txn-id": txn_id,
                     "ts": store.now_iso()})
        except Exception:
            pass
        raise


def _materialize_fetched_unlocked(txn_id: str, msg_ids: list[str], seat: str,
                                  adapter: str, existing: set[str], metadata=None) -> None:
    for msg_id in msg_ids:
        if msg_id not in existing:
            _append({"kind": "delivery", "msg-id": msg_id, "seat": seat,
                     "event": "FETCHED", "adapter": adapter, "txn-id": txn_id,
                     **(metadata or {}), "ts": store.now_iso()})


def _recover_fetched_transactions_unlocked() -> None:
    """Finish crash-orphaned FETCHED transactions while holding nudge.lock."""
    import recall
    recall.recover_unlocked()
    all_rows = rows()
    committed, aborted, prepares, materialized = set(), set(), [], {}
    # Index the snapshot once. Rescanning every historical row for every
    # completed transaction made an ordinary hook fetch quadratic in history,
    # while holding the commit lock and after its durable inbox was written.
    for row in all_rows:
        txn = row.get('txn-id')
        if row.get('kind') == 'delivery-transaction':
            phase = row.get('phase')
            if phase == 'commit':
                committed.add(txn)
            elif phase == 'abort':
                aborted.add(txn)
            elif phase == 'prepare':
                prepares.append(row)
        elif row.get('kind') == 'delivery':
            materialized.setdefault(txn, set()).add(row.get('msg-id'))
    for prepare in prepares:
        if (prepare.get("txn-id") in aborted
                or prepare.get("txn-id") not in committed):
            continue
        txn_id = prepare["txn-id"]
        _materialize_fetched_unlocked(
            txn_id, list(prepare.get("msg-ids") or []), str(prepare.get("seat")),
            str(prepare.get("adapter")), materialized.get(txn_id, set()),
            {k: prepare[k] for k in ("via", "session_ref", "launched") if k in prepare})


def _delivery_transitions(all_rows=None):
    # A caller may supply an already-fenced read-only snapshot.
    if all_rows is None:
        all_rows = rows()
    import recall
    recalled = recall.graph(all_rows)
    committed = ({row.get("txn-id") for row in all_rows
                  if row.get("kind") == "delivery-transaction"
                  and row.get("phase") == "commit"}
                 - {row.get("txn-id") for row in all_rows
                    if row.get("kind") == "delivery-transaction"
                    and row.get("phase") == "abort"})
    fetched = set()
    for row in all_rows:
        # A committed batch is durable before its individual rows materialize.
        # Replay that boundary so a late asynchronous POKED cannot resurrect it.
        if (row.get("kind") == "delivery-transaction" and row.get("phase") == "prepare"
                and row.get("event") == "FETCHED" and row.get("txn-id") in committed):
            for mid in row.get("msg-ids", []):
                if isinstance(mid, str):
                    fetched.add((row.get("seat"), mid))
                    yield mid, {**row, "kind": "delivery", "msg-id": mid}
        if row.get("kind") == "delivery":
            if row.get("txn-id") is not None and row.get("txn-id") not in committed:
                continue
            msg_id = row.get("msg-id")
            if isinstance(msg_id, str):
                key = (row.get("seat"), msg_id)
                if row.get("adapter") in {"inapp-socket", "agy-desktop", "launched"} and row.get("event") == "POKED" and key in fetched:
                    continue
                if row.get("event") == "FETCHED":
                    fetched.add(key)
                if msg_id not in recalled:
                    yield msg_id, row
    for msg_id, event in recalled.items():
        for seat in event['recipients']:
            yield msg_id, {'kind': 'delivery', 'msg-id': msg_id, 'seat': seat, 'event': 'RECALLED'}


def rows() -> list[Dict[str, Any]]:
    return _read_all(path())


def _read_all(jsonl_path: Path) -> list[Dict[str, Any]]:
    """Read every complete JSONL row, honoring store.read_jsonl batching."""
    found: list[Dict[str, Any]] = []
    offset = 0
    while True:
        batch, next_offset = store.read_jsonl(jsonl_path, offset)
        found.extend(batch)
        if next_offset == offset:
            return found
        offset = next_offset


def _select_messages(msg_ids: set[str]) -> dict[str, Dict[str, Any]]:
    """Stream the canonical log in bounded batches, retaining requested ids only."""
    selected: dict[str, Dict[str, Any]] = {}
    offset = 0
    while msg_ids - selected.keys():
        batch, next_offset = store.read_jsonl(store.LOG_FILE, offset)
        for row in batch:
            row_id = row.get("id")
            if row_id in msg_ids:
                selected[row_id] = row
        if next_offset == offset:
            break
        offset = next_offset
    return selected


def audit_nudges() -> list[Dict[str, Any]]:
    """Derive one crash-honest outcome per pre-write receipt."""
    all_rows = rows()
    posts = {row.get("event-id"): row for row in all_rows
             if row.get("kind") == "nudge" and row.get("phase") == "post"}
    reconciled = {row.get('event-id'): row for row in all_rows
                  if row.get('kind') == 'recall-reconciliation'}
    attempts = []
    for pre in all_rows:
        if pre.get("kind") != "nudge" or pre.get("phase") != "pre":
            continue
        post = posts.get(pre.get("event-id"))
        settlement = reconciled.get(pre.get('event-id'))
        attempts.append({
            "event-id": pre.get("event-id"),
            "outcome": (settlement or post or {}).get("result", "UNKNOWN"),
            "pre": pre, "post": post,
            **({'reconciliation': settlement} if settlement else {}),
        })
    return attempts


def outstanding_poke(seat: str) -> Dict[str, Any] | None:
    """Newest successful POKED row not followed by FETCHED for *seat*."""
    current = None
    for msg_id, row in _delivery_transitions():
        if row.get("seat") != seat:
            continue
        if row.get("event") == "POKED":
            current = {**row, "msg-id": msg_id}
        elif row.get("event") in {"FETCHED", "RECALLED"} and current is not None \
                and current.get("msg-id") == msg_id:
            current = None
    return current


def _pending_by_seat():
    states = {}
    for mid, row in _delivery_transitions():
        seat = row.get('seat')
        if isinstance(seat, str):
            states.setdefault(seat, {})[mid] = str(row.get('event', ''))
    return {seat: tuple(mid for mid, event in items.items() if event in {'QUEUED', 'POKED'})
            for seat, items in states.items()}


def pending_message_ids(seat: str) -> list[str]:
    from console_read_cache import memo
    cached = memo(('pending', str(path())), _pending_by_seat)
    if cached is not None:
        return list(cached.get(seat, ()))
    state: dict[str, str] = {}
    order: list[str] = []
    for msg_id, row in _delivery_transitions():
        if row.get("seat") != seat:
            continue
        if msg_id not in state:
            order.append(msg_id)
        state[msg_id] = str(row.get("event", ""))
    return [msg_id for msg_id in order if state.get(msg_id) in {"QUEUED", "POKED"}]


def _delivery_state(msg_id: str, seat: str) -> str | None:
    state = None
    for found_id, row in _delivery_transitions():
        if row.get("seat") == seat and found_id == msg_id:
            state = str(row.get("event", ""))
    return state


@contextmanager
def _nudge_lock():
    lock_path = path().with_suffix(".nudge.lock")
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with lock_path.open("a") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        yield


def mark_fetched(msg_ids: list[str], seat: str, *, adapter: str, metadata=None) -> None:
    """Journal consumption under the same lock as nudge injection."""
    with _nudge_lock():
        mark_fetched_unlocked(msg_ids, seat, adapter=adapter, metadata=metadata)


def mark_fetched_unlocked(msg_ids, seat, *, adapter, metadata=None):
    _recover_fetched_transactions_unlocked()
    import recall
    history = strict_rows()
    remaining = [msg_id for msg_id in msg_ids
                 if not recall.readers_at(history, msg_id, [seat])]
    _journal_fetched_batch(remaining, seat, adapter=adapter,
                           **({"metadata": metadata} if metadata is not None else {}))


def stage1(message: Dict[str, Any]) -> Dict[str, Any]:
    """The bounded fetch view; compatible with legacy pre-A.8 records."""
    import recall
    message = recall.project(message)
    result = {k: message.get(k) for k in ("id", "ts", "from", "to", "kind")}
    if message.get('actionable') is False:
        result.update({k: message[k] for k in ("status", "superseded_by", "actionable", "text", "withdrawal_notices")})
    result["envelope"] = message.get("envelope") or {}
    return result


def fetch(msg_id: str, seat: str) -> Dict[str, Any]:
    with _nudge_lock():
        _recover_fetched_transactions_unlocked()
        # Serialize the pending-set snapshot/FETCHED transition with poke
        # coalescing, so an adapter cannot observe a half-fetched set and emit
        # a duplicate poke in the middle of this fetch.
        pending_ids = pending_message_ids(seat)
        by_id = _select_messages({msg_id, *pending_ids})
        requested = by_id.get(msg_id)
        if requested is None:
            raise KeyError(f"unknown message: {msg_id}")
        if seat not in (requested.get("recipients") or requested.get("to") or []):
            raise PermissionError(f"{seat} is not a recipient of {msg_id}")
        resolved_ids = [mid for mid in pending_ids if mid in by_id]
        pending = [stage1(by_id[mid]) for mid in resolved_ids]
        # Never consume a receipt-only ID that was not actually returned.  It
        # remains pending for canonical-log repair or a later successful fetch.
        import recall
        if msg_id in recall.graph() and not recall.readers_at(strict_rows(), msg_id, [seat]):
            resolved_ids = list(dict.fromkeys([*resolved_ids, msg_id]))
        _journal_fetched_batch(resolved_ids, seat, adapter="mail")
        return {"message": stage1(requested), "pending": pending}


def inject_nudge(*, presented_token: str, expected_requester: str,
                 target_seat: str, msg_id: str,
                 exact_bytes: str, writer: Callable[[], tuple[bool, str]] | None,
                 route_kind: str = "tmux") -> tuple[bool, str]:
    """Authorize, receipt, and perform one nudge write at the chokepoint."""
    if route_kind == "launched":
        if writer is not None:
            return False, "launched_writer_is_daemon_owned"
        from launched_outbox import at_chokepoint
        return at_chokepoint(presented_token=presented_token,
            expected_requester=expected_requester, target_seat=target_seat,
            msg_id=msg_id, exact_bytes=exact_bytes)
    if route_kind == "inapp-socket":
        if writer is not None:
            return False, "inapp_writer_is_daemon_owned"
        from desktop_support import optional
        inapp_dispatch = optional('inapp_dispatch')
        if inapp_dispatch is None:
            return False, 'desktop_preview_unavailable'
        return inapp_dispatch.at_chokepoint(
            presented_token=presented_token, expected_requester=expected_requester,
            target_seat=target_seat, msg_id=msg_id, exact_bytes=exact_bytes)
    if route_kind == "agy-desktop":
        if writer is not None:
            return False, "agy_writer_is_daemon_owned"
        from desktop_support import optional
        agy_dispatch = optional('agy_dispatch')
        if agy_dispatch is None:
            return False, 'desktop_preview_unavailable'
        return agy_dispatch.at_chokepoint(
            presented_token=presented_token, expected_requester=expected_requester,
            target_seat=target_seat, msg_id=msg_id, exact_bytes=exact_bytes)

    if route_kind == "codex-ipc":
        if writer is not None:
            return False, "codex_writer_is_daemon_owned"
        from desktop_support import optional
        codex_dispatch = optional('codex_dispatch')
        if codex_dispatch is None:
            return False, 'desktop_preview_unavailable'
        return codex_dispatch.at_chokepoint(
            presented_token=presented_token, expected_requester=expected_requester,
            target_seat=target_seat, msg_id=msg_id, exact_bytes=exact_bytes)
    if route_kind != "tmux" or writer is None:
        return False, "unsupported_nudge_writer"
    requester, why = store.token_verdict(presented_token)
    if requester is None:
        return False, f"nudge_auth_{why}"
    role = requester.get("role")
    requester_id = requester.get("participant_id")
    if requester_id != expected_requester:
        return False, "nudge_auth_wrong_seat"
    # ``chief_of_staff`` is the registry's canonical spelling of the spec's
    # ``CoS`` role; caller-supplied aliases are never accepted.
    if role not in {"daemon", "chief_of_staff"} or not requester_id:
        return False, "nudge_requester_not_allowed"
    participant = store.load_participants().get(requester_id) or {}
    if role == "chief_of_staff" and participant.get("role") != "chief_of_staff":
        return False, "nudge_auth_stale_role"
    if role == "daemon" and (requester_id != store.DAEMON_SEAT
                              or participant.get("kind") != "system"):
        return False, "nudge_auth_wrong_daemon"
    with _nudge_lock():
        _recover_fetched_transactions_unlocked()
        # A drain may win the lock after the daemon observed this message but
        # before it attempted the poke.  Do not resurrect a consumed message.
        import recall
        if msg_id in recall.graph():
            return True, "recalled"
        if _delivery_state(msg_id, target_seat) == "FETCHED":
            return True, "already_fetched"
        outstanding = outstanding_poke(target_seat)
        retry = outstanding is not None and outstanding.get("msg-id") == msg_id
        if outstanding is not None and not retry:
            return True, "coalesced"
        if retry:
            previous_bytes = next((row.get("exact bytes") for row in reversed(rows())
                                   if row.get("kind") == "nudge"
                                   and row.get("phase") == "pre"
                                   and row.get("target seat") == target_seat
                                   and row.get("msg-id") == msg_id), None)
            if previous_bytes != exact_bytes:
                return False, "retry_bytes_mismatch"
        if not retry:
            # D-GOV-2 (f): a focus period defers a new poke and nothing else; the
            # outstanding poke's own retry above is never deferred.
            import focus
            if focus.deferring_unlocked(target_seat) is not None:
                return False, "focus_deferred"
        event_id = "evt-" + uuid.uuid4().hex
        _append({
            "kind": "nudge", "phase": "pre", "event-id": event_id,
            "requester": requester_id, "role": role, "target seat": target_seat,
            "msg-id": msg_id, "exact bytes": exact_bytes, "ts": store.now_iso(),
        })
        try:
            ok, detail = writer()
        except Exception:
            _append({"kind": "nudge", "phase": "post", "event-id": event_id,
                     "result": "failure", "ts": store.now_iso()})
            if retry:
                return True, "retry_failed_after_poke"
            raise
        _append({"kind": "nudge", "phase": "post", "event-id": event_id,
                 "result": "success" if ok else "failure", "ts": store.now_iso()})
        if ok and not retry:
            journal(msg_id, target_seat, "POKED", adapter="tmux")
        if retry and not ok:
            return True, "retry_failed_after_poke"
        return ok, detail
