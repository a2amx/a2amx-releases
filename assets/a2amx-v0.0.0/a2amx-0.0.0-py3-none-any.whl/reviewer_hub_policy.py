"""Narrow hub-output policy for sandboxed Codex reviewer seats.

Codex exec-policy rules allow these seats to run only ``orch --as <seat> send``
outside the read-only sandbox, through a provisioned isolated ``orch`` launcher.
The global rule file necessarily contains both explicit reviewer identities, so
this module binds the claimed identity to the caller's real process ancestry
before ``orch send`` may touch the store.  Caller-controlled tmux environment
variables are never identity evidence.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Mapping

import tmux_bridge


# No identity-based sandbox escape is shipped. Store token authentication still
# applies to every sender; deployments may retain their explicitly reviewed policy.
CODEX_REVIEWER_SEND_SEATS = ()


def reviewer_codex_home() -> Path:
    """Normalized active Codex config root shared by rule and launcher paths."""
    configured = os.environ.get("CODEX_HOME")
    if configured:
        return Path(configured).expanduser().resolve()
    return (Path.home() / ".codex").resolve()


def reviewer_command_path() -> Path:
    """Absolute path provisioned ahead of reviewer Codex seats on PATH."""
    return reviewer_codex_home() / "orch-reviewer-bin" / "orch"


def sender_binding_error(sender: str, participants: Mapping[str, Mapping[str, Any]],
                         *, process_id: int | None = None) -> str | None:
    """Return a fail-closed reason when a reviewer sender is not its tmux seat.

    Non-Codex-reviewer identities do not use the exec-policy escape and are
    outside this narrow check.  For an escaped reviewer send, every missing or
    unprovable binding refuses before the message store is called.
    """
    if sender not in CODEX_REVIEWER_SEND_SEATS:
        return None
    participant = participants.get(sender) or {}
    if participant.get("kind") != "agent" \
            or str(participant.get("family", "")).lower() != "codex" \
            or participant.get("channel") != "tmux":
        return f"reviewer sender {sender!r} is not a registered Codex tmux seat"
    expected_session = (participant or {}).get("tmux_session")
    if not expected_session:
        return f"reviewer sender {sender!r} has no registered tmux session"
    if not participant.get("tmux_socket"):
        return f"reviewer sender {sender!r} has no registered private tmux socket"
    session_owners = sorted(
        pid for pid, row in participants.items()
        if row.get("tmux_session") == expected_session
    )
    if session_owners != [sender]:
        return (f"reviewer tmux session {expected_session!r} is not uniquely bound "
                f"to {sender!r}: {session_owners!r}")
    caller_pid = process_id if process_id is not None else os.getpid()
    resolved = tmux_bridge.session_name_for_process(
        caller_pid, seat=sender, participants=participants)
    if not resolved.ok or not resolved.stdout:
        detail = resolved.stderr or "tmux returned no process ancestry"
        return f"cannot resolve reviewer process ancestry for pid {caller_pid}: {detail}"
    if resolved.stdout != expected_session:
        return (f"reviewer sender {sender!r} is bound to tmux session "
                f"{resolved.stdout!r}, not {expected_session!r}")
    return None
