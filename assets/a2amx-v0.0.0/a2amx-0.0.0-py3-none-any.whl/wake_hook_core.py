"""Harness-independent fetching hook. No environment, store or credential reads.

Endpoint.fetch must durably install the inbox before committing FETCHED and
returning. This module prints nothing itself, so cancellation before its caller
emits the completed string cannot leak a partial message or control object.
"""
from __future__ import annotations

from dataclasses import dataclass
import json
import math
import re
import time
from typing import Protocol

CLAUDE_OUTPUT_BYTES = 9500
CODEX_OUTPUT_BYTES = 8000
# Compatibility for the separately reviewed, unchanged Codex shim. The renderer
# always counts UTF-8 bytes; this legacy symbol is not a character-count setting.
CODEX_OUTPUT_CHARACTERS = CODEX_OUTPUT_BYTES
FETCH_DEADLINE_SECONDS = 10.0
POINTER_RE = re.compile(r"mail: msg-[0-9a-f]{10}\n?", re.ASCII)
PASS = 'PASS'
# The envelope's parts a delivery leaves out: the text's opening repeated, and bookkeeping.
ENVELOPE_REMOVED = ('bluf', 'v', 'triage')


@dataclass(frozen=True)
class Fetched:
    messages: list[dict]
    inbox_path: str
    neutral_grounding: bool = False
    activity_unconfirmed: bool = False


class Endpoint(Protocol):
    def post(self, pointer: str, session_ref, *, timeout: float) -> None: ...
    def fetch(self, session_ref, *, timeout: float) -> Fetched: ...


def _row_passes(row) -> bool:
    return isinstance(row, dict) and row.get('result') == PASS and row.get('disposition') == PASS


def _report(vet: dict):
    """The report as shown: None when wholly PASS, else without its PASS rows."""
    checks = vet.get('checks')
    if not isinstance(checks, list):
        return vet
    if (vet.get('verdict') == PASS and vet.get('disposition') == PASS
            and all(_row_passes(row) for row in checks)):
        return None
    return {**vet, 'checks': [row for row in checks if not _row_passes(row)]}


def delivery_view(message):
    """What a delivery prints of one stored message; the inbox file keeps the record whole.

    The view is the record less exactly these parts: the envelope's ``bluf``, ``v`` and
    ``triage``; the envelope's ``confirm`` when it is false; the displayed ``to`` when the typed
    ``recipients`` are present; and, of the validator's report (``vet``), all of it when its
    verdict, its disposition and every row are PASS, and otherwise only its PASS rows (the
    verdict, disposition, reason and every row that is not PASS are printed). Every other field
    is printed as stored, so each value in a view is the stored value at the same path, except
    that the report's printed rows are an order-preserving subsequence of its rows, whose indices
    may compact. A record, envelope or report of another shape is printed as stored. The
    argument is never modified.
    """
    if not isinstance(message, dict):
        return message
    shown = dict(message)
    envelope = shown.get('envelope')
    if isinstance(envelope, dict):
        shown['envelope'] = {key: value for key, value in envelope.items()
                             if key not in ENVELOPE_REMOVED
                             and not (key == 'confirm' and value is False)}
    vet = shown.get('vet')
    if isinstance(vet, dict):
        report = _report(vet)
        if report is None:
            del shown['vet']
        else:
            shown['vet'] = report
    if isinstance(shown.get('recipients'), list) and 'to' in shown:
        del shown['to']
    return shown


def dump_delivery_views(messages) -> str:
    """The views as one JSON array, as the hook frames them: every string escaped."""
    return json.dumps([delivery_view(m) for m in messages], ensure_ascii=True, separators=(',', ':'))


def pointer_line(prompt) -> str | None:
    if not isinstance(prompt, str) or POINTER_RE.fullmatch(prompt) is None:
        return None
    return prompt.removesuffix("\n")


def render(fetched: Fetched, *, budget: int) -> str:
    """Bound the *complete* output; omit whole texts, never slices of text.

    Each fetched message is printed as its delivery view; the inbox file the first line names
    keeps every record whole.

    The fixed non-JSON index prevents parsing as a harness control response.
    Newlines in message strings are JSON-escaped, so a body cannot impersonate
    this first line or become an unframed header from another sender.
    """
    if (type(budget) is not int or budget <= 0
            or type(fetched.neutral_grounding) is not bool
            or not isinstance(fetched.messages, list)
            or any(not isinstance(m, dict) for m in fetched.messages)
            or not isinstance(fetched.inbox_path, str)
            or not fetched.inbox_path.startswith("/")
            or any(ord(c) < 32 or ord(c) == 127 for c in fetched.inbox_path)):
        raise ValueError("invalid durable inbox result or budget")
    first = f"ORCH mail: {len(fetched.messages)} messages; inbox: {fetched.inbox_path}\n"
    warning = ('ORCH hook activity recording unconfirmed; mail fetch committed.\n'
               if fetched.activity_unconfirmed else '')
    notice = ('ORCH neutral grounding: no expectations adopted; nothing is compared.\n'
              if fetched.neutral_grounding else '')
    if len((first + notice + warning).encode("utf-8")) > budget:
        raise ValueError("inbox index exceeds output budget")
    messages = [delivery_view(m) for m in fetched.messages]

    def output():
        return first + json.dumps(messages, ensure_ascii=True, separators=(",", ":")) + "\n" + notice + warning

    candidate = output()
    # Removing the largest texts first preserves the most complete short rows.
    for idx in sorted(range(len(messages)), key=lambda i: len(json.dumps(messages[i].get("text", ""))), reverse=True):
        if len(candidate.encode("utf-8")) <= budget:
            return candidate
        if "text" in messages[idx]:
            del messages[idx]["text"]
            messages[idx]["text_in_inbox"] = True
            candidate = output()
    return candidate if len(candidate.encode("utf-8")) <= budget else first + notice + warning


def run(prompt, session_ref, endpoint: Endpoint, *, budget=CLAUDE_OUTPUT_BYTES,
        deadline_seconds=FETCH_DEADLINE_SECONDS, clock=time.monotonic) -> str:
    pointer = pointer_line(prompt)
    if pointer is None:
        return ""
    def failed():
        # Only failure asks the endpoint for local inbox metadata. No filesystem
        # or harness dependency enters this core and no error text is exposed.
        context = getattr(endpoint, 'failure_context', None)
        try:
            suffix = context() if context is not None else ''
        except Exception:
            suffix = ''  # Diagnostic failure cannot block the native prompt.
        return f"ORCH hook fetch failed: {pointer}{suffix}\n"
    if not isinstance(deadline_seconds, (int, float)) or not math.isfinite(deadline_seconds) or deadline_seconds <= 0:
        return failed()
    deadline = clock() + deadline_seconds
    try:
        # A failed/refused event post never prevents the authenticated fetch.
        try:
            endpoint.post(pointer, session_ref, timeout=max(0.001, deadline-clock()))
        except Exception:
            pass
        remaining = deadline-clock()
        if remaining <= 0:
            return failed()
        fetched = endpoint.fetch(session_ref, timeout=remaining)
        return render(fetched, budget=budget)
    except Exception:
        # Error text can contain credentials or harness paths; never echo it.
        return failed()


def run_prompt(prompt, session_ref, endpoint: Endpoint, *, budget=CLAUDE_OUTPUT_BYTES,
               deadline_seconds=FETCH_DEADLINE_SECONDS, clock=time.monotonic, post_pointer=True) -> str:
    """Fetch once for any prompt; only an exact pointer creates a seat event."""
    if post_pointer and pointer_line(prompt) is not None:
        return run(prompt, session_ref, endpoint, budget=budget,
                   deadline_seconds=deadline_seconds, clock=clock)
    if not isinstance(prompt, str):
        return ''
    try:
        if (not isinstance(deadline_seconds, (int, float)) or not math.isfinite(deadline_seconds)
                or deadline_seconds <= 0):
            raise ValueError('invalid deadline')
        fetched = endpoint.fetch(session_ref, timeout=deadline_seconds)
        output = render(fetched, budget=budget)
        return output if fetched.messages or fetched.neutral_grounding or fetched.activity_unconfirmed else ''
    except Exception:
        try:
            context = getattr(endpoint, 'failure_context', None)
            suffix = context() if context is not None else ''
        except Exception:
            suffix = ''
        return 'ORCH hook fetch failed for this prompt; fetch your inbox explicitly.' + suffix + '\n'
