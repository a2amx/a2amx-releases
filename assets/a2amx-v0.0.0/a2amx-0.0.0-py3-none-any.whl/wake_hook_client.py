"""Bounded CLI endpoint for the shared hook; never exports or prints a token."""
from __future__ import annotations

import json
import hashlib
import os
from pathlib import Path
import subprocess
import sys
import re
import stat
import time

from wake_hook_core import Fetched


def stderr_evidence(value):
    """Keep fixed product stderr, plus size/digest for arbitrary withheld bytes.

    Exception output can contain credentials. Only exact known product lines
    enter the hook's context; a hash never makes unknown text safe to echo.
    """
    raw = value if isinstance(value, bytes) else value.encode('utf-8', errors='replace') if isinstance(value, str) else b''
    known = {'hook fetch failed', 'hook event refused', 'AGY hook fetch failed'}
    lines = raw[:2048].decode('utf-8', errors='replace').splitlines()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'safe_lines': [line for line in lines if line in known][:3],
            'withheld': len(raw) > 2048 or any(line not in known for line in lines)}


class CliEndpoint:
    def __init__(self, home, command=None):
        self.home = Path(home)
        self.started_ns = time.time_ns()
        self.command = tuple(command) if command is not None else (sys.executable, '-I', '-m', 'orch_cli')
        self.failure_stage = None
        self.failure_reason = None
        self.step_evidence = []

    def failure_context(self):
        """Metadata-only hint, not proof of consumption or of the file's contents.

        Never follow links or read a batch. The recipient must verify its id in
        its own inbox; another overlapping hook may have written the newest file.
        """
        directory = self.home / '.orch' / 'inbox'
        newest = None
        descriptors = []
        try:
            if not self.home.is_absolute() or self.home.resolve() != self.home:
                raise ValueError('noncanonical hook home')
            flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
            descriptors.append(os.open(self.home, flags))
            for child in ('.orch', 'inbox'):
                descriptors.append(os.open(child, flags, dir_fd=descriptors[-1]))
            candidates = []
            with os.scandir(descriptors[-1]) as entries:
                for entry in entries:
                    if re.fullmatch(r'hook-(?:[0-9]{8}T[0-9]{6}\.[0-9]{6}Z-)?[0-9a-f]{32}\.json', entry.name) is None:
                        continue
                    info = entry.stat(follow_symlinks=False)
                    if (stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid()
                            and info.st_mtime_ns >= self.started_ns):
                        candidates.append((info.st_mtime_ns, entry.name))
            if candidates:
                newest = str(directory / max(candidates)[1])
        except (OSError, ValueError):
            pass  # Directory still named even when no safe candidate is visible.
        finally:
            for fd in reversed(descriptors):
                os.close(fd)
        step = ('; step: ' + self.failure_stage + '; reason: ' + self.failure_reason
                if self.failure_stage in {'post', 'fetch'} and self.failure_reason in
                {'timeout', 'spawn', 'command_refused', 'invalid_response'} else '')
        evidence = ('; evidence: ' + json.dumps(self.step_evidence[-2:], separators=(',', ':'))
                    if self.step_evidence else '')
        return (step + '; inbox: ' + json.dumps(str(directory), ensure_ascii=True)
                + '; newest: ' + (json.dumps(newest, ensure_ascii=True) if newest else 'none') + evidence)

    def _call(self, action, value, timeout):
        # Token FILE is explicit on each command; no token value enters argv/env.
        env = {k: v for k, v in os.environ.items() if k not in {'ORCH_TOKEN','ORCH_TOKEN_FILE','ORCH_AGENT'}}
        arguments = [action] if isinstance(action, str) else list(action)
        self.failure_stage = 'fetch' if action == 'hook-fetch' else 'post' if action == 'seat-event' else None
        self.failure_reason = None
        started = time.monotonic()
        child_stderr = b''
        returncode = None
        try:
            try:
                result = subprocess.run([*self.command, '--token-file', str(self.home/'.orch/token'), *arguments],
                                        input=json.dumps(value), text=True, capture_output=True,
                                        cwd=self.home, env=env, timeout=timeout)
                child_stderr = result.stderr
                returncode = result.returncode
            except subprocess.TimeoutExpired as exc:
                child_stderr = exc.stderr
                self.failure_reason = 'timeout'
                raise
            except OSError:
                self.failure_reason = 'spawn'
                raise
            if result.returncode:
                self.failure_reason = 'command_refused'
                try:
                    err = json.loads(result.stdout)
                    r = err.get('reason')
                    allowed = {'event_schema', 'event_kind', 'invalid_pointer', 'seat_mismatch', 'session_ref_mismatch'}
                    reason = r if isinstance(r, str) and r in allowed else 'unknown'
                except Exception:
                    reason = 'invalid_response'
                raise RuntimeError(f'hook store command refused: {reason}')
            try:
                return json.loads(result.stdout)
            except (ValueError, TypeError):
                self.failure_reason = 'invalid_response'
                raise
        finally:
            if self.failure_stage is not None:
                self.step_evidence.append({'step': self.failure_stage,
                    'elapsed_ms': round(max(0.0, time.monotonic()-started)*1000),
                    'budget_ms': round(timeout*1000), 'returncode': returncode,
                    'outcome': self.failure_reason or 'response_received',
                    'stderr': stderr_evidence(child_stderr)})
                self.step_evidence = self.step_evidence[-2:]

    def grounding(self, seat, *, timeout):
        return self._call(['seat', 'grounding-show', seat], None, timeout)

    def post(self, pointer, session_ref, *, timeout):
        self._call('seat-event', {'event':'UserPromptSubmit', 'pointer':pointer,
                                 'session_ref':session_ref, 'session_id':self.session_id}, timeout)

    def fetch(self, session_ref, *, timeout):
        value = {'session_ref': session_ref, 'home': str(self.home)}
        if getattr(self, 'harness', None) is not None:
            value['harness'] = self.harness
        result = self._call('hook-fetch', value, timeout)
        if not result.get('accepted', True):
            r = result.get('reason')
            if r == 'session_ref_mismatch':
                raise ValueError('invalid selector')
            allowed = {'session_ref_mismatch'}
            reason = r if isinstance(r, str) and r in allowed else 'unknown'
            raise RuntimeError(f"hook store command refused: {reason}")
        self.route_bound = result.get('route_bound') is True
        return Fetched(result['messages'], result['inbox_path'],
                       neutral_grounding=result.get('neutral_grounding') is True,
                       activity_unconfirmed=(result.get('activity_reported') is False
                                             or result.get('harness_reported') is False))
