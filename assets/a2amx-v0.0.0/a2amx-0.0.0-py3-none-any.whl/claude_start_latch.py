"""Operator-only, exact-file disposition of a Claude startup latch.

This local file tool grants no authority: the operator must already have a
recorded disposition and keep the session quiescent. It never invokes a hook,
changes a route, retries a declaration or contacts the store/native app.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import uuid

import product_identity

LIMIT = 4096


def _private(info, *, directory=False):
    return ((stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode))
            and info.st_uid == os.getuid() and not info.st_mode & 0o077)


def _read(fd):
    info = os.fstat(fd)
    if not _private(info) or info.st_size > LIMIT:
        raise ValueError('latch_not_private_regular_bounded')
    data = os.read(fd, LIMIT + 1)
    if len(data) > LIMIT:
        raise ValueError('latch_too_large')
    if len(data) != info.st_size or not _same(info, os.fstat(fd)):
        raise ValueError('latch_short_read_or_changed')
    return data, info


def _same(a, b):
    fields = ('st_dev','st_ino','st_uid','st_mode','st_size','st_mtime_ns','st_ctime_ns')
    return all(getattr(a, k) == getattr(b, k) for k in fields)


def dispose(home, name, *, expected_sha256=None, disposition_sha256=None, apply=False):
    home = Path(home)
    if not home.is_absolute() or home.resolve(strict=True) != home or not home.is_dir():
        raise ValueError('canonical_existing_home_required')
    if not re.fullmatch(r'\.[A-Za-z0-9_-]+-session-start\.stop', name):
        raise ValueError('exact_startup_latch_name_required')
    for value in (expected_sha256, disposition_sha256):
        if value is not None and re.fullmatch(r'[a-f0-9]{64}', value) is None:
            raise ValueError('sha256_required')
    if apply and (expected_sha256 is None or disposition_sha256 is None):
        raise ValueError('apply_requires_latch_and_disposition_digests')
    directory = home/'.claude'
    if directory.resolve(strict=True) != directory:
        raise ValueError('hook_directory_symlink')
    parent = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    locks = []
    latch = None
    try:
        # Hook folders can be 0755; reject foreign ownership and write access.
        info = os.fstat(parent)
        if info.st_uid != os.getuid() or info.st_mode & 0o022:
            raise ValueError('hook_directory_owner_or_mode')
        if apply:
            # Coordinate with both the current product hook and the old
            # hook which owned a selected legacy latch. All locks are nonblocking.
            for lock_name in sorted({'.'+product_identity.command()+'-session-start.lock', name[:-5]+'.lock'}):
                lock = os.open(lock_name, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600, dir_fd=parent)
                locks.append(lock)
                if not _private(os.fstat(lock)):
                    raise ValueError('startup_lock_owner_type_or_mode')
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        latch = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
        data, before = _read(latch)
        actual = hashlib.sha256(data).hexdigest()
        if expected_sha256 is not None and expected_sha256 != actual:
            raise ValueError('latch_digest_changed')
        result = {'home':str(home), 'latch':name, 'sha256':actual, 'apply':apply,
                  'scope':'local latch only; no route change or retry'}
        if not apply:
            return result
        # Archive both original bytes and the operator's disposition reference
        # durably BEFORE removing the blocking name. Never overwrite evidence.
        archive_name = 'startup-disposition-'+uuid.uuid4().hex
        os.mkdir(archive_name, 0o700, dir_fd=parent)
        archive = os.open(archive_name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
        try:
            record = {**result, 'disposition_sha256':disposition_sha256,
                      'recorded_at':datetime.now(timezone.utc).isoformat(),
                      'state':'archived_before_clear'}
            for filename, content in [('latch', data), ('record.json', (json.dumps(record,sort_keys=True)+'\n').encode())]:
                fd = os.open(filename, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=archive)
                try:
                    if os.write(fd, content) != len(content):
                        raise OSError('incomplete_archive_write')
                    os.fsync(fd)
                finally:
                    os.close(fd)
            os.fsync(archive)
        finally:
            os.close(archive)
        os.fsync(parent)
        # A cooperating startup is excluded by its same named lock. Recheck
        # non-cooperating changes too, without claiming a filesystem-wide CAS.
        if (directory.resolve(strict=True) != directory
                or os.stat(directory).st_ino != os.fstat(parent).st_ino
                or not _same(before, os.stat(name, dir_fd=parent, follow_symlinks=False))):
            raise ValueError('latch_or_directory_changed; archive_retained')
        os.unlink(name, dir_fd=parent)
        os.fsync(parent)
        return {**result, 'state':'cleared', 'archive':str(directory/archive_name)}
    finally:
        if latch is not None: os.close(latch)
        for lock in reversed(locks): os.close(lock)
        os.close(parent)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--home', type=Path, required=True)
    parser.add_argument('--name', required=True)
    parser.add_argument('--expected-sha256')
    parser.add_argument('--disposition-sha256')
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args(argv)
    try:
        value = dispose(args.home, args.name, expected_sha256=args.expected_sha256,
                        disposition_sha256=args.disposition_sha256, apply=args.apply)
    except Exception:
        # Filesystem errors can include private paths/bytes. Do not echo them.
        print('Latch disposition refused or unconfirmed; preserve any archive and inspect the exact latch.',file=__import__('sys').stderr)
        return 1
    print(json.dumps(value,sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
