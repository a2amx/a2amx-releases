"""R2 §6: map recorded courier references, never user-supplied filesystem paths."""
import os
from pathlib import Path
import re

from console_files import digest, directory, packet, read


def root():
    configured = os.environ.get('PSQR_CONSOLE_COURIER_DIR')
    return Path(configured) if configured else None


def references(body, courier_root=None):
    base = Path(courier_root) if courier_root is not None else root()
    if base is None:
        return []
    # Only the configured root and its documented home-relative spelling.
    prefixes = [str(base)]
    try:
        prefixes.append('~/' + str(base.relative_to(Path.home())))
    except ValueError:
        pass
    prefix = '|'.join(re.escape(s) for s in prefixes)
    pattern = re.compile(r'(?<![\w/:])(?:' + prefix + r')/([^\s<>`"\]\)]+)')
    matches = list(pattern.finditer(body))
    refs = []
    for index, match in enumerate(matches):
        recorded = match[0].rstrip('.,;:')
        relative = match[1].rstrip('.,;:').rstrip('/')
        # Do not truncate a traversal/member/URL into an apparently safe packet.
        safe = re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', relative) is not None and relative not in {'.', '..'}
        stop = matches[index + 1].start() if index + 1 < len(matches) else len(body)
        context = body[match.end():min(stop, match.end() + 700)]
        pins = re.findall(r'\bSHA256SUMS\s*[:=]?\s*`?([a-fA-F0-9]{64})\b', context)
        pins = list(dict.fromkeys(pin.lower() for pin in pins))
        refs.append({'recorded_path': recorded, 'packet': relative if safe else None,
                     'claimed_pin': pins[0] if len(pins) == 1 else None,
                     'claim_status': 'recorded claim' if len(pins) == 1 else 'missing or ambiguous claim',
                     'mapping': 'read-only packet mapping' if safe else 'refused unsafe packet path'})
    return refs


def inspect_reference(messages, message_id, reference_index, *, courier_root=None):
    base = Path(courier_root) if courier_root is not None else root()
    if base is None:
        return {'status': 'unavailable', 'verification': 'unavailable',
                'error': 'Courier unavailable: set PSQR_CONSOLE_COURIER_DIR.'}
    matching = [m for m in messages if m.get('id') == message_id]
    if len(matching) != 1:
        raise ValueError('message id is missing or ambiguous')
    base = Path(courier_root) if courier_root is not None else root()
    body = matching[0].get('text')
    refs = references(body if isinstance(body, str) else '', base)
    if not 0 <= reference_index < len(refs):
        raise ValueError('recorded courier reference not found')
    reference = refs[reference_index]
    result = {**reference, 'measured_pin': None, 'verification': 'unverified', 'members': {}}
    if not reference['packet']:
        return {**result, 'verification': 'refused unsafe packet path'}
    try:
        with directory(base, reference['packet']) as fd:
            result['measured_pin'] = digest(read(fd, 'SHA256SUMS', limit=1024 * 1024))
            check, contents = packet(fd)
        result['measured_pin'] = check['manifest_sha256']
        result['members'] = check['members']
        result['pin_matches'] = (reference['claimed_pin'] == result['measured_pin']) if reference['claimed_pin'] else None
        result['verification'] = ('member hash mismatch' if not check['verified'] else
                                  'verified: claim and all manifest members match' if result['pin_matches'] else
                                  'claim mismatch: all manifest members match' if reference['claimed_pin'] else
                                  'members verified; no unique claimed pin')
        # Documents remain literal text, including HTML. Binary members get a
        # hash/size only; no file download URL or inline executable content.
        result['documents'] = []
        budget = 1024 * 1024
        for name, data in contents.items():
            if Path(name).suffix.lower() not in {'.md', '.txt', '.html', '.json', '.csv'}:
                continue
            if len(data) > min(budget, 256 * 1024):
                continue
            try:
                text = data.decode('utf-8')
            except UnicodeError:
                continue
            result['documents'].append({'name': name, 'text': text, 'sha256': digest(data)})
            budget -= len(data)
        result['document_notice'] = 'Literal text preview, up to 256 KiB per document / 1 MiB total; other members remain in the hash table.'
    except (OSError, ValueError, UnicodeError):
        result['verification'] = 'refused or unavailable: unsafe, missing, changing or over-limit packet'
    return result
