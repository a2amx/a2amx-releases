"""Telemetry — read-only projections over the trace ledger (META_HARNESS_PLAN Stage 4).

Pure READ side: never writes, never mutates. Projects the append-only ledger into the operational
views the operator (and the future evolution agent, §3.5) read — activity/idle roles, tool usage,
governance verdicts, convergence signals, and call->result latency. Everything derives from
``ledger.read_events``; partial coverage is fine (the schema tolerates sparse tool telemetry until
the adapters fill it in). Each function accepts an explicit ``events`` list (pure/testable) or reads
the live ledger when omitted.

    python3 telemetry.py        # prints the full report as JSON
"""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime
from typing import Any, Dict, List, Optional

import ledger
import store


def _events(events: Optional[List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    return events if events is not None else ledger.read_events()[0]


def counts_by_kind(events: Optional[List[Dict[str, Any]]] = None) -> Dict[str, int]:
    """Event count per ledger kind."""
    return dict(Counter(e.get("kind") for e in _events(events)))


def actor_activity(events: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Dict[str, Any]]:
    """Per actor: event count + last-seen ts (+ role) — the basis for idle-role detection."""
    out: Dict[str, Dict[str, Any]] = {}
    for e in _events(events):
        actor = e.get("actor_id") or "?"
        rec = out.setdefault(actor, {"events": 0, "last_ts": "", "role": e.get("role")})
        rec["events"] += 1
        ts = e.get("ts", "")
        if ts > rec["last_ts"]:                 # ISO-8601 sorts lexically
            rec["last_ts"] = ts
    return out


def idle_actors(events: Optional[List[Dict[str, Any]]] = None, *,
                among: Optional[List[str]] = None) -> List[str]:
    """Registered participants (or the ``among`` pool) with ZERO ledger events — silent roles."""
    active = set(actor_activity(events))
    pool = set(among) if among is not None else set(store.load_participants())
    return sorted(pool - active)


def tool_usage(events: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Dict[str, int]]:
    """tool_call counts per actor per tool name."""
    out: Dict[str, Counter] = defaultdict(Counter)
    for e in _events(events):
        if e.get("kind") == "tool_call":
            out[e.get("actor_id", "?")][(e.get("payload") or {}).get("tool_name", "?")] += 1
    return {actor: dict(c) for actor, c in out.items()}


def governance(events: Optional[List[Dict[str, Any]]] = None) -> Dict[str, int]:
    """permission_decision verdict counts (allow / deny / escalate)."""
    return dict(Counter((e.get("payload") or {}).get("verdict") for e in _events(events)
                        if e.get("kind") == "permission_decision"))


def convergence(events: Optional[List[Dict[str, Any]]] = None) -> Dict[str, int]:
    """convergence_signal counts by signal (converged / contested / cleared / dead_end / …)."""
    return dict(Counter((e.get("payload") or {}).get("signal") for e in _events(events)
                        if e.get("kind") == "convergence_signal"))


def _parse(ts: str) -> Optional[datetime]:
    try:
        return datetime.fromisoformat(ts)
    except Exception:
        return None


def corr_latencies(events: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, Any]]:
    """call->result latency for each tool_result paired to its tool_call by corr_id (the call's
    id). ``ms`` is None when either ts is unparseable. Best-effort; unpaired results are skipped."""
    evs = _events(events)
    calls = {e["id"]: e for e in evs if e.get("kind") == "tool_call" and e.get("id")}
    out: List[Dict[str, Any]] = []
    for e in evs:
        if e.get("kind") != "tool_result":
            continue
        call = calls.get(e.get("corr_id"))
        if call is None:
            continue
        t0, t1 = _parse(call.get("ts", "")), _parse(e.get("ts", ""))
        ms = int((t1 - t0).total_seconds() * 1000) if (t0 and t1) else None
        out.append({"call_id": call["id"], "actor": call.get("actor_id"),
                    "tool": (call.get("payload") or {}).get("tool_name"),
                    "ok": (e.get("payload") or {}).get("ok"), "ms": ms})
    return out


def report(events: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """The full read-only projection set in one dict."""
    evs = _events(events)
    return {
        "total": len(evs),
        "by_kind": counts_by_kind(evs),
        "by_actor": actor_activity(evs),
        "idle_actors": idle_actors(evs),
        "tool_usage": tool_usage(evs),
        "governance": governance(evs),
        "convergence": convergence(evs),
        "latencies": corr_latencies(evs),
    }


if __name__ == "__main__":
    import json
    print(json.dumps(report(), indent=2, ensure_ascii=False))
