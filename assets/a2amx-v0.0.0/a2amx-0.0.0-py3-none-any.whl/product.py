"""Selected names behind the installer product/version interface.

The installer-facing API stays stable; the values come from the same packaged
profile as CLI usage, state paths and rendered kits, not a second rename table.
"""
from importlib import metadata
import json
import re

from product_identity import ProfileError, load

_PROFILE = load()
COMMAND = _PROFILE.command()
DISTRIBUTION = _PROFILE.distribution


def installed_version():
    try:
        return metadata.version(DISTRIBUTION)
    except metadata.PackageNotFoundError:
        return None


def installed_build():
    if not _PROFILE.is_public:
        return None
    try:
        distribution = metadata.distribution(DISTRIBUTION)
        raw = distribution.read_text('extra_metadata/quovisto-build.json')
        if raw is None or len(raw.encode()) > 16384:
            raise ValueError('missing or oversized')
        def unique(pairs):
            result = {}
            for key, value in pairs:
                if key in result:
                    raise ValueError('duplicate key')
                result[key] = value
            return result
        value = json.loads(raw, object_pairs_hook=unique)
        fields = {'schema', 'public_version', 'internal_version', 'source_commit',
                  'snapshot_commit', 'snapshot_tree', 'snapshot_manifest_sha256'}
        if (not isinstance(value, dict) or set(value) != fields
                or value['schema'] != 'quovisto.wheel-origin.v1'
                or value['public_version'] != distribution.version
                or not isinstance(value['internal_version'], str)
                or re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+', value['internal_version']) is None):
            raise ValueError('shape or version')
        for field, size in [('source_commit', 40), ('snapshot_commit', 40),
                            ('snapshot_tree', 40), ('snapshot_manifest_sha256', 64)]:
            if not isinstance(value[field], str) or re.fullmatch('[a-f0-9]{'+str(size)+'}', value[field]) is None:
                raise ValueError('pin')
        return value
    except (OSError, ValueError, TypeError, metadata.PackageNotFoundError):
        raise ProfileError('public_build_origin_invalid_or_missing') from None


def version_line():
    version = installed_version()
    if _PROFILE.is_public:
        build = installed_build()
        return (f'{COMMAND} {version} (internal {build["internal_version"]}; '
                f'snapshot {build["snapshot_commit"]})')
    return (f'{COMMAND} version unknown (not installed as a package)' if version is None
            else f'{COMMAND} {version}')
