"""Product seat-kit preparation; never installs machine rules or starts an app.

Read-only previews intentionally avoid the store's lock-creating authenticated
act. Writes recheck current credentials and registry roles under its locks.
"""
from __future__ import annotations

import stage1_features

import hashlib
import json
from pathlib import Path

import receipts
import store
import seat_grounding
import product_identity
from desktop_support import optional as optional_desktop
inapp_hookset = optional_desktop('inapp_hookset')
from provision import machine

CODEX_RECORD = 'codex-seat-install'
# All historical prefixes retain their stop condition; new kits use STOP_NAME.
LEGACY_STOP_SUFFIX = '-session-start.stop'
INSTALL_REFUSAL_REASONS = frozenset({
    'settings_changed_since_read', 'install_directory_owner_mode_or_type',
    'invalid_install_intent', 'multiple_unresolved_install_intents',
    'installed_hook_entries_invalid', 'installed_managed_hook_not_unique',
    'install_settings_type_owner_or_bound', 'install_preimage_missing',
    'install_preimage_invalid', 'install_preimage_changed', 'install_directory_changed',
    'startup_template_marker', 'installed_permissions_invalid', 'install_file_changed',
    'install_post_write_mismatch', 'install_expected_generation_invalid',
    'registered_home_mismatch', 'provision_from_outside_target_home',
    'prior_start_failure_requires_disposition', 'unreceipted_installed_record',
    'stale_install_generation', 'install_expected_generation_required',
    'install_local_source_names_unsupported', 'unresolved_install_intent_changed',
    'unrecorded_or_changed_install_file', 'unresolved_install_render_changed',
    'install_render_file_bound', 'unsupported_home_spelling', 'noncanonical_or_missing_home',
    'interpreter_path_invalid', 'interpreter_file_unsafe', 'interpreter_changed_during_read',
    'interpreter_product_import_failed', 'interpreter_product_origin_mismatch',
    'interpreter_changed_during_probe', 'install_provisioner_credential_required',
    'codex_install_record_invalid', 'codex_active_seat_required', 'codex_roster_empty',
    'codex_candidate_changed', 'codex_install_generation_stale',
    'codex_install_generation_required', 'codex_candidate_changed_during_preparation',
    'codex_hook_settings_invalid', 'codex_hook_managed_entry_changed',
    'codex_seat_home_unavailable',
    'remove_generation_required', 'remove_stale_generation', 'remove_plan_invalid',
    'remove_settings_changed', 'remove_pending_install', 'remove_seat_required',
    'claude_desktop_kit_requires_inapp_seat',
    'product_command_profile_mismatch',
})


def refusal_reason(error):
    """Expose fixed product reasons, never arbitrary exception data or paths."""
    reason = str(error)
    return reason if reason in INSTALL_REFUSAL_REASONS else 'managed_state_invalid'


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     ensure_ascii=True, allow_nan=False).encode()).hexdigest()


def preview_actor(token):
    actor, reason = (store._verdict_unlocked(token, store._read_tokens_unlocked())
                     if token else (None, 'missing'))
    if actor is None:
        raise store.RegistryMutationRefused('install_auth_' + reason,
                                           'current provisioner required')
    parts = store._read_participants_unlocked()
    store._require_current_provisioner(actor, parts)
    return actor['participant_id'], parts


def codex_record(destination):
    """Validate the durable CAS chain; corrupted history never becomes absence."""
    current = None
    fields = {'kind', 'destination', 'candidate', 'sha256', 'roster',
              'grounding_generations', 'previous_generation', 'generation', 'requester', 'ts'}
    for row in receipts.rows():
        if row.get('kind') != CODEX_RECORD or row.get('destination') != destination:
            continue
        if (set(row) != fields or row['previous_generation'] !=
                (current['generation'] if current else 'none')
                or row['generation'] != digest({k: v for k, v in row.items() if k != 'generation'})):
            raise ValueError('codex_install_record_invalid')
        current = row
    return current


def codex_install(*, presented_token, seat=None, dry_run=False, replace=None):
    """Render the complete registered roster; installation stays a human step."""
    stage1_features.require_private('codex_desktop')
    def apply(actor):
        parts = store._read_participants_unlocked()
        if seat is not None:
            row = parts.get(seat, {})
            if (row.get('kind') != 'agent' or store.inactive_participant(row)
                    or store.normalize_family(row.get('family')) != 'codex'):
                raise ValueError('codex_active_seat_required')
        plan = machine.generate_rules(parts, dry_run=True)
        if not plan['roster']:
            raise ValueError('codex_roster_empty')
        expectations = {name: seat_grounding.current(name, required=False) for name in plan['roster']}
        grounding = {name: value['generation'] if value else None for name, value in expectations.items()}
        # Even a dry-run must diagnose a damaged content-addressed candidate.
        path = machine.canonical_path(plan['candidate'])
        data = machine.render_rules(plan['roster'])
        if path.exists() or path.is_symlink():
            if inapp_hookset.read_file(str(path), len(data)) != data:
                raise ValueError('codex_candidate_changed')
        current = codex_record(plan['destination'])
        generation = current['generation'] if current else 'none'
        if replace is not None and replace != generation:
            raise ValueError('codex_install_generation_stale')
        if current and replace is None and not dry_run:
            raise ValueError('codex_install_generation_required')
        hook = None
        if seat is not None:
            import sys
            stage1_features.require_private('codex_desktop')
            import wake_hook_install_codex
            from agy_runtime import qualify
            if seat not in plan['roster']:
                raise ValueError('codex_seat_home_unavailable')
            home = Path(plan['roster'][seat]).parent.parent
            python = str(Path(sys.executable).absolute())
            hook = wake_hook_install_codex.plan(home, python=python)
            hook['runtime'] = qualify(python, modules=('wake_hook_codex', 'orch_cli'))
        result = {**plan, 'kind': 'codex', 'dry_run': dry_run,
                  'grounding_generations': grounding,
                  'neutral_grounding_to_create': [name for name, value in expectations.items() if value is None],
                  'workspace_hook': hook,
                  'installed_generation': generation,
                  'generation': 'assigned-at-commit',
                  'writes': [{'path': str(path), 'sha256': plan['sha256'],
                              'content': data.decode(), 'operation': 'reuse' if path.exists() else 'create'}],
                  'human_acts': [
                      'Verify the candidate hash and install it at ' + plan['destination']
                      + '; preserve the previous file and retire the two legacy seat rule files.',
                      'Restart the Codex app once to load the rules.'],
                  'qualification': 'Candidate only; no machine installation, app restart or route declaration.'}
        if hook is not None:
            result['human_acts'].append(hook['manual_step'])
            result['qualification'] = ('Workspace prompt hook and machine rules candidate only; '
                'no trust change, machine-rule installation, app restart or native invocation proof.')
        if dry_run:
            return result
        for name in result['neutral_grounding_to_create']:
            grounding[name] = seat_grounding.install_default(name, actor)['generation']
        if hook is not None:
            wake_hook_install_codex.publish(hook)
        # Registry/token locks serialize this act with role changes and other
        # candidate writers. Publication is immutable; a receipt failure may
        # leave an unused candidate, never a false installation record.
        generated = machine.generate_rules(parts)
        if generated['sha256'] != plan['sha256'] or generated['candidate'] != str(path):
            raise ValueError('codex_candidate_changed_during_preparation')
        record = {'kind': CODEX_RECORD, 'destination': plan['destination'],
                  'candidate': str(path), 'sha256': plan['sha256'], 'roster': plan['roster'],
                  'grounding_generations': grounding,
                  'previous_generation': generation, 'requester': actor, 'ts': store.now_iso()}
        record['generation'] = digest(record)
        with receipts._nudge_lock():
            receipts._append(record)
        result['generation'] = record['generation']
        return result
    if dry_run:
        actor, _ = preview_actor(presented_token)
        return apply(actor)
    return store.authenticated_registry_act(presented_token, apply, provisioning=True)


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _json(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True)+'\n').encode()


def _directory(path):
    import os
    import stat
    machine.canonical_path(path)
    info = path.stat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o022:
        raise ValueError('install_directory_owner_mode_or_type')


def _pending_install(seat, rows):
    pending = []
    for item in rows:
        if item.get('kind') != 'claude-seat-install-intent' or item.get('seat') != seat:
            continue
        if item.get('digest') != digest({k:v for k,v in item.items() if k != 'digest'}):
            raise ValueError('invalid_install_intent')
        reference = {'reference': item['id'], 'sha256': item['digest']}
        if not any(r.get('kind') == 'inapp-hookset' and r.get('event') == 'provisioned'
                   and r.get('seat') == seat
                   and r.get('record', {}).get('spec', {}).get('installer_receipt') == reference for r in rows):
            pending.append(item)
    if len(pending) > 1:
        raise ValueError('multiple_unresolved_install_intents')
    return pending[0] if pending else None


def _replace_managed_hooks(settings, home, startup, desired, *, prompt=None):
    """Recognize the two recorded generation-2/3 commands, never delete peers."""
    import shlex
    for event, new_groups in desired.items():
        groups = settings.get('hooks', {}).get(event)
        if not isinstance(groups, list):
            raise ValueError('installed_hook_entries_invalid')
        found = 0
        updated = []
        for group in groups:
            if not isinstance(group, dict) or not isinstance(group.get('hooks'), list):
                raise ValueError('installed_hook_entries_invalid')
            remaining = []
            removed = False
            for hook in group['hooks']:
                if not isinstance(hook, dict):
                    raise ValueError('installed_hook_entries_invalid')
                args = shlex.split(hook.get('command', ''))
                managed = (hook.get('type') == 'command' and
                    ((event == 'SessionStart' and len(args) == 3 and args[1:] == ['-I', str(home/'.claude'/startup)])
                     or (event == 'UserPromptSubmit' and
                         ((len(args) == 6 and args[1:] == ['-I', '-m', 'wake_hook_claude', '--home', str(home)])
                          or (prompt is not None and args[1:] == ['-I', str(home/'.claude'/prompt)])))))
                if managed:
                    found += 1
                    removed = True
                else:
                    remaining.append(hook)
            if remaining or not removed:
                updated.append({**group, 'hooks': remaining})
        if found != 1:
            raise ValueError('installed_managed_hook_not_unique')
        settings['hooks'][event] = updated + new_groups


def _removed_settings_image(before, record, row, home):
    """Derive removal output from a receipt-bound settings preimage."""
    if _sha(before) != record['spec']['settings']['sha256']:
        raise ValueError('remove_settings_changed')
    settings = json.loads(before)
    if not isinstance(settings, dict) or settings.get('hooks') != record['spec']['settings']['entries']:
        raise ValueError('remove_settings_changed')
    names = inapp_hookset.local_hook_names({**row, inapp_hookset.FIELD: record}, home)
    startup = next(n for n in names if n.endswith('.py') and not n.endswith('_prompt_hook.py'))
    prompt = next((n for n in names if n.endswith('_prompt_hook.py')), None)
    _replace_managed_hooks(settings, home, startup, {'SessionStart': [], 'UserPromptSubmit': []}, prompt=prompt)
    for event in ('SessionStart', 'UserPromptSubmit'):
        if not settings['hooks'][event]:
            settings['hooks'].pop(event)
    if not settings['hooks']:
        settings.pop('hooks')
    return _json(settings)


def _retired_settings_hash(directory, seat, record, row, home):
    parent = directory / '.orch-install-preimages'
    _directory(parent)
    path = parent / (record['generation'] + '.remove.json')
    plan = json.loads(inapp_hookset.read_file(str(path), 2*inapp_hookset.MAX_SPEC_BYTES+2048))
    if (not isinstance(plan, dict) or set(plan) != {'schema', 'seat', 'generation', 'before', 'after'}
            or plan['schema'] != 'orch.claude-removal.v1' or plan['seat'] != seat
            or plan['generation'] != record['generation']
            or not isinstance(plan['before'], str) or not isinstance(plan['after'], str)):
        raise ValueError('remove_plan_invalid')
    after = _removed_settings_image(plan['before'].encode(), record, row, home)
    if plan['after'].encode() != after:
        raise ValueError('remove_plan_invalid')
    return _sha(after)


def _settings_snapshot(path):
    """Bounded inspected bytes and metadata, not exclusion of later writers."""
    import os
    import stat
    machine.canonical_path(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        if (not stat.S_ISREG(before.st_mode) or before.st_uid != os.getuid()
                or before.st_mode & 0o022 or before.st_size > inapp_hookset.MAX_SPEC_BYTES):
            raise ValueError('install_settings_type_owner_or_bound')
        data = stream.read(inapp_hookset.MAX_SPEC_BYTES + 1)
        after = os.fstat(stream.fileno())
        if (len(data) > inapp_hookset.MAX_SPEC_BYTES or len(data) != before.st_size
                or (before.st_mode, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
                != (after.st_mode, after.st_size, after.st_mtime_ns, after.st_ctime_ns)):
            raise ValueError('settings_changed_since_read')
    return data, {'mode': stat.S_IMODE(before.st_mode), 'mtime_ns': before.st_mtime_ns}


def _validate_preimage(directory, intent, prior_hash):
    """An interrupted replacement must retain its original inspected version."""
    import re
    ref = intent.get('settings_preimage')
    if ref is None:
        if prior_hash is not None:
            raise ValueError('install_preimage_missing')
        return
    if (not re.fullmatch(r'seat-install-[0-9a-f]{32}', intent.get('id', ''))
            or not isinstance(ref, dict) or set(ref) != {'path', 'sha256', 'mode', 'mtime_ns'}
            or ref['path'] != str(directory/'.orch-install-preimages'/(intent['id']+'.settings.json'))
            or ref['sha256'] != prior_hash or not isinstance(prior_hash, str)
            or type(ref['mode']) is not int or type(ref['mtime_ns']) is not int):
        raise ValueError('install_preimage_invalid')
    _directory(directory/'.orch-install-preimages')
    data, metadata = _settings_snapshot(Path(ref['path']))
    if _sha(data) != ref['sha256'] or any(metadata[k] != ref[k] for k in metadata):
        raise ValueError('install_preimage_changed')


def _preserve_settings(directory, intent, data):
    """Durably save the inspected version before intent and managed publication.

    A failed write is retained for inspection; never overwrite an earlier copy.
    This cannot capture an external edit made after the inspected snapshot.
    """
    import os
    ref = intent['settings_preimage']
    if ref is None:
        return
    _directory(directory)
    parent = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        try: os.mkdir('.orch-install-preimages', mode=0o700, dir_fd=parent)
        except FileExistsError: pass
        backup = directory/'.orch-install-preimages'
        _directory(backup)
        fd = os.open('.orch-install-preimages', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
        try:
            name = intent['id']+'.settings.json'
            out = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=fd)
            with os.fdopen(out, 'wb') as stream:
                stream.write(data)
                stream.flush()
                os.fchmod(stream.fileno(), ref['mode'])
                os.utime(stream.fileno(), ns=(ref['mtime_ns'], ref['mtime_ns']))
                os.fsync(stream.fileno())
            os.fsync(fd)
            os.fsync(parent)
            for path, held in ((directory, parent), (backup, fd)):
                info, opened = path.lstat(), os.fstat(held)
                if (info.st_ino, info.st_dev) != (opened.st_ino, opened.st_dev):
                    raise ValueError('install_directory_changed')
        finally:
            os.close(fd)
    finally:
        os.close(parent)
    _validate_preimage(directory, intent, ref['sha256'])


def _render_claude(seat, home, names, catalog, existing_settings, *, managed_removed=False,
                   startup_recovery='legacy', command_name=None):
    import copy
    import shlex
    import sys
    import claude_hook_interface as interface
    import claude_session_start
    from agy_runtime import qualify
    profile = product_identity.load()
    startup = next(n for n in names if n.endswith('.py') and not n.endswith('_prompt_hook.py'))
    prompt = next((n for n in names if n.endswith('_prompt_hook.py')), None)
    if bool(prompt) != profile.is_public:
        raise ValueError('product_command_profile_mismatch')
    pins = next(n for n in names if n.endswith('.json'))
    template = interface.read_bytes(Path(claude_session_start.__file__).resolve())
    marker = b"CONFIG_NAME = 'orch-runtime-pins.json'"
    if template.count(marker) != 1:
        raise ValueError('startup_template_marker')
    source = template.replace(marker, ('CONFIG_NAME = '+repr(pins)).encode())
    prefix_marker = b"PRODUCT_PREFIX = 'orch'"
    if source.count(prefix_marker) != 1:
        raise ValueError('startup_template_marker')
    source = source.replace(prefix_marker, ('PRODUCT_PREFIX = '+repr(profile.command())).encode())
    python = Path(sys.executable).absolute()
    runtime = interface.ROOT.resolve()
    # Match the template's supported command spelling rather than invent a
    # broad shell permission for a path the hook itself would refuse.
    try:
        for value in (str(home), str(runtime), str(Path.home().resolve())):
            claude_session_start.canonical_home(value)
    except claude_session_start.Stop as exc:
        raise ValueError(str(exc)) from None
    # Exercise the same isolated interpreter spelling that the hooks will use.
    # Importing the SessionStart module also executes its standard-library
    # imports, without invoking its main function or accessing a native session.
    command_name = profile.command() if command_name is None else command_name
    if command_name != profile.command():
        raise ValueError('product_command_profile_mismatch')
    qualified = qualify(python, modules=('wake_hook_claude', 'claude_session_start', 'orch_cli', 'product_identity'),
                        root=runtime)
    if startup_recovery not in {'legacy', 'held-v1'}:
        raise ValueError('claude_startup_recovery_invalid')
    config = {'schema': 'orch.claude-runtime-pins.v3', 'seat': seat, 'home': str(home),
              'startup_recovery_policy': startup_recovery,
              'interface': catalog, 'runtime_root': str(runtime),
              'python': qualified['python'], 'python_realpath': qualified['python_realpath'],
              'python_sha256': qualified['python_sha256'],
              'account_home': str(Path.home().resolve()), 'session_start_sha256': _sha(source),
              'product_identity': {
                  'profile_sha256': profile.sha256,
                  'module_sha256': _sha(interface.read_bytes(runtime/'product_identity.py')),
                  'commands': dict(profile.commands), 'home_directory': profile.home_directory}}
    hooks = {
        'SessionStart': [{'matcher': 'startup|resume|compact', 'hooks': [{'type': 'command',
            'command': shlex.join([str(python), '-I', str(home/'.claude'/startup)]), 'timeout': claude_session_start.HOOK_TIMEOUT_SECONDS}]}],
        'UserPromptSubmit': [{'hooks': [{'type': 'command',
            'command': shlex.join([str(python), '-I', '-m', 'wake_hook_claude', '--home', str(home)]), 'timeout': 20}]}]}
    prompt_source = None
    if prompt is not None:
        import public_hook_claude
        prompt_source = interface.read_bytes(Path(public_hook_claude.__file__).resolve())
        brand_marker = b"BRAND = 'Quovisto'"
        if prompt_source.count(brand_marker) != 1:
            raise ValueError('startup_template_marker')
        prompt_source = prompt_source.replace(brand_marker, ('BRAND = '+repr(profile.display_name)).encode())
        config_marker = b"CONFIG_NAME = 'quovisto-runtime-pins.json'"
        if prompt_source.count(config_marker) != 1:
            raise ValueError('startup_template_marker')
        prompt_source = prompt_source.replace(config_marker, ('CONFIG_NAME = '+repr(pins)).encode())
        config['prompt_hook_name'] = prompt
        config['prompt_hook_sha256'] = _sha(prompt_source)
        hooks['UserPromptSubmit'][0]['hooks'][0]['command'] = shlex.join(
            [str(python), '-I', str(home/'.claude'/prompt)])
    settings = copy.deepcopy(existing_settings) if existing_settings is not None else {'hooks': hooks}
    if existing_settings is not None:
        if managed_removed:
            # Only the receipt-bound, rederived removal image reaches this path.
            # Append this kit's missing groups without replacing unrelated hooks.
            retained = settings.setdefault('hooks', {})
            for event, groups in hooks.items():
                retained.setdefault(event, []).extend(groups)
        else:
            _replace_managed_hooks(settings, home, startup, hooks, prompt=prompt)
    permissions = settings.setdefault('permissions', {})
    if not isinstance(permissions, dict):
        raise ValueError('installed_permissions_invalid')
    allowed = permissions.setdefault('allow', [])
    if not isinstance(allowed, list) or not all(isinstance(x, str) for x in allowed):
        raise ValueError('installed_permissions_invalid')
    denied = permissions.setdefault('deny', [])
    if not isinstance(denied, list) or not all(isinstance(x, str) for x in denied):
        raise ValueError('installed_permissions_invalid')
    read = shlex.join([str(python), '-I', '-m', 'orch_read', '--token-file',
                       str(home/'.orch/token'), seat])
    for rule in (f'Bash({profile.command("read")} --token-file {home}/.orch/token {seat})',
                 f'Bash({command_name} --token-file {home}/.orch/token send:*)',
                 f'Bash({command_name} --token-file {home}/.orch/token seat grounding-show {seat})',
                 f'Bash({read})'):
        if rule not in allowed:
            allowed.append(rule)
    cli = shlex.join([str(python), '-I', '-m', 'orch_cli'])
    credential = shlex.join(['--token-file', str(home/'.orch/token')])
    # D-CRED-4: fixed prefixes and word-bounded suffixes include --resume,
    # without denying adjacent commands such as principal password measure.
    for prefix in (command_name, f'{command_name} {credential}', cli, f'{cli} {credential}'):
        for command in ('principal recover', 'principal password set'):
            rule = f'Bash({prefix} {command}:*)'
            if rule not in denied:
                denied.append(rule)
    result = {startup: source, pins: _json(config), 'settings.json': _json(settings)}
    if prompt_source is not None:
        result[prompt] = prompt_source
    return result


def _publish(directory, contents, expected):
    """Held-directory writes, settings last; interruption is retained, not hidden.

    The durable intent authorizes only an explicit same-generation recovery.
    Each file must still be an inspected old hash or the exact intended bytes.
    Checked replacement cannot exclude an external writer between read/rename.
    """
    import os
    import stat
    import uuid
    if not directory.exists():
        directory.mkdir(mode=0o700)
        parent = os.open(directory.parent, os.O_RDONLY)
        try: os.fsync(parent)
        finally: os.close(parent)
    _directory(directory)
    fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        identity = os.fstat(fd)
        for name, data in contents.items():  # renderer inserts settings last
            current = directory.lstat()
            if (current.st_ino, current.st_dev) != (identity.st_ino, identity.st_dev) or directory.resolve() != directory:
                raise ValueError('install_directory_changed')
            path = directory/name
            old = inapp_hookset.read_file(str(path), inapp_hookset.MAX_SPEC_BYTES) if path.exists() or path.is_symlink() else None
            if old == data:
                continue
            if (_sha(old) if old is not None else None) not in expected[name]:
                raise ValueError('settings_changed_since_read' if name == 'settings.json' else 'install_file_changed')
            if old is None:
                out = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=fd)
                with os.fdopen(out, 'wb') as stream:
                    stream.write(data); stream.flush(); os.fsync(stream.fileno())
            else:
                stage = '.orch-install-'+uuid.uuid4().hex
                try:
                    out = os.open(stage, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=fd)
                    with os.fdopen(out, 'wb') as stream:
                        stream.write(data); stream.flush(); os.fsync(stream.fileno())
                    if inapp_hookset.read_file(str(path)) != old:
                        raise ValueError('settings_changed_since_read' if name == 'settings.json' else 'install_file_changed')
                    os.replace(stage, name, src_dir_fd=fd, dst_dir_fd=fd)
                finally:
                    try: os.unlink(stage, dir_fd=fd)
                    except FileNotFoundError: pass
            os.fsync(fd)
        _directory(directory)
        if (directory.stat().st_ino, directory.stat().st_dev) != (identity.st_ino, identity.st_dev):
            raise ValueError('install_directory_changed')
        for name, data in contents.items():
            if inapp_hookset.read_file(str(directory/name)) != data:
                raise ValueError('install_post_write_mismatch')
    finally:
        os.close(fd)


def claude_install(*, presented_token, seat, dry_run=False, replace=None, startup_recovery=None):
    import os
    import uuid
    import claude_hook_interface as interface
    if not isinstance(seat, str) or not store.PARTICIPANT_ID_RE.fullmatch(seat):
        raise ValueError('Claude seat required')
    if replace is not None and replace != 'none' and not interface.is_digest(replace):
        raise ValueError('install_expected_generation_invalid')
    if startup_recovery not in {None, 'legacy', 'held-v1'}:
        raise ValueError('claude_startup_recovery_invalid')

    def apply(actor):
        parts = store._read_participants_unlocked()
        row = seat_grounding.active_seat(seat, parts)
        if store.normalize_family(row.get('family')) != 'claude':
            raise ValueError('Claude seat required')
        # The desktop start hook declares an in-app socket. A terminal seat
        # needs the separate claude-cli grounding/prompt hooks instead. Check
        # both legacy and explicit hosting markers, including mixed records.
        # apply() is also the write-time check under the provisioner locks.
        if row.get('channel') == 'tmux' or row.get('hosting_kind') == 'tmux-hosted':
            raise ValueError('claude_desktop_kit_requires_inapp_seat')
        grounding = seat_grounding.current(seat, required=False)
        grounding_generation = grounding['generation'] if grounding else None
        home = machine.canonical_path(row.get('provisioned_home', ''))
        _directory(home)
        if inapp_hookset._home(seat, row) != home:
            raise ValueError('registered_home_mismatch')
        if Path.cwd() == home or home in Path.cwd().parents:
            raise ValueError('provision_from_outside_target_home')
        directory = home/'.claude'
        if directory.exists() or directory.is_symlink():
            _directory(directory)
        # Conservatively retain stop files from every earlier prefix, including
        # dangling links. Compatibility does not embed a private seat identity.
        if directory.exists():
            with os.scandir(directory) as entries:
                if any(entry.name.startswith('.') and entry.name.endswith(LEGACY_STOP_SUFFIX)
                       for entry in entries):
                    raise ValueError('prior_start_failure_requires_disposition')
        old = row.get(inapp_hookset.FIELD)
        rows = receipts.rows()
        if old is not None:
            inapp_hookset.validate_record(old, seat, row, measure=False)
            if not any(r.get('kind') == 'inapp-hookset' and r.get('event') == 'provisioned'
                       and r.get('seat') == seat and r.get('record') == old for r in rows):
                raise ValueError('unreceipted_installed_record')
        generation = old['generation'] if old else 'none'
        if replace is not None and replace != generation:
            raise ValueError('stale_install_generation')
        pending = _pending_install(seat, rows)
        if grounding is None and (old is not None or pending is not None):
            raise seat_grounding.Refused('grounding_record_missing')
        if (old is not None or pending is not None) and replace is None and not dry_run:
            raise ValueError('install_expected_generation_required')
        retired = inapp_hookset.retired_record(seat, row, rows) if old is None else None
        source_record = old or retired
        names_row = {**row, inapp_hookset.FIELD: source_record} if source_record else row
        names = inapp_hookset.local_hook_names(
            names_row, home)
        public = product_identity.is_public()
        if (len(names) != (3 if public else 2)
                or sum(n.endswith('.py') for n in names) != (2 if public else 1)
                or (public and sum(n.endswith('_prompt_hook.py') for n in names) != 1)):
            raise ValueError('install_local_source_names_unsupported')
        pins = next(n for n in names if n.endswith('.json'))
        paths = [directory/n for n in (*names, 'settings.json')]
        before = {p.name: inapp_hookset.read_file(str(p), inapp_hookset.MAX_SPEC_BYTES)
                  if p.exists() or p.is_symlink() else None for p in paths}
        settings_metadata = None
        if before['settings.json'] is not None:
            snapshot, settings_metadata = _settings_snapshot(directory/'settings.json')
            if snapshot != before['settings.json']:
                raise ValueError('settings_changed_since_read')
        hashes = {Path(item['path']).name: item['sha256'] for item in source_record['spec']['hook_sources']
                  if Path(item['path']).parent == directory} if source_record else {}
        if old:
            hashes['settings.json'] = old['spec']['settings']['sha256']
        elif (retired and before['settings.json'] is not None
              and (pending is None or pending.get('settings_preimage') is not None)):
            # A local .remove.json is not authority on its own. Its before bytes
            # must hash to the receipted record and its after bytes are rederived.
            hashes['settings.json'] = _retired_settings_hash(directory, seat, retired, row, home)
        expected = {p.name: {hashes.get(p.name)} for p in paths}
        if retired:
            for name, values in expected.items():
                if before[name] is None:
                    values.add(None)  # Cleanup already observed before this act.
        prior_settings_hash = hashes.get('settings.json')
        if retired:
            ref = pending.get('settings_preimage') if pending else None
            prior_settings_hash = (ref.get('sha256') if isinstance(ref, dict) else None) if pending else (
                _sha(before['settings.json']) if before['settings.json'] is not None else None)
            if prior_settings_hash not in expected['settings.json']:
                raise ValueError('install_preimage_invalid')
        if pending:
            if (pending.get('home') != str(home) or pending.get('previous_generation') != generation
                    or pending.get('grounding_generation') != grounding_generation
                    or set(pending.get('files', {})) != set(before)):
                raise ValueError('unresolved_install_intent_changed')
            for name, sha in pending['files'].items():
                if not interface.is_digest(sha): raise ValueError('invalid_install_intent')
                expected[name].add(sha)
        for name, data in before.items():
            if (_sha(data) if data is not None else None) not in expected[name]:
                raise ValueError('unrecorded_or_changed_install_file')
        existing = json.loads(before['settings.json']) if before['settings.json'] is not None else None
        catalog = interface.deployed()
        render_options = ({'managed_removed': True}
                          if retired and before['settings.json'] is not None
                          and _sha(before['settings.json']) == hashes.get('settings.json') else {})
        policy = startup_recovery
        if policy is None:
            prior_config = json.loads(before[pins]) if before[pins] is not None else {}
            policy = prior_config.get('startup_recovery_policy', 'legacy')
        if policy != 'legacy':
            render_options['startup_recovery'] = policy
        contents = _render_claude(seat, home, names, catalog, existing, **render_options)
        if any(len(data) > inapp_hookset.MAX_SPEC_BYTES for data in contents.values()):
            raise ValueError('install_render_file_bound')
        # A source pin alone cannot identify an installation. Seal the local
        # config to its predecessor, including a retired predecessor on reinstall.
        # This is deterministic across preview/apply and interrupted publication,
        # but changes on every completed replacement, even with identical code.
        config = json.loads(contents[pins])
        config['installation_id'] = digest({
            'schema': 'orch.claude-installation.v1', 'seat': seat, 'home': str(home),
            'previous_hookset_generation': (source_record or {}).get('generation', 'none'),
            'rendered_files': {name: _sha(data) for name, data in contents.items()},
        })
        contents[pins] = _json(config)
        intended = {name: _sha(data) for name, data in contents.items()}
        if pending and pending['files'] != intended:
            raise ValueError('unresolved_install_render_changed')
        # Validate the prospective bytes and complete qualification before a
        # successful preview or any durable intent/file publication. Local
        # sources share the tighter replacement pre-read bound, even though
        # the general hook-source reader would admit larger files.
        if any(len(data) > inapp_hookset.MAX_SPEC_BYTES for data in contents.values()):
            raise ValueError('install_render_file_bound')
        intent = pending or {'kind': 'claude-seat-install-intent', 'id': 'seat-install-'+uuid.uuid4().hex,
                  'seat': seat, 'home': str(home), 'previous_generation': generation,
                  'grounding_generation': grounding_generation, 'files': intended,
                  'actor': actor, 'ts': store.now_iso()}
        if pending is None:
            intent['settings_preimage'] = ({'path': str(directory/'.orch-install-preimages'/(intent['id']+'.settings.json')),
                'sha256': _sha(before['settings.json']), **settings_metadata}
                if before['settings.json'] is not None else None)
            intent['digest'] = digest(intent)
        else:
            _validate_preimage(directory, intent, prior_settings_hash)
        settings = json.loads(contents['settings.json'])
        spec = {'schema': inapp_hookset.SCHEMA_V2, 'seat': seat, 'home': str(home), 'interface': catalog,
                'hook_sources': [{'path': str(directory/n), 'sha256': intended[n]} for n in names]
                    + [{'path': str(interface.ROOT/n), 'sha256': catalog['sources'][n]} for n in sorted(interface.CLIENT_SOURCES)],
                'settings': {'path': str(directory/'settings.json'), 'sha256': intended['settings.json'], 'entries': settings['hooks']},
                'installer_receipt': {'reference': intent['id'], 'sha256': intent['digest']}}
        inapp_hookset.validate_spec(spec, seat, names_row, measure=False)
        result = {'kind': 'claude', 'seat': seat, 'home': str(home), 'dry_run': dry_run,
                  'installed_generation': generation, 'grounding_generation': grounding_generation,
                  'neutral_grounding_to_create': grounding is None,
                  'catalog_digest': interface.digest(catalog),
                  'writes': [{'path': str(directory/name), 'sha256': intended[name], 'content': data.decode(),
                              'operation': 'replace' if before[name] is not None else 'create'} for name, data in contents.items()],
                  'resuming_intent': pending['id'] if pending else None,
                  'settings_preimage': intent.get('settings_preimage'),
                  'operator_condition': 'Install on a quiescent seat, with no prompt in flight and the app not mid-edit; this condition is not detected or attested.',
                  'human_acts': ['Open the registered folder once in the Claude app; accept folder/hook trust if prompted.'],
                  'qualification': 'Installed bytes and v2 record only; SessionStart refresh and native invocation are separate.'}
        if dry_run:
            return result
        if grounding is None:
            grounding = seat_grounding.install_default(seat, actor)
            intent['grounding_generation'] = grounding['generation']
            intent['digest'] = digest({k: v for k, v in intent.items() if k != 'digest'})
            spec['installer_receipt']['sha256'] = intent['digest']
            result['grounding_generation'] = grounding['generation']
        if pending is None:
            _preserve_settings(directory, intent, before['settings.json'])
            with receipts._nudge_lock(): receipts._append(intent)
        _publish(directory, contents, expected)
        recorded = inapp_hookset.provision(seat, spec, presented_token=presented_token, expected_generation=generation)
        return {**result, **recorded, 'generation': recorded['record']['generation']}

    if dry_run:
        actor, _ = preview_actor(presented_token)
        return apply(actor)
    return store.authenticated_registry_act(presented_token, apply, provisioning=True)


def claude_remove(*, presented_token, seat, dry_run=False, replace=None):
    """Remove verified hook entries; preserve credentials and recovery evidence."""
    def apply(actor):
        parts = store._read_participants_unlocked()
        row = parts.get(seat) or {}
        home = inapp_hookset._home(seat, row)
        _directory(home)
        directory = home/'.claude'
        history = receipts.rows()
        if _pending_install(seat, history) is not None:
            raise ValueError('remove_pending_install')
        record = row.get(inapp_hookset.FIELD)
        active = record is not None
        if record is None:
            record = next((r.get('record') for r in reversed(history)
                           if r.get('kind')=='inapp-hookset' and r.get('event')=='provisioned'
                           and r.get('seat')==seat), None)
        if record is None:
            return {'kind':'claude','seat':seat,'dry_run':dry_run,'remove':True,
                    'changed':False,'action':'no_recorded_installation','generation':'none',
                    'qualification':'No recorded kit; no files were removed.'}
        inapp_hookset.validate_removal_record(record, seat, row)
        if not any(r.get('kind')=='inapp-hookset' and r.get('event')=='provisioned'
                   and r.get('seat')==seat and r.get('record')==record for r in history):
            raise ValueError('unreceipted_installed_record')
        generation = record['generation']
        plan_path = directory/'.orch-install-preimages'/(generation+'.remove.json')
        if not active and not plan_path.exists():
            return {'kind':'claude','seat':seat,'dry_run':dry_run,'remove':True,
                    'changed':False,'action':'no_recorded_installation','generation':'none',
                    'qualification':'No current kit or removal plan; no files were removed.'}
        if replace is None and not dry_run:
            raise ValueError('remove_generation_required')
        if replace is not None and replace != generation:
            raise ValueError('remove_stale_generation')
        _directory(directory)
        settings_path = directory/'settings.json'
        current, _ = _settings_snapshot(settings_path)
        if plan_path.exists() or plan_path.is_symlink():
            plan = json.loads(inapp_hookset.read_file(str(plan_path), 2*inapp_hookset.MAX_SPEC_BYTES+2048))
            if (not isinstance(plan,dict) or set(plan) != {'schema','seat','generation','before','after'}
                    or plan['schema']!='orch.claude-removal.v1' or plan['seat']!=seat
                    or plan['generation']!=generation or not isinstance(plan['before'],str)
                    or not isinstance(plan['after'],str)):
                raise ValueError('remove_plan_invalid')
            before = plan['before'].encode()
        else:
            before = current
        after = _removed_settings_image(before, record, row, home)
        proposed = {'schema':'orch.claude-removal.v1','seat':seat,'generation':generation,
                    'before':before.decode(),'after':after.decode()}
        if plan_path.exists() and plan != proposed:
            raise ValueError('remove_plan_invalid')
        if current not in (before,after):
            raise ValueError('remove_settings_changed')
        result = {'kind':'claude','seat':seat,'remove':True,'dry_run':dry_run,
                  'generation':generation,'installed_generation':generation if active else 'none',
                  'changed':active or current!=after,'action':'remove_managed_hooks',
                  'writes':[{'path':str(settings_path),'sha256':_sha(after),'content':after.decode()}],
                  'recovery_plan':str(plan_path),
                  'leaves':['account and seat token','messages and receipts','grounding record',
                            'source/pins, allow rules, stop latches and preimages','wake route and native credential'],
                  'human_acts':['Clear the seat wake route under its own credential first.',
                                'Close/reopen the app session and verify the removed hooks no longer run.'],
                  'qualification':'Configuration removal, not native pickup or process termination.'}
        if dry_run:return result
        # Persist the exact before/after plan before any managed effect. On
        # interruption only those two settings images remain admissible.
        if not plan_path.exists():
            _publish(plan_path.parent,{plan_path.name:_json(proposed)},{plan_path.name:{None}})
        if current != after:
            _publish(directory,{'settings.json':after},{'settings.json':{_sha(before),_sha(after)}})
        result['receipt'] = inapp_hookset.retire(seat,record,presented_token=presented_token)
        return result
    if dry_run:
        actor,_ = preview_actor(presented_token)
        return apply(actor)
    return store.authenticated_registry_act(presented_token,apply,provisioning=True)


def codex_remove(*, presented_token, seat, dry_run=False, replace=None):
    """Remove the named workspace hook; global rules and credentials remain."""
    stage1_features.require_private('codex_desktop')
    def apply(actor):
        stage1_features.require_private('codex_desktop')
        import wake_hook_install_codex
        parts=store._read_participants_unlocked();row=parts.get(seat) or {}
        if not seat or row.get('kind')!='agent' or store.normalize_family(row.get('family'))!='codex':
            raise ValueError('remove_seat_required')
        home=machine.canonical_path(row.get('provisioned_home',''))
        _directory(home)
        rules=machine.generate_rules(parts,dry_run=True)
        record=codex_record(rules['destination'])
        generation=record['generation'] if record else 'none'
        if replace is None and not dry_run:raise ValueError('remove_generation_required')
        if replace is not None and replace!=generation:raise ValueError('remove_stale_generation')
        proposed=wake_hook_install_codex.plan(home,remove=True)
        result={'kind':'codex','seat':seat,'remove':True,'dry_run':dry_run,
                'generation':generation,'installed_generation':generation,'workspace_hook':proposed,
                'leaves':['machine rules and candidates','account and seat token','messages and receipts',
                          'grounding record','wake route and app trust state'],
                'human_acts':['Clear the seat wake route under its own credential first.',
                              'Close/reopen the app session to reload hook configuration.'],
                'qualification':'Workspace configuration only; no global rule or native-process change.'}
        if not dry_run:wake_hook_install_codex.publish(proposed)
        return result
    if dry_run:
        actor,_=preview_actor(presented_token)
        return apply(actor)
    return store.authenticated_registry_act(presented_token,apply,provisioning=True)
