"""Shared fail-closed validation for registry-declared private tmux sockets."""

from __future__ import annotations

import os
from collections.abc import Mapping
from pathlib import Path
from typing import Any


def registered_socket(seat: str, registry: Mapping[str, Mapping[str, Any]]) -> str:
    """Return the normalized private socket uniquely and safely owned by ``seat``."""
    participant = registry.get(seat)
    if not isinstance(participant, Mapping) or participant.get("hosting_kind") != "tmux-hosted":
        raise ValueError(f"seat {seat!r} is not registered tmux-hosted")
    socket_value = participant.get("tmux_socket")
    if not isinstance(socket_value, str) or not socket_value.strip():
        raise ValueError("registered tmux_socket must be a non-empty absolute path")
    socket_path = Path(socket_value)
    try:
        resolved_socket = socket_path.resolve(strict=False)
        leaf_is_symlink = socket_path.is_symlink()
        ancestor_is_symlink = any(parent.is_symlink() for parent in socket_path.parents)
    except (OSError, RuntimeError) as exc:
        raise ValueError("registered tmux_socket cannot be safely resolved") from exc
    if not socket_path.is_absolute() or leaf_is_symlink or ancestor_is_symlink \
            or os.path.normpath(socket_value) != socket_value \
            or str(resolved_socket) != socket_value:
        raise ValueError("registered tmux_socket must be an absolute non-symlink path")
    owners = sorted(
        name for name, row in registry.items()
        if isinstance(row, Mapping) and row.get("tmux_socket") == socket_value)
    if owners != [seat]:
        raise ValueError(f"registered tmux_socket is not uniquely owned by {seat!r}: {owners!r}")
    return socket_value


def registered_session(participant: Mapping[str, Any]) -> str:
    """Return a clean registry-declared tmux session name."""
    session = participant.get("tmux_session")
    if not isinstance(session, str) or not session.strip() \
            or session != session.strip() or "\0" in session:
        raise ValueError("registered tmux_session must be a clean non-empty string")
    return session
