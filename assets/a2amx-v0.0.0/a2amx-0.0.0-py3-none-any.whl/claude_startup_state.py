"""Bounded local startup reports, copied to durable store observations.

Files are read outside shared store fences. A second authenticated transaction
rechecks the registered home/hookset before publication. This observes a local
report; it does not authenticate native model behavior or change a wake route.
"""
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat

import receipts
import store
import product_identity

ENABLE_ENV = 'ORCH_CLAUDE_HELD_RECOVERY_ENABLED'
POLICY = 'claude-held-v1'
KIND = 'claude-startup'
FILENAME = '.'+product_identity.command()+'-session-start-evidence.jsonl'
MAX_BYTES = 1024 * 1024
MAX_ROW = 2048
LEGACY_FIELDS = {'schema','id','seat','source','state','reason','recorded_at',
                 'declaration_state','source_sha256'}
FIELDS = LEGACY_FIELDS | {'installation_sha256'}


def enabled():
    return os.environ.get(ENABLE_ENV) == '1'


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def _object(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError('duplicate field')
        value[key] = item
    return value


def _record_pins(record, seat, home):
    if (not isinstance(record, dict) or not isinstance(record.get('spec'), dict)
            or not re.fullmatch('[a-f0-9]{64}', str(record.get('generation', '')))):
        return []
    spec = record['spec']
    if (spec.get('seat') != seat or spec.get('home') != home
            or record.get('digest') != _digest(spec)
            or record['generation'] != _digest({k:v for k,v in record.items() if k!='generation'})):
        return []
    sources = spec.get('hook_sources', [])
    if not isinstance(sources, list):
        return []
    return sorted(item['sha256'] for item in sources if isinstance(item, dict)
                  and isinstance(item.get('path'), str)
                  and Path(item['path']).parent == Path(home)/'.claude'
                  and Path(item['path']).suffix == '.py'
                  and re.fullmatch('[a-f0-9]{64}', str(item.get('sha256', ''))))


def _installation(record, seat, home):
    sources = _record_pins(record, seat, home)
    if not sources:
        return None
    configs = sorted(item['sha256'] for item in record['spec']['hook_sources']
                     if isinstance(item, dict) and isinstance(item.get('path'), str)
                     and Path(item['path']).parent == Path(home)/'.claude'
                     and Path(item['path']).suffix == '.json'
                     and re.fullmatch('[a-f0-9]{64}', str(item.get('sha256', ''))))
    return {'source_pins': sources, 'installation_pins': configs} if configs else None


def _binding(seat, row, parts, history):
    if not isinstance(row, dict):
        return None
    home = row.get('provisioned_home')
    if (row.get('kind') != 'agent' or store.inactive_participant(row)
            or store.normalize_family(row.get('family')) != 'claude'
            or not isinstance(home, str) or not Path(home).is_absolute()
            or str(Path(home)) != home or '..' in Path(home).parts
            or sum(isinstance(p, dict) and p.get('provisioned_home') == home for p in parts.values()) != 1):
        return None
    record = row.get('inapp_hookset') or {}
    current = _installation(record, seat, home)
    if current is None:
        return None
    historical = {}
    for r in history:
        if r.get('kind')=='inapp-hookset' and r.get('event')=='provisioned' and r.get('seat')==seat:
            prior = _installation(r.get('record'), seat, home)
            if prior is not None and prior != current:
                historical[_digest(prior)] = prior
    return {'seat': seat, 'home': home, 'generation': record.get('generation'),
            **current, 'historical_installations': [historical[k] for k in sorted(historical)]}


def _valid(value, binding, *, legacy=False):
    if type(value) is not dict or set(value) != (LEGACY_FIELDS if legacy else FIELDS):
        return False
    try:
        stamp = datetime.fromisoformat(value['recorded_at'])
        return (value['schema'] == ('orch.claude-start-state.v1' if legacy else 'orch.claude-start-state.v2')
                and value['seat'] == binding['seat']
                and re.fullmatch(r'start-[a-f0-9]{32}', value['id']) is not None
                and value['source'] in {'startup','resume','compact'}
                and ((value['state'] == 'held' and value['reason'] in
                      {'grounding_read_timeout','grounding_read_budget_exhausted'}
                      and value['declaration_state'] == 'not_attempted')
                     or (value['state'] == 'ready' and value['reason'] == 'grounding_ready'
                         and value['declaration_state'] in {'not_attempted','confirmed'})
                     or (value['state'] == 'refused' and value['reason'] == 'startup_refused'))
                and value['declaration_state'] in {'not_attempted','confirmed','unknown'}
                and (value['state'] != 'held' or value['declaration_state'] == 'not_attempted')
                and stamp.utcoffset() is not None
                and value['source_sha256'] in binding['source_pins']
                and (legacy or value['installation_sha256'] in binding['installation_pins']))
    except (ValueError, TypeError, KeyError):
        return False


def _read(binding):
    """Single-link, bounded regular file; no transcript or credential reads."""
    fd = None
    try:
        fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
        for component in (*Path(binding['home']).parts[1:], '.claude'):
            child = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd); fd = child
        directory = os.fstat(fd)
        if directory.st_uid != os.getuid() or directory.st_mode & 0o077:
            raise ValueError('unsafe configuration directory')
        try:
            info = os.stat(FILENAME, dir_fd=fd, follow_symlinks=False)
        except FileNotFoundError:
            return {'events': [], 'fault': None, 'digest': 'absent'}
        if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != os.getuid()
                or info.st_mode & 0o077 or info.st_size > MAX_BYTES):
            raise ValueError('unsafe evidence file')
        child = os.open(FILENAME, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=fd)
        with os.fdopen(child, 'rb') as stream:
            opened = os.fstat(stream.fileno())
            if (opened.st_dev, opened.st_ino, opened.st_mode, opened.st_nlink) != (
                    info.st_dev, info.st_ino, info.st_mode, info.st_nlink):
                raise ValueError('evidence replaced')
            raw = stream.read(MAX_BYTES + 1)
            after = os.fstat(stream.fileno())
            linked = os.stat(FILENAME, dir_fd=fd, follow_symlinks=False)
            if (len(raw) > MAX_BYTES or after.st_size != len(raw) or after.st_mtime_ns != opened.st_mtime_ns
                    or (linked.st_dev, linked.st_ino) != (opened.st_dev, opened.st_ino)):
                raise ValueError('evidence changed')
        events = []; fault = None
        if raw and not raw.endswith(b'\n'):
            fault = 'startup_evidence_incomplete'
        # A valid-looking JSON tail without its commit newline is still torn.
        for line in raw.split(b'\n')[:-1]:
            if not line.strip():
                continue
            try:
                if len(line) > MAX_ROW:
                    raise ValueError('oversize row')
                value = json.loads(line, object_pairs_hook=_object)
                if isinstance(value, dict) and value.get('schema') == 'orch.claude-start-evidence.v3':
                    continue  # historical diagnostic, never converted into new state
                if not _valid(value, binding):
                    known = [binding, *({**binding, **old} for old in binding['historical_installations'])]
                    if any(_valid(value, old) or _valid(value, old, legacy=True) for old in known):
                        # An old installation or an unbound v1 report is history.
                        # Neither may be stamped with the current generation.
                        continue
                    raise ValueError('invalid state')
                events.append(value)
            except (ValueError, TypeError, UnicodeError, RecursionError):
                fault = 'startup_evidence_invalid'
        return {'events': events, 'fault': fault, 'digest': hashlib.sha256(raw).hexdigest()}
    except (OSError, ValueError):
        return {'events': [], 'fault': 'startup_evidence_unreadable', 'digest': 'unreadable'}
    finally:
        if fd is not None:
            os.close(fd)


def observe(token):
    if not enabled():
        return {'observed': 0}
    from provision.machine import _require_daemon
    def select(actor):
        _require_daemon(actor)
        parts = store._read_participants_unlocked()
        with receipts._nudge_lock():
            history = receipts.strict_rows()
            return [b for seat, row in sorted(parts.items()) if (b := _binding(seat, row, parts, history))]
    bindings = store.authenticated_registry_act(token, select)
    observations = [(b, _read(b)) for b in bindings]  # no registry/token/nudge fence held
    def commit(actor):
        _require_daemon(actor)
        parts = store._read_participants_unlocked(); count = 0
        with receipts._nudge_lock():
            rows = receipts.strict_rows()
            for binding, value in observations:
                seat = binding['seat']
                if _binding(seat, parts.get(seat, {}), parts, rows) != binding:
                    continue
                known = {r.get('source_id'): r for r in rows if r.get('kind') == KIND
                         and r.get('event') == 'observed' and r.get('seat') == seat}
                for event in value['events']:
                    digest = _digest(event); prior = known.get(event['id'])
                    if prior:
                        if prior.get('source_digest') != digest:
                            value['fault'] = 'startup_evidence_conflict'
                        continue
                    entry = {'kind': KIND, 'event': 'observed', 'actor': actor, 'seat': seat,
                             'home': binding['home'], 'hookset_generation': binding['generation'],
                             'source_id': event['id'], 'source_digest': digest, 'source': event,
                             'state': event['state'], 'ts': store.now_iso(),
                             'provenance': 'seat-local-report; not native behavior verification'}
                    receipts.append_durable(entry); rows.append(entry); known[event['id']] = entry; count += 1
                observation = _digest([binding, value['digest'], value['fault']])
                latest = next((r for r in reversed(rows) if r.get('kind') == KIND
                               and r.get('seat') == seat and r.get('event') == 'read-status'), None)
                if value['fault'] or latest:
                    if not latest or latest.get('observation') != observation:
                        entry = {'kind': KIND, 'event': 'read-status', 'actor': actor, 'seat': seat,
                                 'state': 'unreadable' if value['fault'] else 'readable',
                                 'reason': value['fault'], 'observation': observation, 'home': binding['home'],
                                 'hookset_generation': binding['generation'], 'ts': store.now_iso()}
                        receipts.append_durable(entry); rows.append(entry)
            return {'observed': count}
    return store.authenticated_registry_act(token, commit)


def panel_state(rows, seat, participant):
    """Receipt-only projection. Missing files never clear a held startup."""
    generation = (participant.get('inapp_hookset') or {}).get('generation')
    installation = _installation(participant.get('inapp_hookset'), seat,
                                 participant.get('provisioned_home'))
    history = [r for r in rows if r.get('kind') == KIND and r.get('seat') == seat
               and r.get('hookset_generation') == generation
               and r.get('home') == participant.get('provisioned_home')]
    status = next((r for r in reversed(history) if r.get('event') == 'read-status'), None)
    if status and status.get('state') == 'unreadable':
        return {'state': 'startup-evidence-unreadable', 'reason': status['reason'],
                'ts': status['ts'], 'remedy': 'CoS to inspect startup evidence'}
    last = next((r for r in reversed(history) if r.get('event') == 'observed'
                 and installation is not None
                 and _valid(r.get('source'), {'seat':seat, **installation})), None)
    if last and last.get('state') in {'held','refused'}:
        return {'state': 'startup-' + last['state'], 'reason': last['source']['reason'],
                'ts': last['ts'], 'remedy': 'CoS to inspect startup; no route declaration attempted'
                if last['state'] == 'held' else 'CoS to inspect startup latch and receipts'}
    return None
