"""Pure console attribution over stored declarations, panel fields and receipts.

No probe, clock-based failure classification, mail consumption or repair belongs
here. Native readers retain ownership of their failure/hold classification.
"""
from __future__ import annotations

from desktop_support import optional as optional_desktop
agy_wake_route = optional_desktop('agy_wake_route')
codex_wake_route = optional_desktop('codex_wake_route')
inapp_wake_route = optional_desktop('inapp_wake_route')
import receipts
import store


def route_generation(route):
    """Validate declaration structure, never the filesystem or native target."""
    if not isinstance(route, dict):
        return None
    try:
        if codex_wake_route is not None and route.get('kind') == 'codex-ipc':
            return codex_wake_route.generation(route, check_path=False)
        if inapp_wake_route is not None and route.get('kind') == 'inapp-socket':
            return inapp_wake_route.generation(route, check_path=False)
        if agy_wake_route is not None and route.get('kind') == 'agy-desktop':
            return agy_wake_route.generation(route)
    except (ValueError, TypeError, KeyError):
        pass
    return None


def project(seat, participant, panel_row, journal):
    """Attribute stored observations to the declared route without probing it."""
    family = store.normalize_family(participant.get('family'))
    required = ((family == 'codex' and participant.get('hosting_kind') != 'tmux-hosted')
                or (family == 'claude' and participant.get('hosting_kind') == 'in-app'))
    route = participant.get('wake_route')
    kind = route.get('kind') if isinstance(route, dict) else None
    generation = route_generation(route)
    presence = ('declared' if generation else 'absent' if route is None else 'unknown')
    current = {'presence': presence, 'required': required, 'kind': kind,
               'generation': generation, 'declared_at': route.get('declared_at') if generation else None,
               'source': 'DECLARED'}

    def scope(g, k):
        return ('current' if generation and g == generation and k == kind
                else 'historical' if g and k else 'unattributed')

    history, pres, current_receipts = {}, [], {}
    for position, receipt in enumerate(journal):
        if receipt.get('seat', receipt.get('target seat')) != seat:
            continue
        event_kind = receipt.get('kind')
        if event_kind not in {'wake-route', 'nudge', 'wake_route_hold', 'wake_route_dead', 'wake_route_revived',
                              'claude-route-hold', 'claude-reconciliation'}:
            continue
        declared = receipt.get('route')
        k = receipt.get('route_kind') or (declared.get('kind') if isinstance(declared, dict) else None)
        g = receipt.get('generation')
        # Latest record of each type/phase for each route generation. Preserve
        # old generations and un-attributed records, without publishing routes,
        # native references, message bodies or arbitrary receipt contents.
        state = receipt.get('state') or receipt.get('result') or receipt.get('event') or event_kind
        item = {'state': state, 'kind': event_kind, 'phase': receipt.get('phase'),
                'route_kind': k, 'generation': g, 'scope': scope(g, k),
                'measured_at': receipt.get('ts'), 'reason': receipt.get('reason'),
                'attempt_count': receipt.get('attempt_count'), 'retry_at': receipt.get('retry_at'),
                'receipt_position': position, 'source': 'RUNTIME-VERIFIED: stored receipt'}
        history[(g, k, event_kind, receipt.get('phase'))] = item
        if scope(g, k) == 'current':
            current_receipts[receipts.reference(receipt)['sha256']] = position
        if event_kind == 'nudge' and receipt.get('phase') == 'pre':
            pres.append((position, receipt, k))

    native = dict(panel_row.get('wake_adapter_status') or {})
    evidence = native.get('receipt_evidence') or []
    # Native readers name the exact stored rows used by their classifier.
    # Require every side of an event join to be present in this snapshot and
    # current. Equal timestamps, event IDs or an unrelated declaration do not
    # establish identity. A newer panel read also cannot borrow old evidence.
    attributed = bool(evidence) and all(isinstance(r, dict)
        and scope(r.get('generation'), r.get('route_kind')) == 'current'
        and r.get('sha256') in current_receipts for r in evidence)
    declaration = native.get('value') in {'declared', 'queued', 'unprobed', 'unreceipted'}
    native.update(route_kind=kind if attributed or declaration else None,
                  generation=generation if attributed or declaration else None,
                  scope='current' if generation and (attributed or declaration) else 'unattributed')
    if attributed:
        native['receipt_positions'] = [current_receipts[r['sha256']] for r in evidence]
    # The Claude reader can report a hook/act from an older message. Qualify
    # that particular observation through the committed FETCHED/pre join.
    act = None
    fetch_position = None
    latest_pre = next((p for p in reversed(pres) if scope(p[1].get('generation'), p[2]) == 'current'), None)
    if latest_pre:
        pre_position, pre, _ = latest_pre
        deliveries = [(i, row) for i, row in store.valid_fetched_deliveries(journal)
                      if i > pre_position and row.get('seat') == seat
                      and row.get('msg-id') == pre.get('msg-id')]
        if native.get('value') == 'fetched' and deliveries:
            delivery_position, delivery = deliveries[-1]
            if evidence == [receipts.reference(pre), receipts.reference(delivery)]:
                # Attribute delivery resolution to this attempt, not the native
                # session that happened to perform a non-hook fetch.
                native.update(route_kind=kind, generation=generation, scope='current',
                              evidence_kind='committed-delivery', proves_native_acceptance=False,
                              receipt_positions=[pre_position, delivery_position])
        # FETCHED records the session identity validated against the registry
        # by the authenticated hook reader. A delayed old-session fetch may
        # consume the same message but carries no matching session identity.
        # Ordering and message id can resolve this attempt's delivery above,
        # but cannot establish a native-session observation or subsequent act.
        session_ref = route.get('session_ref')
        fetched = [(i, row) for i, row in deliveries if row.get('via') == 'hook'
                   and isinstance(session_ref, (str, dict)) and bool(session_ref)
                   and row.get('session_ref') == session_ref]
        if fetched:
            fetch_position = fetched[-1][0]
            acts = [(i, r) for i, r in enumerate(journal) if i > fetch_position
                    and r.get('kind') == 'seat-act' and r.get('seat') == seat
                    and r.get('command') not in {'await', 'hook-fetch'}]
            if acts:
                i, row = acts[-1]
                act = {'value': 'seat_act_observed', 'detail': 'authenticated seat act after committed hook fetch',
                       'command': row.get('command'), 'measured_at': row.get('ts'),
                       'route_kind': kind, 'generation': generation, 'scope': 'current',
                       'source': 'RUNTIME-VERIFIED: stored receipt',
                       'receipt_positions': [pre_position, fetch_position, i]}
    if ((native.get('value') == 'seat_act_observed' and act is None)
            or (native.get('value') == 'hook_fetched_no_seat_act' and fetch_position is None)):
        native['scope'] = 'unattributed'
        native['generation'] = None
    elif native.get('value') == 'seat_act_observed':
        native.update(act)
    elif (native.get('value') == 'hook_fetched_no_seat_act' and fetch_position is not None
          and evidence == [receipts.reference(journal[fetch_position])]):
        # The native reader may have selected a later old-session message.
        # Only its exact selected FETCHED row can acquire this pre/session join.
        native.update(route_kind=kind, generation=generation, scope='current',
                      receipt_positions=[latest_pre[0], fetch_position])
    # Snapshot-only refusal/unknown is never promoted to a route failure here.
    observations = [native] + ([act] if act and native.get('value') != 'seat_act_observed' else [])
    # The Antigravity panel uses the broad word "unreachable" for refusals.
    # Its daemon's explicit terminal receipt, not that word or its reason text,
    # is the evidence that distinguishes a dead current generation.
    if kind == 'agy-desktop':
        terminal = next((r for r in reversed(journal) if r.get('kind') == 'wake_route_dead'
                         and r.get('seat') == seat and r.get('terminal') is True
                         and scope(r.get('generation'), r.get('route_kind')) == 'current'), None)
        if terminal:
            observations.append({'value': 'dead', 'detail': terminal.get('reason'),
                'measured_at': terminal.get('ts'), 'route_kind': kind, 'generation': generation,
                'scope': 'current', 'source': 'RUNTIME-VERIFIED: stored terminal receipt'})
    return {'route': current, 'observations': observations,
            'history': sorted(history.values(), key=lambda row: row['receipt_position'])}
