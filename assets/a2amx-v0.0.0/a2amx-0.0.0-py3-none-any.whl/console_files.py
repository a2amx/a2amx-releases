"""Descriptor-relative, bounded, read-only courier/register file access.

Configured roots are operator inputs. Every descendant is opened NOFOLLOW;
request/body text can never select another root, URL, or arbitrary host file.
"""
from contextlib import contextmanager
import hashlib
import os
from pathlib import Path, PurePosixPath
import re
import stat

MAX_FILE_BYTES = 16 * 1024 * 1024
MAX_PACKET_BYTES = 64 * 1024 * 1024
MAX_MEMBERS = 2048


def digest(data):
    return hashlib.sha256(data).hexdigest()


def parts(name):
    if (not isinstance(name, str) or not name or '\\' in name or '\x00' in name
            or name.startswith('/') or any(p in {'', '.', '..'} for p in name.split('/'))):
        raise ValueError('unsafe relative path')
    return PurePosixPath(name).parts


@contextmanager
def directory(root, relative=None):
    path = Path(root)
    if not path.is_absolute():
        raise ValueError('configured root must be absolute')
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for component in parts(relative) if relative else ():
            child = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = child
        yield fd
    finally:
        os.close(fd)


def read(fd, relative, *, limit=MAX_FILE_BYTES):
    names = parts(relative)
    current = os.dup(fd)
    try:
        for name in names[:-1]:
            child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=current)
            os.close(current)
            current = child
        source = os.open(names[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=current)
        try:
            before = os.fstat(source)
            if not stat.S_ISREG(before.st_mode) or before.st_size > limit:
                raise ValueError('not a regular file within the read limit')
            data = bytearray()
            while len(data) <= limit:
                block = os.read(source, min(65536, limit + 1 - len(data)))
                if not block:
                    break
                data.extend(block)
            after = os.fstat(source)
            if (len(data) > limit or len(data) != before.st_size
                    or (before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) !=
                       (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)):
                raise ValueError('file changed during read or exceeds limit')
            return bytes(data)
        finally:
            os.close(source)
    finally:
        os.close(current)


def manifest(data):
    result = {}
    for line in data.decode('utf-8').splitlines():
        match = re.fullmatch(r'([0-9a-fA-F]{64}) [ *](.+)', line)
        if not match:
            raise ValueError('invalid manifest line')
        name = match[2].removeprefix('./')
        parts(name)
        if name == 'SHA256SUMS' or name in result:
            raise ValueError('self-referential or duplicate manifest member')
        result[name] = match[1].lower()
    if not result or len(result) > MAX_MEMBERS:
        raise ValueError('empty or oversized manifest')
    return result


def packet(fd, *, displayed=None):
    seal = read(fd, 'SHA256SUMS', limit=1024 * 1024)
    members = manifest(seal)
    selected = list(members) if displayed is None else list(displayed)
    if any(name not in members for name in selected):
        raise ValueError('displayed member absent from manifest')
    total = 0
    contents = {}
    for name in selected:
        contents[name] = read(fd, name)
        total += len(contents[name])
        if total > MAX_PACKET_BYTES:
            raise ValueError('packet exceeds read limit')
    if read(fd, 'SHA256SUMS', limit=1024 * 1024) != seal:
        raise ValueError('manifest changed during read')
    checks = {name: {'claimed': members[name], 'measured': digest(data),
                     'matches': members[name] == digest(data)} for name, data in contents.items()}
    return {'manifest_sha256': digest(seal), 'members': checks,
            'verified': all(row['matches'] for row in checks.values())}, contents
