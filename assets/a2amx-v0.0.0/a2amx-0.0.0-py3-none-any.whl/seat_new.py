"""One provisioning act per Claude desktop seat: participant, home, credential, kit.

A current provisioner runs it under the store's existing provisioning gate. Each
step is idempotent: a step already done as this act would do it is reported under
``already`` and never redone; a differing state refuses with a fixed reason and is
never overwritten. One intent receipt precedes the first write and one completion
receipt lists exactly what the act made, so removal undoes that and nothing else.
The seat's credential is claimed in process straight into its home; its value is
never printed, returned or receipted. Opening the home in the desktop app and
accepting trust remains the one human act.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import shutil
from string import Template
import tempfile
import uuid

import ledger
import receipts
import seat_grounding
import store
from desktop_support import require
from provision import machine

KIND = 'seat-new'
REMOVAL_KIND = 'seat-new-removal'
CYCLE = 'registration'
FAMILY = 'claude'
CHANNEL = 'pull'  # Not tmux: the desktop kit refuses tmux-hosted seats.
DEFAULT_COMMISSION = 'Commission: as assigned by the Chief of Staff in the store.\n'
MAX_COMMISSION_BYTES = 65536
SETTABLE_ROLES = frozenset({'chief_of_staff', 'coder', 'reviewer'})
# The kit's start hook accepts only this home spelling; refuse it before any write.
HOME_SPELLING = re.compile(r'/[A-Za-z0-9_./-]+')
PRODUCT = re.compile(r'[a-z][a-z0-9_-]{0,31}')
CODE = re.compile(r'[a-z][a-z0-9_]{0,95}')
DIGEST = re.compile(r'[0-9a-f]{64}')
KIT_DIRECTORY = '.claude'
KIT_SETTINGS = 'settings.json'
# The Chief of Staff's onboarding skill and the commission templates it fills (stage 1 B2), rendered
# with the seat files' values and the product's command name, written beside the kit's files.
ONBOARDING_ROLE = 'chief_of_staff'
ONBOARDING_SOURCES = ('SKILL.md', 'templates/worker.md', 'templates/reviewer.md')
ONBOARDING_DIRECTORY = Path(KIT_DIRECTORY) / 'skills' / 'onboarding'
REMOVAL_PLAN_SCHEMA = 'orch.claude-removal.v1'
# Registry facts a home binding sets; a participant this act did not create gets its prior ones back.
BINDING_FIELDS = ('provisioned_home', 'provisioning')
# Receipt kinds this act and its kit write about a seat; any other row naming the
# seat, or any row it authored, means the seat acted and is retired, not removed.
OWN_KINDS = frozenset({KIND, REMOVAL_KIND, 'seat-grounding', 'inapp-hookset',
                       'claude-seat-install-intent', 'seat-provisioned', 'registry-role'})
AUTHOR_FIELDS = ('actor', 'requester', 'sender', 'by', 'from', 'actor_id')

CREDENTIAL_REASONS = frozenset({'provisioner_credential_required', 'provisioner_credential_refused'})
REFUSAL_REASONS = CREDENTIAL_REASONS | frozenset({
    'seat_invalid', 'kind_unsupported', 'product_invalid', 'role_invalid', 'approval_invalid',
    'approval_required', 'approval_without_role', 'commission_invalid',
    'home_spelling_unsupported', 'home_noncanonical', 'home_reserved', 'remove_options_invalid',
    'receipt_history_invalid', 'act_unresolved', 'removal_unresolved',
    'multiple_unresolved_acts', 'intent_receipt_failed',
    'participant_retired', 'participant_parked', 'participant_differs',
    'participant_tmux_hosted', 'participant_home_differs', 'participant_id_collides',
    'role_differs', 'home_belongs_to_other_seat', 'home_owner_mode_or_type',
    'home_file_differs', 'home_provisioning_receipt_missing', 'home_template_invalid',
    'home_render_mismatch', 'cwd_inside_home', 'invite_file_present', 'token_file_differs',
    'seat_has_live_credential', 'kit_present_differs', 'kit_file_present',
    'kit_install_pending', 'grounding_record_invalid',
    'participant_refused', 'role_refused', 'home_refused', 'token_refused', 'kit_refused',
    'act_failed', 'kit_changed_since_act', 'seat_has_other_credentials',
    'kit_remove_refused', 'token_revoke_refused', 'participant_remove_refused',
    'managed_state_invalid',
})
# Store outcomes that are committed but exceptional. They are not refusals: they
# propagate unchanged after this act's completion receipt records the state.
COMMITTED_EXCEPTIONS = (
    store.SeatActWithoutReceipt, store.SeatTokenNotPlaced, store.SeatInviteNotPlaced,
    store.SeatCredentialCommitIndeterminate, store.SeatCredentialPlacementIndeterminate,
    store.SeatCredentialPlacedAfterCallbackError, store.SeatUncommittedStageNotRemoved,
    store.SeatActCleanupUnconfirmed, store.RegistryRoleIncomplete)


class Refused(store.RegistryMutationRefused):
    """The store's structured refusal; only a fixed reason and fixed detail leave."""

    def __init__(self, reason: str, detail: str = ''):
        if reason not in REFUSAL_REASONS:
            reason, detail = 'managed_state_invalid', ''
        self.detail = detail or reason
        super().__init__(reason, self.detail)


def _install():
    return require('inapp_install')


def _hookset():
    return require('inapp_hookset')


def _digest(value) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     ensure_ascii=True, allow_nan=False).encode()).hexdigest()


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _code(exc) -> str:
    """An inner refusal's own fixed code; any other exception text stays masked."""
    if isinstance(exc, store.RegistryMutationRefused):
        return exc.reason
    text = str(exc)
    return text if CODE.fullmatch(text) else 'masked'


def _key(item):
    return (item['item'], item.get('path') or item.get('seat'))


# --- inputs -------------------------------------------------------------------------------

def check_kind(kind):
    if kind != FAMILY:
        raise Refused('kind_unsupported', 'only --kind claude is provisioned by this act')


def _check_seat(seat):
    if not isinstance(seat, str) or not store.PARTICIPANT_ID_RE.fullmatch(seat):
        raise Refused('seat_invalid', 'seat names a registry identity')


def _target_home(seat, home) -> Path:
    path = Path(os.fspath(home)).expanduser() if home is not None else Path.home() / 'agents' / seat
    text = str(path)
    if not path.is_absolute() or not HOME_SPELLING.fullmatch(text) or '..' in path.parts:
        raise Refused('home_spelling_unsupported', 'home must be a simple absolute path')
    if path.resolve() != path:
        raise Refused('home_noncanonical', 'home must be canonical and free of symlinks')
    account = Path.home().resolve()
    root = Path(store.STORE_DIR).resolve()
    if path == account or path in account.parents or path == root or root in path.parents \
            or path in root.parents:
        raise Refused('home_reserved', 'home may not be the account home, the store or their ancestor')
    return path


def read_commission(path) -> str:
    """Bounded UTF-8 commission text from a file; the file itself is not copied."""
    try:
        with open(Path(path).expanduser(), 'rb') as stream:
            data = stream.read(MAX_COMMISSION_BYTES + 1)
        text = data.decode('utf-8')
    except (OSError, UnicodeDecodeError) as exc:
        raise Refused('commission_invalid', 'commission file unreadable') from exc
    if len(data) > MAX_COMMISSION_BYTES:
        raise Refused('commission_invalid', 'commission exceeds its bound')
    return text


def _commission(text) -> bytes:
    value = DEFAULT_COMMISSION if text is None else text
    if not isinstance(value, str) or not value.strip() or '\0' in value:
        raise Refused('commission_invalid', 'commission must be nonempty text')
    data = value.encode('utf-8')
    if len(data) > MAX_COMMISSION_BYTES:
        raise Refused('commission_invalid', 'commission exceeds its bound')
    return data


def _approval(role, approval):
    if role is not None and role not in SETTABLE_ROLES:
        raise Refused('role_invalid', 'role is one of ' + ', '.join(sorted(SETTABLE_ROLES)))
    if approval is not None:
        if (not isinstance(approval, (tuple, list)) or len(approval) != 2
                or not isinstance(approval[0], str) or not approval[0].strip()
                or len(approval[0]) > 256 or any(c.isspace() or ord(c) < 32 for c in approval[0])
                or not isinstance(approval[1], str)
                or not re.fullmatch(r'[0-9a-fA-F]{64}', approval[1])):
            raise Refused('approval_invalid', 'approval is a record id and its content SHA-256')
        if role is None:
            raise Refused('approval_without_role', 'an approval binds an explicit role')
        approval = (approval[0], approval[1].lower())
    if role in store.PROVISIONING_ROLES and approval is None:
        raise Refused('approval_required', 'a privileged role requires its approval record')
    return approval


def _human_act(home) -> str:
    return f'Open {home} in the Claude desktop app and accept trust'


def _gate(presented_token, act, *, dry_run):
    """The store's provisioning gate; its refusal keeps the store's code as detail."""
    if not presented_token:
        raise Refused('provisioner_credential_required', 'a current provisioner credential is required')
    entered = []

    def run(actor):
        entered.append(actor)
        return act(actor)
    try:
        if dry_run:
            actor, _ = _install().preview_actor(presented_token)
            entered.append(actor)
            return act(actor)
        return store.authenticated_registry_act(presented_token, run, provisioning=True)
    except Refused:
        raise
    except store.RegistryMutationRefused as exc:
        if entered:
            raise Refused('managed_state_invalid') from exc
        raise Refused('provisioner_credential_refused', exc.reason) from exc


# --- receipts -----------------------------------------------------------------------------

def _history():
    try:
        rows = receipts.strict_rows()
    except (OSError, ValueError) as exc:
        raise Refused('receipt_history_invalid', 'receipt journal unreadable') from exc
    for row in rows:
        if row.get('kind') in (KIND, REMOVAL_KIND) and (
                row.get('digest') != _digest({k: v for k, v in row.items() if k != 'digest'})
                or row.get('event') not in ('intent', 'issued', 'completed')):
            raise Refused('receipt_history_invalid', 'seat act receipt invalid')
    return rows


def _append(row):
    row = {**row, 'ts': store.now_iso()}
    row['digest'] = _digest(row)
    with receipts._nudge_lock():
        receipts.append_durable(row)
    return row


def _unresolved(seat, rows, kind):
    intents, done = {}, set()
    for row in rows:
        if row.get('kind') != kind or row.get('seat') != seat:
            continue
        if row['event'] == 'intent':
            intents[row['act']] = row
        elif row['event'] == 'completed':
            done.add(row['act'])
        if row.get('resumes'):
            done.add(row['resumes'])
    pending = [row for act, row in intents.items() if act not in done]
    if len(pending) > 1:
        raise Refused('multiple_unresolved_acts', 'inspect the seat act receipts')
    return pending[0] if pending else None


def _active(seat, rows):
    """Items made by provisioning acts and not yet resolved by a removal, in order."""
    active, home, last = {}, None, None
    for row in rows:
        if row.get('seat') != seat or row.get('event') != 'completed':
            continue
        if row.get('kind') == KIND:
            home = row.get('home')
            for item in row['made']:
                active.pop(_key(item), None)
                active[_key(item)] = item
        elif row.get('kind') == REMOVAL_KIND:
            last = row
            for name in ('undone', 'already', 'left'):
                for item in row[name]:
                    active.pop(_key(item), None)
    return active, home, last


# --- the provisioning plan ----------------------------------------------------------------

def _cycle(seat, row, rows):
    """The current cycle, else the first never-applied one (a re-created name needs one)."""
    current = ((row or {}).get('provisioning') or {}).get('cycle')
    if isinstance(current, str) and current:
        return current
    used = {r.get('cycle') for r in rows if r.get('kind') == 'seat-provisioned' and r.get('seat') == seat}
    n = 1
    while (CYCLE if n == 1 else f'{CYCLE}-{n}') in used:
        n += 1
    return CYCLE if n == 1 else f'{CYCLE}-{n}'


def _home_outputs(seat, home, commission, cycle, authority):
    """The seat files machine.provision_home writes for a Claude seat, rendered the same way."""
    try:
        standard = machine._read_regular(machine.TEMPLATES / 'agent-communication.md')
        if machine.digest(standard) != machine.STANDARD_SHA256:
            raise ValueError('standard')
        import product_identity
        values = dict(command=product_identity.command(), seat=seat, home=str(home), token_path=str(home / '.orch' / 'token'),
                      standard=standard.decode(), lifecycle_authority=authority)

        def render(name):
            return Template(machine._read_regular(machine.TEMPLATES / name).decode()).substitute(values).encode()
        outputs = {'CLAUDE.md': render('seat.md'), 'GROUNDING.md': commission + b'\n\n' + standard,
                   f'GROUNDING_ADDENDUM_PROVISION_{cycle}.md': commission + b'\n\n' + standard,
                   f'MODEL_CHANGE_{cycle}.md': render('model-change.md')}
    except (OSError, ValueError, KeyError) as exc:
        raise Refused('home_template_invalid', 'seat templates unreadable or changed') from exc
    inputs = {'seat': seat, 'home': str(home), 'cycle': cycle, 'standard_sha256': machine.digest(standard),
              'commission_sha256': machine.digest(commission), 'lifecycle_authority': authority,
              'files': {name: _sha(data) for name, data in outputs.items()}}
    return outputs, inputs


def render_onboarding(name, seat, home, product) -> bytes:
    """One onboarding text from the package, rendered with the seat files' values and the command name."""
    values = dict(seat=seat, home=str(home), token_path=str(Path(home) / '.orch' / store.SEAT_TOKEN_FILENAME),
                  product=product)
    try:
        text = machine._read_regular(machine.TEMPLATES / 'onboarding' / name).decode()
        return Template(text).substitute(values).encode()
    except (OSError, ValueError, KeyError) as exc:
        raise Refused('home_template_invalid', 'onboarding templates unreadable or changed') from exc


def chief_commission(seat, *, product='orch', home=None) -> str:
    """The Chief of Staff's commission, the GROUNDING text the first run passes to `provision`."""
    _check_seat(seat)
    if not isinstance(product, str) or not PRODUCT.fullmatch(product):
        raise Refused('product_invalid', 'product names the command-line program')
    return render_onboarding('chief_commission.md', seat, _target_home(seat, home), product).decode()


def _onboarding_outputs(seat, home, role, product):
    """For the Chief of Staff, its onboarding skill and templates, by path relative to the home."""
    if role != ONBOARDING_ROLE:
        return {}
    return {str(ONBOARDING_DIRECTORY / name): render_onboarding(name, seat, home, product)
            for name in ONBOARDING_SOURCES}


def _regular(path) -> bytes:
    try:
        return machine._read_regular(path)
    except (OSError, ValueError) as exc:
        raise Refused('home_file_differs', 'a home file is not a readable regular file') from exc


def _check_directory(path, *, private=True):
    """A self-owned directory, never a link; the home and kit directory also not group/world-writable."""
    import stat
    try:
        info = os.lstat(path)
    except OSError as exc:
        raise Refused('home_owner_mode_or_type', 'home directory unreadable') from exc
    if (not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid()
            or (private and info.st_mode & 0o022)):
        raise Refused('home_owner_mode_or_type', 'home and its directories must be private directories')


def _live(rec, tokens):
    import time
    return (rec.get('kind') in {'invite', 'session'} and not rec.get('revoked') and not rec.get('used')
            and not store._token_expired(rec, time.time(), tokens=tokens))


def _seat_credentials(seat, tokens):
    return [rec for rec in store._token_records(tokens) if isinstance(rec, dict) and _live(rec, tokens)
            and (rec.get('participant_id') == seat or rec.get('allowed_participant_id') == seat)]


def _token_in_file(path, seat, tokens):
    """The live session record of this seat held at path, or None; never the value."""
    try:
        value = store.read_secret_file(path)
    except OSError:
        return None
    rec, _ = store._verdict_unlocked(value, tokens)
    return rec if rec is not None and rec.get('participant_id') == seat else None


def _act_invite(pending, rows):
    """The id of the invite the unresolved act owns, or None. A resumed act carries it in its plan;
    an act that issued records it in its own `issued` receipt, written in the same token-lock hold
    as the issue. An act that never recorded one owns none."""
    plan = pending['plan']
    for item in plan['make'] + plan.get('adopted', []) + plan['already']:
        if item.get('item') == 'token' and item.get('invite_id'):
            return item['invite_id']
    issued = [r for r in rows if r.get('kind') == KIND and r.get('event') == 'issued' and r.get('act') == pending['act']]
    return issued[-1].get('invite_id') if issued else None


def _owned_invite(seat, path, pending, rows, tokens):
    """The seat invite held at path when it is the one the unresolved act owns and its plaintext
    matches; otherwise None. The value is compared and dropped, never kept."""
    invite_id = _act_invite(pending, rows) if pending is not None else None
    rec = tokens.get(invite_id) if invite_id else None
    if (not isinstance(rec, dict) or rec.get('kind') != 'invite' or rec.get('scope') != store.SEAT_SCOPE
            or rec.get('allowed_participant_id') != seat):
        return None
    try:
        value = store.read_secret_file(path)
    except OSError:
        return None
    try:
        return rec if store._token_matches(value, rec) else None
    finally:
        value = None


def _creation_collision(seat, parts):
    """Mirror the registrar's creation rules so a collision refuses before any write."""
    if seat in store.load_aliases():
        return 'participant_retired'
    taken = {}
    for other, row in parts.items():
        taken[other.lower()] = other
        taken[(row.get('label') or other).lower()] = other
    base = seat.split('-')[0].lower()
    if seat.lower() in taken or (base != seat.lower() and base in taken):
        return 'participant_id_collides'
    return None


def _kit_names():
    return (*_hookset().DEFAULT_LOCAL_HOOK_NAMES, KIT_SETTINGS)


def _plan(seat, home, actor, role, approval, commission, parts, rows, tokens, *, onboarding=None):
    """Read-only preflight shared by the preview and the act; refuses before any write."""
    try:
        cwd = Path.cwd()
    except OSError:
        cwd = None
    if cwd is not None and (cwd == home or home in cwd.parents):
        raise Refused('cwd_inside_home', 'run the act from outside the target home')
    if _unresolved(seat, rows, REMOVAL_KIND) is not None:
        raise Refused('removal_unresolved', 'complete the earlier removal first')
    pending = _unresolved(seat, rows, KIND)
    make, already = [], []
    row = parts.get(seat)
    default_role = store._default_role('agent', FAMILY)
    # a. participant
    if row is None:
        collision = _creation_collision(seat, parts)
        if collision:
            raise Refused(collision, 'the registrar refuses this identity')
        make.append({'item': 'participant', 'seat': seat, 'role': default_role})
    else:
        if row.get('retired_at'):
            raise Refused('participant_retired', 'a retired identity is never reused')
        if row.get('parked_at'):
            raise Refused('participant_parked', 'a parked seat is unparked by its own act')
        if row.get('kind') != 'agent' or store.normalize_family(row.get('family')) != FAMILY:
            raise Refused('participant_differs', 'the existing participant is not a Claude agent')
        if row.get('channel') == 'tmux' or row.get('hosting_kind') == 'tmux-hosted':
            raise Refused('participant_tmux_hosted', 'the desktop kit requires a seat that is not tmux-hosted')
        if row.get('provisioned_home') not in (None, str(home)) or row.get('workspace_dir') not in (None, str(home)):
            raise Refused('participant_home_differs', 'the existing participant has another home')
        if role is None and row.get('role') != default_role:
            raise Refused('role_differs', 'the existing role differs from the family default')
        already.append({'item': 'participant', 'seat': seat, 'role': row.get('role')})
    for other, other_row in parts.items():
        value = other_row.get('provisioned_home')
        if other != seat and isinstance(value, str) and value and (
                Path(value) == home or Path(value) in home.parents or home in Path(value).parents):
            raise Refused('home_belongs_to_other_seat', 'another seat is registered at, inside or above this home')
    credentials = _seat_credentials(seat, tokens)
    # b. role, before any credential is issued
    if role is not None:
        item = {'item': 'role', 'seat': seat, 'role': role,
                'approval': {'record_id': approval[0], 'sha256': approval[1]} if approval else None}
        if row is not None and row.get('role') == role and row.get('role_source') == 'explicit':
            already.append(item)
        else:
            if row is not None and row.get('role') != role and credentials:
                raise Refused('role_differs', 'a role change after a credential is issued needs a revocation first')
            if row is not None and row.get('role') in store.PROVISIONING_ROLES and approval is None:
                raise Refused('approval_required', 'changing a privileged role requires its approval record')
            make.append(item)
    # c. home
    cycle = _cycle(seat, row, rows)
    provisioning = home / '.orch' / 'provisioning'
    json_path, hello_path = provisioning / (cycle + '.json'), provisioning / (cycle + '-hello.txt')
    authority = actor
    prior = None
    if os.path.lexists(json_path):
        try:
            prior = json.loads(_regular(json_path))
            authority = prior['inputs']['lifecycle_authority']
        except (ValueError, KeyError, TypeError) as exc:
            raise Refused('home_file_differs', 'the provisioning record differs') from exc
    outputs, inputs = _home_outputs(seat, home, commission, cycle, authority)
    if prior is not None and prior.get('inputs') != inputs:
        raise Refused('home_file_differs', 'the provisioning record differs')
    committed = any(r.get('kind') == 'seat-provisioned' and r.get('seat') == seat and r.get('cycle') == cycle
                    for r in rows)
    if prior is None and (committed or ((row or {}).get('provisioning') or {}).get('cycle') == cycle):
        raise Refused('home_provisioning_receipt_missing', 'an applied provisioning record is missing')
    if prior is None and os.path.lexists(hello_path):
        raise Refused('home_file_differs', 'an unrecorded provisioning hello exists')
    missing_ancestors = []
    parent = home.parent
    while not os.path.lexists(parent):
        missing_ancestors.insert(0, parent)
        parent = parent.parent
    for path in missing_ancestors:
        make.append({'item': 'directory', 'path': str(path)})
    for path in (home, home / '.orch', provisioning, home / KIT_DIRECTORY):
        if os.path.lexists(path):
            _check_directory(path, private=path in (home, home / KIT_DIRECTORY))
            already.append({'item': 'directory', 'path': str(path)})
        elif path != home / KIT_DIRECTORY:
            make.append({'item': 'directory', 'path': str(path)})
    present = True
    for name, data in outputs.items():
        path = home / name
        item = {'item': 'file', 'path': str(path), 'sha256': _sha(data)}
        if os.path.lexists(path):
            if _regular(path) != data:
                raise Refused('home_file_differs', 'an existing home file differs; it is never overwritten')
            already.append(item)
        else:
            present = False
            make.append({**item, 'existed': False})
    for path in (json_path, hello_path):
        if os.path.lexists(path):
            already.append({'item': 'file', 'path': str(path), 'sha256': _sha(_regular(path))})
        else:
            present = False
            make.append({'item': 'file', 'path': str(path), 'sha256': None, 'existed': False})
    bound = row is not None and row.get('provisioned_home') == str(home)
    recorded = ((row or {}).get('provisioning') or {})
    binding = {'item': 'provisioned_home', 'seat': seat, 'path': str(home), 'cycle': cycle}
    if bound and recorded.get('cycle') == cycle and present \
            and recorded.get('sha256') == _sha(_regular(json_path)):
        already.append(binding)
        provision_home = False
    else:
        if bound and recorded.get('cycle') == cycle:
            already.append(binding)
        else:
            # The facts this binding replaces, so removal can restore them on a participant it keeps.
            make.append({**binding, 'prior': {key: row[key] for key in BINDING_FIELDS if key in (row or {})}})
        provision_home = True
    # d. token. An invite file is admitted only as the unresolved act's own, by the id it recorded:
    # its claim is resumed, or, once claimed into this home's session, the consumed file is removed.
    # Any other refuses.
    token_path = home / '.orch' / store.SEAT_TOKEN_FILENAME
    invite_path = home / '.orch' / store.SEAT_INVITE_FILENAME
    owned = None
    if os.path.lexists(invite_path):
        owned = _owned_invite(seat, invite_path, pending, rows, tokens)
        if owned is None:
            raise Refused('invite_file_present', 'an invite file no unresolved act of this seat issued is in the home')
    if os.path.lexists(token_path):
        rec = _token_in_file(token_path, seat, tokens)
        if rec is None:
            raise Refused('token_file_differs', 'the home holds a credential that is not this seat\'s live session')
        if owned is not None and rec.get('from_invite') != owned['id']:
            raise Refused('invite_file_present', 'the invite file is not the one this home\'s session was claimed from')
        if role is not None and rec.get('role') != role:
            raise Refused('role_differs', 'the live credential carries another role')
        item = {'item': 'token', 'path': str(token_path), 'token_id': rec['id']}
        if owned is not None:
            item['invite_id'] = owned['id']
            make.append({'item': 'invite', 'path': str(invite_path), 'token_id': owned['id'], 'cleanup': True})
        already.append(item)
    elif owned is not None:
        if not _live(owned, tokens):
            raise Refused('invite_file_present', 'the unresolved act\'s invite is no longer claimable')
        if any(rec['id'] != owned['id'] for rec in credentials):
            raise Refused('seat_has_live_credential', 'the seat already holds a live credential elsewhere')
        make.append({'item': 'token', 'path': str(token_path), 'token_id': None, 'invite_id': owned['id']})
    else:
        if credentials:
            raise Refused('seat_has_live_credential', 'the seat already holds a live credential elsewhere')
        make.append({'item': 'token', 'path': str(token_path), 'token_id': None})
    # e. kit and its grounding record
    hookset = _hookset()
    try:
        grounding = seat_grounding.current(seat, rows=rows, required=False)
    except seat_grounding.Refused as exc:
        raise Refused('grounding_record_invalid', _code(exc)) from exc
    kit_dir = home / KIT_DIRECTORY
    record = (row or {}).get(hookset.FIELD)
    if record is not None:
        try:
            hookset.validate_record(record, seat, row, measure=True)
        except (ValueError, OSError) as exc:
            raise Refused('kit_present_differs', _code(exc)) from exc
        if not any(r.get('kind') == 'inapp-hookset' and r.get('event') == 'provisioned'
                   and r.get('seat') == seat and r.get('record') == record for r in rows):
            raise Refused('kit_present_differs', 'the installed kit is unreceipted')
        already.append({'item': 'hookset', 'seat': seat, 'generation': record['generation']})
        for source in record['spec']['hook_sources']:
            if Path(source['path']).parent == kit_dir:
                already.append({'item': 'file', 'path': source['path'], 'sha256': source['sha256']})
        already.append({'item': 'file', 'path': record['spec']['settings']['path'],
                        'sha256': record['spec']['settings']['sha256']})
    else:
        try:
            unresolved_install = _install()._pending_install(seat, rows)
        except ValueError as exc:
            raise Refused('kit_present_differs', _code(exc)) from exc
        if unresolved_install is not None:
            raise Refused('kit_install_pending', 'an earlier kit installation is unresolved')
        retired = next((r for r in reversed(rows) if r.get('kind') == 'inapp-hookset'
                        and r.get('seat') == seat and r.get('event') in {'provisioned', 'removed'}), None)
        if retired is None and any(os.path.lexists(kit_dir / name) for name in _kit_names()):
            raise Refused('kit_file_present', 'unrecorded kit files exist; they are never overwritten')
        if not os.path.lexists(kit_dir):
            make.append({'item': 'directory', 'path': str(kit_dir)})
        for name in _kit_names():
            make.append({'item': 'file', 'path': str(kit_dir / name), 'sha256': None,
                         'existed': os.path.lexists(kit_dir / name)})
        make.append({'item': 'hookset', 'seat': seat, 'generation': None})
    item = {'item': 'grounding', 'seat': seat,
            'generation': grounding['generation'] if grounding else None}
    (already if grounding else make).append(item)
    # f. the Chief of Staff's onboarding skill and templates, beside the kit's files; written after the
    # kit has made its directory, never over a file that differs
    onboarding = onboarding or {}
    if onboarding:
        skill = home / ONBOARDING_DIRECTORY
        for path in (skill.parent, skill, skill / 'templates'):
            if os.path.lexists(path):
                _check_directory(path)
                already.append({'item': 'directory', 'path': str(path)})
            else:
                make.append({'item': 'directory', 'path': str(path)})
        for name, data in onboarding.items():
            path = home / name
            item = {'item': 'file', 'path': str(path), 'sha256': _sha(data)}
            if os.path.lexists(path):
                if _regular(path) != data:
                    raise Refused('home_file_differs', 'an existing home file differs; it is never overwritten')
                already.append(item)
            else:
                make.append({**item, 'existed': False})
    return {'make': make, 'already': already, 'cycle': cycle, 'authority': authority,
            'outputs': outputs, 'provision_home': provision_home, 'pending': pending,
            'onboarding': onboarding}


# --- the act ------------------------------------------------------------------------------

def provision(seat, *, kind='claude', home=None, presented_token, role=None, approval=None,
              commission_text=None, product=None, dry_run=False) -> dict:
    """Create or confirm one Claude desktop seat in one receipted act."""
    _check_seat(seat)
    check_kind(kind)
    if product is None:
        import product_identity
        product = product_identity.command()
    if not isinstance(product, str) or not PRODUCT.fullmatch(product):
        raise Refused('product_invalid', 'product names the command-line program')
    approval = _approval(role, approval)
    commission = _commission(commission_text)
    target = _target_home(seat, home)
    onboarding = _onboarding_outputs(seat, target, role, product)
    result = {'seat': seat, 'home': str(target), 'kind': FAMILY, 'dry_run': bool(dry_run),
              'human_act': _human_act(target), 'act': None,
              'remove_command': f'{product} seat new {seat} --kind {FAMILY} --remove'}

    def act(actor):
        rows = _history()
        plan = _plan(seat, target, actor, role, approval, commission,
                     store._read_participants_unlocked(), rows, store._read_tokens_unlocked(),
                     onboarding=onboarding)
        if dry_run or (not plan['make'] and plan['pending'] is None):
            return {**result, 'made': plan['make'], 'already': plan['already']}
        return _apply(seat, target, actor, presented_token, role, approval, commission, plan, result)
    return _gate(presented_token, act, dry_run=dry_run)


def _apply(seat, home, actor, presented_token, role, approval, commission, plan, result):
    act_id = 'seat-new-' + uuid.uuid4().hex
    pending = plan['pending']
    # An interrupted earlier act planned some items that now exist: this act adopts
    # and lists them, so a removal still undoes them. Adoption carries forward, with the
    # earlier act's own provenance (what existed, the facts a binding replaced) as it saw
    # them before it wrote anything.
    adopted = {}
    if pending is not None:
        adopted = {_key(item): item for item in pending['plan'].get('adopted', []) + pending['plan']['make']}
    try:
        intent = _append({'kind': KIND, 'event': 'intent', 'act': act_id, 'seat': seat,
                          'home': str(home), 'actor': actor, 'role': role,
                          'approval': list(approval) if approval else None, 'cycle': plan['cycle'],
                          'commission_sha256': _sha(commission),
                          'resumes': pending['act'] if pending else None,
                          'plan': {'make': plan['make'],
                                   'already': [i for i in plan['already'] if _key(i) not in adopted],
                                   'adopted': [{**adopted[_key(i)], **i} for i in plan['already']
                                               if _key(i) in adopted]}})
    except OSError as exc:
        raise Refused('intent_receipt_failed', 'nothing was written') from exc
    made, already = [], []
    watched = [Path(item['path']) for item in plan['make'] if item['item'] == 'directory'] + \
        [home, home / '.orch', home / '.orch' / 'provisioning', home / KIT_DIRECTORY]
    before = {path: os.path.lexists(path) for path in watched}
    outcome, reason, failure = 'completed', None, None
    try:
        _steps(seat, home, act_id, actor, presented_token, role, approval, commission, plan, made, already)
    except Refused as exc:
        outcome, reason, failure = 'refused', exc.reason, exc
    except COMMITTED_EXCEPTIONS as exc:
        outcome, reason, failure = 'incomplete', 'store_act_incomplete', exc
    except Exception as exc:
        outcome, reason = 'refused', 'act_failed'
        failure = Refused('act_failed', 'unexpected failure; inspect the receipts')
        failure.__cause__ = exc
    directories = []
    for path in sorted(before, key=lambda p: len(p.parts)):
        if not before[path] and os.path.isdir(path) and not os.path.islink(path):
            directories.append({'item': 'directory', 'path': str(path)})
    made[:0] = directories
    known = {_key(item) for item in made}
    already[:0] = [item for item in plan['already'] if item['item'] == 'directory' and _key(item) not in known]
    if adopted:
        made.extend({**adopted[_key(item)], **item} for item in already if _key(item) in adopted)
        already[:] = [item for item in already if _key(item) not in adopted]
    hookset_item = next((item for item in made + already if item['item'] == 'hookset'), None)
    try:
        _append({'kind': KIND, 'event': 'completed', 'act': act_id, 'intent_digest': intent['digest'],
                 'seat': seat, 'home': str(home), 'actor': actor, 'outcome': outcome,
                 'reason': reason, 'resumes': pending['act'] if pending else None,
                 'made': made, 'already': already,
                 'kit_generation': hookset_item['generation'] if hookset_item else None})
    except Exception as exc:
        raise store.SeatActWithoutReceipt('seat new', seat, 'completion receipt failed; '
                                          'inspect the home and registry before retrying') from (failure or exc)
    if failure is not None:
        raise failure
    return {**result, 'act': act_id, 'made': made, 'already': already}


def _step(name, function):
    try:
        return function()
    except (Refused, *COMMITTED_EXCEPTIONS):
        raise
    except (store.RegistryMutationRefused, ValueError, OSError, TypeError, KeyError) as exc:
        raise Refused(name + '_refused', f'{name}: {_code(exc)}') from exc


def _observe(items, made):
    """List each planned file that now exists, with the bytes actually written."""
    for item in items:
        path = Path(item['path'])
        if os.path.lexists(path) and not any(_key(m) == _key(item) for m in made):
            made.append({**item, 'sha256': _file_sha(path)})


def _write_onboarding(home, plan, files, created):
    """The planned onboarding directories, private, then each planned file, created and never replaced.
    A file is this act's only once its exclusive open succeeds: it is appended to `created` then, so a
    file another writer made after the plan (EEXIST) is refused and never listed as made."""
    kit = home / KIT_DIRECTORY
    _check_directory(kit)
    for path in sorted((Path(i['path']) for i in plan['make'] if i['item'] == 'directory'
                        and kit in Path(i['path']).parents), key=lambda p: len(p.parts)):
        try:
            os.mkdir(path, 0o700)
        except FileExistsError:
            pass
        _check_directory(path)
    rendered = {str(home / name): data for name, data in plan['onboarding'].items()}
    for item in files:
        fd = os.open(item['path'], os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
        created.append(item)                 # ownership acquired here, before any byte is written
        with os.fdopen(fd, 'wb') as stream:
            stream.write(rendered[item['path']])


def _steps(seat, home, act_id, actor, presented_token, role, approval, commission, plan, made, already):
    """Run the planned steps in order. What each step made is observed even when it fails."""
    install = _install()
    hookset = _hookset()
    planned = {_key(item) for item in plan['make']}
    for item in plan['already']:
        if item['item'] != 'directory':
            already.append(item)

    def row():
        return store._read_participants_unlocked().get(seat) or {}
    # a. participant
    if ('participant', seat) in planned:
        try:
            _step('participant', lambda: store.join_participant(
                seat, presented_token=presented_token, kind='agent', family=FAMILY, channel=CHANNEL))
        finally:
            if row():
                made.append({'item': 'participant', 'seat': seat, 'role': store._default_role('agent', FAMILY)})
    # b. role, before the credential (a live credential pins the role)
    if ('role', seat) in planned:
        item = next(i for i in plan['make'] if _key(i) == ('role', seat))
        try:
            _step('role', lambda: store.set_participant_role(
                seat, role, presented_token=presented_token,
                approved_by_principal=approval[0] if approval else None,
                approved_by_principal_sha256=approval[1] if approval else None))
        finally:
            current = row()
            (made if current.get('role') == role and current.get('role_source') == 'explicit'
             else already).append(item)
    # c. home: private directory, seat files from the templates, registry binding
    for path in [Path(i['path']) for i in plan['make'] if i['item'] == 'directory']:
        if path in (home / '.orch', home / '.orch' / 'provisioning', home / KIT_DIRECTORY) \
                or home / KIT_DIRECTORY in path.parents:
            continue  # written by the provisioning, kit and onboarding steps below
        try:
            os.mkdir(path, 0o700)
        except FileExistsError:
            pass
        except OSError as exc:
            raise Refused('home_refused', 'home: directory_create_failed') from exc
    _check_directory(home)
    if plan['provision_home']:
        scratch = Path(tempfile.mkdtemp(prefix='orch-seat-new-')).resolve()
        files = [i for i in plan['make'] if i['item'] == 'file'
                 and Path(i['path']).parent in (home, home / '.orch' / 'provisioning')]
        try:
            commission_path = scratch / 'commission.md'
            fd = os.open(commission_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, 'wb') as stream:
                stream.write(commission)
            _step('home', lambda: machine.provision_home(
                seat, home, commission_path, plan['authority'], cycle=plan['cycle'],
                token=presented_token))
        finally:
            shutil.rmtree(scratch, ignore_errors=True)
            _observe(files, made)
            binding = next((i for i in plan['make'] if i['item'] == 'provisioned_home'), None)
            if binding is not None and row().get('provisioned_home') == str(home):
                made.append(binding)
        for name, data in plan['outputs'].items():
            if _file_sha(home / name) != _sha(data):
                raise Refused('home_render_mismatch', 'seat file bytes differ from the rendered plan')
    # d. credential: issued, or the unresolved act's own invite resumed; claimed in process into
    # the home; the consumed invite file removed
    token_item = next((i for i in plan['make'] if _key(i) == ('token', str(home / '.orch' / store.SEAT_TOKEN_FILENAME))),
                      None)
    if token_item is not None and token_item.get('invite_id'):
        invite_path = home / '.orch' / store.SEAT_INVITE_FILENAME
        made.append(_step('token', lambda: _claim(seat, token_item['invite_id'], invite_path, presented_token, made)))
    elif token_item is not None:
        made.append(_step('token', lambda: _issue_and_claim(seat, act_id, actor, presented_token, made)))
    for item in [i for i in plan['make'] if i['item'] == 'invite' and i.get('cleanup')]:
        try:
            Path(item['path']).unlink(missing_ok=True)  # consumed by the claim into this home's session
        except OSError as exc:
            raise Refused('token_refused', 'token: invite_cleanup_failed') from exc
        made.append(item)
    # e. kit (renders .claude files, writes a missing neutral grounding, records the hook set)
    if ('hookset', seat) in planned:
        kit = None
        try:
            kit = _step('kit', lambda: install.claude_install(presented_token=presented_token, seat=seat))
        finally:
            writes = {w['path']: w for w in (kit or {}).get('writes', [])}
            kit_files = [i for i in plan['make'] if i['item'] == 'file'
                         and Path(i['path']).parent == home / KIT_DIRECTORY]
            # Every file the kit reports writing is listed, so a kit that grows is still undone.
            listed = {i['path'] for i in kit_files}
            kit_files += [{'item': 'file', 'path': path, 'sha256': None,
                           'existed': writes[path].get('operation') != 'create'} for path in writes if path not in listed]
            for item in kit_files:
                if os.path.lexists(item['path']):
                    write = writes.get(item['path'], {})
                    # Provenance is what the plan saw before the act wrote; the installer's report can only
                    # add a replacement. A lost report never turns a file that existed into one the act made.
                    existed = item.get('existed') is not False or write.get('operation') == 'replace'
                    made.append({**item, 'sha256': write.get('sha256') or _file_sha(item['path']),
                                 'existed': existed, 'operation': 'replace' if existed else 'create'})
            record = row().get(hookset.FIELD)
            if record is not None:
                made.append({'item': 'hookset', 'seat': seat, 'generation': record['generation']})
            if ('grounding', seat) in planned:
                current = seat_grounding.current(seat, required=False)
                if current is not None:
                    made.append({'item': 'grounding', 'seat': seat, 'generation': current['generation']})
        if not kit or record is None or record['generation'] != kit['generation']:
            raise Refused('kit_refused', 'kit: record_not_current')
    elif ('grounding', seat) in planned:
        # A present kit whose neutral grounding record is missing: write only that record.
        current = _step('kit', lambda: seat_grounding.install_default(seat, actor))
        made.append({'item': 'grounding', 'seat': seat, 'generation': current['generation']})
    # f. the Chief of Staff's onboarding skill and templates, rendered in the plan
    skill = home / ONBOARDING_DIRECTORY
    files = [i for i in plan['make'] if i['item'] == 'file' and skill in Path(i['path']).parents]
    if files:
        created = []
        try:
            _step('onboarding', lambda: _write_onboarding(home, plan, files, created))
        finally:
            _observe(created, made)          # only what this act's exclusive opens created
        for name, data in plan['onboarding'].items():
            if _file_sha(home / name) != _sha(data):
                raise Refused('home_render_mismatch', 'onboarding file bytes differ from the rendered plan')


def _newest(seat, kind):
    tokens = store._read_tokens_unlocked()
    found = [rec for rec in store._token_records(tokens) if isinstance(rec, dict)
             and rec.get('kind') == kind and seat in (rec.get('participant_id'), rec.get('allowed_participant_id'))]
    return max(found, key=lambda rec: rec.get('created') or '', default={}).get('id')


def _seat_invites(seat):
    return [rec['id'] for rec in store._token_records(store._read_tokens_unlocked())
            if isinstance(rec, dict) and rec.get('kind') == 'invite' and rec.get('allowed_participant_id') == seat]


def _issue_and_claim(seat, act_id, actor, presented_token, made):
    """Issue the seat's invite, record which invite this act issued, then claim it in process.
    Committed but exceptional store outcomes are listed, then propagate."""
    invite_path = store.seat_invite_path(seat)
    before = set(_seat_invites(seat))
    try:
        invite = store.issue_seat_invite(seat, issuer=actor, auth='token', presented_token=presented_token)
    except COMMITTED_EXCEPTIONS as exc:
        made.append({'item': 'invite', 'path': str(invite_path),
                     'token_id': getattr(exc, 'token_id', None) or _newest(seat, 'invite')})
        raise
    finally:
        # The act still holds the token lock: an invite of this seat that appeared during the call is
        # this act's, and none means it issued none. A rerun owns only the invite recorded here.
        new = [tid for tid in _seat_invites(seat) if tid not in before]
        issued = new[0] if len(new) == 1 else None
        try:
            _append({'kind': KIND, 'event': 'issued', 'act': act_id, 'seat': seat, 'invite_id': issued})
        except OSError:
            if issued is not None and not any(i.get('token_id') == issued for i in made):
                made.append({'item': 'invite', 'path': str(invite_path), 'token_id': issued})
            raise
    return _claim(seat, invite['token_id'], Path(invite['path']), presented_token, made)


def _claim(seat, invite_id, path, presented_token, made):
    """Claim the seat's invite held at path in process, as `orch token claim` does: a new
    invite, or the unresolved act's own one resumed.

    The plaintext moves from the invite file into the claim and is dropped; only ids
    are kept. Committed but exceptional store outcomes are listed, then propagate.
    """
    token_path = store.seat_token_path(seat)

    def withdraw():
        # Nothing was consumed: withdraw the invite this act issued, then refuse.
        try:
            store.revoke_token(invite_id, presented_token=presented_token)
            path.unlink(missing_ok=True)
        except (ValueError, OSError):
            made.append({'item': 'invite', 'path': str(path), 'token_id': invite_id})
    try:
        value = store.read_secret_file(path)
    except OSError:
        withdraw()
        raise
    try:
        claim = store.claim_seat_token(seat, value)
    except (store.SeatCredentialCommitIndeterminate, store.SeatUncommittedStageNotRemoved):
        # Commit unknown or known absent: the invite file stays recoverable.
        made.append({'item': 'invite', 'path': str(path), 'token_id': invite_id})
        raise
    except (store.SeatTokenNotPlaced, store.SeatCredentialPlacementIndeterminate,
            store.SeatCredentialPlacedAfterCallbackError, store.SeatActWithoutReceipt,
            store.SeatCredentialPlacedAfterInterruption) as exc:
        path.unlink(missing_ok=True)  # consumed: never a phantom credential
        made.append({'item': 'token', 'path': str(token_path), 'invite_id': invite_id,
                     'token_id': getattr(exc, 'token_id', None) or _newest(seat, 'session')})
        raise
    except (ValueError, OSError):
        withdraw()
        raise
    finally:
        value = None
    path.unlink(missing_ok=True)  # consumed: never a phantom credential
    return {'item': 'token', 'path': str(claim['path']), 'token_id': claim['token_id'],
            'invite_id': invite_id, 'role': claim['role']}


# --- removal ------------------------------------------------------------------------------

def _acted(seat, rows, own_tokens):
    """Any log record from or to the seat, or any receipt by or about it but this act's own.

    Conservative: a seat named by any other record is retired, never removed, so a
    reused name can never inherit its mail or history.
    """
    if store.LOG_FILE.exists():
        for message in receipts._read_all(store.LOG_FILE):
            targets = message.get('recipients') or message.get('to') or []
            if message.get('from') == seat or seat in ([targets] if isinstance(targets, str) else targets):
                return True
    for row in rows:
        if any(row.get(field) == seat for field in AUTHOR_FIELDS):
            return True
        if row.get('seat') == seat and row.get('kind') not in OWN_KINDS:
            return True
    events, _ = ledger.read_events(0)
    for event in events:
        if event.get('actor_id') != seat:
            continue
        payload = event.get('payload') or {}
        if payload.get('mutation') == 'seat_token_claimed' and payload.get('token_id') in own_tokens:
            continue
        return True
    return False


def _removal_plan_file(home, seat, generation, settings_sha):
    """This kit's own removal plan and the settings image it derives, or (None, None)."""
    path = home / KIT_DIRECTORY / '.orch-install-preimages' / (generation + '.remove.json')
    if not os.path.lexists(path):
        return None, None
    try:
        data = machine._read_regular(path)
        plan = json.loads(data)
    except (OSError, ValueError):
        return None, None
    if (isinstance(plan, dict) and set(plan) == {'schema', 'seat', 'generation', 'before', 'after'}
            and plan['schema'] == REMOVAL_PLAN_SCHEMA and plan['seat'] == seat
            and plan['generation'] == generation and isinstance(plan['before'], str)
            and isinstance(plan['after'], str) and _sha(plan['before'].encode()) == settings_sha):
        return {'item': 'file', 'path': str(path), 'sha256': _sha(data)}, _sha(plan['after'].encode())
    return None, None


def _restore_binding(seat, item, dry_run):
    """Put back the registry facts this act's home binding replaced, while the row still holds
    exactly that binding. Runs inside the act's registry hold."""
    if 'prior' not in item:
        return False
    parts = store._read_participants_unlocked()
    row = parts.get(seat)
    if row is None or row.get('provisioned_home') != item['path'] \
            or (row.get('provisioning') or {}).get('cycle') != item['cycle']:
        return False
    if not dry_run:
        for key in BINDING_FIELDS:
            if key in item['prior']:
                row[key] = item['prior'][key]
            else:
                row.pop(key, None)
        row['last_update'] = store.now_iso()
        store._write_participants_unlocked(parts)
    return True


def _file_sha(path):
    try:
        return _sha(machine._read_regular(Path(path)))
    except (OSError, ValueError):
        return 'unreadable'


def remove(seat, *, presented_token, dry_run=False) -> dict:
    """Undo exactly what this seat's provisioning acts list, and nothing else."""
    _check_seat(seat)
    return _gate(presented_token, lambda actor: _remove(seat, actor, presented_token, dry_run),
                 dry_run=dry_run)


def _remove(seat, actor, presented_token, dry_run):
    rows = _history()
    if _unresolved(seat, rows, KIND) is not None:
        raise Refused('act_unresolved', 'rerun the provisioning act to resolve it first')
    pending = _unresolved(seat, rows, REMOVAL_KIND)
    active, home, last = _active(seat, rows)
    result = {'seat': seat, 'home': home, 'dry_run': bool(dry_run), 'act': None,
              'undone': [], 'already': [], 'left': [], 'participant': None}
    if not active and pending is None:
        if last is not None:
            result['already'] = last['undone'] + last['already']
            result['participant'] = last['participant']
        return result
    home = Path(home)
    parts = store._read_participants_unlocked()
    row = parts.get(seat)
    tokens = store._read_tokens_unlocked()
    items = list(active.values())
    own_tokens = {i['token_id'] for i in items if i['item'] in ('token', 'invite')}
    others = [rec['id'] for rec in _seat_credentials(seat, tokens) if rec['id'] not in own_tokens]
    if others:
        raise Refused('seat_has_other_credentials', 'revoke the seat\'s other credentials first')
    hookset = _hookset()
    kit = next((i for i in items if i['item'] == 'hookset'), None)
    settings = next((i for i in items if i['item'] == 'file'
                     and i['path'] == str(home / KIT_DIRECTORY / KIT_SETTINGS)), None)
    kit_undo = False
    after_sha = None
    if kit is not None:
        current = (row or {}).get(hookset.FIELD)
        if current is not None and current.get('generation') == kit['generation']:
            kit_undo = True
            if dry_run:
                try:
                    preview = _install().claude_remove(presented_token=presented_token, seat=seat, dry_run=True)
                except (ValueError, OSError, store.RegistryMutationRefused) as exc:
                    raise Refused('kit_remove_refused', _code(exc)) from exc
                after_sha = preview['writes'][0]['sha256']
        elif current is not None:
            raise Refused('kit_changed_since_act', 'the seat\'s kit was replaced after this act')
    participant = next((i for i in items if i['item'] == 'participant'), None)
    disposition = None
    if participant is not None:
        if row is None:
            disposition = 'absent'
        elif row.get('retired_at'):
            disposition = 'retired'
        else:
            disposition = 'retire' if _acted(seat, rows, own_tokens) else 'remove'
    plan = {'kit': kit_undo, 'participant': disposition}
    act_id = None
    intent = None
    if not dry_run:
        act_id = 'seat-new-removal-' + uuid.uuid4().hex
        try:
            intent = _append({'kind': REMOVAL_KIND, 'event': 'intent', 'act': act_id, 'seat': seat,
                              'home': str(home), 'actor': actor,
                              'resumes': pending['act'] if pending else None,
                              'plan': {**plan, 'items': items}})
        except OSError as exc:
            raise Refused('intent_receipt_failed', 'nothing was removed') from exc
    undone, already, left = [], [], []
    outcome, reason, failure = 'completed', None, None
    try:
        _undo(seat, home, presented_token, dry_run, items, kit, kit_undo, settings, after_sha,
              disposition, tokens, undone, already, left)
    except Refused as exc:
        outcome, reason, failure = 'refused', exc.reason, exc
    except COMMITTED_EXCEPTIONS as exc:
        outcome, reason, failure = 'incomplete', 'store_act_incomplete', exc
    except Exception as exc:
        outcome, reason = 'refused', 'act_failed'
        failure = Refused('act_failed', 'unexpected failure; inspect the receipts')
        failure.__cause__ = exc
    state = {'remove': 'removed', 'retire': 'retired'}.get(disposition, disposition)
    if failure is not None and disposition in ('remove', 'retire') and not any(
            i['item'] == 'participant' for i in undone):
        state = 'unchanged'
    result.update(home=str(home), undone=undone, already=already, left=left, participant=state, act=act_id)
    if dry_run:
        if failure is not None:
            raise failure
        result['participant'] = disposition
        return result
    try:
        _append({'kind': REMOVAL_KIND, 'event': 'completed', 'act': act_id,
                 'intent_digest': intent['digest'], 'seat': seat, 'home': str(home), 'actor': actor,
                 'outcome': outcome, 'reason': reason, 'resumes': pending['act'] if pending else None,
                 'undone': undone, 'already': already, 'left': left, 'participant': state})
    except Exception as exc:
        raise store.SeatActWithoutReceipt('seat new --remove', seat, 'completion receipt failed; '
                                          'inspect the home and registry before retrying') from (failure or exc)
    if failure is not None:
        raise failure
    return result


def _undo(seat, home, presented_token, dry_run, items, kit, kit_undo, settings, after_sha,
          disposition, tokens, undone, already, left):
    removing = set()        # paths this removal deletes (or would delete)
    # 1. kit: the managed hooks and the recorded qualification, by generation
    if kit is not None:
        if kit_undo:
            if not dry_run:
                try:
                    _install().claude_remove(presented_token=presented_token, seat=seat,
                                             replace=kit['generation'])
                except (ValueError, OSError, store.RegistryMutationRefused) as exc:
                    raise Refused('kit_remove_refused', _code(exc)) from exc
            undone.append(kit)
        else:
            already.append(kit)
    plan_file = None
    if settings is not None and kit is not None:
        plan_file, plan_after = _removal_plan_file(home, seat, kit['generation'], settings['sha256'])
        after_sha = plan_after or after_sha
    # 2. credentials: revoke what this act issued; its file only if it still holds it
    for item in [i for i in items if i['item'] in ('token', 'invite')]:
        rec = tokens.get(item['token_id']) or {}
        live = _live(rec, tokens) or (rec.get('kind') == 'session' and not rec.get('revoked'))
        if live and not dry_run:
            try:
                store.revoke_token(item['token_id'], presented_token=presented_token)
            except (ValueError, OSError, store.RegistryMutationRefused) as exc:
                raise Refused('token_revoke_refused', _code(exc)) from exc
        path = Path(item['path'])
        holds = False
        if os.path.lexists(path):
            try:
                holds = bool(rec) and store._token_matches(store.read_secret_file(path), rec)
            except OSError:
                holds = False
        if holds:
            removing.add(path)
            if not dry_run:
                path.unlink()
        if os.path.lexists(path) and not holds:
            left.append({**item, 'note': 'file differs; credential revoked' if live or rec.get('revoked')
                         else 'file differs'})
        elif live or holds:
            undone.append(item)
        else:
            already.append(item)
    # 3. files, newest first, only while byte-equal to what was written
    files = [i for i in items if i['item'] == 'file']
    if plan_file is not None and not any(_key(i) == _key(plan_file) for i in files):
        files.append({**plan_file, 'existed': False, 'note': 'this kit removal plan'})
    for item in reversed(files):
        path = Path(item['path'])
        if not os.path.lexists(path):
            already.append(item)
            continue
        current = _file_sha(path)
        allowed = {item['sha256']}
        if settings is not None and item['path'] == settings['path'] and after_sha:
            allowed.add(after_sha)
        if item.get('existed') is not False or item.get('operation', 'create') != 'create':
            # Only a file the act is shown to have created is removed: a replaced file's earlier bytes,
            # and a file of unknown provenance, are not this act's to remove.
            left.append({**item, 'note': 'replaced by the act, not created by it; kept' if item.get('existed')
                         else 'not shown to be created by the act; kept'})
        elif DIGEST.fullmatch(item['sha256'] or '') and current in allowed:
            removing.add(path)
            if not dry_run:
                path.unlink()
            undone.append(item)
        else:
            left.append({**item, 'note': 'changed since the act; kept'})
    # 4. directories, deepest first, only when then empty
    directories = [i for i in items if i['item'] == 'directory']
    if plan_file is not None:
        directories.append({'item': 'directory', 'path': str(Path(plan_file['path']).parent),
                            'note': 'this kit removal plan directory'})
    for item in sorted(directories, key=lambda i: len(Path(i['path']).parts), reverse=True):
        path = Path(item['path'])
        if not os.path.lexists(path):
            if 'note' not in item:
                already.append(item)
            continue
        try:
            remaining = [p for p in path.iterdir() if p not in removing]
        except OSError:
            remaining = [path]
        if os.path.islink(path) or remaining:
            if 'note' not in item:
                left.append({**item, 'note': 'not empty; kept'})
            continue
        removing.add(path)
        if not dry_run:
            path.rmdir()
        undone.append(item)
    # 5. registry facts, then the participant: removed if it never acted, else retired
    for item in [i for i in items if i['item'] in ('provisioned_home', 'role', 'grounding')]:
        if item['item'] == 'grounding':
            left.append({**item, 'note': 'receipt history is append-only'})
        elif disposition == 'remove':
            undone.append({**item, 'note': 'with the participant'})
        elif item['item'] == 'provisioned_home' and disposition is None:
            # A participant this act did not create keeps its row: the binding's prior facts come back,
            # so its next cycle provisions again.
            if _restore_binding(seat, item, dry_run):
                undone.append({**item, 'note': 'the participant kept; its prior home binding restored'})
            else:
                left.append({**item, 'note': 'changed since the act, or its prior facts unknown; kept'})
        else:
            left.append({**item, 'note': 'kept on the registry row'})
    participant = next((i for i in items if i['item'] == 'participant'), None)
    if participant is None:
        return
    if disposition in ('absent', 'retired'):
        already.append({**participant, 'note': disposition})
        return
    if not dry_run:
        try:
            if disposition == 'retire':
                store.retire_participant(seat, presented_token=presented_token)
            else:
                store.remove_participant(seat, presented_token=presented_token)
        except (ValueError, OSError, store.RegistryMutationRefused) as exc:
            raise Refused('participant_remove_refused', _code(exc)) from exc
    undone.append({**participant, 'note': 'retired: it acted' if disposition == 'retire' else 'removed: it never acted'})
