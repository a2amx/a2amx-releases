#!/usr/bin/env python3
"""PSQR Orchestrator web server — a thin view over the message store.

All state lives in the append-only store (see store.py and
docs/DELIVERY_V2_DESIGN.md). This server only renders it for the web UI
(index.html) and remote humans, and proxies pane interactions. Notification
is the delivery daemon's job (delivery.py), not this server's.

The operator entry point is the `orch` CLI; legacy CLI subcommands here
print a pointer and exit.

Usage:
    uv run python psqr_orchestrator.py serve [--host H] [--port P]
"""

from __future__ import annotations

import json
import product_identity
import os
import hmac
import sys
import time
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Dict

try:
    from fastapi import FastAPI, HTTPException
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import FileResponse
    from starlette.requests import Request  # module level: postponed annotations
    import uvicorn                           # must resolve in module globals
    WEB_SUPPORT = True
except ImportError:
    WEB_SUPPORT = False

import store
from attention import scan_pane
import ledger  # noqa: F401 — import activates the Stage-0 trace-ledger mirror (registers a
              # post-send hook into store at import; see ledger.install()). Kept a bare import
              # so the running hub captures every send() to store/ledger.jsonl.
from console_observation import observe

def package_version():
    # Source checkout uses its own pyproject; an installed wheel uses metadata.
    import tomllib
    source = Path(__file__).with_name('pyproject.toml')
    if source.is_file():
        with source.open('rb') as stream:
            return tomllib.load(stream)['project']['version']
    from importlib.metadata import version
    return version(product_identity.load().distribution)


VERSION = package_version()
SCRIPT_DIR = Path(__file__).resolve().parent
AUTH_TOKEN = os.environ.get("PSQR_AUTH_TOKEN", "")        # operator: observation only
OWNER = product_identity.inherited_setting("PSQR_OWNER") or "local-operator"             # the one participant nobody can remove
RUNTIME_SNAPSHOT = store.STORE_DIR / "runtime.json"
# Proxy/forwarding headers an L7 (HTTP) reverse proxy / ngrok-http stamps.
_PROXY_HEADERS = ("x-forwarded-for", "x-forwarded-host", "x-real-ip", "forwarded")


def _is_direct_local(request) -> bool:
    """Direct loopback observation for the startup readiness HMAC only.

    This predicate grants neither authentication nor access to a credential.
    HTML is public and never contains the UI token, including on loopback.
    """
    client = (request.client.host if request.client else "") or ""
    if client not in ("127.0.0.1", "::1"):
        return False
    return not any(h in request.headers for h in _PROXY_HEADERS)


def _public_origin() -> str:
    """The ONE explicitly-configured public origin (the stable tunnel domain,
    e.g. https://hub.example.com) — consumed by BOTH the CORS allowlist and
    the CSRF Origin guard below, so the two can never drift (reviewer lockout,
    2026-07-10: the tunnel origin was wired into CORSMiddleware only, and the
    CSRF guard 403'd every remote browser request — including POST /claim —
    before the invite token was even examined; every curl test passed because
    curl sends no Origin). PSQR_PUBLIC_ORIGIN is canonical; PSQR_EXTRA_CORS_ORIGIN
    is honored as the pre-existing alias. Normalized without a trailing slash."""
    v = (os.environ.get("PSQR_PUBLIC_ORIGIN", "").strip()
         or os.environ.get("PSQR_EXTRA_CORS_ORIGIN", "").strip())
    return v.rstrip("/")


def _is_local_origin(request, port) -> bool:
    """The request's browser Origin (if any) is the hub itself — local, or the
    ONE configured public origin (see _public_origin). A missing Origin
    (same-origin top-level navigation, or a non-browser client) is allowed; any
    other PRESENT Origin (a cross-site/CSRF attempt) is rejected."""
    origin = request.headers.get("origin", "")
    if not origin:
        return True
    if origin in (f"http://127.0.0.1:{port}", f"http://localhost:{port}"):
        return True
    pub = _public_origin()
    return bool(pub) and origin == pub


SAFETY_DISCLAIMER = f"""[{product_identity.load().display_name}: discussion-only]
This is a collaborative discussion prompt. Do not edit files, run side-effecting commands,
perform git/process actions, or treat this message as task authorization.
Operational instructions should be given directly by the operator inside your own CLI session."""

# Distinctive LIVE-prompt / approval-menu strings only. Dropped the over-generic
# "Action Required" and "Press enter to continue": they false-positived on agents'
# own output — e.g. Gemma writing "Standing Down — No Action Required" tripped the
# "Action Required" substring while idle, flagging her red with nothing pending.
# The pattern list and the scan live in `attention` — ONE definition, shared with
# delivery.py. This module used to carry a private copy under a "keep in sync by
# hand" comment; it drifted, and the test carried a third copy that could not
# detect the drift. Do not reintroduce a local list here.


# In-process cache so /state polling never triggers a capture-pane storm.
_runtime_cache: Dict[str, Any] = {"ts": 0.0, "value": None}
RUNTIME_TTL = 2.0

# Presence: web clients heartbeat by passing ?who=<id> on their /state poll.
# Ephemeral (in-process) by design — presence is "connected right now", not
# durable state. A participant is online if seen within PRESENCE_TTL.
_presence: Dict[str, float] = {}
PRESENCE_TTL = 15.0  # poll is ~3s; tolerate a couple of missed beats
# SDK-channel agents (Claude/Codex via run_sdk_agent) don't poll /state; they heartbeat a
# store file every ~3s (store.mark_present). Fresh within this window == online (PSQ-251).
SDK_PRESENCE_TTL = 12.0


def _role(request) -> str:
    return getattr(request.state, "role", None)


def _seat_read_identity(request):
    """Only the surface observes the estate; roles never widen seat reads."""
    if _role(request) == "surface":
        return None
    identity = getattr(request.state, "identity", None)
    if not isinstance(identity, str) or not identity:
        raise HTTPException(status_code=403, detail="seat_read_identity_required")
    return identity


def _require_participant_read(request, participant_id):
    identity = _seat_read_identity(request)
    if identity is not None and participant_id != identity:
        raise HTTPException(status_code=403, detail="seat_read_scope_mismatch")


def _sanitize_participants_for_guest(view: Dict[str, Any]) -> Dict[str, Any]:
    """Strip tmux-targeting fields from a participants map for guests.
    native_session_id / channel reveal which sessions a nudge could hit."""
    out = {}
    for pid, p in view.items():
        out[pid] = {k: v for k, v in p.items()
                    if k not in ("native_session_id", "channel")}
    return out


def _inject_head_script(html: str, script_tag: str) -> str:
    """Insert a script tag immediately after the real opening <head> tag.

    Content-immune by PARSING, never pattern-matching — the recurring PR #57
    lesson: a close-anchored replace was swallowed by a commented closing-head
    token (round-1 HIGH), and the first regex remediation could be fooled by a
    commented literal ``<head>`` or a ``<header``-prefixed tag (reviewer,
    round 2). html.parser tokenizes the way a browser does, so comments,
    quoted ``>`` in attributes, and tag-name boundaries are all handled. The
    insertion point is the first parser event after the real head-open tag;
    a head-injected assignment is parsed before any script that reads it.
    Falls back to prepending when no real head tag exists.
    """
    class _HeadOpenFinder(HTMLParser):
        def __init__(self) -> None:
            super().__init__()
            self.head_seen = False
            self.insert_pos: tuple[int, int] | None = None  # (line, col)

        def _mark(self) -> None:
            # First event AFTER the real <head> start tag = the offset just
            # past that tag's closing '>' (whitespace/data counts as an event).
            if self.head_seen and self.insert_pos is None:
                self.insert_pos = self.getpos()

        def handle_starttag(self, tag, attrs):
            self._mark()
            if tag == "head":
                self.head_seen = True

        def handle_startendtag(self, tag, attrs):
            self._mark()

        def handle_endtag(self, tag):
            self._mark()

        def handle_data(self, data):
            self._mark()

        def handle_comment(self, data):
            self._mark()

        def handle_decl(self, decl):
            self._mark()

        def handle_pi(self, data):
            self._mark()

    finder = _HeadOpenFinder()
    finder.feed(html)
    finder.close()
    if not finder.head_seen:
        return script_tag + html
    if finder.insert_pos is None:
        return html + script_tag  # <head> is the last token in the document
    line, col = finder.insert_pos  # 1-based line, 0-based column
    lines = html.split("\n")
    offset = sum(len(l) + 1 for l in lines[: line - 1]) + col
    return html[:offset] + script_tag + html[offset:]


def _message_auth_meta(request, sender: str, **extra: Any) -> Dict[str, Any]:
    """Server-asserted provenance consumed by paid SDK seats before a turn.

    The client never supplies these fields. Local same-UID ``store.send`` calls
    remain the explicit host trust boundary; every HTTP-originated message is
    marked so a seat can reject the legacy shared guest token and any request
    without a source-bound principal before invoking a vendor. Surface-level
    operator/UI tokens do not authorize sends; _message_seat_token requires the
    existing identity-bound session credential.
    """
    source = getattr(request.state, "auth_source", None) or "unauthenticated"
    actor = getattr(request.state, "identity", None)
    meta = {**extra, "auth_source": source}
    if actor:
        meta["authenticated_actor"] = actor
        if actor != sender:
            meta["on_behalf_of"] = sender
    return meta


def _message_seat_token(request, sender: str) -> str:
    """Return the A.4 credential bound to ``sender`` or refuse the hub action.

    Operator/UI/shared guest authentication protects the HTTP surface but does
    not establish a seat identity.  Message authorship is therefore available
    only to an existing per-seat session; store.send revalidates the same token
    at the canonical write boundary.
    """
    token = getattr(request.state, "seat_token", None)
    record, _ = store.token_verdict(token) if token else (None, "missing")
    if record is None or record.get("participant_id") != sender:
        raise HTTPException(
            status_code=403,
            detail="message send requires a valid seat credential bound to sender",
        )
    return token


# --- legacy-shape views over the store ---

def _participants_view() -> Dict[str, Dict[str, Any]]:
    parts = store.load_participants()
    return {
        pid: {
            "id": pid,
            "label": p.get("label", pid),
            "family": p.get("family"),
            "kind": "human" if p.get("kind") == "human" else "chat",
            "is_daemon": pid == store.DAEMON_SEAT,
            "model": p.get("recorded_model"),
            "effort": p.get("effort"),
            "native_session_id": p.get("tmux_session"),
            "channel": p.get("channel"),
            "hand_raised": bool(p.get("hand_raised")),
            "message": p.get("hand_message", ""),
            "last_update": p.get("last_update", ""),
        }
        for pid, p in parts.items()
        if not store.inactive_participant(p) and store.has_mailbox(p)
    }


def _broadcasts_view(limit: int = 100, *, identity: str | None = None) -> list:
    parts = store.load_participants()
    aliases = store.load_aliases()
    out = []
    import dialogue
    messages, _ = dialogue.select(
        limit=limit,
        predicate=(lambda row: dialogue.matches(row, participant=identity))
            if identity is not None else None,
        visible=lambda row: not store.obsolete_human_notice(row, parts))
    from console_projection import delivery_projection
    delivery = delivery_projection(messages, registry=parts)
    if identity is not None:
        from console_read_scope import delivery as scoped_delivery
        delivery = scoped_delivery(delivery, identity)
    for m in messages:
        sender = m.get("from", "unknown")
        if any(store.inactive_participant(parts.get(pid, {}))
               for pid in [sender, *m.get("to", [])]):
            continue
        p = parts.get(sender, {})
        label = p.get("label") or (
            f"{aliases[sender]['successor']} (then {sender})" if sender in aliases
            else sender)
        out.append({
            **{k: m[k] for k in ("status", "superseded_by", "actionable", "withdrawal_notices") if k in m},
            "id": m.get("id"),
            "participant_id": sender,
            "agent": sender,
            "display_name": label,
            "family": p.get("family"),
            "kind": "human" if p.get("kind") == "human" else "chat",
            "message_class": "system" if sender == "System" else "dialogue",
            "message": m.get("text", ""),
            # Same evidence as /log; vetting and delivery are separate facts.
            # The shared projection is read-only, including FETCHED replay.
            "vet": m.get("vet") or {},
            "delivery": delivery.get(m.get("id"), []),
            # sender-tag fix (msg-6d48d854ea): expose addressing so the UI can
            # render "Operator → reviewer" instead of an unaddressed broadcast.
            "to": m.get("to", []),
            "room": m.get("room"),
            "is_broadcast": m.get("to") == ["all"],
            "sent_to_agents": m.get("kind") == "message" and m.get("to") != ["all"],
            "timestamp": m.get("ts", ""),
        })
    return out


def _tmux_sessions_view() -> Dict[str, Dict[str, str]]:
    return {
        pid: {"session_name": p["tmux_session"]}
        for pid, p in store.load_participants().items()
        if p.get("tmux_session") and not store.inactive_participant(p)
    }


def _compute_runtime() -> Dict[str, Any]:
    # The daemon's legacy snapshot has no socket provenance. Never consume it.
    registry = store.load_participants()
    runtime = {}
    for pid in registry:
        if store.inactive_participant(registry[pid]) or not store.has_mailbox(registry[pid]):
            continue
        row = observe(pid, registry, lines=30)
        reason = scan_pane(row["pane"]) if row["alive"] else None
        runtime[pid] = {**{key: value for key, value in row.items() if key != "pane"},
                        "needs_attention": reason is not None, "reason": reason}
    return {"tmux_runtime": runtime}


def _runtime_view() -> Dict[str, Any]:
    # Cache only observations made by this web process for this exact registry.
    # A re-declaration invalidates the cache immediately, including socket moves.
    registry = store.load_participants()
    if (time.time() - _runtime_cache["ts"] > RUNTIME_TTL
            or _runtime_cache["value"] is None
            or _runtime_cache.get("registry") != registry):
        _runtime_cache["value"] = _compute_runtime()
        _runtime_cache["ts"] = time.time()
        _runtime_cache["registry"] = registry
    return _runtime_cache["value"]


def build_state_view(*, identity: str | None = None) -> Dict[str, Any]:
    from console_projection import panel_snapshot, harness_snapshot
    registry = store.load_participants()
    harness, harness_sources = harness_snapshot(registry)
    return {
        "harness_facts": harness,
        "harness_sources": harness_sources,
        "version": VERSION,
        "mode": "brainstorm",
        "participants": _participants_view(),
        "panel": panel_snapshot(),
        "broadcasts": _broadcasts_view(identity=identity),
        "tmux_sessions": _tmux_sessions_view(),
        "channel_messages": [],
        "channel_replies": [],
        "send_events": [],
        "locks": {},
        "assignments": {},
        "tasks": [task for task in store.task_board()
                  if not any(store.inactive_participant(registry.get(pid, {}))
                      for pid in [task.get("assignee"), task.get("created_by"),
                                  *(note.get("by") for note in task.get("notes", []))])],
        **_runtime_view(),
        "home_dir": str(Path.home()),
        "script_dir": str(SCRIPT_DIR),
        "work_dir": str(SCRIPT_DIR.parent.parent),
    }


# --- server ---

def cmd_serve(args) -> None:
    # Phase 0 W0.5 (ORCH_SPEC_01 D-STO-1): the server resolves its store through the one
    # resolver and refuses to start without a valid locator — before binding a port.
    try:
        store.require_bound_store()
    except store.StoreUnbound as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(exc.exit_code)
    if not WEB_SUPPORT:
        print(f"web dependencies are missing; reinstall {product_identity.load().distribution}",
              file=sys.stderr)
        raise SystemExit(1)
    from starlette.middleware.base import BaseHTTPMiddleware
    from starlette.responses import JSONResponse

    if not AUTH_TOKEN:
        print("refusing to start without PSQR_AUTH_TOKEN on any host",
              file=sys.stderr)
        raise SystemExit(1)

    store.ensure_store()
    app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)

    from fastapi.responses import JSONResponse

    @app.exception_handler(store.RegistryMutationRefused)
    def _registry_refusal(request: Request, exc: store.RegistryMutationRefused):
        return JSONResponse(status_code=403, content={'reason': exc.reason, 'detail': str(exc)})

    @app.exception_handler(store.BurnGuardTripped)
    def _burn_guard_handler(request: Request, exc: store.BurnGuardTripped):
        # Hub-layer storm/loop cap tripped — 429, not a 500.
        return JSONResponse(status_code=429, content={"detail": f"burn-guard: {exc}"})

    # Local origins ONLY, even in remote mode. The previous '*' (reviewer DO-NOT-SHIP
    # #27 v1) let a malicious site issue cross-origin requests to the local hub; the
    # browser allowed them, and the bare-loopback exemption then elevated them to
    # operator (CSRF). Remote guests reach the hub through the served UI on the
    # tunnel origin, which we add explicitly when bound to 0.0.0.0.
    cors_origins = [f"http://127.0.0.1:{args.port}", f"http://localhost:{args.port}"]
    extra = _public_origin()   # ONE knob for CORS + the CSRF guard — never drifts
    if extra:
        cors_origins.append(extra)
    app.add_middleware(CORSMiddleware, allow_origins=cors_origins,
                       allow_methods=["*"], allow_headers=["*"])

    import secrets
    UI_TOKEN = os.environ.get("PSQR_UI_TOKEN") or secrets.token_urlsafe(24)
    # The shared atomic 0600 writer sets permissions before writing plaintext.
    from product_identity import state_root
    store.write_secret_file(state_root() / "run" / ".ui_token", UI_TOKEN)
    PUBLIC_PATHS = {"/", "/index.html", "/manifest.json", "/icon.svg",
                    "/icon-192.png", "/icon-512.png", "/app", "/app/"}

    class TokenAuthMiddleware(BaseHTTPMiddleware):
        async def dispatch(self, request: Request, call_next):
            if (request.method in {"GET", "HEAD"}
                    and (request.url.path in PUBLIC_PATHS
                         or request.url.path.startswith("/app/assets/"))):
                return await call_next(request)
            if not _is_local_origin(request, args.port):
                return JSONResponse(status_code=403,
                                    content={"detail": "cross-origin request rejected"})
            # The body invite is the sole credential for this operation.
            if request.method == "POST" and request.url.path == "/claim":
                return await call_next(request)
            auth = request.headers.get("authorization", "")
            presented = auth[7:] if auth.startswith("Bearer ") else ""
            if presented and (hmac.compare_digest(presented.encode(), AUTH_TOKEN.encode())
                              or hmac.compare_digest(presented.encode(), UI_TOKEN.encode())):
                request.state.role = "surface"
                request.state.identity = None
                request.state.auth_source = ("ui_token" if hmac.compare_digest(presented.encode(), UI_TOKEN.encode())
                                             else "operator_token")
                return await call_next(request)
            rec = store.resolve_token(presented) if presented else None
            if rec:
                pid = rec["participant_id"]
                participant = store.load_participants().get(pid)
                if participant is not None:
                    request.state.role = participant.get("role")
                    request.state.identity = pid
                    request.state.auth_source = "per_user_token"
                    request.state.seat_token = presented
                    return await call_next(request)
            headers = {}
            challenge = request.headers.get('x-orch-readiness', '')
            if (request.method == 'GET' and request.url.path == '/state'
                    and _is_direct_local(request) and len(challenge) == 64
                    and all(c in '0123456789abcdef' for c in challenge)):
                from service_lifecycle import readiness_proof
                headers = {'X-Orch-Readiness-Proof': readiness_proof(AUTH_TOKEN, os.getpid(), challenge),
                           'Cache-Control': 'no-store'}
            return JSONResponse(status_code=401,
                                content={"detail": "Invalid or missing bearer credential"},
                                headers=headers)

    app.add_middleware(TokenAuthMiddleware)

    class UsagePublicationMiddleware:
        """Publish after authentication, outside BaseHTTPMiddleware's body buffer."""
        def __init__(self, app):
            self.app = app

        async def __call__(self, scope, receive, send):
            if (scope.get('type') != 'http' or scope.get('method') != 'GET'
                    or scope.get('path') != '/console/usage'):
                return await self.app(scope, receive, send)
            scope.pop('_orch_usage_publication', None)
            held = []

            async def defer_placeholder(message):
                if scope.get('_orch_usage_publication'):
                    held.append(message)
                else:
                    await send(message)

            await self.app(scope, receive, defer_placeholder)
            if not scope.get('_orch_usage_publication'):
                return
            # The authorized endpoint emits only an empty placeholder. Keep its
            # CORS headers but perform the private read and transport send here.
            if (not held or held[0].get('status') != 200
                    or any(m.get('body') for m in held)):
                raise RuntimeError('invalid usage publication placeholder')
            import anyio
            from account_usage_control import publish, PUBLICATION_SEND_TIMEOUT

            def emit(result):
                response = JSONResponse(result, status_code=200 if result['status'] == 'ok' else 503,
                                        headers={"Cache-Control": "no-store"})
                response.raw_headers.extend((k, v) for k, v in held[0].get('headers', [])
                                            if k.lower() not in {b'content-type', b'content-length', b'cache-control'})

                async def emit_with_deadline():
                    with anyio.fail_after(PUBLICATION_SEND_TIMEOUT):
                        await response(scope, receive, send)
                anyio.from_thread.run(emit_with_deadline)

            # A worker owns the fence through the final ASGI send or its bounded
            # cancellation. No buffered body can be delivered after it releases.
            await anyio.to_thread.run_sync(lambda: publish(emit))

    app.add_middleware(UsagePublicationMiddleware)

    @app.get("/")
    @app.get("/index.html")
    def serve_index(request: Request):
        from fastapi.responses import HTMLResponse
        html = (SCRIPT_DIR / "index.html").read_text(encoding="utf-8")
        from product_identity import html_shell
        return HTMLResponse(html_shell(html) if product_identity.is_public() else html,
                            headers={"Cache-Control": "no-store"})

    @app.get("/manifest.json")
    def serve_manifest():
        from fastapi.responses import JSONResponse
        return JSONResponse(product_identity.manifest_shell(
            (SCRIPT_DIR / "public" / "manifest.json").read_bytes()),
            headers={"Cache-Control": "no-store"})

    @app.get("/icon.svg")
    def serve_icon():
        return FileResponse(SCRIPT_DIR / "public" / "icon.svg", media_type="image/svg+xml")

    @app.get("/icon-192.png")
    def serve_icon_192():
        return FileResponse(SCRIPT_DIR / "public" / "icon-192.png", media_type="image/png")

    @app.get("/icon-512.png")
    def serve_icon_512():
        return FileResponse(SCRIPT_DIR / "public" / "icon-512.png", media_type="image/png")

    # --- orch app (docs/ORCH_APP_SPEC.md §7.4) --------------------------------
    # The committed web/dist build is served at /app as a public static shell —
    # identical posture to index.html: the page/assets carry no data, all data
    # flows through the authed endpoints. Credentials come only from the private
    # file selected by the operator, never from this shell. Vite's base is /app/ so the
    # HTML's asset URLs are absolute; in-app navigation is hash-based (no
    # catch-all rewrites needed).
    APP_DIST = SCRIPT_DIR / "web" / "dist"

    @app.get("/app")
    @app.get("/app/")
    def serve_app(request: Request):
        from fastapi.responses import HTMLResponse
        if not (APP_DIST / "index.html").is_file():
            return JSONResponse(
                status_code=503,
                content={"detail": "web/dist missing — regenerate it with the "
                                   "pinned build (web/README.md)"})
        html = (APP_DIST / "index.html").read_text(encoding="utf-8")
        from product_identity import html_shell
        return HTMLResponse(html_shell(html) if product_identity.is_public() else html,
                            headers={"Cache-Control": "no-store"})

    if (APP_DIST / "assets").is_dir():
        from fastapi.staticfiles import StaticFiles
        app.mount("/app/assets", StaticFiles(directory=APP_DIST / "assets"),
                  name="app_assets")


    @app.get("/app/unread")
    def get_unread(request: Request):
        if _role(request) != "surface":
            raise HTTPException(status_code=403, detail="Unread ledger requires a surface credential")
        from fastapi.responses import HTMLResponse
        from console_unread import render
        from console_projection import unread_snapshot
        return HTMLResponse(render(unread_snapshot()),
                            headers={"Cache-Control": "no-store"})


    from console_board import Board
    app.state.console_board = Board()
    from console_plan import Plan
    app.state.console_plan = Plan()

    def require_surface(request):
        if _role(request) != "surface":
            raise HTTPException(status_code=403, detail="Console ledger and files require a surface credential")

    @app.get("/console/usage")
    def get_console_usage(request: Request):
        require_surface(request)
        from starlette.responses import Response
        request.scope['_orch_usage_publication'] = True
        return Response(headers={"Cache-Control": "no-store"})

    @app.get("/console/ledger")
    def get_console_ledger(request: Request, view: str = 'all',
                           participant: str | None = None,
                           thread: str = '', re_only: str = '', lane: str = '',
                           authority: str = '', limit: int = 500):
        require_surface(request)
        from console_ledger import read_messages, select, change_token, RETIRED_SELECTION
        from console_courier import references, root as courier_root
        from starlette.responses import Response
        # from= and to= are the sender and recipient sets ("from" is a Python keyword). A client still
        # sending the retired selection is refused plainly, before any read or conditional answer.
        senders = request.query_params.get('from', '')
        recipients = request.query_params.get('to', '')
        if 'seats' in request.query_params or view in {'tuple', 'pair'}:
            raise HTTPException(status_code=400, detail=RETIRED_SELECTION)
        selection = dict(senders=senders, recipients=recipients, view=view, participant=participant, thread=thread,
                         re_only=re_only, lane=lane, authority=authority, limit=limit)
        try:
            etag = change_token(selection, courier_root())
            headers = {"Cache-Control": "no-store", "ETag": etag}
            if request.headers.get('if-none-match') == etag:
                return Response(status_code=304, headers=headers)
            messages = read_messages()
        except (OSError, ValueError, UnicodeError):
            raise HTTPException(status_code=503, detail="Ledger source read failed or incomplete")
        try:
            result = select(messages, senders=senders, recipients=recipients, view=view, participant=participant, thread=thread,
                            re_only=re_only, lane=lane, authority=authority, limit=limit)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
        result['courier_status'] = 'configured' if courier_root() is not None else 'unavailable'
        for row in result['messages']:
            row['courier_references'] = references(row['body'])
        return JSONResponse(result, headers=headers)

    @app.get("/console/board")
    def get_console_board(request: Request, view: str = 'live', owner: str = '',
                          status: str = '', trigger: str = ''):
        require_surface(request)
        try:
            result = app.state.console_board.snapshot(view=view, owner=owner, status=status, trigger=trigger,
                                                      registered_seats=store.load_participants())
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
        return JSONResponse(result, status_code=200 if result['status'] == 'ok' else 503,
                            headers={"Cache-Control": "no-store"})

    # The plan view (request 20): the latest sealed build-coordination cut, verified by its contract.
    # Read-only, surface only; unavailable (503) until PSQR_CONSOLE_PLAN_DIR names the cuts' root.
    @app.get("/console/plan")
    def get_console_plan(request: Request):
        require_surface(request)
        result = app.state.console_plan.snapshot()
        return JSONResponse(result, status_code=200 if result['status'] == 'ok' else 503,
                            headers={"Cache-Control": "no-store"})

    @app.get("/console/courier")
    def get_console_courier(request: Request, message: str = '', reference: int = 0):
        require_surface(request)
        from console_ledger import read_messages
        from console_courier import inspect_reference, root as courier_root
        if courier_root() is None:
            return JSONResponse(inspect_reference([], message, reference), status_code=503,
                                headers={"Cache-Control": "no-store"})
        try:
            messages = read_messages()
        except (OSError, ValueError, UnicodeError):
            raise HTTPException(status_code=503, detail="Ledger source read failed or incomplete")
        try:
            result = inspect_reference(messages, message, reference)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
        return JSONResponse(result, headers={"Cache-Control": "no-store"})

    from console_read_cache import state_snapshot

    @app.get("/state")
    @state_snapshot
    def get_state(request: Request):
        # The poll doubles as a heartbeat: mark the caller present.
        now = time.time()
        identity = getattr(request.state, "identity", None)
        if identity and identity in store.load_participants():
            _presence[identity] = now
        scoped_identity = _seat_read_identity(request) if _role(request) != "guest" else None
        view = build_state_view(identity=scoped_identity) if scoped_identity is not None else build_state_view()
        from console_status import snapshot as console_status_snapshot
        view['console_status'] = console_status_snapshot()
        if _role(request) == "surface":
            from console_projection import unread_snapshot
            view["unread"] = unread_snapshot()
        for pid, p in view["participants"].items():
            # online = a live web client (in-process heartbeat) OR a fresh SDK-channel
            # heartbeat (store file) — the latter is how native-SDK agents show up (PSQ-251).
            web_live = (now - _presence.get(pid, 0)) < PRESENCE_TTL
            sdk_age = store.presence_age(pid)
            sdk_live = sdk_age is not None and sdk_age < SDK_PRESENCE_TTL
            p["online"] = web_live or sdk_live
        role = getattr(request.state, "role", None)
        view["role"] = role
        if role == "guest":
            # Guests see the shared conversation, not the machine: no local
            # filesystem paths, no tmux session names to aim requests at, no
            # pane attention state. They DO get read-only liveness (alive
            # true/false per agent) so the roster shows who's up — but never
            # the session name (no targeting info) and never the pane button
            # (tmux_sessions stays stripped, so the UI's hasTmux is false).
            for key in ("home_dir", "script_dir", "work_dir", "tmux_sessions",
                        "available_sessions"):
                view.pop(key, None)
            view["tmux_runtime"] = {
                pid: {"alive": bool(r.get("alive"))}
                for pid, r in (view.get("tmux_runtime") or {}).items()
            }
            view["participants"] = _sanitize_participants_for_guest(view["participants"])
            view["broadcasts"] = [
                {key: value for key, value in row.items() if key not in {"vet", "delivery"}}
                for row in view.get("broadcasts", [])]
            # Guest policy: shared dialogue and roster facts, not operational
            # route/receipt/help/token metadata. Allowlisting also contains
            # future additions to the privileged panel projection.
            public_fields = {"seat", "vendor_family", "model", "effort", "context_window", "label"}
            view["panel"] = {"seats": [
                {key: {part: value for part, value in field.items() if part in {"value", "source"}}
                 for key, field in row.items() if key in public_fields and isinstance(field, dict)}
                for row in view.get("panel", {}).get("seats", [])]}
            view.pop("harness_sources", None)
            view.pop("console_status", None)
        elif scoped_identity is not None:
            from console_read_scope import state as scoped_state
            view = scoped_state(view, scoped_identity)
        from fastapi.responses import JSONResponse
        return JSONResponse(view, headers={"Cache-Control": "no-store"})


    @app.get("/participants")
    def get_participants(request: Request):
        view = _participants_view()
        if _role(request) == "guest":
            view = _sanitize_participants_for_guest(view)
        else:
            identity = _seat_read_identity(request)
            if identity is not None:
                from console_read_scope import participants as scoped_participants
                view = scoped_participants(view, identity)
        return list(view.values())


    # --- per-user access tokens (#20 wiring): invite / claim / logout / revoke ---


    @app.post("/claim")
    async def api_claim_invite(request: Request):
        """Redeem a seat invite for an existing identity; mint its browser session. The invite token is read from the BODY (never the
        query string — it's a secret). Returns the session token (shown once)."""
        try:
            body = await request.json()
        except Exception:  # noqa: BLE001
            body = {}
        invite = body.get("invite_token", "") if isinstance(body, dict) else ""
        if not isinstance(invite, str) or not invite:
            raise HTTPException(status_code=400, detail="invite_token required in JSON body")
        try:
            session_token, pid = store.claim_invite(invite, surface="browser")
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
        return {"session_token": session_token, "participant_id": pid}

    @app.post("/logout")
    async def api_logout(request: Request):
        from fastapi.responses import Response
        # No token selector exists: even a valid holder cannot name another.
        if request.query_params or await request.body():
            raise HTTPException(status_code=400, detail="logout accepts only the presented credential")
        presented = getattr(request.state, "seat_token", None)
        if presented:
            store.revoke_presented(presented)
        return Response(status_code=204)

    @app.get("/capabilities")
    def api_capabilities(request: Request):
        import authority
        pid = getattr(request.state, "identity", None)
        role = (store.load_participants().get(pid) or {}).get("role") if pid else None
        return {"participant_id": pid, "role": role,
                "authorities": authority.allowed_authorities(role) if pid else []}

    @app.get("/whoami")
    def api_whoami(request: Request):
        """The presenting token's bound identity. The UI calls this on EVERY auth
        path (injected UI token, stored/reused session token, fresh entry, claim)
        to sync its display name to the server's source of truth — so a stale
        localStorage name on a reused per-user token can never drift from the
        token's identity and trip sender-binding (Bugbot #32 MED)."""
        return {"participant_id": getattr(request.state, "identity", None),
                "display_name": ("OWNER" if getattr(request.state, "role", None) == "surface"
                                 else getattr(request.state, "identity", None)),
                "role": getattr(request.state, "role", None),
                "auth_source": getattr(request.state, "auth_source", None)}

    @app.post("/channel/send")
    async def post_channel_send(request: Request):
        from starlette.concurrency import run_in_threadpool
        body = None
        if await request.body():
            try:
                body = await request.json()
            except ValueError:
                raise HTTPException(status_code=400, detail="send requires a JSON object")
            if not isinstance(body, dict):
                raise HTTPException(status_code=400, detail="send requires a JSON object")
        return await run_in_threadpool(_store_channel_send, request, body)

    def _store_channel_send(request: Request, body):
        """Validate/store in a worker: registry/log IO must not block the event loop."""
        sender = getattr(request.state, "identity", None)
        if "sender" in request.query_params:
            raise HTTPException(status_code=403, detail="sender is derived from the bound identity")
        seat_token = _message_seat_token(request, sender)
        if body is not None:
            if "sender" in body or "from" in body:
                raise HTTPException(status_code=403, detail="sender is derived from the bound identity")
            text, targets, envelope = body.get("text"), body.get("targets"), body.get("envelope")
        else:
            text, targets, envelope = request.query_params.get("text"), request.query_params.get("targets"), None
        if (not isinstance(text, str) or not isinstance(targets, (list, str))
                or (isinstance(targets, list) and not all(isinstance(t, str) for t in targets))
                or (envelope is not None and not isinstance(envelope, dict))):
            raise HTTPException(status_code=400, detail="text, explicit targets and an envelope object are required")
        target_list = targets.split(",") if isinstance(targets, str) else targets
        try:
            import message_headers
            target_list = store.resolve_recipients(target_list, sender)
            comparison = message_headers.validate(text, envelope, sender, target_list)
            if comparison["verdict"] == "refused":
                raise HTTPException(status_code=422, detail=comparison)
            msg = store.send(sender, target_list, text,
                             envelope=envelope,
                             presented_token=seat_token,
                             validate_client_headers=True,
                             meta=_message_auth_meta(
                                 request, sender, disclaimer="discussion-only"))
        except message_headers.ClientHeaderRefused as exc:
            raise HTTPException(status_code=422, detail=exc.comparison)
        except (store.UnreadMailRefused, store.UnreadStateBusy) as exc:
            raise HTTPException(status_code=409, detail=exc.detail)
        except store.RecipientPolicyError as exc:
            raise HTTPException(status_code=400, detail=exc.detail)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc))
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
        import receipts
        queued = [row for row in receipts.rows() if row.get("kind") == "delivery"
                  and row.get("msg-id") == msg["id"] and row.get("event") == "QUEUED"]
        focusing = msg.get("focus") or {}  # D-GOV-2 (f) §3.9: present only for a focusing recipient
        return {"message": msg, "vet": msg["vet"], "queued": queued,
                "sends": [{"participant_id": row["seat"], "status": "queued",
                           **({"focus_until": focusing[row["seat"]]["until"]}
                              if row["seat"] in focusing else {})} for row in queued]}


    @app.get("/log")
    def get_log(request: Request, participant: str | None = None, among: str | None = None, limit: int = 100):
        import dialogue
        if participant is not None and among is not None:
            raise HTTPException(status_code=400, detail="participant and among are mutually exclusive")
        try:
            seats = dialogue.resolve_names(among, option="among") if among is not None else None
            selected = dialogue.resolve_names(participant, option="participant") if participant is not None else None
            if selected is not None and len(selected) != 1:
                raise ValueError("participant must name exactly one seat")
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
        seat = next(iter(selected)) if selected else None
        identity = _seat_read_identity(request) if _role(request) != "guest" else None
        # Query filters only narrow the token-bound predicate; they never
        # choose whose mail the authenticated seat is allowed to read.
        predicate = (lambda row: (identity is None or dialogue.matches(row, participant=identity))
                     and dialogue.matches(row, participant=seat, among=seats)) \
            if identity is not None or seat is not None or seats is not None else None
        participants = store.load_participants()
        messages, offset = dialogue.select(
            limit=limit, predicate=predicate,
            visible=lambda row: not store.obsolete_human_notice(row, participants))
        from console_projection import delivery_projection
        if _role(request) == "guest":
            messages = [{key: row[key] for key in ("id", "ts", "from", "to", "recipients", "kind", "text") if key in row}
                        for row in messages]
            delivery = {}
        else:
            delivery = delivery_projection(messages)
            if identity is not None:
                from console_read_scope import delivery as scoped_delivery
                delivery = scoped_delivery(delivery, identity)
        # The global byte cursor reveals unrelated log volume and is not an
        # ordinary-seat paging contract. Keep the key without exposing it.
        return {"messages": messages, "offset": offset if identity is None else None,
                "delivery": delivery}

    @app.get("/participants/{participant_id}/transcript")
    def get_transcript(participant_id: str, request: Request):
        _require_participant_read(request, participant_id)
        from console_transcript import open_transcript
        from fastapi.responses import StreamingResponse
        from starlette.background import BackgroundTask
        registry = store.load_participants()
        if participant_id not in registry:
            raise HTTPException(status_code=404, detail="participant not registered")
        try:
            start = int(request.query_params['from']) if 'from' in request.query_params else None
            stop = int(request.query_params['to']) if 'to' in request.query_params else None
        except ValueError:
            raise HTTPException(status_code=400, detail="from and to must be byte offsets")
        try:
            snapshot = open_transcript(participant_id, registry, start=start, stop=stop)
        except FileNotFoundError:
            raise HTTPException(status_code=404, detail="pane.log is unavailable")
        except (OSError, ValueError) as exc:
            raise HTTPException(status_code=409, detail=f"registered transcript unavailable: {exc}")
        return StreamingResponse(snapshot.chunks(), media_type="application/octet-stream",
            headers={"X-Transcript-From": str(snapshot.start), "X-Transcript-To": str(snapshot.stop),
                     "X-Transcript-Size": str(snapshot.size), "Cache-Control": "no-store"},
            background=BackgroundTask(snapshot.close))


    @app.get("/participants/{participant_id}/pane")
    def get_participant_pane(participant_id: str, request: Request, lines: int = 400):
        _require_participant_read(request, participant_id)
        registry = store.load_participants()
        if participant_id not in registry:
            raise HTTPException(status_code=404, detail="participant not registered")
        return observe(participant_id, registry, lines=lines)

    # log_level="warning" keeps uvicorn quiet — without this banner a healthy start
    # printed NOTHING and looked hung (operator confusion during the Stage-3a smoke).
    print(f"[{product_identity.command()}] serving http://{args.host}:{args.port}  (store: {store.STORE_DIR})")
    print(f"[{product_identity.command()}] quiet by design — only warnings/errors are logged. Ctrl-C to stop.")
    from server_process import owned_server
    with owned_server():
        uvicorn.run(app, host=args.host, port=args.port, log_level="warning")


def main():
    import argparse
    parser = argparse.ArgumentParser(description=product_identity.load().display_name+" web server")
    sub = parser.add_subparsers(dest="command")
    p_serve = sub.add_parser("serve")
    p_serve.add_argument("--host", default="127.0.0.1")
    p_serve.add_argument("--port", type=int, default=8020)
    args = parser.parse_args()
    if args.command == "serve":
        cmd_serve(args)
    else:
        print(f"This is the web server. The operator entry point is the `{product_identity.command()}` CLI\n"
              f"(run `{product_identity.command()}` for the menu, `{product_identity.command()} --help` for subcommands).")


if __name__ == "__main__":
    main()
