"""Location-neutral message transport contract for native adapter hosts.

The soundness core and protocol clients use only this module.  Process ids,
signals, filesystem session paths, and child ownership belong to a concrete
transport implementation and must never be added here.  A future network
transport can therefore satisfy the same bounded message/liveness contract
without changing protocol or soundness decisions.

``management`` remains the deliberately operator-visible extension point.
Callers that render it must treat unknown future values as neutral/degraded,
not as a crash or an implicit local-process classification.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Dict, Protocol, runtime_checkable


JsonObject = Dict[str, Any]


class TransportError(RuntimeError):
    """The transport failed or violated its bounded framing contract."""


class TransportTimeout(TransportError):
    """A monotonic transport deadline expired."""


class ProtocolError(RuntimeError):
    """A peer message violated the pinned protocol contract."""


def require_deadline(deadline: float) -> float:
    """Validate an absolute ``time.monotonic()`` deadline."""
    if isinstance(deadline, bool) or not isinstance(deadline, (int, float)) \
            or not math.isfinite(deadline):
        raise ValueError("deadline must be a finite monotonic timestamp")
    return float(deadline)


@dataclass(frozen=True)
class PeerIdentityReceipt:
    """Opaque proof that the concrete transport attested its peer.

    ``binding_sha256`` binds the receipt to the concrete evidence consumed by
    the local evidence registrar.  The protocol host can compare bindings but
    cannot inspect or invent location-specific evidence.  In B-C2 the local
    registrar feeds that evidence through ``record_vendor_observed`` before it
    returns this receipt; a boolean assertion is never sufficient.
    """

    kind: str
    proof_ref: str
    binding_sha256: str

    def __post_init__(self) -> None:
        for name, value in (("kind", self.kind), ("proof_ref", self.proof_ref)):
            if not isinstance(value, str) or not value \
                    or any(char in value for char in "\r\n\0"):
                raise ValueError(f"{name} must be a clean non-empty string")
        digest = self.binding_sha256
        if not isinstance(digest, str) or len(digest) != 64 \
                or any(char not in "0123456789abcdef" for char in digest):
            raise ValueError("binding_sha256 must be a lowercase SHA-256 digest")


@dataclass(frozen=True)
class TransportHealth:
    alive: bool
    detail: str | None = None


@runtime_checkable
class MessageTransport(Protocol):
    """One bounded, location-neutral, full-duplex message channel."""

    def open(self, *, deadline: float) -> PeerIdentityReceipt:
        """Open the channel and return authenticated opaque peer evidence."""

    def send(self, message: JsonObject, *, deadline: float) -> None:
        """Send one complete message before the absolute deadline."""

    def receive(self, *, deadline: float) -> JsonObject:
        """Receive one complete message before the absolute deadline."""

    def health(self) -> TransportHealth:
        """Return a low-cost local liveness observation."""

    def close(self, *, deadline: float) -> None:
        """Close the channel and release its concrete resources."""
