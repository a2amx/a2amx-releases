"""S7 launched intent/claim/result and fetch-derived acceptance.

Only the daemon-owned Controller writes intents or settlement receipts. Host
calls can verify and fetch but cannot claim, submit results or mint acceptance.
No method in this module submits a vendor turn or transports a message body.
"""
from __future__ import annotations

import re
import secrets
import time

import launched_protocol as wire
import launched_storage as files
import receipts
import store

_controller = None  # No implicit enablement, environment switch or lazy activation.
HOLD_DELAYS = (60., 300., 1800.)  # Adopted temporary-hold schedule, persisted per attempt.


class _Snapshot:
    """One authoritative journal read/index per locked reconciliation operation.

    FETCHED validity is rebuilt once, including late aborts. Only this operation's
    own durable appends extend the snapshot; it never crosses a lock release.
    """
    def __init__(self, rows=None):
        self.rows = list(receipts.strict_rows() if rows is None else rows)
        self.pres, self.posts, self.by_seat = {}, {}, {}
        self.positions, self.poked, self.holds, self.dead = {}, set(), set(), set()
        import recall
        self.recalled = recall.graph(self.rows)
        self.fetches = {}
        for i, row in enumerate(self.rows):
            self._index(row, i)
        commits = {r.get("txn-id"):i for i,r in enumerate(self.rows)
                   if r.get("kind") == "delivery-transaction" and r.get("phase") == "commit"}
        for i, row in store.valid_fetched_deliveries(self.rows):
            self.fetches.setdefault((row.get("seat"), row.get("msg-id")), []).append(
                (i, commits.get(row.get("txn-id"), -1), row))

    def _index(self, row, position):
        eid = row.get("event-id")
        if row.get("kind") == "nudge" and row.get("phase") == "pre":
            self.pres.setdefault(eid, []).append(row)
            self.positions[eid] = position
            if row.get("route_kind") == "launched":
                self.by_seat.setdefault(row.get("target seat"), []).append(row)
        if (row.get("kind") == "nudge" and row.get("phase") == "post") or row.get("kind") == "wake-reconciled":
            self.posts[eid] = row
        if row.get("kind") == "delivery" and row.get("event") == "POKED":
            self.poked.add(row.get("nudge-event-id"))
        if row.get("kind") == "wake_route_hold": self.holds.add(eid)
        if row.get("kind") == "wake_route_dead": self.dead.add(eid)

    def append(self, row):
        receipts.append_durable(row)
        self._index(row, len(self.rows))
        self.rows.append(row)

    def fetched(self, value):
        position = self.positions.get(value["pre_receipt_ref"], -1)
        for i, commit, row in self.fetches.get((value["seat"], value["message_id"]), ()):
            if i <= position or commit <= position:
                continue
            link = row.get("launched")
            if link is not None and (link.get("host_generation") != value["binding"]["host_generation"]
                                     or link.get("route_generation") != value["route_generation"]):
                continue
            return row
        return None

    def needs_settlement(self, pre):
        value, eid = pre["intent"], pre["event-id"]
        if value["message_id"] in self.recalled:
            return False
        post, fetched = self.posts.get(eid), self.fetched(value)
        if fetched:
            return (not post or post.get("result") != "accepted" or
                    post.get("fetch-txn-id") != fetched["txn-id"] or eid not in self.poked)
        # Preserve late invalidation instead of trusting an accepted label.
        return post is None or post.get("result") == "accepted"


def _intent(seat, params, *, snapshot=None):
    iid = params.get("intent_id") or params.get("delivery", {}).get("intent_id")
    value = files.read("intent", iid)
    if (not value or value.get("seat") != seat or value.get("binding") != params["binding"]
            or value.get("route_generation") != params["route_generation"]):
        raise wire.Refused("intent_mismatch")
    snapshot = snapshot or _Snapshot()
    journal = snapshot.rows
    matches = snapshot.pres.get(value["pre_receipt_ref"], [])
    if len(matches) != 1 or matches[0].get("intent") != value:
        raise wire.Refused("intent_mismatch")
    return value, journal, matches[0]


def _claimed(value):
    claim = files.read("claim", value["intent_id"])
    if (not claim or claim.get("intent_sha256") != wire.fingerprint(value)
            or claim.get("intent_id") != value["intent_id"]):
        raise wire.Refused("intent_mismatch")
    return claim


def _result_observation(intent_id):
    try:
        return files.read("result", intent_id)
    except (OSError, wire.Refused):
        return None


def _fetched(value, journal, pre, *, snapshot=None):
    found = (snapshot or _Snapshot(journal)).fetched(value)
    if found is not None:
        yield found


def verify(seat, params, *, now):
    value, journal, pre = _intent(seat, params)
    claim = _claimed(value)
    delivery = {k: value[k] for k in ("intent_id", "pre_receipt_ref", "pointer", "not_after")}
    delivery["claim_ref"] = claim["claim_ref"]
    if params["delivery"] != delivery:
        raise wire.Refused("intent_mismatch")
    if now >= value["not_after"]:
        raise wire.Refused("intent_expired")
    if files.read("withdrawn", value["intent_id"]) is not None:
        raise wire.Refused("intent_withdrawn")
    # Newer pending mail invalidates this unsubmitted pointer; the daemon must
    # preserve its non-submission evidence before publishing a replacement.
    pending = receipts.pending_message_ids(seat)
    if not pending or pending[-1] != value["message_id"]:
        raise wire.Refused("intent_withdrawn")
    witness_ref = "verify-" + wire.fingerprint({"intent": value, "claim": claim})
    result = {"verification_ref": witness_ref, "intent_id": value["intent_id"],
              "binding": value["binding"], "route_generation": value["route_generation"],
              "message_id": value["message_id"], "pointer": value["pointer"], "not_after": value["not_after"]}
    # An immutable lookup, reproducible from intent+claim; not a receipt/lease.
    files.create("witness", witness_ref, {"seat": seat, "params": params, "result": result})
    return result


def witness(seat, params, *, now):
    record = files.read("witness", params["verification_ref"])
    if (not record or record.get("seat") != seat or record["params"]["binding"] != params["binding"]
            or record["params"]["route_generation"] != params["route_generation"]):
        raise wire.Refused("intent_mismatch")
    result = verify(seat, record["params"], now=now)
    if result != record["result"] or result["verification_ref"] != params["verification_ref"]:
        raise wire.Refused("intent_mismatch")
    return result


def proof(seat, params, *, now, snapshot=None):
    snapshot = snapshot or _Snapshot()
    value, journal, pre = _intent(seat, params, snapshot=snapshot)
    if params["pre_receipt_ref"] != value["pre_receipt_ref"]:
        raise wire.Refused("intent_mismatch")
    fetched = snapshot.fetched(value)
    state, reason, fetch_ref = "pending", "fetch_pending", None
    if fetched:
        state, reason, fetch_ref = "accepted", "fetch_committed", fetched["txn-id"]
    else:
        try:
            claim = files.read("claim", value["intent_id"])
        except (OSError, wire.Refused):
            claim = {"corrupt": True}  # Unresolved claim is not an unclaimed slot.
        result = _result_observation(value["intent_id"])
        if result:
            if (not claim or result.get("claim_ref") != claim.get("claim_ref")
                    or result.get("intent_sha256") != wire.fingerprint(value)):
                result = None
        if result and result["status"] == "rejected":
            state, reason = "refused", "protocol_unsupported"
        elif result and result["status"] == "not_attempted":
            state, reason = "held", "seat_busy"
        elif result and result["status"] == "submitted" and now >= value["reconcile_at"]:
            state, reason = "uncertain", "delivery_uncertain"
        elif not result and now >= value["not_after"]:
            state, reason = (("uncertain", "delivery_uncertain") if claim else ("held", "seat_busy"))
    return {"delivery_state": state, "fetch_ref": fetch_ref, "reason": reason, "evaluated_at": now}


def at_chokepoint(**kwargs):
    if _controller is None:
        return False, "launched_gateway_unavailable"
    return _controller.enqueue(**kwargs)


def install_controller(controller, *, presented_token):
    """Explicit trusted-owner integration, authenticated as the daemon.

    No host-wire/CLI endpoint calls this. The implemented profile is disposable
    only, so this entrypoint cannot turn on live-store dispatch.
    """
    if type(controller) is not Controller:
        raise wire.Refused("qualification_invalid")
    def apply(_):
        global _controller
        controller._bounds()
        if _controller is not None and _controller is not controller:
            raise wire.Refused("launch_conflict")
        _controller = controller
    return controller._daemon(presented_token, apply)


def observe_pass(*, credential, participants, log, handled_pairs=None):
    """Daemon sweep through the same chokepoint; inert without an installed owner."""
    for seat, row in participants.items():
        route = row.get("wake_route") or {}
        if route.get("kind") != "launched":
            continue
        pending = receipts.pending_message_ids(seat)
        if handled_pairs is not None:
            handled_pairs.update((seat, mid) for mid in pending)
        if _controller is None or credential is None:
            continue
        try:
            _controller.reconcile(seat, presented_token=credential)
            if pending:
                receipts.inject_nudge(presented_token=credential, expected_requester=store.DAEMON_SEAT,
                    target_seat=seat, msg_id=pending[-1], exact_bytes="mail: " + pending[-1],
                    writer=None, route_kind="launched")
        except (wire.Refused, store.RegistryMutationRefused, OSError, ValueError):
            log("launched gateway observation unavailable; retained evidence requires reconciliation")


class Controller:
    """The supervisor's core execution plane, never a seat-token consumer.

    Installed profile controls both bounds. A live timing profile must have a
    measured adoption reference resolved by the trusted qualifier. No business
    request may supply either a timing value or a qualification.
    """

    def __init__(self, enrollment, *, dispatch_profile=None, clock=time.time):
        self.enrollment, self.dispatch_profile, self.clock = enrollment, dispatch_profile, clock

    @staticmethod
    def _daemon(token, action, expected=None):
        def apply(seat):
            actor, _ = store._verdict_unlocked(token, store._read_tokens_unlocked())
            row = store._read_participants_unlocked().get(seat) or {}
            if (seat != store.DAEMON_SEAT or row.get("kind") != "system" or row.get("role") != "system_governor"
                    or actor.get("role") != "daemon" or (expected is not None and seat != expected)):
                raise wire.Refused("credential_scope")
            with receipts._nudge_lock():
                return action(seat)
        return store.authenticated_registry_act(token, apply)

    def _current(self, seat, binding=None, generation=None):
        from launched_gateway import Gateway
        route = (store._read_participants_unlocked().get(seat) or {}).get("wake_route")
        if not route or route.get("kind") != "launched":
            raise wire.Refused("binding_mismatch")
        Gateway._route(seat, {"binding": binding or route["binding"],
                              "route_generation": generation or route["generation"]})
        self.enrollment.current(seat, route["binding"])
        return route

    def _bounds(self):
        profile = self.dispatch_profile
        if not profile:
            raise wire.Refused("live_unqualified", "unavailable")
        wire.exact(profile, {"mode", "submission_seconds", "reconciliation_seconds", "adoption_ref"})
        a, b = profile["submission_seconds"], profile["reconciliation_seconds"]
        wire.timestamp(a); wire.timestamp(b)
        if not 0 < a <= b <= 3600:
            raise wire.Refused("qualification_invalid")
        if profile["mode"] == "disposable":
            root = store.require_bound_store().resolve()
            if not root.is_relative_to('/private/tmp') and not root.is_relative_to('/tmp'):
                raise wire.Refused("live_unqualified", "unavailable")
        else:
            # No live measured T is shipped with gateway v1. Qualification is
            # a later adopted record, not an environment/caller switch.
            raise wire.Refused("live_unqualified", "unavailable")
        return a, b

    def enqueue(self, *, presented_token, expected_requester, target_seat, msg_id, exact_bytes):
        def apply(requester):
            route = self._current(target_seat)
            a, b = self._bounds()
            if wire.pointer(exact_bytes) != "mail: " + msg_id:
                raise wire.Refused("intent_mismatch")
            if receipts._delivery_state(msg_id, target_seat) == "FETCHED":
                return True, "already_fetched"
            pending = receipts.pending_message_ids(target_seat)
            if not pending or pending[-1] != msg_id:
                raise wire.Refused("intent_mismatch")
            lineage = self._next_attempt(target_seat, route, b)
            if isinstance(lineage, str):
                return True, lineage
            if lineage.get("supersedes") is None:
                # D-GOV-2 (f): a focus period defers only a new intent's pre; a held
                # or uncertain intent's successor above is the open attempt's own.
                import focus
                if focus.deferring_unlocked(target_seat, None, self.clock()) is not None:
                    return True, "focus_deferred"
            now = self.clock(); iid = "intent-" + secrets.token_hex(16); preid = "evt-" + secrets.token_hex(16)
            value = {"intent_id": iid, "pre_receipt_ref": preid, "seat": target_seat,
                     "binding": route["binding"], "route_generation": route["generation"],
                     "message_id": msg_id, "pointer": exact_bytes, "created_at": now,
                     "not_after": now + a, "reconcile_at": now + b,
                     "window_seconds": b, **lineage}
            receipts.append_durable({"kind": "nudge", "phase": "pre", "route_kind": "launched",
                "event-id": preid, "requester": requester, "role": "daemon", "target seat": target_seat,
                "msg-id": msg_id, "exact bytes": exact_bytes, "generation": route["generation"],
                "intent": value, "epoch": now, "ts": store.now_iso(), **lineage})
            files.create("intent", iid, value)
            return True, "intent_queued"
        try:
            return self._daemon(presented_token, apply, expected_requester)
        except wire.Refused as exc:
            return False, exc.code
        except store.RegistryMutationRefused:
            return False, "credential_invalid"

    def _next_attempt(self, seat, route, window):
        snapshot = _Snapshot()
        # A provisioned incarnation gets its own active queue and budget. Old
        # records remain in the snapshot for late fetch reconciliation only.
        pres = [p for p in snapshot.by_seat.get(seat, ()) if p["intent"]["binding"] == route["binding"]
                and p["intent"]["message_id"] not in snapshot.recalled]
        budget_spent = any(p["intent"].get("recovery") for p in pres)
        if not pres:
            return {"recovery": False, "supersedes": None, "hold_attempt": 0, "terminal_at": None}
        for old in pres:
            if snapshot.needs_settlement(old):
                self._settle(old["intent"], snapshot=snapshot)
        last = pres[-1]; value = last["intent"]
        state = proof(seat, value, now=self.clock(), snapshot=snapshot)
        if state["delivery_state"] == "accepted":
            return {"recovery": False, "supersedes": None, "hold_attempt": 0, "terminal_at": None}
        post = snapshot.posts.get(last["event-id"])
        if post and post["result"] == "refused":
            state.update(delivery_state="refused", reason=post["reason"])
        now = self.clock()
        if state["delivery_state"] == "pending":
            return "coalesced"
        if state["delivery_state"] == "held":
            attempts = value.get("hold_attempt", 0)
            ready = value["not_after"] + HOLD_DELAYS[min(attempts, 2)]
            self._hold(value, ready, attempts, snapshot=snapshot)
            if now < ready:
                return "held"
            # The old immutable intent is closed before any successor exists.
            # It has no claim, or a definitive not_attempted result.
            files.create("withdrawn", value["intent_id"], {"intent_id": value["intent_id"], "reason": "seat_busy"})
            return {"recovery": value.get("recovery", False), "supersedes": last["event-id"],
                    "hold_attempt": attempts + 1, "terminal_at": value.get("terminal_at")}
        if post is None:
            raise wire.Refused("persistence_unknown", "unknown")
        if state["delivery_state"] == "refused":
            if budget_spent or value.get("recovery"):
                return self._dead(value, state["reason"], snapshot=snapshot)
            if now < post["epoch"] + 30:
                return "retry_scheduled"
            terminal_at = None
        else:
            terminal_at = value.get("terminal_at") or post["epoch"] + 2 * window
            boundary = (value.get("terminal_at") if value.get("recovery") else post["epoch"] + window)
            if boundary is None:
                boundary = post["epoch"] + window
            if now < boundary:
                return "awaiting_reconciliation"
            if budget_spent or value.get("recovery"):
                return self._dead(value, "acceptance_unresolved", snapshot=snapshot)
        # enqueue already rechecked current OS ownership. This creates a new
        # event, never reclaims/reissues the old claim. Its uncertainty survives.
        return {"recovery": True, "supersedes": last["event-id"],
                "hold_attempt": 0, "terminal_at": terminal_at}

    def _hold(self, value, ready, attempt, *, snapshot):
        if value["pre_receipt_ref"] not in snapshot.holds:
            snapshot.append({"kind": "wake_route_hold", "route_kind": "launched", "seat": value["seat"],
                "generation": value["route_generation"], "event-id": value["pre_receipt_ref"], "reason": "seat_busy",
                "retry_at": ready, "attempt_count": attempt + 1, "retry_pointer": True,
                "epoch": self.clock(), "ts": store.now_iso()})

    def _dead(self, value, reason, *, snapshot):
        if value["pre_receipt_ref"] not in snapshot.dead:
            snapshot.append({"kind": "wake_route_dead", "route_kind": "launched", "seat": value["seat"],
                "generation": value["route_generation"], "event-id": value["pre_receipt_ref"],
                "reason": reason, "epoch": self.clock(), "ts": store.now_iso()})
        return "dead_" + reason

    def claim(self, intent_id, *, presented_token):
        def apply(_):
            value = files.read("intent", intent_id)
            if not value:
                raise wire.Refused("intent_mismatch")
            self._current(value["seat"], value["binding"], value["route_generation"])
            value, journal, pre = _intent(value["seat"], value)
            if next(_fetched(value, journal, pre), None):
                files.create("withdrawn", intent_id, {"intent_id": intent_id, "reason": "fetch_committed"})
                raise wire.Refused("intent_withdrawn")
            if files.read("withdrawn", intent_id):
                raise wire.Refused("intent_withdrawn")
            if files.read("claim", intent_id):
                raise wire.Refused("claim_conflict")
            if self.clock() >= value["not_after"]:
                raise wire.Refused("intent_expired")
            pending = receipts.pending_message_ids(value["seat"])
            if not pending or pending[-1] != value["message_id"]:
                raise wire.Refused("intent_withdrawn")
            claim = {"intent_id": intent_id, "intent_sha256": wire.fingerprint(value),
                     "claim_ref": "claim-" + secrets.token_hex(16)}
            files.create("claim", intent_id, claim)
            return {**{k: value[k] for k in ("intent_id", "pre_receipt_ref", "pointer", "not_after")},
                    "claim_ref": claim["claim_ref"]}
        return self._daemon(presented_token, apply)

    def result(self, intent_id, claim_ref, status, *, presented_token, diagnostic=""):
        wire.text(intent_id); wire.text(claim_ref)
        if status not in {"submitted", "rejected", "not_attempted"}:
            raise wire.Refused()
        if type(diagnostic) is not str:
            raise wire.Refused()
        def apply(_):
            def ignored(code):
                receipts.append_durable({"kind": "launched-result-ignored", "reason": code,
                    "intent_sha256": wire.fingerprint(intent_id), "claim_sha256": wire.fingerprint(claim_ref),
                    "epoch": self.clock(), "ts": store.now_iso()})
                raise wire.Refused(code)
            value = files.read("intent", intent_id)
            if not value:
                ignored("intent_mismatch")
            try:
                claim = _claimed(value)
            except wire.Refused:
                ignored("intent_mismatch")
            if claim["claim_ref"] != claim_ref:
                ignored("intent_mismatch")
            if files.read("result", intent_id):
                ignored("result_conflict")
            if status == "not_attempted" and self.clock() < value["not_after"]:
                raise wire.Refused("intent_mismatch")
            # Retain late evidence, but proof() never equates submitted with a
            # fetch and settlement cannot rewrite an earlier uncertain post.
            masked = re.sub(r"[A-Za-z0-9_-]{28,}|[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}",
                            "[masked]", diagnostic[:4096])
            masked = masked.encode("utf-8")[:512].decode("utf-8", errors="ignore")
            result = {**claim, "status": status, "epoch": self.clock(),
                      "diagnostic": masked if status == "rejected" else ""}
            files.create("result", intent_id, result)
            return {"recorded": True}
        return self._daemon(presented_token, apply)

    def settle(self, intent_id, *, presented_token):
        def apply(_):
            value = files.read("intent", intent_id)
            if not value:
                raise wire.Refused("intent_mismatch")
            return self._settle(value)
        return self._daemon(presented_token, apply)

    def reconcile(self, seat, *, presented_token):
        def apply(_):
            snapshot = _Snapshot()
            binding = ((store._read_participants_unlocked().get(seat) or {}).get("wake_route") or {}).get("binding")
            for pre in snapshot.by_seat.get(seat, ()):
                if (snapshot.needs_settlement(pre) and
                        (pre["intent"]["binding"] == binding or snapshot.fetched(pre["intent"]))):
                    self._settle(pre["intent"], snapshot=snapshot)
        return self._daemon(presented_token, apply)

    def _settle(self, value, *, snapshot=None):
        snapshot = snapshot or _Snapshot()
        state = proof(value["seat"], value, now=self.clock(), snapshot=snapshot)
        if state["delivery_state"] == "pending":
            try:
                self._current(value["seat"], value["binding"], value["route_generation"])
            except wire.Refused as exc:
                reason = exc.code if exc.code in {"no_process", "owner_mismatch"} else "owner_unresolved"
                state.update(delivery_state="refused", reason=reason)
        if state["delivery_state"] == "pending":
            return state
        prior = snapshot.posts.get(value["pre_receipt_ref"])
        if prior is None or (prior["result"] != state["delivery_state"] and state["delivery_state"] == "accepted"):
            snapshot.append({"kind": "wake-reconciled" if prior else "nudge",
                **({} if prior else {"phase": "post"}), "route_kind": "launched",
                "event-id": value["pre_receipt_ref"], "target seat": value["seat"],
                "generation": value["route_generation"], "result": state["delivery_state"],
                "reason": state["reason"], "fetch-txn-id": state["fetch_ref"],
                "epoch": (value["reconcile_at"] if state["delivery_state"] == "uncertain" and
                          _result_observation(value["intent_id"]) else value["not_after"])
                          if state["delivery_state"] in {"uncertain", "held"} else self.clock(),
                "ts": store.now_iso()})
        if state["delivery_state"] == "accepted" and value["pre_receipt_ref"] not in snapshot.poked:
            snapshot.append({"kind": "delivery", "event": "POKED", "adapter": "launched",
                "seat": value["seat"], "msg-id": value["message_id"],
                "nudge-event-id": value["pre_receipt_ref"], "ts": store.now_iso()})
        return state
