from __future__ import annotations

import os
import pwd
import subprocess
import time
import uuid
from dataclasses import dataclass
from pathlib import Path

from seat_socket import registered_session, registered_socket


@dataclass
class TmuxResult:
    ok: bool
    stdout: str = ""
    stderr: str = ""
    timed_out: bool = False


TMUX_BIN = os.environ.get("PUSH_ORCHESTRATOR_TMUX_BIN", "tmux")
TMUX_COMMAND_TIMEOUT_SEC = 10

# Reviewer identity checks run after Codex has granted one command an
# out-of-sandbox execution.  That boundary must not resolve ``tmux`` or ``ps``
# through caller-controlled PATH/environment values.  Keep the candidate list
# explicit and resolve symlinks before execution; absence is a fail-closed
# identity result, not a fallback to PATH.
_TRUSTED_TMUX_CANDIDATES = (
    "/opt/homebrew/bin/tmux",
    "/usr/local/bin/tmux",
    "/usr/bin/tmux",
)
_TRUSTED_PS_CANDIDATES = ("/bin/ps", "/usr/bin/ps")


def _run_tmux(*args: str, environment=None) -> TmuxResult:
    from launch_environment import sanitized_env
    try:
        proc = subprocess.run(
            [TMUX_BIN, *args],
            capture_output=True,
            text=True,
            check=False,
            timeout=TMUX_COMMAND_TIMEOUT_SEC,
            env=sanitized_env(environment),
        )
    except FileNotFoundError:
        return TmuxResult(ok=False, stderr=f"tmux binary not found: {TMUX_BIN}")
    except subprocess.TimeoutExpired:
        return TmuxResult(ok=False,
                          stderr=f"tmux command timed out after {TMUX_COMMAND_TIMEOUT_SEC}s",
                          timed_out=True)
    return TmuxResult(
        ok=proc.returncode == 0,
        stdout=proc.stdout.strip(),
        stderr=proc.stderr.strip(),
    )


def _trusted_executable(candidates: tuple[str, ...], label: str) -> tuple[str | None, str]:
    for candidate in candidates:
        try:
            resolved = Path(candidate).resolve(strict=True)
        except OSError:
            continue
        if resolved.is_file() and os.access(resolved, os.X_OK):
            return str(resolved), ""
    return None, f"trusted {label} executable not found in {candidates!r}"


def _trusted_process_env() -> dict[str, str]:
    """Minimal environment for identity probes.

    In particular, do not inherit TMUX/TMUX_PANE/TMUX_TMPDIR or PATH from the
    reviewer command. A private socket is accepted only when it is obtained
    from the participant registry and passed explicitly with ``-S``; arbitrary
    caller-supplied ``-S``/``-L`` values are never identity evidence.
    """
    account = pwd.getpwuid(os.getuid())
    return {
        "HOME": account.pw_dir,
        "USER": account.pw_name,
        "LOGNAME": account.pw_name,
        "PATH": "/usr/bin:/bin:/usr/sbin:/sbin",
        "LANG": "C",
    }


def _run_trusted_tmux(*args: str) -> TmuxResult:
    executable, error = _trusted_executable(_TRUSTED_TMUX_CANDIDATES, "tmux")
    if not executable:
        return TmuxResult(ok=False, stderr=error)
    try:
        proc = subprocess.run(
            [executable, *args],
            capture_output=True,
            text=True,
            check=False,
            env=_trusted_process_env(),
            timeout=TMUX_COMMAND_TIMEOUT_SEC,
        )
    except subprocess.TimeoutExpired:
        return TmuxResult(ok=False,
                          stderr=f"trusted tmux timed out after {TMUX_COMMAND_TIMEOUT_SEC}s",
                          timed_out=True)
    except OSError as exc:
        return TmuxResult(ok=False, stderr=f"trusted tmux failed: {exc}")
    return TmuxResult(
        ok=proc.returncode == 0,
        stdout=proc.stdout.strip(),
        stderr=proc.stderr.strip(),
    )


def _registered_socket(seat: str, participants) -> TmuxResult:
    """Resolve exactly one normalized, registry-declared private seat socket."""
    try:
        socket_path = registered_socket(seat, participants)
    except (AttributeError, TypeError, ValueError) as exc:
        return TmuxResult(ok=False, stderr=str(exc))
    return TmuxResult(ok=True, stdout=socket_path)


def _run_registered_tmux(seat: str, participants, *args: str) -> TmuxResult:
    registered = _registered_socket(seat, participants)
    if not registered.ok:
        return registered
    return _run_trusted_tmux("-S", registered.stdout, *args)


def _parent_process_id(process_id: int) -> TmuxResult:
    executable, error = _trusted_executable(_TRUSTED_PS_CANDIDATES, "ps")
    if not executable:
        return TmuxResult(ok=False, stderr=error)
    try:
        proc = subprocess.run(
            [executable, "-o", "ppid=", "-p", str(process_id)],
            capture_output=True,
            text=True,
            check=False,
            env=_trusted_process_env(),
            timeout=TMUX_COMMAND_TIMEOUT_SEC,
        )
    except subprocess.TimeoutExpired:
        return TmuxResult(ok=False,
                          stderr=f"trusted ps timed out after {TMUX_COMMAND_TIMEOUT_SEC}s",
                          timed_out=True)
    except OSError as exc:
        return TmuxResult(ok=False, stderr=f"trusted ps failed: {exc}")
    raw = proc.stdout.strip()
    if proc.returncode != 0 or not raw:
        return TmuxResult(ok=False, stderr=proc.stderr.strip() or
                          f"ps returned no parent for pid {process_id}")
    try:
        parent = int(raw)
    except ValueError:
        return TmuxResult(ok=False, stderr=f"invalid parent pid for {process_id}: {raw!r}")
    return TmuxResult(ok=True, stdout=str(parent))


def session_exists(name: str) -> bool:
    return _run_tmux("has-session", "-t", name).ok


def registered_session_exists(seat: str, participants) -> bool:
    try:
        socket_path = registered_socket(seat, participants)
        session = registered_session(participants[seat])
    except (KeyError, TypeError, ValueError):
        return False
    return _run_tmux("-S", socket_path, "has-session", "-t", session).ok


def capture_registered_pane(seat: str, participants, *, lines: int = 400) -> TmuxResult:
    """Read only the declared socket; never fall back to a default server."""
    try:
        socket_path = registered_socket(seat, participants)
        session = registered_session(participants[seat])
    except (KeyError, TypeError, ValueError) as exc:
        return TmuxResult(ok=False, stderr=str(exc))
    return _run_tmux("-S", socket_path, "capture-pane", "-p", "-t", session,
                     "-S", str(-lines))


def kill_registered_server(seat: str, participants) -> TmuxResult:
    try:
        socket_path = registered_socket(seat, participants)
    except (TypeError, ValueError) as exc:
        return TmuxResult(ok=False, stderr=str(exc))
    return _run_tmux("-S", socket_path, "kill-server")


def list_sessions() -> list[str]:
    result = _run_tmux("list-sessions", "-F", "#{session_name}")
    if not result.ok:
        return []
    return [line for line in result.stdout.splitlines() if line]


def _run_tmux_reconciled(*args: str) -> TmuxResult:
    """Run a state-changing command and confirm a timeout via the tmux server."""
    return _run_tmux_reconciled_at((), *args)


def _run_tmux_reconciled_at(prefix: tuple[str, ...], *args: str) -> TmuxResult:
    """Reconcile a state change on the exact tmux server selected by ``prefix``."""
    marker = f"@psqr-confirm-{uuid.uuid4().hex}"
    token = uuid.uuid4().hex
    result = _run_tmux(*prefix, *args, ";", "set-option", "-g", marker, token)
    if result.timed_out:
        observed = _run_tmux(*prefix, "show-options", "-gv", marker)
        if observed.ok and observed.stdout == token:
            result = TmuxResult(ok=True, stdout="reconciled_after_timeout")
    # The confirmation option is unique and no longer useful after this call.
    _run_tmux(*prefix, "set-option", "-gu", marker)
    return result


def send_prompt(name: str, text: str) -> TmuxResult:
    """Type `text` into a session and submit it.

    `-l --` sends the text literally: without it tmux interprets key names
    (a word like "Escape" in the message becomes the key), and any embedded
    newline submits the prompt early. Multi-line text goes through a paste
    buffer with bracketed paste so the target CLI receives it as one block.
    """
    if not session_exists(name):
        return TmuxResult(ok=False, stderr=f"tmux session '{name}' not found")
    if "\n" in text:
        # Unique buffer per call: concurrent multiline sends must not swap
        # payloads between panes (-d deletes the buffer after pasting).
        buf = f"psqr-send-{uuid.uuid4().hex[:8]}"
        try:
            proc = subprocess.run(
                [TMUX_BIN, "load-buffer", "-b", buf, "-"],
                input=text, capture_output=True, text=True, check=False,
                timeout=TMUX_COMMAND_TIMEOUT_SEC,
            )
        except subprocess.TimeoutExpired:
            # The server may have created the named buffer before the client
            # timed out.  Never let repeated timeouts accumulate buffers.
            _run_tmux("delete-buffer", "-b", buf)
            return TmuxResult(
                ok=False, stderr=f"tmux command timed out after {TMUX_COMMAND_TIMEOUT_SEC}s")
        if proc.returncode != 0:
            return TmuxResult(ok=False, stderr=proc.stderr.strip())
        pasted = _run_tmux_reconciled(
            "paste-buffer", "-p", "-d", "-b", buf, "-t", name)
        if not pasted.ok:
            _run_tmux("delete-buffer", "-b", buf)
            return pasted
    else:
        typed = _run_tmux_reconciled("send-keys", "-t", name, "-l", "--", text)
        if not typed.ok:
            return typed
    time.sleep(0.3)
    return _run_tmux_reconciled("send-keys", "-t", name, "Enter")


def send_registered_prompt(seat: str, participants, text: str, *, before_write=None) -> TmuxResult:
    """Send a rebirth prompt only through the seat's validated private server."""
    try:
        socket_path = registered_socket(seat, participants)
        session = registered_session(participants[seat])
    except (KeyError, TypeError, ValueError) as exc:
        return TmuxResult(ok=False, stderr=str(exc))
    prefix = ("-S", socket_path)
    if not _run_tmux(*prefix, "has-session", "-t", session).ok:
        return TmuxResult(ok=False, stderr=f"private tmux session {session!r} not found")
    if before_write is not None and not before_write():
        return TmuxResult(ok=False, stderr="pane_input_withheld")
    if "\n" in text:
        buf = f"psqr-send-{uuid.uuid4().hex[:8]}"
        try:
            proc = subprocess.run(
                [TMUX_BIN, *prefix, "load-buffer", "-b", buf, "-"], input=text,
                capture_output=True, text=True, check=False,
                timeout=TMUX_COMMAND_TIMEOUT_SEC)
        except subprocess.TimeoutExpired:
            _run_tmux(*prefix, "delete-buffer", "-b", buf)
            return TmuxResult(ok=False, stderr="private tmux load-buffer timed out",
                              timed_out=True)
        if proc.returncode != 0:
            return TmuxResult(ok=False, stderr=proc.stderr.strip())
        sent = _run_tmux_reconciled_at(
            prefix, "paste-buffer", "-p", "-d", "-b", buf, "-t", session)
    else:
        sent = _run_tmux_reconciled_at(
            prefix, "send-keys", "-t", session, "-l", "--", text)
    if not sent.ok:
        if "\n" in text:
            # paste-buffer -d removes the buffer only when the server applies
            # the paste. Preserve the original delivery result even if this
            # best-effort compensation also fails.
            _run_tmux(*prefix, "delete-buffer", "-b", buf)
        return sent
    time.sleep(0.3)
    if before_write is not None and not before_write():
        return TmuxResult(ok=False, stderr="pane_input_withheld")
    return _run_tmux_reconciled_at(
        prefix, "send-keys", "-t", session, "Enter")


def registered_pane_ready(seat: str, participants) -> bool:
    try:
        socket_path = registered_socket(seat, participants)
        session = registered_session(participants[seat])
    except (KeyError, TypeError, ValueError):
        return False
    result = _run_tmux("-S", socket_path, "display-message", "-p", "-t", session,
                       "#{pane_current_command}")
    return result.ok and bool(result.stdout) and result.stdout not in SHELL_COMMANDS


def wait_for_registered_pane_ready(seat: str, participants, *, timeout: float,
                                   poll_interval: float = 0.5) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if registered_pane_ready(seat, participants):
            return True
        time.sleep(poll_interval)
    return registered_pane_ready(seat, participants)


def pane_current_command(name: str) -> str:
    """The foreground command of the session's active pane ('' if unknown)."""
    result = _run_tmux("display-message", "-p", "-t", name, "#{pane_current_command}")
    return result.stdout if result.ok else ""


def session_name_for_pane(pane_id: str) -> TmuxResult:
    """Resolve an inherited tmux pane id (for example ``%6``) to its session."""
    return _run_tmux("display-message", "-p", "-t", pane_id, "#{session_name}")


def pane_identity_for_process(process_id: int, *, seat: str,
                              participants, max_depth: int = 64) -> TmuxResult:
    """Resolve a live process to its unique ``pane-id:session`` ancestry.

    Unlike ``TMUX_PANE``, a caller cannot select another pane by changing an
    environment variable.  We enumerate tmux's actual pane-root PIDs and walk
    the OS parent chain.  Missing, malformed, too-deep, or multi-session
    ancestry all refuse rather than guessing.
    """
    if not isinstance(process_id, int) or process_id <= 1:
        return TmuxResult(ok=False, stderr=f"invalid reviewer process id: {process_id!r}")
    panes = _run_registered_tmux(
        seat, participants,
        # tmux 3.7 normalizes literal tabs in format output. A colon remains
        # stable here and cannot occur in a tmux session name.
        "list-panes", "-a", "-F", "#{pane_pid}:#{pane_id}:#{session_name}"
    )
    if not panes.ok:
        return panes
    pane_identities: dict[int, set[tuple[str, str]]] = {}
    for line in panes.stdout.splitlines():
        try:
            raw_pid, pane_id, session = line.split(":", 2)
            pane_pid = int(raw_pid)
        except (ValueError, TypeError):
            return TmuxResult(ok=False, stderr=f"invalid tmux pane record: {line!r}")
        if pane_pid <= 1 or not pane_id.startswith("%") or not session:
            return TmuxResult(ok=False, stderr=f"invalid tmux pane record: {line!r}")
        pane_identities.setdefault(pane_pid, set()).add((pane_id, session))

    current = process_id
    seen: set[int] = set()
    matched_identities: set[tuple[str, str]] = set()
    for _ in range(max_depth):
        if current in seen:
            return TmuxResult(ok=False, stderr=f"process ancestry cycle at pid {current}")
        seen.add(current)
        matched_identities.update(pane_identities.get(current, set()))
        if current == 1:
            break
        parent = _parent_process_id(current)
        if not parent.ok:
            return parent
        next_pid = int(parent.stdout)
        if next_pid <= 0:
            break
        current = next_pid
    else:
        return TmuxResult(ok=False, stderr=f"process ancestry exceeds {max_depth} levels")

    if not matched_identities:
        return TmuxResult(ok=False, stderr=f"pid {process_id} is not descended from a tmux pane")
    if len(matched_identities) != 1:
        return TmuxResult(
            ok=False,
            stderr=f"pid {process_id} has ambiguous tmux ancestry: {sorted(matched_identities)!r}",
        )
    pane_id, session = next(iter(matched_identities))
    return TmuxResult(ok=True, stdout=f"{pane_id}:{session}")


def session_name_for_process(process_id: int, *, seat: str,
                             participants, max_depth: int = 64) -> TmuxResult:
    """Compatibility wrapper returning only the proven ancestry session."""
    identity = pane_identity_for_process(
        process_id, seat=seat, participants=participants, max_depth=max_depth)
    if not identity.ok:
        return identity
    _pane_id, session = identity.stdout.split(":", 1)
    return TmuxResult(ok=True, stdout=session)


SHELL_COMMANDS = {"zsh", "bash", "sh", "fish", "-zsh", "-bash"}


def pane_ready(name: str) -> bool:
    """True when something beyond a bare shell is running in the pane.

    Used before nudging an agent: if the pane is still a shell, the agent CLI
    hasn't started (or crashed) and typed text would land in the shell.
    """
    cmd = pane_current_command(name)
    return bool(cmd) and cmd not in SHELL_COMMANDS


def wait_for_pane_ready(name: str, *, timeout: float,
                        poll_interval: float = 0.5) -> bool:
    """Wait until a fresh pane leaves its shell, bounded by ``timeout``."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if pane_ready(name):
            return True
        time.sleep(poll_interval)
    return pane_ready(name)


def send_key(name: str, key: str) -> TmuxResult:
    """Send a raw tmux key (e.g. 'Escape', 'C-c', 'Tab', 'Enter')."""
    if not session_exists(name):
        return TmuxResult(ok=False, stderr=f"tmux session '{name}' not found")
    return _run_tmux("send-keys", "-t", name, key)


def capture_pane(name: str, lines: int = 80) -> TmuxResult:
    if not session_exists(name):
        return TmuxResult(ok=False, stderr=f"tmux session '{name}' not found")
    return _run_tmux("capture-pane", "-p", "-S", f"-{lines}", "-t", name)


def new_session(name: str, working_dir: str | None = None) -> TmuxResult:
    args = ["new-session", "-d", "-s", name]
    if working_dir:
        args.extend(["-c", working_dir])
    return _run_tmux(*args)


def kill_session(name: str) -> TmuxResult:
    return _run_tmux("kill-session", "-t", name)


def open_in_terminal(name: str) -> TmuxResult:
    """Open a tmux session in a native macOS Terminal.app window."""
    if not session_exists(name):
        return TmuxResult(ok=False, stderr=f"tmux session '{name}' not found")
    # Sanitize for both AppleScript string context and shell interpretation
    import re
    if not re.match(r'^[a-zA-Z0-9_.-]+$', name):
        return TmuxResult(ok=False, stderr=f"Unsafe session name: '{name}'")
    script = f'tell application "Terminal" to do script "tmux attach -t {name}"'
    try:
        proc = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True, text=True, check=False,
        )
    except FileNotFoundError:
        return TmuxResult(ok=False, stderr="osascript not found (not macOS?)")
    return TmuxResult(ok=proc.returncode == 0, stdout=proc.stdout.strip(), stderr=proc.stderr.strip())


def list_untracked_sessions(tracked: list[str]) -> list[str]:
    """Return tmux sessions not in the tracked set."""
    all_sessions = list_sessions()
    return [s for s in all_sessions if s not in tracked]
