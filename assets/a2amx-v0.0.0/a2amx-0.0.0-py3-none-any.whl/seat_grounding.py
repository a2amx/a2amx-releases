"""Store-owned, already-adopted grounding expectations.

The receipt is the record: there is no second file whose publication could
diverge from its receipt. This records values, never adopts norms or grants a
role. Current provisioner authorization and CAS serialize with revocation.
"""
from __future__ import annotations

import claude_hook_interface as interface
from desktop_support import optional as optional_desktop
hookset = optional_desktop('inapp_hookset')
import receipts
import store

KIND = 'seat-grounding'
FIELDS = {'norms_sha256', 'standard_revision', 'addenda', 'basis'}
RECORD_FIELDS = FIELDS | {'kind', 'seat', 'actor', 'ts', 'previous_generation', 'generation'}
NEUTRAL_BASIS = 'no-expectations-adopted'


def neutral_fields():
    """One explicit absence of adopted expectations; never measured defaults."""
    return dict(norms_sha256=None, standard_revision=None, addenda=None, basis=NEUTRAL_BASIS)


def is_neutral(row):
    return (isinstance(row, dict) and FIELDS <= row.keys()
            and {k: row[k] for k in FIELDS} == neutral_fields())


class Refused(ValueError):
    pass


def validate_fields(fields):
    if isinstance(fields, dict) and set(fields) == FIELDS and is_neutral(fields):
        return
    if (not isinstance(fields, dict) or set(fields) != FIELDS
            or fields.get('basis') == NEUTRAL_BASIS
            or not interface.is_digest(fields['norms_sha256'])
            or type(fields['standard_revision']) is not int or fields['standard_revision'] < 1
            or type(fields['addenda']) is not int or fields['addenda'] < 0
            or not isinstance(fields['basis'], str) or not fields['basis'].strip()
            or len(fields['basis'].encode()) > 2048
            or any(ord(c) < 32 for c in fields['basis'])):
        raise Refused('grounding_fields_invalid')


def current(seat, *, rows=None, required=True):
    """Non-writing view for previews; mutation callers hold registry/nudge locks."""
    result = None
    for row in receipts.rows() if rows is None else rows:
        if row.get('kind') != KIND or row.get('seat') != seat:
            continue
        if (set(row) != RECORD_FIELDS or row['previous_generation'] !=
                (result['generation'] if result else 'none')
                or row['generation'] != interface.digest({k: v for k, v in row.items() if k != 'generation'})
                or not isinstance(row['actor'], str) or not store.PARTICIPANT_ID_RE.fullmatch(row['actor'])
                or not isinstance(row['ts'], str) or not row['ts']):
            raise Refused('grounding_record_invalid')
        validate_fields({k: row[k] for k in FIELDS})
        result = row
    if result is None and required:
        raise Refused('grounding_record_missing')
    return result


def install_default(seat, actor):
    """Caller holds the authenticated provisioner act; append only if absent.

    Installers call this after their read-only preflight, never for a preview.
    A failed later installation may leave this explicit neutral record, but no
    successful kit installation is implied and existing expectations never change.
    """
    active_seat(seat, store._read_participants_unlocked())
    with receipts._nudge_lock():
        existing = current(seat, required=False)
        if existing is not None:
            return existing
        row = dict(kind=KIND, seat=seat, actor=actor, ts=store.now_iso(),
                   previous_generation='none', **neutral_fields())
        row['generation'] = interface.digest(row)
        receipts._append(row)
        return row


def active_seat(seat, parts):
    row = parts.get(seat) or {}
    if row.get('kind') != 'agent' or store.inactive_participant(row):
        raise Refused('grounding_active_seat_required')
    return row


def record(seat, *, presented_token, expected_generation, norms_sha256,
           standard_revision, addenda, basis):
    fields = dict(norms_sha256=norms_sha256, standard_revision=standard_revision,
                  addenda=addenda, basis=basis)
    validate_fields(fields)
    if expected_generation != 'none' and not interface.is_digest(expected_generation):
        raise Refused('grounding_expected_generation_required')

    def apply(actor):
        active_seat(seat, store._read_participants_unlocked())
        with receipts._nudge_lock():
            old = current(seat, required=False)
            previous = old['generation'] if old else 'none'
            if expected_generation != previous:
                raise Refused('grounding_stale_generation')
            row = dict(kind=KIND, seat=seat, actor=actor, ts=store.now_iso(),
                       previous_generation=previous, **fields)
            row['generation'] = interface.digest(row)
            receipts._append(row)
        return row
    return store.authenticated_registry_act(presented_token, apply, provisioning=True)


def inspect_own(seat, *, presented_token):
    """Own-seat snapshot; model is declared, installed pin is record-derived.

Do not nest nudge locks: the existing hookset snapshot owns that lock. The
outer registry/token locks keep grounding writes and hookset replacement from
interleaving with this snapshot.
"""
    def apply(actor):
        row = active_seat(seat, store._read_participants_unlocked())
        grounding = current(seat)
        catalog = interface.deployed()
        result = {'grounding': grounding, 'catalog_digest': interface.digest(catalog),
                  'model': {'value': row.get('recorded_model'), 'source': 'DECLARED'},
                  'installed_kit_pin': None, 'hookset': None}
        if hookset is not None and store.normalize_family(row.get('family')) == 'claude':
            snapshot = hookset.inspect_own(seat, presented_token=presented_token)
            result['hookset'] = snapshot
            if snapshot['record'] is not None:
                result['installed_kit_pin'] = snapshot['record']['digest']
        return result
    return store.authenticated_registry_act(presented_token, apply, expected_actor=seat)
