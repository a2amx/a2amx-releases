"""Store-bound web-process ownership for an infrastructure-only orch down.

No process-name enumeration: a stop requires a live held lease, this store,
and the same process incarnation the server recorded when it took the lease.
"""
from contextlib import contextmanager
import fcntl
import json
import os
import signal
import stat

import store
from runtime_registry import os_proc_birth, proc_identity_ok


def _path():
    return store.STORE_DIR / 'web-server.lock'


@contextmanager
def owned_server():
    pid = os.getpid()
    birth = os_proc_birth(pid)
    if birth is None:
        raise ValueError('web server process birth unavailable; refusing startup')
    fd = os.open(_path(), os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'r+') as lock:
        info = os.fstat(lock.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid():
            raise ValueError('web server lease is not an owned regular file')
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        named = _path().lstat()
        if ((named.st_dev, named.st_ino) != (info.st_dev, info.st_ino)
                or not stat.S_ISREG(named.st_mode) or named.st_nlink != 1):
            raise ValueError('web server lease changed before claim; refusing startup')
        os.fchmod(lock.fileno(), 0o600)
        record = {'kind': 'orch-web', 'pid': pid,
                  'proc_birth': birth, 'store_dir': str(store.STORE_DIR),
                  'operator': os.environ.get('PSQR_OWNER')}
        lock.seek(0)
        json.dump(record, lock)
        lock.truncate()
        lock.flush()
        os.fsync(lock.fileno())
        yield record


def stop_owned_server():
    try:
        fd = os.open(_path(), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except FileNotFoundError:
        return True, 'no recorded web server'
    except OSError:
        return False, 'web server ownership unavailable; no signal sent'
    with os.fdopen(fd) as lock:
        info = os.fstat(lock.fileno())
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                or stat.S_IMODE(info.st_mode) != 0o600):
            return False, 'web server lease permissions invalid; no signal sent'
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            pass
        else:
            return True, 'web server lease is no longer held'
        try:
            record = json.load(lock)
        except (ValueError, OSError):
            return False, 'web server lease unreadable; no signal sent'
        pid = record.get('pid') if isinstance(record, dict) else None
        if (type(pid) is not int or pid <= 1 or record.get('kind') != 'orch-web'
                or record.get('store_dir') != str(store.STORE_DIR)
                or not proc_identity_ok(pid, record.get('proc_birth'))):
            return False, 'web server identity unproven; no signal sent'
        try:
            os.kill(pid, signal.SIGTERM)
        except ProcessLookupError:
            return True, 'recorded web server already exited'
        return True, 'sent SIGTERM to the verified store-owned web server'
