"""Notification daemon.

Tails the global message log and alerts each recipient through its channel:
tmux one-line nudge (Gemini/Codex CLI panes), macOS notification (humans on
this Mac), nothing for watch/pull subscribers — their inbox append already
woke or will be drained by them. Also ingests drop-file replies and refreshes
a cached pane-attention snapshot and a separate memory-only terminal-state
observation exposed through a read-only local socket.

Messages are durable in the store before this process ever sees them; the
daemon can die and restart without losing anything (cursor replay).

Run: python delivery.py [--once]      (normally launched by `orch up`)
"""

from __future__ import annotations

import argparse
import fcntl
import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict

import store
import receipts
import launched_outbox
from desktop_support import optional as optional_desktop
codex_dispatch = optional_desktop('codex_dispatch')
inapp_dispatch = optional_desktop('inapp_dispatch')
agy_dispatch = optional_desktop('agy_dispatch')
from attention import scan_pane
from tmux_bridge import capture_pane, list_sessions
from notify import compose_nudge, macos_notify, one_line, registered_tmux_nudge
import pane_state_adapter
from pane_state import input_allowed

DAEMON_LOCK = store.STORE_DIR / "daemon.lock"
DELIVERY_CURSOR = store.STORE_DIR / "delivery.cursor"
PENDING_NUDGES = store.STORE_DIR / "pending_nudges.json"
RUNTIME_SNAPSHOT = store.STORE_DIR / "runtime.json"

POLL_INTERVAL = 0.5
ATTENTION_INTERVAL = 2.0
APPROVAL_SWEEP_INTERVAL = 10.0   # G0.3 timeout auto-deny cadence (item TTLs are minutes)
PROVISION_OBSERVATION_INTERVAL = 5.0
_last_provision_observation = None
_provision_observation_error = None
_quarantine_incomplete = {}


def sweep_approvals() -> None:
    """G0.3 fail-closed timeout, daemon half: settle expired approval items and
    DURABLY notify the waiting seat so its loop continues with a refusal, never
    hangs (the operator's non-negotiable). Settlement and notification are separate
    durable steps (reviewer #55 HIGH): a settled item keeps notify_pending until
    store.send succeeds, so a failed send is retried on every sweep instead of
    being lost to a log line. Duplicate delivery after a crash between send and
    mark_notified is acceptable — a stranded agent is not."""
    import approvals
    approvals.sweep_expired()
    for item in approvals.unnotified_settlements():
        seat = item.get("seat")
        if not seat:
            approvals.mark_notified(item["item_id"])   # nothing to notify
            continue
        ident = (f"approval item {item['item_id']} ({item.get('effect_kind')}, "
                 f"payload sha256 {item.get('raw_payload_sha256', '')[:12]}…)")
        if item.get("status") == "authorization_expired":
            # the operator DID approve — the agent just never redeemed it in time
            # (Bugbot #55 MED: don't misstate an approval as an unanswered window)
            text = (f"{ident}: the operator APPROVED it, but the authorization "
                    "expired unconsumed. Re-escalate the action if still needed — "
                    "a fresh item will reach the operator.")
        else:
            text = (f"{ident} was DENIED on timeout — no operator decision inside "
                    "the window. Do not retry the same action unprompted; a re-ask "
                    "after timeout-denials trips the circuit breaker.")
        try:
            credential, why = daemon_identity()
            if credential is None:
                raise RuntimeError(f"daemon credential unavailable: {why}")
            sent = store.send(store.DAEMON_SEAT, [seat], text, kind="system",
                              presented_token=credential)
            verdict = (sent.get("vet") or {}).get("verdict")
            if verdict not in (None, "PASS"):
                raise RuntimeError(f"approval notice vetted {verdict}")
        except KeyError as exc:
            # the seat no longer exists in the registry — no future retry can
            # succeed; mark it so a deleted seat can't spam the log forever
            _log(f"approval notify: seat {seat} unknown, marking notified: {exc!r}")
            approvals.mark_notified(item["item_id"])
            continue
        except Exception as exc:
            _log(f"approval notify failed for {seat} (will retry): {exc!r}")
            continue
        approvals.mark_notified(item["item_id"])

# The pattern list and the scan live in `attention` — ONE definition, shared with
# psqr_orchestrator. This module used to carry a private copy under a "keep in sync
# by hand" comment; it drifted, and the test carried a third copy that could not
# detect the drift. Do not reintroduce a local list here.



def _log(msg: str) -> None:
    print(f"[{store.now_iso()}] {msg}", flush=True)


def _read_cursor() -> int:
    try:
        return int(json.loads(DELIVERY_CURSOR.read_text()).get("offset", 0))
    except (FileNotFoundError, json.JSONDecodeError, ValueError):
        return 0


def _atomic_write(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w") as f:
        f.write(text)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def _write_cursor(offset: int) -> None:
    _atomic_write(DELIVERY_CURSOR, json.dumps({"offset": offset, "updated_at": store.now_iso()}))


def _read_pending() -> Dict[str, Dict[str, Any]]:
    try:
        return json.loads(PENDING_NUDGES.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def _write_pending(pending: Dict[str, Dict[str, Any]]) -> None:
    _atomic_write(PENDING_NUDGES, json.dumps(pending, indent=2))


def collect_alerts(messages: list, *, pointer_only_seats=frozenset(), participants=None) -> Dict[str, Dict[str, Any]]:
    """Group new messages into one alert per recipient."""
    if participants is None:
        participants = store.load_participants()
    import recall
    recall_edges = recall.graph()
    alerts: Dict[str, Dict[str, Any]] = {}
    for msg in messages:
        if msg.get("kind") == "legacy":
            continue
        if store.delivery_blocked(msg, recall_edges=recall_edges):
            continue
        notify = (msg.get("human_notify_recipients", [])
                  if msg.get("kind") == "system" and msg.get("from") in {"System", store.DAEMON_SEAT}
                  else [])
        recipients = store.mailbox_targets(msg)
        if (msg.get("vet") or {}).get("verdict") == "QUARANTINED":
            import quarantine
            recipients = quarantine.status(msg).get("recipients", [])
        for pid in dict.fromkeys([*recipients, *notify]):
            participant = participants.get(pid, {})
            human_notify = pid in notify and store.human_notification_channel(participant)
            if not store.has_mailbox(participant):
                if not human_notify:
                    continue  # Historical/ordinary human mail cannot join this batch.
            elif pid not in recipients:
                continue  # A former human notification target is not an agent route.
            a = alerts.setdefault(pid, {"count": 0, "last_from": "", "preview": "", "since": msg.get("ts", ""), "msg_ids": []})
            if human_notify:
                a["human_notify"] = True
            a["count"] += 1
            a["last_from"] = msg.get("from", "")
            if pid not in pointer_only_seats:
                a["preview"] = msg.get("text", "")
            if msg.get("id"):
                a["msg_ids"].append(msg["id"])
    return alerts


# Phase A A.4 (ORCH_SPEC_01 D-IDT-1 "the daemon holds a system token"): the daemon presents
# ITS OWN seat token before it may inject a nudge into any pane. The token file is
# $PSQR_DAEMON_TOKEN_FILE, else ~/agents/<store.DAEMON_SEAT>/.orch/token — deliberately NOT
# $ORCH_TOKEN / $ORCH_TOKEN_FILE, which `orch up` would inherit from the OPERATOR's shell and
# turn into the daemon acting as the operator. The record must carry the daemon token role; any
# other seat's token is not the daemon's identity. A.3 builds the requester-role check and
# the pre/post-write receipts on top of this identity.
DAEMON_TOKEN_FILE_ENV = "PSQR_DAEMON_TOKEN_FILE"
_identity_note: str | None = None


def daemon_identity() -> tuple[str | None, str]:
    """(sanitized token record, "ok") or (None, reason) — same store.token_verdict as the CLI."""
    found = store.find_presented_token(os.environ.get(DAEMON_TOKEN_FILE_ENV),
                                       default_seat=store.DAEMON_SEAT, env={})
    if found["error"]:
        return None, f"unusable: {found['error']}"
    if not found["token"]:
        return None, "no_token"
    rec, why = store.token_verdict(found["token"])
    if rec is None:
        return None, why
    # The daemon's credential is THE daemon's: role `daemon` AND participant_id == the
    # designated daemon seat AND that registry row is kind `system` — the same three facts
    # provisioning checks (reviewer DJK-A4-4: role alone accepted any system seat's token).
    if rec.get("role") != store.DAEMON_TOKEN_ROLE:
        return None, "wrong_role"
    if rec.get("participant_id") != store.DAEMON_SEAT:
        return None, "wrong_seat"
    row = store.load_participants().get(store.DAEMON_SEAT)
    if not row or row.get("kind") != "system":
        return None, "daemon_row_not_system"
    return found["token"], "ok"


def _note_identity(note: str | None) -> None:
    """Log a change of the daemon's identity state once, not once per pass."""
    global _identity_note
    if note != _identity_note:
        _identity_note = note
        _log(note or "system token valid — nudges enabled")


def _notify_alert(alert):
    """Use the existing native notification formatter and delivery branch."""
    title = f"PSQR · {alert['last_from']}"
    body = one_line(alert["preview"], 180)
    if alert["count"] > 1:
        body = f"({alert['count']} new) {body}"
    ok = macos_notify(title, body)
    return ok, "macos_notification" if ok else "osascript_failed"


def _alert_eligible(participant, alert):
    """Keep accepted human notification intent separate from agent delivery."""
    if alert.get("human_notify"):
        return store.human_notification_channel(participant)
    return store.has_mailbox(participant)


def dispatch_alert(pid: str, participant: Dict[str, Any], alert: Dict[str, Any],
                   *, participants: Dict[str, Dict[str, Any]] | None = None) -> tuple[bool, str]:
    """Route one batched alert through the participant's channel.

    Returns (delivered, detail). watch/pull channels are always 'delivered' —
    the inbox append already did the work.
    """
    if alert.get("human_notify"):
        if store.human_notification_channel(participant):
            return _notify_alert(alert)
        return True, "human_notification_ineligible"
    if not store.has_mailbox(participant):
        return True, "no_human_mailbox"
    # Phase A A.9: an in-app seat discovers canonical mail through its own
    # re-armed filtered watcher.  There is no pane and therefore no injection,
    # nudge receipt, or POKED journal row.  QUEUED was already recorded by the
    # send path; the watcher's later ``orch mail``/inbox fetch records FETCHED.
    # Dispatch by the governance-owned hosting declaration before consulting
    # the legacy channel field so a stale ``channel: tmux`` cannot inject into
    # an in-app seat.
    if (isinstance(participant.get("wake_route"), dict)
            and participant["wake_route"].get("kind") == "launched"):
        return True, "launched_receipt_queue"
    if (isinstance(participant.get("wake_route"), dict)
            and participant["wake_route"].get("kind") == "inapp-socket"):
        if inapp_dispatch is None:
            return False, 'desktop_not_offered'
        return True, "inapp_receipt_queue" if inapp_dispatch.enabled() else "inapp_dispatch_disabled"
    if (isinstance(participant.get("wake_route"), dict)
            and participant["wake_route"].get("kind") == "codex-ipc"):
        if codex_dispatch is None:
            return False, 'desktop_not_offered'
        # The receipt-owned sweep handles this route; this is not delivery evidence.
        return True, "codex_receipt_queue" if codex_dispatch.enabled() else "codex_dispatch_disabled"
    if (isinstance(participant.get("wake_route"), dict)
            and participant["wake_route"].get("kind") == "agy-desktop"):
        if agy_dispatch is None:
            return False, 'desktop_not_offered'
        if not agy_dispatch.enabled():
            return False, "agy_ipc_disabled"
        credential, _ = daemon_identity()
        if credential is None:
            return False, "agy_liveness_not_measurable"
        return True, "agy_receipt_queue"
    if participant.get("hosting_kind") == "in-app":
        return True, "watcher"
    channel = participant.get("channel", "pull")
    if channel in ("watch", "pull"):
        return True, channel
    if channel == "notify":
        return _notify_alert(alert)
    if channel == "tmux":
        # A.4: no valid system token → the alert stays pending; nothing touches tmux.
        credential, why = daemon_identity()
        if credential is None:
            import product_identity
            if product_identity.is_public():
                _note_identity(f"delivery withheld: daemon identity unavailable ({why}); run "
                               f"`{product_identity.command()} setup` to inspect or finish this installation")
                return False, f"no_system_token:{why}"
            _note_identity(f"nudges withheld: the daemon has no valid system token ({why}); "
                           f"provision (as the CoS or the principal; a store's first token: "
                           f"orch --as <you> invite <you> --bootstrap, then orch token claim "
                           f"<you>): orch join {store.DAEMON_SEAT} --kind system; "
                           f"orch invite {store.DAEMON_SEAT}; orch token claim {store.DAEMON_SEAT}; "
                           f"start the daemon with {DAEMON_TOKEN_FILE_ENV} naming that file "
                           f"or leave it at its default path")
            return False, f"no_system_token:{why}"
        _note_identity(None)
        msg_ids = alert.get("msg_ids") or []
        if not msg_ids:
            # An unread ID is not proof that it belonged to an unidentified
            # pre-A.3 alert; it may be a newly arrived message. Preserve the
            # legacy state until an external migration can identify it.
            return False, "legacy_pending_unidentified"
        if participants is None:
            participants = store.load_participants()
        registered = participants.get(pid)
        if not isinstance(registered, dict):
            return False, "seat_not_registered"
        # Before the nudge receipt/retry path: a dialog or limit is not a poke
        # attempt. Retain pending IDs quietly until the class changes.
        state = pane_state_adapter.observe(pid, participants)
        if state == "limit":
            pane_state_adapter.report_limit(pid, participants)
        if not input_allowed(state):
            return False, "pane_input_withheld"
        from tmux_bridge import wait_for_registered_pane_ready
        if not wait_for_registered_pane_ready(pid, participants, timeout=5.0):
            return False, "registered_pane_not_ready"
        msg_id = msg_ids[-1]
        nudge = compose_nudge(msg_id)
        exact_bytes = nudge + "\n"
        ok, err = receipts.inject_nudge(
            presented_token=credential, expected_requester=store.DAEMON_SEAT,
            target_seat=pid, msg_id=msg_id,
            exact_bytes=exact_bytes,
            writer=lambda: registered_tmux_nudge(pid, participants, nudge))
        return ok, err or "nudged"
    return False, f"unknown_channel:{channel}"


class StartupTiming:
    """One startup pass only; static phase labels and elapsed monotonic seconds."""
    def __init__(self):
        self.started = self.previous = time.monotonic()

    def mark(self, phase):
        now = time.monotonic()
        _log(f"startup phase={phase} elapsed={now - self.previous:.3f}s "
             f"total={now - self.started:.3f}s")
        self.previous = now


def run_pass(pending: Dict[str, Dict[str, Any]], *, timing=None) -> Dict[str, Dict[str, Any]]:
    """One delivery pass: read new log entries, alert, retry pending."""
    # A blocked seat cannot send. Observe its bounded help file without invoking
    # a native adapter; the resulting System notice takes the normal mail path.
    from provision import seat_help
    credential, _ = daemon_identity()
    if credential is not None:
        try:
            seat_help.observe(credential)
        except Exception as exc:
            _log(f"seat help observation unavailable: {type(exc).__name__}")
    if timing is not None:
        timing.mark('seat-help')
    # Provisioning evidence must not starve ordinary mail on a failed filesystem
    # check. The daemon is the observer, never the installer of Codex permissions.
    from provision import machine
    global _last_provision_observation, _provision_observation_error
    now = time.monotonic()
    if _last_provision_observation is None or now - _last_provision_observation >= PROVISION_OBSERVATION_INTERVAL:
        _last_provision_observation = now
        credential, _ = daemon_identity()
        if credential is not None:
            faults = []
            for observe in (machine.observe_rules, machine.observe_onboarding):
                try:
                    observe(credential)
                except Exception as exc:
                    faults.append(f"{observe.__name__}:{type(exc).__name__}")
            fault = ", ".join(faults) or None
            if fault and fault != _provision_observation_error:
                _log(f"provision observation unavailable: {fault}")
            _provision_observation_error = fault
    if timing is not None:
        timing.mark('provision-observation')
    import recall
    try:
        recall.recover()
    except (OSError, ValueError):
        # Native dispatch already refuses corrupt authoritative history. Keep
        # independent pull/legacy work observable; never heal a torn journal.
        _log('recall recovery unavailable; admitted recalls remain non-actionable')
    # D-GOV-2 (f) §3.3: write every focus row the record owes (expired, broken and
    # pass-through ends; an admission's QUEUED or DEFERRED) before any pointer is
    # selected, so the one poke at a period's end follows its end record.
    import focus
    try:
        for row in focus.settle(daemon=True):
            _log(focus.describe(row))
    except (OSError, ValueError):
        _log('focus settle unavailable; focus defers nothing it cannot read')
    participants = store.load_participants()
    pointer_only_seats = frozenset(pid for pid, row in participants.items()
                                  if isinstance(row.get("wake_route"), dict)
                                  and row["wake_route"].get("kind") in {"codex-ipc", "inapp-socket", "agy-desktop", "launched"})
    codex_handled_pairs: set[tuple[str, str]] = set()
    if timing is not None:
        timing.mark('registry')
    # This branch owns only Codex routes; legacy receipt framing is a separate fix.
    if codex_dispatch is not None and (pointer_only_seats or codex_dispatch.enabled()):
        credential, _ = daemon_identity()
        codex_dispatch.observe_pass(credential=credential, participants=participants, log=_log, handled_pairs=codex_handled_pairs)
    if timing is not None:
        timing.mark('codex-dispatch')
    if inapp_dispatch is not None and (inapp_dispatch.enabled() or inapp_dispatch.startup_observation_enabled() or any(
            isinstance(row.get('wake_route'), dict) and row['wake_route'].get('kind') == 'inapp-socket'
            for row in participants.values())):
        credential, _ = daemon_identity()
        inapp_dispatch.observe_pass(credential=credential, participants=participants, log=_log, handled_pairs=codex_handled_pairs)
    if timing is not None:
        timing.mark('inapp-dispatch')
    if agy_dispatch is not None and (agy_dispatch.enabled() or any(
            isinstance(row.get('wake_route'), dict) and row['wake_route'].get('kind') == 'agy-desktop'
            for row in participants.values())):
        credential, _ = daemon_identity()
        agy_dispatch.observe_pass(credential=credential, participants=participants, log=_log, handled_pairs=codex_handled_pairs)
    if timing is not None:
        timing.mark('agy-dispatch')
    if any(isinstance(row.get('wake_route'), dict) and row['wake_route'].get('kind') == 'launched'
           for row in participants.values()):
        credential, _ = daemon_identity()
        launched_outbox.observe_pass(credential=credential, participants=participants, log=_log,
                                     handled_pairs=codex_handled_pairs)
    offset = _read_cursor()
    log_size = store.LOG_FILE.stat().st_size if store.LOG_FILE.exists() else 0
    if offset > log_size:
        offset = 0  # log replaced/reset
    messages, new_offset = store.read_jsonl(store.LOG_FILE, offset)
    # A governance release may concern an old log row beyond this cursor.
    # Its immutable admission authorizes recovery; the original vet is retained.
    import quarantine
    current_ids = {message.get("id") for message in messages}
    incomplete = []
    released = quarantine.pending_messages(on_incomplete=incomplete.append)
    global _quarantine_incomplete
    current = {(str(store.STORE_DIR), issue["record_ref"]): issue for issue in incomplete}
    for key, issue in current.items():
        if _quarantine_incomplete.get(key) != issue:
            _log(f"quarantine {issue['id'] or issue['record_ref']}: incomplete; {issue['reason']}")
    _quarantine_incomplete = current
    messages.extend(message for message in released
                    if message["id"] not in current_ids)

    # Heal any inbox that missed its copy (sender crashed mid-fan-out).
    for msg in messages:
        for pid in store.repair_fanout(msg):
            _log(f"repaired missing inbox copy of {msg.get('id')} for {pid}")

    alerts = collect_alerts(messages, pointer_only_seats=pointer_only_seats, participants=participants)
    if timing is not None:
        timing.mark('mail-fanout')
    retained_legacy: Dict[str, Dict[str, Any]] = {}
    # Merge in pending (failed earlier) alerts
    for pid, stale in _normalize_pending(pending).items():
        if not _alert_eligible(participants.get(pid, {}), stale):
            continue
        stale = dict(stale)
        embedded_legacy = stale.pop("_retained_legacy", None)
        if embedded_legacy:
            retained_legacy[pid] = embedded_legacy
        a = alerts.setdefault(pid, stale)
        if a is not stale:
            unidentified = embedded_legacy or (stale if not stale.get("msg_ids") else None)
            if unidentified:
                # Keep unidentified state independent from identified alerts.
                # Inbox membership alone cannot positively associate an ID
                # with the legacy row.
                retained_legacy[pid] = unidentified
                if not embedded_legacy:
                    continue
            a["count"] += stale["count"]
            a.setdefault("msg_ids", [])[:0] = stale.get("msg_ids", [])
            if "handoff" in stale and "handoff" not in a:
                a["handoff"] = stale["handoff"]  # earlier undelivered handoff file

    participants = store.load_participants()
    still_pending: Dict[str, Dict[str, Any]] = {}
    focusing = focus.focusing_seats()
    for pid, alert in alerts.items():
        participant = participants.get(pid)
        if not participant:
            continue
        if not _alert_eligible(participant, alert):
            continue
        if pid in focusing and _focus_defers(participant, alert):
            # Retained quietly (§3.2): no pre while the period lasts; the newest
            # pending id is poked once, on the first pass after its end record.
            period = focusing[pid]['period-id']
            if (pid, period) not in _focus_logged:
                _focus_logged.add((pid, period))
                _log(f"alerts for {pid} deferred by focus period {period}")
            if pid in retained_legacy:
                alert["_retained_legacy"] = retained_legacy[pid]
            still_pending[pid] = alert
            continue
        # Filter by the sweep's finite batch, not its seat set: the log may
        # contain newer mail after a route was cleared during this pass.
        ids = alert.get("msg_ids") or []
        recalled = recall.graph()
        remaining = [mid for mid in ids if (pid, mid) not in codex_handled_pairs and mid not in recalled]
        if len(remaining) != len(ids):
            alert = dict(alert, msg_ids=remaining,
                         count=max(0, alert["count"] - len(ids) + len(remaining)))
            if not alert["count"]:
                if pid in retained_legacy:
                    still_pending[pid] = retained_legacy[pid]
                continue
        ok, detail = dispatch_alert(pid, participant, alert, participants=participants)
        if ok:
            if detail not in ("watch", "pull"):
                _log(f"alerted {pid} via {participant.get('channel')}: {detail}")
            if pid in retained_legacy:
                still_pending[pid] = retained_legacy[pid]
        else:
            if detail != "pane_input_withheld":
                _log(f"alert deferred for {pid}: {detail}")
            if pid in retained_legacy:
                alert["_retained_legacy"] = retained_legacy[pid]
            still_pending[pid] = alert

    # Pending before cursor: a crash between the two re-processes the pass
    # (duplicate nudges are harmless) instead of losing failed-nudge records.
    if still_pending != pending:
        _write_pending(still_pending)
    if new_offset != offset:
        _write_cursor(new_offset)
    if timing is not None:
        timing.mark('pending-dispatch')
    return still_pending


_focus_logged: set[tuple[str, str]] = set()


def _focus_defers(participant: Dict[str, Any], alert: Dict[str, Any]) -> bool:
    """True for an alert this pass would turn into a wake: a tmux poke or a notification."""
    if alert.get("human_notify"):
        return True
    route = participant.get("wake_route")
    if isinstance(route, dict) or participant.get("hosting_kind") == "in-app":
        return False  # the route's own chokepoint holds the gate
    return participant.get("channel", "pull") in {"tmux", "notify"}


def _normalize_pending(pending: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    out = {}
    for pid, a in pending.items():
        if isinstance(a, dict) and a.get("count"):
            out[pid] = a
    return out


def refresh_runtime_snapshot() -> None:
    """Cache tmux liveness + attention state for the web server / doctor."""
    participants = store.load_participants()
    sessions = set(list_sessions())
    runtime: Dict[str, Any] = {}
    for pid, p in participants.items():
        session = p.get("tmux_session")
        alive = bool(session and session in sessions)
        needs_attention, reason = False, None
        if alive:
            result = capture_pane(session, lines=30)
            if result.ok:
                reason = scan_pane(result.stdout)
                needs_attention = reason is not None
        runtime[pid] = {"session_name": session, "alive": alive,
                        "needs_attention": needs_attention, "reason": reason}
    _atomic_write(RUNTIME_SNAPSHOT,
                  json.dumps({"ts": store.now_iso(), "tmux_runtime": runtime,
                              "available_sessions": sorted(sessions)}, indent=2))


def refresh_terminal_state() -> None:
    """Additive memory-only observation; the legacy snapshot is independent."""
    credential, _ = daemon_identity()
    pane_state_adapter.refresh(store.load_participants(), report=credential is not None)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--once", action="store_true", help="single pass (for tests)")
    args = parser.parse_args()

    # Phase 0 W0.5 (ORCH_SPEC_01 D-STO-1): the daemon refuses to start without a valid
    # locator — one diagnostic, nothing written — and its lock records the store it bound
    # plus its own process birth, so `orch status`/`doctor` can prove UP rather than infer
    # it from a pid number that may since have been reused.
    try:
        bound = store.require_bound_store()
    except store.StoreUnbound as exc:
        print(str(exc), file=sys.stderr)
        return exc.exit_code
    from runtime_registry import os_proc_birth   # lazy: the registry is heavy, the daemon light

    # reviewer-P0-4: the check (the locator STILL names the store this process resolved at
    # import) and the commit (taking daemon.lock and recording this process) happen under
    # the same locator-level exclusion a registration holds across its whole sequence — so
    # a daemon can neither enter on a binding that is being superseded nor slip in between
    # a registration's live-daemon check and its commit. It waits for a registration in
    # flight (they are short), then re-reads; a binding that moved is refused, and nothing
    # is written on the superseded store.
    with store.registration_exclusion(wait=True):
        try:
            now_bound, _ = store.read_locator()
        except store.StoreUnbound as exc:
            print(f"delivery daemon refusing to start: the locator changed while this "
                  f"process was starting — {exc}", file=sys.stderr)
            return exc.exit_code
        if not store._same_dir(now_bound, bound):
            print(f"delivery daemon refusing to start: the locator now names {now_bound}, "
                  f"not the store this process resolved ({bound}) — a registration "
                  f"superseded it; start again to bind the current store", file=sys.stderr)
            return store.STORE_UNBOUND_EXIT
        store.ensure_store()
        lock_file = DAEMON_LOCK.open("a")
        try:
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print("delivery daemon already running (daemon.lock held)", file=sys.stderr)
            return 1
        import uuid
        identity = {"pid": os.getpid(),
                    "proc_birth": os_proc_birth(os.getpid()),
                    "store_dir": str(bound),
                    "operator": os.environ.get("PSQR_OWNER"),
                    "started": store.now_iso(), "instance": uuid.uuid4().hex}
        lock_file.truncate(0)
        lock_file.write(json.dumps(identity))
        lock_file.flush()
        os.fsync(lock_file.fileno())

    from daemon_heartbeat import Pulse
    from pane_state import StateMemory
    from pane_state_socket import ObservationService
    # Only the class and seat enter this transition log; never captured text.
    pane_state_adapter.memory = StateMemory(
        on_change=lambda seat, state: _log(f"terminal state {seat}: {state}"))
    pane_state_adapter.sampled_at = None
    try:
        with Pulse(bound, identity, _log), ObservationService(identity,
                lambda: pane_state_adapter.projection(store.load_participants()), _log):
            # D-GOV-2 (f) §3.3: after a restart, read the period records first and
            # write every owed focus row before any observation or pointer selection.
            import focus
            try:
                for row in focus.settle(daemon=True):
                    _log(focus.describe(row) + ' (at start)')
            except (OSError, ValueError):
                _log('focus settle unavailable at start; focus defers nothing it cannot read')
            participants = store.load_participants()
            observed_codex = codex_dispatch is not None and (codex_dispatch.enabled() or any(
                isinstance(p.get("wake_route"), dict) and p["wake_route"].get("kind") == "codex-ipc"
                for p in participants.values()))
            if observed_codex:
                credential, _ = daemon_identity()
                codex_dispatch.observe_pass(credential=credential, participants=participants, log=_log, phase="started")
            observed_inapp = inapp_dispatch is not None and (inapp_dispatch.enabled() or any(
                isinstance(p.get('wake_route'), dict) and p['wake_route'].get('kind') == 'inapp-socket'
                for p in participants.values()))
            observed_agy = agy_dispatch is not None and (agy_dispatch.enabled() or any(
                isinstance(p.get('wake_route'), dict) and p['wake_route'].get('kind') == 'agy-desktop'
                for p in participants.values()))
            if observed_inapp:
                credential, _ = daemon_identity()
                inapp_dispatch.observe_pass(credential=credential, participants=participants, log=_log, phase='started')
            if observed_agy:
                credential, _ = daemon_identity()
                agy_dispatch.observe_pass(credential=credential, participants=participants, log=_log, phase='started')
            try:
                _log(f"delivery daemon up (pid {os.getpid()}, store {bound})")
                pending = _read_pending()
                last_attention = 0.0
                last_approval_sweep = 0.0
                startup_timing = StartupTiming()
                while True:
                    # The approval timeout sweep (G0.3 fail-closed) runs in its OWN guarded
                    # block, NEVER inside the delivery-pass try (Bugbot r11 MED): a
                    # persistently failing run_pass must not also starve the sweep, or
                    # expired approvals would sit unsettled and their seat notifications
                    # undelivered — the exact fail-open the timeout design forbids. Each
                    # subsystem's failure is isolated; the daemon stays alive through both.
                    try:
                        pending = run_pass(pending, timing=startup_timing)
                        if time.monotonic() - last_attention > ATTENTION_INTERVAL:
                            try:
                                refresh_runtime_snapshot()
                            finally:
                                # The additive state read must survive a failed legacy write.
                                try:
                                    refresh_terminal_state()
                                except Exception:
                                    _log("terminal-state observation unavailable")
                            last_attention = time.monotonic()
                            if startup_timing is not None:
                                startup_timing.mark('tmux-snapshot')
                    except Exception as exc:  # keep the daemon alive; log and continue
                        _log(f"ERROR in delivery pass: {exc!r}")
                    finally:
                        # A failed first pass does not turn this into a retry log.
                        startup_timing = None
                    try:
                        if time.monotonic() - last_approval_sweep > APPROVAL_SWEEP_INTERVAL:
                            sweep_approvals()
                            last_approval_sweep = time.monotonic()
                    except Exception as exc:
                        _log(f"ERROR in approval sweep: {exc!r}")
                    if args.once:
                        return 0
                    time.sleep(POLL_INTERVAL)
            finally:
                if observed_inapp:
                    credential, _ = daemon_identity()
                    try:
                        inapp_dispatch.observe_pass(credential=credential, participants=store.load_participants(),
                                                    log=_log, phase='stopped')
                        time.sleep(min(1.0, inapp_dispatch.OBSERVATION / 10.0))
                    except Exception as exc:
                        _log(f"Error shutting down observation: {exc}")
                if observed_agy:
                    credential, _ = daemon_identity()
                    try:
                        agy_dispatch.observe_pass(credential=credential, participants=store.load_participants(),
                                                  log=_log, phase='stopped')
                    except Exception as exc:
                        _log(f"Error shutting down AGY observation: {exc}")
                if observed_codex:
                    credential, _ = daemon_identity()
                    codex_dispatch.observe_pass(credential=credential, participants=store.load_participants(),
                                                log=_log, phase="stopped")
    finally:
        lock_file.close()


if __name__ == "__main__":
    raise SystemExit(main())
