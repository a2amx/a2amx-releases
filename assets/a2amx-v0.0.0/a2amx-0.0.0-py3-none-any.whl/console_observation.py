"""Console D-CON-1: bounded observation of a registry-declared private socket."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Mapping

import panel
import store
from seat_socket import registered_session, registered_socket
from tmux_bridge import registered_session_exists, capture_registered_pane

DEFAULT_DEPTH = 400
MAX_DEPTH = 5000


def observe(seat: str, registry: Mapping[str, Mapping[str, Any]], *,
            lines: int = DEFAULT_DEPTH) -> dict[str, Any]:
    participant = registry[seat]
    measured_at = datetime.now(timezone.utc).isoformat()
    result = {"participant_id": seat, "measured_at": measured_at,
              "hosting": "none", "socket": None, "session_name": None,
              "alive": False, "pane": ""}
    if not store.has_mailbox(participant):
        return {**result, "liveness": {"value": None, "source": panel.UNMEASURABLE,
                                      "detail": "human authority is not a seat"}}
    if participant.get("hosting_kind") != "tmux-hosted":
        result["liveness"] = panel.non_tmux_liveness()
        return result
    depth = max(1, min(lines, MAX_DEPTH))
    result.update(hosting="tmux-hosted", depth=depth, liveness="down")
    try:
        result["socket"] = registered_socket(seat, registry)
        result["session_name"] = registered_session(participant)
    except (TypeError, ValueError) as exc:
        result["detail"] = str(exc)
        return result
    if not registered_session_exists(seat, registry):
        return result
    capture = capture_registered_pane(seat, registry, lines=depth)
    result.update(alive=capture.ok, liveness="live" if capture.ok else "down",
                  pane=capture.stdout if capture.ok else "")
    if not capture.ok:
        result["detail"] = capture.stderr or "pane unavailable"
    return result
