"""Authenticated launched-host business methods; no vendor or console effects.

Each call holds the core's launch/token/registry locks through final admission.
The owner supplies Enrollment/Challenges objects; these never come from JSON.
Origin-dependent methods remain unavailable with the default unqualified owner.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime
import importlib.metadata
import hashlib
import json
import os
from pathlib import Path
import secrets
import stat
import threading
import time

import launched_launch as launch
import launched_origin as origin
import launched_protocol as wire
import launched_storage as files
import receipts
import store
import wake_hook_store

_route_context = threading.local()
_MARK = object()


def check_registry_change(seat, actor, before, after):
    """Only a verifier-admitted own declaration may change a launched route."""
    marker = getattr(_route_context, "active", None)
    retiring = (getattr(_route_context, "retiring", None) == (_MARK, seat)
                and actor is not None and (before.get(actor.get("participant_id")) or {}).get("role") in store.PROVISIONING_ROLES)
    if retiring:
        marker = (_MARK, seat, None)
    if (marker is None or marker[0] is not _MARK or marker[1] != seat
            or actor is None or (not retiring and actor.get("participant_id") != seat)):
        raise store.RegistryMutationRefused("launched_origin_required", "verified launched declaration required")
    old, new = before.get(seat), after.get(seat)
    if not old or not new or new.get("wake_route") != marker[2]:
        raise wire.Refused("binding_mismatch")
    if {k for k in old.keys() | new.keys() if old.get(k) != new.get(k)} - {"wake_route", "last_update"}:
        raise wire.Refused("binding_mismatch")


@contextmanager
def _declaring(seat, route):
    old = getattr(_route_context, "active", None)
    _route_context.active = (_MARK, seat, route)
    try:
        yield
    finally:
        _route_context.active = old


@contextmanager
def _retiring(seat):
    old = getattr(_route_context, "retiring", None)
    _route_context.retiring = (_MARK, seat)
    try:
        yield
    finally:
        _route_context.retiring = old


def _version():
    import product_identity
    return importlib.metadata.version(product_identity.load().distribution)


class Gateway:
    def __init__(self, *, enrollment=None, challenges=None, clock=time.time):
        self.enrollment = enrollment or launch.Enrollment()
        self.challenges = challenges or origin.Challenges()
        self.clock = clock

    @staticmethod
    def _identity(presented_token, seat):
        actor, why = store._verdict_unlocked(presented_token, store._read_tokens_unlocked())
        row = store._read_participants_unlocked().get(seat) or {}
        if actor is None or actor.get("participant_id") != seat:
            raise wire.Refused("credential_invalid")
        if (actor.get("scope") != store.SEAT_SCOPE or actor.get("surface") != "terminal"
                or row.get("kind") != "agent" or row.get("role") not in store.PARTICIPANT_ROLES
                or row.get("role") in {"human_authority", "system_governor"}):
            raise wire.Refused("credential_scope")
        return actor

    def _capabilities(self, seat):
        reason = "origin_unqualified"
        row = store._read_participants_unlocked().get(seat) or {}
        route = row.get("wake_route") or {}
        # Before first declaration the launch post already names the binding.
        entries = [r for r in receipts.strict_rows() if r.get("kind") == "seat_lifecycle"
                   and r.get("seat") == seat]
        binding = route.get("binding") or next(((entry.get("origin") or {}).get("binding")
                                               for entry in reversed(entries) if entry.get("origin")), None)
        if binding:
            try:
                self.enrollment.current(seat, binding)
                reason = None
            except wire.Refused as exc:
                reason = exc.code
        result = {name: {"status": "supported", "reason": "ok"} for name in wire.METHOD_FIELDS}
        if reason:
            for name in wire.PROTECTED:
                result[name] = {"status": "unavailable", "reason": reason}
        for name in wire.V2:
            result[name] = {"status": "unavailable", "reason": "requires_O9_v2"}
        return result

    def challenge(self, value, *, presented_token):
        request = wire.request(value)
        if request["method"] not in wire.PROTECTED:
            raise wire.Refused()
        def apply(seat):
            self._identity(presented_token, seat)
            record = self.enrollment.current(seat, request["params"]["binding"])
            return self.challenges.issue(record, seat, request)
        return store.authenticated_registry_act(presented_token, apply)

    def call(self, value, *, presented_token, proof=None):
        call_id = None
        try:
            # Preserve a valid correlation id for unavailable v2 responses.
            decoded = wire.decode(wire.canonical(value)) if type(value) is dict else wire.decode(value)
            if type(decoded) is dict:
                call_id = decoded.get("call_id")
            request = wire.request(decoded)
            def apply(seat):
                actor = self._identity(presented_token, seat)
                if request["method"] in wire.PROTECTED:
                    record = self.enrollment.current(seat, request["params"]["binding"])
                    return self.challenges.admit(record, seat, request, proof,
                        lambda: self._method(seat, actor, request, record))
                return self._method(seat, actor, request, None)
            result = store.authenticated_registry_act(presented_token, apply)
            return wire.response(call_id, result=result)
        except store.RegistryMutationRefused:
            return wire.response(call_id, error=wire.Refused("credential_invalid"))
        except wire.Refused as exc:
            return wire.response(call_id, error=exc)
        except (OSError, ValueError, KeyError, TypeError):
            # A file or append may have committed. Never leak exception text,
            # return success, or encourage a blind retry.
            return wire.response(call_id, error=wire.Refused("persistence_unknown", "unknown"))

    @staticmethod
    def _route(seat, params):
        route = (store._read_participants_unlocked().get(seat) or {}).get("wake_route")
        if (type(route) is not dict or route.get("kind") != "launched"
                or route.get("binding") != params["binding"]
                or route.get("generation") != params.get("route_generation")):
            raise wire.Refused("stale_generation")
        # A registry replacement without its durable declaration never activates.
        if not any(r.get("kind") == "wake-route" and r.get("event") == "declared"
                   and r.get("seat") == seat and r.get("route") == route
                   for r in receipts.strict_rows()):
            raise wire.Refused("persistence_unknown", "unknown")
        return route

    def _method(self, seat, actor, request, record):
        method, params = request["method"], request["params"]
        if method == "host.capabilities":
            return {"version": 1, "implementation": _version(), "capabilities": self._capabilities(seat)}
        if method == "host.authenticate":
            return self._authenticated(seat, actor)
        if method == "host.status":
            return self._status(seat, params)
        if method == "host.route.declare":
            return self._declare(seat, params, record)
        self._route(seat, params)
        if method == "host.intent.verify":
            import launched_outbox
            return launched_outbox.verify(seat, params, now=self.clock())
        if method == "host.mail.fetch":
            return self._fetch(seat, params, record)
        if method == "host.fetch.proof":
            import launched_outbox
            self.enrollment.current(seat, params["binding"])
            return launched_outbox.proof(seat, params, now=self.clock())
        if method in {"host.event.pointer", "host.event.arrival"}:
            return self._event(seat, params, method)
        raise wire.Refused("method_unsupported", "unavailable")

    @staticmethod
    def _authenticated(seat, actor):
        """host.authenticate's result: one of three exact shapes (CRED-G; CREDENTIALS_01 D-CRED-1).

        Without the credentials_01 marker it is today's result, byte for byte: no `lifetime`, and
        `expires_at` from the session. With the marker, a seat session without a time limit (the
        store's own rule, `_untimed_seat_session`) says `lifetime: until_revoked` and carries no
        `expires_at`; any other session the store admitted is timed and says `lifetime: timed`
        with its `expires_at`. The store's verdict has already refused every record that is
        neither, an expired one included, so revocation and a new generation are refusals of the
        next call, here as everywhere."""
        result = {"seat": seat, "scope": "seat", "surface": "terminal", "credential_ref": actor["id"]}
        if store._credentials_on(store._read_tokens_unlocked()):
            if store._untimed_seat_session(actor, None):
                return {**result, "lifetime": store.LIFETIME_UNTIL_REVOKED}
            result["lifetime"] = "timed"
        expiry = datetime.fromisoformat(actor["expires_at"]).timestamp()
        wire.timestamp(expiry)
        return {**result, "expires_at": expiry}

    def _status(self, seat, params):
        row = store._read_participants_unlocked().get(seat) or {}
        route = row.get("wake_route")
        found = None
        if type(route) is dict and route.get("kind") == "launched":
            found = next((r for r in reversed(receipts.strict_rows())
                          if r.get("kind") == "wake-route" and r.get("event") == "declared"
                          and r.get("seat") == seat and r.get("route") == route
                          and (params["declaration_id"] is None or
                               r.get("declaration_id") == params["declaration_id"])), None)
        current = found is not None and route.get("binding") == params["binding"]
        return {"binding_state": "current" if current else ("absent" if route is None else "stale"),
                "route_generation": route["generation"] if current else None,
                "declaration_receipt_ref": found["event-id"] if current else None,
                "core_version": _version(), "capabilities": self._capabilities(seat)}

    def _declare(self, seat, params, record):
        with receipts._nudge_lock():
            parts = store._read_participants_unlocked()
            old = parts[seat].get("wake_route")
            signature = wire.fingerprint(params)
            history = [r for r in receipts.strict_rows() if r.get("kind") == "wake-route"
                       and r.get("seat") == seat and r.get("declaration_id") == params["declaration_id"]]
            if history:
                prior = history[-1]
                if prior.get("request_sha256") != signature:
                    raise wire.Refused("declaration_conflict")
                if prior.get("route") != old or not old or old.get("binding") != params["binding"]:
                    raise wire.Refused("stale_generation")
                return {**prior["gateway_result"], "replayed": True}
            for field, source in (("ref", "supervisor_control_ref"), ("identity_sha256", "identity_sha256"),
                                  ("adapter_pin", "adapter_pin")):
                if params[field] != record[source]:
                    raise wire.Refused("binding_mismatch")
            launch.canonical_path(params["ref"])
            if old is not None and (old.get("kind") != "launched" or old.get("binding") != params["binding"]):
                raise wire.Refused("binding_mismatch")
            operation = wire.fingerprint({"seat": seat, "declaration_id": params["declaration_id"]})
            intent = files.read("declaration", operation)
            if intent is not None:
                wire.exact(intent, {"seat", "request_sha256", "previous_route", "route", "receipt"})
                if intent["seat"] != seat or intent["request_sha256"] != signature:
                    raise wire.Refused("declaration_conflict")
                if old not in (intent["previous_route"], intent["route"]):
                    raise wire.Refused("stale_generation")
            previous = intent["previous_route"] if intent is not None else old
            expected = previous.get("generation") if previous else None
            if params["expected_route_generation"] != expected:
                raise wire.Refused("stale_generation")
            for other, participant in parts.items():
                peer = participant.get("wake_route") or {}
                if other != seat and (peer.get("ref") == params["ref"] or
                                      peer.get("session_ref") == params["binding"]["session_ref"]):
                    raise wire.Refused("binding_mismatch")
            replayed = intent is not None
            if intent is None:
                ref = "route-receipt-" + secrets.token_hex(16)
                route = {"kind": "launched", "ref": params["ref"], "session_ref": params["binding"]["session_ref"],
                         "binding": params["binding"], "generation": "route-" + secrets.token_hex(16),
                         "declared_at": store.now_iso()}
                result = {"receipt_ref": ref, "binding": params["binding"], "route_generation": route["generation"],
                          "ref": params["ref"], "replayed": False}
                receipt = {"kind": "wake-route", "event": "declared", "event-id": ref,
                    "seat": seat, "actor": seat, "route": route, "generation": route["generation"],
                    "declaration_id": params["declaration_id"], "request_sha256": signature,
                    "gateway_result": result, "epoch": self.clock(), "ts": store.now_iso()}
                intent = {"seat": seat, "request_sha256": signature, "previous_route": old,
                          "route": route, "receipt": receipt}
                # A retry can now reconcile either side of registry publication
                # without reverting a route or inventing a new generation.
                files.create("declaration", operation, intent)
            route, receipt = intent["route"], intent["receipt"]
            wire.exact(route, {"kind", "ref", "session_ref", "binding", "generation", "declared_at"})
            wire.text(route["generation"])
            wire.text(route["declared_at"])
            wire.exact(receipt, {"kind", "event", "event-id", "seat", "actor", "route", "generation",
                                "declaration_id", "request_sha256", "gateway_result", "epoch", "ts"})
            wire.text(receipt["event-id"])
            expected_result = {"receipt_ref": receipt["event-id"], "binding": params["binding"],
                               "route_generation": route["generation"], "ref": params["ref"], "replayed": False}
            if (route["kind"] != "launched" or route["ref"] != params["ref"]
                    or route["binding"] != params["binding"]
                    or route["session_ref"] != params["binding"]["session_ref"]
                    or receipt["kind"] != "wake-route" or receipt["event"] != "declared"
                    or receipt["actor"] != seat or receipt["generation"] != route["generation"]
                    or receipt["gateway_result"] != expected_result
                    or receipt.get("route") != route or receipt.get("seat") != seat
                    or receipt.get("declaration_id") != params["declaration_id"]
                    or receipt.get("request_sha256") != signature):
                raise wire.Refused("declaration_conflict")
            if old != route:
                parts[seat] = {**parts[seat], "wake_route": route, "last_update": store.now_iso()}
                with _declaring(seat, route):
                    store._write_participants_unlocked(parts)
            receipts.append_durable(receipt)
            return {**receipt["gateway_result"], "replayed": replayed}

    def _event(self, seat, params, method):
        if method == "host.event.pointer":
            operation = {k: params[k] for k in ("binding", "route_generation", "verification_ref")}
            operation["session_id"] = params["event"]["session_id"]
        else:
            operation = {k: params[k] for k in ("binding", "route_generation", "admission_id")}
        key, signature = wire.fingerprint(operation), wire.fingerprint(params["event"])
        with receipts._nudge_lock():
            prior = next((r for r in receipts.strict_rows() if r.get("kind") == "seat_event"
                          and r.get("seat") == seat and r.get("gateway_operation") == key), None)
            if prior:
                if prior.get("event_sha256") != signature:
                    raise wire.Refused("event_conflict")
                return {**prior["gateway_result"], "replayed": True}
            if method == "host.event.pointer":
                import launched_outbox
                witness = launched_outbox.witness(seat, params, now=self.clock())
                if params["event"]["pointer"] != witness["pointer"]:
                    raise wire.Refused("intent_mismatch")
            ref = "event-" + secrets.token_hex(16)
            result = {"receipt_ref": ref, "replayed": False}
            if method == "host.event.arrival":
                result["admission_id"] = params["admission_id"]
            receipts.append_durable({"kind": "seat_event", "seat": seat, **params["event"],
                "event-id": ref, "generation": params["route_generation"], "binding": params["binding"],
                "gateway_operation": key, "event_sha256": signature, "gateway_result": result,
                **({"wording": "a prompt arrived on channel attach"} if method == "host.event.arrival" else {}),
                "epoch": self.clock(), "ts": store.now_iso()})
            return result

    def _fetch(self, seat, params, record):
        import launched_outbox
        verification = params["verification_ref"]
        old = files.read("fetch", verification)
        if old:
            if old["seat"] != seat or old["binding"] != params["binding"] or old["route_generation"] != params["route_generation"]:
                raise wire.Refused("binding_mismatch")
            return self._fetch_result(old, home=record["canonical_home"], replayed=True)
        witness = launched_outbox.witness(seat, params, now=self.clock())
        batch_ref = "launched-" + secrets.token_hex(16) + ".json"
        saved = {"seat": seat, "binding": params["binding"], "route_generation": params["route_generation"],
                 "verification_ref": verification, "batch_ref": batch_ref, "message_id": witness["message_id"]}
        home = launch.canonical_path(record["canonical_home"])
        def save(messages):
            # A legitimate own-seat fetch can win after intent verification.
            # Empty drains write no FETCHED transaction, so they must not
            # reserve a batch/proof that can never become committed.
            if not messages:
                raise wire.Refused("intent_withdrawn")
            # Existing full-body durable saver owns inbox directory validation.
            actual = Path(wake_hook_store._save_batch(home, messages))
            destination = home / ".orch" / "inbox" / batch_ref
            actual.rename(destination)
            store._fsync_dir(destination.parent)
            saved["message_ids"] = [m["id"] for m in messages]
            saved["batch_sha256"] = hashlib.sha256(destination.read_bytes()).hexdigest()
            files.create("fetch", verification, saved)
        store.drain_inbox(seat, before_commit=save, fetch_metadata={"via": "hook",
            "session_ref": params["binding"]["session_ref"], "launched": {
                "verification_ref": verification, "batch_ref": batch_ref,
                "host_generation": params["binding"]["host_generation"],
                "route_generation": params["route_generation"]}})
        return self._fetch_result(saved, home=record["canonical_home"], replayed=False)

    @staticmethod
    def _fetch_result(saved, *, home, replayed):
        batch = launch.canonical_path(home) / ".orch" / "inbox" / saved["batch_ref"]
        if (batch.resolve() != batch or batch.name != saved["batch_ref"]
                or not batch.name.startswith("launched-")):
            raise wire.Refused("fetch_unknown", "unknown")
        try:
            fd = os.open(batch, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
            with os.fdopen(fd, "rb") as stream:
                if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
                    raise wire.Refused("fetch_unknown", "unknown")
                digest = hashlib.file_digest(stream, "sha256").hexdigest()
        except OSError:
            raise wire.Refused("fetch_unknown", "unknown") from None
        if digest != saved["batch_sha256"]:
            raise wire.Refused("fetch_unknown", "unknown")
        rows = receipts.strict_rows()
        candidates = [r for _, r in store.valid_fetched_deliveries(rows)
                      if r.get("seat") == saved["seat"] and r.get("launched") == {
                          "verification_ref": saved["verification_ref"], "batch_ref": saved["batch_ref"],
                          "host_generation": saved["binding"]["host_generation"],
                          "route_generation": saved["route_generation"]}]
        txns = {r["txn-id"] for r in candidates}
        for candidate in candidates:
            prepares = [r for r in rows if r.get("kind") == "delivery-transaction"
                        and r.get("phase") == "prepare" and r.get("txn-id") == candidate["txn-id"]]
            if not prepares or any(r.get("launched") != candidate.get("launched")
                                   or r.get("session_ref") != saved["binding"]["session_ref"] for r in prepares):
                raise wire.Refused("fetch_unknown", "unknown")
        if (len(txns) != 1 or set(saved["message_ids"]) != {r["msg-id"] for r in candidates}):
            raise wire.Refused("fetch_unknown", "unknown")
        return {"fetch_ref": next(iter(txns)), "batch_ref": saved["batch_ref"],
                "message_ids": saved["message_ids"], "contains_intent_message": saved["message_id"] in saved["message_ids"],
                "replayed": replayed}
