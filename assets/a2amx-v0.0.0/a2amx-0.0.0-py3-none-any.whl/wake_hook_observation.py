"""Read-only receipt projection: hook fetch is distinct from a subsequent seat act."""
import math
import time

import receipts
import store


def hook_deliveries(journal=None, *, include_evidence=False):
    rows=list(receipts.rows() if journal is None else journal)
    last_act={r['seat']:i for i,r in enumerate(rows) if r.get('kind')=='seat-act' and r.get('command') not in {'await', 'hook-fetch'} and isinstance(r.get('seat'),str)}
    found={}
    for i,row in store.valid_fetched_deliveries(rows):
        pair=(row.get('seat'),row.get('msg-id'))
        if row.get('via')=='hook':
            found[pair]={'recipient':pair[0], 'id':pair[1], 'ts':row.get('ts'),
                         'state':'seat_act_observed' if last_act.get(pair[0],-1)>i else 'hook_fetched_no_seat_act'}
            if include_evidence:
                found[pair]['receipt_evidence'] = [receipts.reference(row)]
        else:
            found.pop(pair,None)
    return list(found.values())


def accepted_without_fetch(journal=None, *, now=None, include_evidence=False):
    """Current overdue accepted pointers; one row per seat/message, not retries.

    Read receipts only, including transactional fetch replay. A cleared/replaced
    declaration cannot leave a stale current warning. Counts are snapshot counts,
    not a cumulative pilot statistic.
    """
    rows = list(receipts.rows() if journal is None else journal)
    now = time.time() if now is None else now
    fetched = {(r.get('seat'), r.get('msg-id')) for _, r in store.valid_fetched_deliveries(rows)}
    declarations = {r.get('seat'): r for r in rows if r.get('kind') == 'wake-route'}
    pres = {r.get('event-id'): r for r in rows
            if r.get('kind') == 'nudge' and r.get('phase') == 'pre' and r.get('route_kind') == 'inapp-socket'}
    import recall
    recalled = recall.graph(rows)
    overdue = {}
    for row in rows:
        reconciled = row.get('kind') == 'claude-reconciliation' and row.get('result') == 'hook_observed'
        if not reconciled and (row.get('kind') != 'nudge' or row.get('phase') != 'post'
                or row.get('route_kind') != 'inapp-socket' or row.get('result') != 'accepted'):
            continue
        pre = pres.get(row.get('nudge-event-id') if reconciled else row.get('event-id'))
        if not pre:
            continue
        seat, mid = pre.get('target seat'), pre.get('msg-id')
        declared = declarations.get(seat, {})
        epoch = row.get('observed_epoch') if reconciled else row.get('epoch')
        if (declared.get('event') != 'declared' or declared.get('generation') != pre.get('generation')
                or (seat, mid) in fetched or mid in recalled or not isinstance(epoch, (int, float))
                or not math.isfinite(epoch) or now - epoch < 720):
            continue
        overdue[(seat, mid)] = {'recipient': seat, 'id': mid, 'state': 'accepted_no_fetch',
                               'accepted_at': row.get('ts'), 'age_seconds': int(now - epoch),
                               'generation': pre['generation'], 'event-id': pre['event-id']}
        if include_evidence:
            overdue[(seat, mid)]['receipt_evidence'] = [receipts.reference(r) for r in (declared, pre, row)]
    return list(overdue.values())


def inapp_status(seat,route, *, evidence=None):
    from desktop_support import optional
    status = optional('inapp_dispatch_status')
    inapp_wake_route = optional('inapp_wake_route')
    if status is None or inapp_wake_route is None:
        return 'not-offered', 'desktop preview is not included', None
    snapshot=status.read()
    if snapshot and snapshot.get('phase')=='stopped':return 'stopped','daemon stopped',snapshot.get('ts')
    if snapshot and snapshot.get('state')=='disabled':return 'disabled','switch off',snapshot.get('ts')
    rows=receipts.rows();generation=inapp_wake_route.generation(route)
    history=[r for r in rows if r.get('generation')==generation and
             (r.get('seat')==seat or r.get('target seat')==seat)]
    import recall
    settled = recall.settled_attempts(rows)
    history = [r for r in history if (r.get('kind') == 'wake_route_dead' and r.get('terminal'))
               or r.get('event-id', r.get('nudge-event-id')) not in settled]
    latest_pre=next((r for r in reversed(history) if r.get('phase')=='pre'),None)
    dead=[r for r in history if r.get('kind')=='wake_route_dead' and
          (r.get('terminal') or latest_pre is None or r.get('event-id')==latest_pre.get('event-id'))]
    if dead:
        if evidence is not None: evidence.append(receipts.reference(dead[-1]))
        return 'dead',dead[-1]['reason'],dead[-1]['ts']
    if latest_pre and latest_pre.get('recovery_policy') == 'claude-held-v1':
        reconciliation = next((r for r in reversed(history) if r.get('kind')=='claude-reconciliation'
                                and r.get('nudge-event-id')==latest_pre['event-id']
                                and r.get('result') in {'hook_observed','fetched'}),None)
        hold = next((r for r in reversed(history) if r.get('kind')=='claude-route-hold'
                     and r.get('nudge-event-id')==latest_pre['event-id']),None)
        fetched = {(r.get('seat'),r.get('msg-id')) for _,r in store.valid_fetched_deliveries(rows)}
        if hold and reconciliation is None and (seat,latest_pre['msg-id']) not in fetched:
            if evidence is not None: evidence.extend(receipts.reference(r) for r in (latest_pre,hold))
            return hold['state'],hold['reason'],hold['ts']
    overdue = [r for r in accepted_without_fetch(rows, include_evidence=True)
               if r['recipient'] == seat and r['generation'] == generation]
    if overdue:
        if evidence is not None:
            evidence.extend(overdue[-1]['receipt_evidence'])
        return 'accepted_no_fetch',f'accepted, no fetch ({len(overdue)} overdue pointer(s))',overdue[-1]['accepted_at']
    observed=[r for r in hook_deliveries(rows, include_evidence=True) if r['recipient']==seat]
    # An older fetched batch must not conceal a newer outstanding wake.
    if latest_pre and not any(r['id']==latest_pre.get('msg-id') for r in observed):
        observed=[]
    if observed:
        last=observed[-1]
        if evidence is not None: evidence.extend(last['receipt_evidence'])
        detail=('delivered to the turn, no act of the seat observed' if last['state']=='hook_fetched_no_seat_act'
                else 'delivered to the turn; later seat act observed')
        return last['state'],detail,last['ts']
    if latest_pre and latest_pre.get('recovery_policy') == 'claude-held-v1':
        position = next(i for i,r in enumerate(rows) if r is latest_pre)
        fetched = next((r for i,r in reversed(list(store.valid_fetched_deliveries(rows)))
                        if i>position and r.get('seat')==seat
                        and r.get('msg-id')==latest_pre.get('msg-id')),None)
        if fetched is not None:
            if evidence is not None:
                evidence.extend(receipts.reference(r) for r in (latest_pre,fetched))
            return 'fetched','mail fetch committed; original attempt evidence retained; fetch is not hook acceptance',fetched['ts']
    post=[r for r in history if r.get('phase')=='post']
    pre=[r for r in history if r.get('phase')=='pre']
    if pre:
        last=next((r for r in reversed(post) if r['event-id']==pre[-1]['event-id']),None)
        if evidence is not None:
            evidence.extend(receipts.reference(r) for r in (pre[-1], last) if r is not None)
        if pre[-1].get('recovery_policy') == 'claude-held-v1':
            reconciled = next((r for r in reversed(history) if r.get('kind')=='claude-reconciliation'
                               and r.get('nudge-event-id')==pre[-1]['event-id']
                               and r.get('result')=='hook_observed'),None)
            if reconciled:
                if evidence is not None:evidence.append(receipts.reference(reconciled))
                return 'accepted','late hook reconciled; original uncertainty retained',reconciled['ts']
            if last and last['result']=='uncertain':
                return 'held-uncertain',last['reason'],last['ts']
            if last is None and time.time()>=pre[-1]['orphan_observation_deadline']:
                return 'held-unknown','unpaired pre; no acceptance established',pre[-1]['ts']
        if last:return last['result'],last['reason'],last['ts']
        return 'awaiting_hook','observation pending; no acceptance yet',pre[-1]['ts']
    if snapshot:
        result=snapshot.get('seats',{}).get(seat,{})
        detail=result.get('reason')
        if (snapshot.get('state')=='enabled' and not snapshot.get('fault')
                and result.get('ok') is True and result.get('route')==route
                and detail=='no_pending_pointer'):
            return 'declared','dispatcher enabled; no pending pointer',snapshot.get('ts')
        if detail:return 'refused',detail,snapshot.get('ts')
    return 'declared','route declared; dispatcher state unknown' if snapshot is None else 'no pointer attempted',None
