"""R9 D-CON-11: the single owner of prose-header extraction and comparison.

Only a contiguous header block after leading blank lines is considered. Labels
start a line or a middle-dot segment; labels inside values are ordinary text.
HRS repeated-label rule: retain every occurrence in order and check each one.
Equal repeats are harmless; a later value cannot overwrite a contradiction.
This module never fills an envelope and never assigns authority from prose.
"""
from __future__ import annotations

import re
from collections.abc import Mapping
from typing import Any

from identity_resolution import resolve_id_or_label

_LABEL = re.compile(r"^\s*(TO|FROM|RE|AUTHORITY)\s*:\s*(.*)$", re.I)
_POSITION = re.compile(r"(?:^|·)\s*(TO|FROM|RE|AUTHORITY)\s*:\s*", re.I)
_AUTHORITY = re.compile(r"^(decision|proposal|relay|FYI)\b", re.I)
_MENTION = re.compile(r"(?<![\w@])@([\w.-]+)")
_BROADCAST = {"all", "everybody", "everyone"}


class ClientHeaderRefused(ValueError):
    """Structured CLI/HTTP refusal before any canonical message append."""
    def __init__(self, comparison):
        self.comparison = comparison
        super().__init__("prose header disagrees with the typed message")


def extract(text: str) -> list[dict[str, str]]:
    """Extract occurrences, excluding quotes, fences and prefaced forwards."""
    headers = []
    for line in text.splitlines():
        if not headers and not line.strip():
            continue
        # A non-header line ends the head block. In particular > and ```/~~~
        # cannot start it, and a header below a forwarding preface is excluded.
        if not _LABEL.match(line):
            break
        positions = list(_POSITION.finditer(line))
        for index, match in enumerate(positions):
            label = match[1].upper()
            end = positions[index + 1].start() if index + 1 < len(positions) else len(line)
            value = line[match.end():end]
            # RE runs to the next label or line end. The identity and authority
            # segments end at any middle dot, including an unlabelled segment.
            if label != "RE":
                value = value.split("·", 1)[0]
            headers.append({"label": label, "value": value.strip()})
    return headers


def _members(value: str) -> list[str]:
    # Strip balanced, possibly nested parentheticals BEFORE splitting commas.
    previous = None
    while value != previous:
        previous = value
        value = re.sub(r"\([^()]*\)", "", value)
    return [member.strip() for member in value.split(",")]


def resolve_member(name: str, participants: Mapping[str, Mapping[str, Any]],
                   retired=()) -> set[str]:
    """Current ids/labels first, then current holders of the named registry role."""
    name = name.strip()
    key = name.casefold()
    if not key or key in _BROADCAST:
        return set()
    # Match the store: a current exact ID survives an overlapping retired name.
    if name in retired and name not in participants:
        return set()
    names = resolve_id_or_label(name, participants)
    if names is not None:
        return names
    role = key.replace("_", " ")
    return {pid for pid, row in participants.items()
            if str(row.get("role") or "").replace("_", " ").casefold() == role}


def compare(text: str, envelope: Mapping[str, Any] | None, sender: str,
            recipients: list[str], participants: Mapping[str, Mapping[str, Any]],
            retired=()) -> dict[str, Any]:
    """Three-valued client verdict with stable evidence for the advisory gate."""
    typed = dict(envelope or {})
    headers = extract(text)
    refused, unresolved = [], []
    for header in headers:
        label, value = header["label"], header["value"]
        if label in {"RE", "AUTHORITY"}:
            field = label.lower()
            match = _AUTHORITY.match(value) if label == "AUTHORITY" else None
            prose = (match[1].casefold() if match else value.casefold()) if label == "AUTHORITY" else value
            twin = typed.get(field)
            if label == "AUTHORITY" and isinstance(twin, str):
                twin = twin.casefold()
            if field not in typed:
                refused.append(f"{label} has no typed twin")
            elif label == "AUTHORITY" and not match:
                refused.append("AUTHORITY is outside the v1 vocabulary")
            elif prose != twin:
                refused.append(f"{label} disagrees with the typed field")
        else:
            members = _members(value)
            resolved = set()
            for member in members:
                found = resolve_member(member, participants, retired)
                resolved.update(found)
                if not found:
                    unresolved.append(member)
            if label == "FROM" and len(members) != 1:
                refused.append("FROM must name exactly one identity or role")
            if resolved and ((label == "TO" and not resolved <= set(recipients)) or
                             (label == "FROM" and sender not in resolved)):
                refused.append(f"{label} disagrees with the bound message identities")
    verdict = "refused" if refused else "advisory" if unresolved else "clean"
    mentions = {name: resolve_member(name, participants, retired)
                for name in _MENTION.findall(text)}
    candidates = sorted({pid for found in mentions.values() for pid in found})
    return {
        "verdict": verdict, "reasons": refused,
        "labels_seen": [h["label"] for h in headers],
        "typed": {"from": sender, "to": list(recipients), "envelope": typed},
        "prose": headers, "candidates": candidates,
        "unresolved_members": list(dict.fromkeys(unresolved)),
        "unresolved_mentions": [name for name, found in mentions.items() if not found],
    }


def validate(text: str, envelope, sender: str, recipients: list[str]) -> dict[str, Any]:
    """CLI/HTTP entry point; refusal happens before either calls store.send."""
    import store
    return compare(text, envelope, sender, recipients,
                   store.load_participants(), store.load_aliases())


def advisory_checks(text: str, envelope, sender: str, recipients: list[str],
                    participants, retired=()) -> list[dict[str, Any]]:
    comparison = compare(text, envelope, sender, recipients, participants, retired)
    claims = (envelope or {}).get("claims_recipients", [])
    claims = claims if isinstance(claims, list) else []
    undeclared = set(comparison["candidates"]) - {c for c in claims if isinstance(c, str)}
    rows = []
    for row, flagged, reason in (
        ("prose-header-contradiction", comparison["verdict"] != "clean",
         "prose header compared with caller's unfilled envelope"),
        ("undeclared-mention", bool(undeclared),
         "mentions are candidates, not declared distribution claims"),
    ):
        evidence = {key: comparison[key] for key in
                    ("labels_seen", "typed", "prose", "candidates", "unresolved_members", "unresolved_mentions")}
        rows.append({"row": row, "result": "FLAG" if flagged else "PASS",
                     "disposition": "FLAG" if flagged else "PASS", "reason": reason,
                     **evidence})
    return rows
