"""Optional private-preview modules, without suppressing broken installations.

The public export omits these modules. An absent module is an unavailable
feature, never permission to bypass its registry or delivery validation.
"""
from importlib import import_module
from importlib.util import find_spec

MODULES = frozenset({
    'agy_bridge', 'agy_dispatch', 'agy_dispatch_status', 'agy_install', 'agy_recovery',
    'agy_runtime', 'agy_sidecar', 'agy_wake_route', 'codex_dispatch', 'codex_dispatch_status',
    'codex_ipc', 'codex_wake_route', 'codex_wake_state', 'inapp_dispatch',
    'inapp_dispatch_status', 'inapp_hookset', 'inapp_wake_route', 'claude_session_start', 'claude_startup_state',
    'inapp_install', 'account_usage_codex', 'wake_hook_agy', 'wake_hook_install_agy',
})


def available(name):
    if name not in MODULES:
        raise ValueError('unknown desktop preview module')
    return find_spec(name) is not None


def optional(name):
    if name not in MODULES:
        raise ValueError('unknown desktop preview module')
    if find_spec(name) is None:
        return None
    # A present module's own import failure always remains visible, including
    # an explicitly raised ModuleNotFoundError that names the module itself.
    return import_module(name)


def require(name):
    module = optional(name)
    if module is None:
        raise ValueError('desktop preview is not included in this installation')
    return module
