"""Private, bounded filesystem primitives shared by mail and legacy CLI kits.

No vendor launcher, settings renderer or credential lookup is imported here.
Error identifiers stay compatible with the existing callers.
"""
from contextlib import contextmanager
import json
import os
from pathlib import Path
import re
import stat
import uuid

LIMIT = 131072

def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True, allow_nan=False)+'\n').encode()


def canonical(value):
    path=Path(value)
    if (not path.is_absolute() or path.resolve()!=path
            or not re.fullmatch(r'[A-Za-z0-9_./-]+',str(path))):
        raise ValueError('cli_kit_path_unsupported')
    return path


@contextmanager
def directory(path, *, create=False):
    path=canonical(path)
    if create:path.mkdir(mode=0o700,parents=True,exist_ok=True)
    fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try:
        info=os.fstat(fd)
        if info.st_uid!=os.getuid() or info.st_mode&0o022:
            raise ValueError('cli_kit_directory_unsafe')
        yield fd
    finally:os.close(fd)


def read_at(fd,name):
    try:child=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=fd)
    except FileNotFoundError:return None
    with os.fdopen(child,'rb') as stream:
        info=os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid() or info.st_mode&0o022 or info.st_size>LIMIT:
            raise ValueError('cli_kit_file_unsafe')
        value=stream.read(LIMIT+1)
        if len(value)>LIMIT:raise ValueError('cli_kit_file_bound')
        return value


def publish(fd,name,data,before):
    if read_at(fd,name)!=before:raise ValueError('cli_kit_changed_since_read')
    temp='.kit-'+uuid.uuid4().hex
    child=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=fd)
    try:
        with os.fdopen(child,'wb') as stream:
            stream.write(data);stream.flush();os.fsync(stream.fileno())
        if read_at(fd,name)!=before:raise ValueError('cli_kit_changed_since_read')
        os.replace(temp,name,src_dir_fd=fd,dst_dir_fd=fd);os.fsync(fd)
    finally:
        try:os.unlink(temp,dir_fd=fd)
        except FileNotFoundError:pass
