"""Role-aware launch profiles for the retiring tmux agent path.

Behavioral contract (META_HARNESS_PLAN III.4 / audit T-0):

* Write access follows the durable seat role, never the vendor family.
* Only explicitly named coder seats receive a write-capable profile. Unknown
  seats fail closed to ``reviewer``.
* A coder profile may spawn only when that participant's durable role is
  already ``coder``; participant mutation is fenced through command activation.
  Launch is not an authority-promotion mechanism.
* Reviewer profiles use each vendor's native review mode. Claude plan mode
  denies shell commands; Gemini plan/approval mode is a prompt-level constraint,
  while mechanical Gemini read-only isolation uses a subagent with
  ``enable_write_tools=false``. Codex permits read-only shell verification
  inside its OS sandbox.
* Managed Claude reviewers and mechanically read-only Gemini subagents cannot
  independently execute test suites. Their executable evidence must come from
  exact-head CI/Bugbot. A review tier that requires a reviewer to run tests
  independently must use the read-only Codex profile or a reviewer outside the
  managed seat under a separately approved OS sandbox. A top-level Gemini seat
  may execute tests, but its plan/approval mode is prompt-only and does not
  itself satisfy mechanical read-only isolation. Test-command allowlists are
  not an escape hatch: invoking a test runner is arbitrary code execution and
  can write.
* An unsupported role/vendor combination refuses to launch. Adding a new coder
  or coder vendor therefore requires an explicit, reviewed contract change.

These launch flags are defense in depth for tmux seats. The governed runtime
policy at the SDK action seam remains the authoritative writer/reviewer control.
"""

from __future__ import annotations

from types import MappingProxyType
from typing import NamedTuple

CODER = "coder"
REVIEWER = "reviewer"

# No identity receives write authority from a shipped roster. This legacy tmux
# path is review-only by default; governed SDK launches use the durable role.
SEAT_TO_LAUNCH_ROLE = MappingProxyType({})

_REVIEWER_COMMANDS = MappingProxyType({
    "claude": (
        "CLAUDE_AUTOCOMPACT_PCT_OVERRIDE=80 "
        "claude --permission-mode plan"
    ),
    "gemini": "gemini --approval-mode plan",
    # `never` suppresses escalation prompts: attempts outside the read-only
    # sandbox fail instead. `--search` preserves public-data research without
    # granting command-level network access or workspace writes.
    "codex": "codex -s read-only -a never --search",
})

_CODER_COMMANDS = MappingProxyType({
    "codex": "codex -s workspace-write -a on-request",
})

SUPPORTED_AGENT_FAMILIES = frozenset(_REVIEWER_COMMANDS)


class LaunchProfile(NamedTuple):
    """A role and its inseparable vendor-native launch command."""

    role: str
    command: str


def launch_role_for_seat(participant_id: str) -> str:
    """Return a seat's launch role, defaulting unknown seats to reviewer."""
    return SEAT_TO_LAUNCH_ROLE.get(participant_id, REVIEWER)


def launch_profile_for_seat(participant_id: str, family: str) -> LaunchProfile:
    """Resolve the fixed role and command for ``participant_id`` and ``family``.

    The seat identity chooses the role; the vendor family only selects the
    native CLI expression for that role. Returning both values prevents a
    launcher from recording family-derived authority that contradicts the
    command it actually started. Missing combinations fail closed.
    """
    family_key = family.strip().lower()
    role = launch_role_for_seat(participant_id)
    commands = _CODER_COMMANDS if role == CODER else _REVIEWER_COMMANDS
    command = commands.get(family_key)
    if command is None:
        raise ValueError(
            f"no {role} launch profile for seat {participant_id!r} "
            f"with family {family_key!r}"
        )
    return LaunchProfile(role=role, command=command)


def launch_command_for_seat(participant_id: str, family: str) -> str:
    """Compatibility accessor for callers that only need the command."""
    return launch_profile_for_seat(participant_id, family).command


def coder_role_precondition_error(
        participant_id: str, profile: LaunchProfile,
        durable_participant: object) -> str | None:
    """Return a fail-closed reason when a coder spawn lacks durable authority.

    Reviewer launches may still repair legacy/missing reviewer metadata after
    readiness because they cannot increase authority. A write-capable launch
    must never do that: its durable role is a precondition, not a post-launch
    side effect.
    """
    if profile.role != CODER:
        return None
    participant = durable_participant if isinstance(durable_participant, dict) else {}
    durable_role = participant.get("role")
    if durable_role != CODER:
        return (
            f"coder launch for {participant_id!r} requires durable role "
            f"{CODER!r} before spawn; found {durable_role!r}"
        )
    return None
