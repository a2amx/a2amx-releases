"""R2 §6: read-only ledger selection; no cursor, receipt or delivery writes.

Product ownership of log.jsonl is append-only; no product writer rewrites the
current inode's prefix. In-place external edits are outside this contract.
Replacement/inode changes and observed shrinkage require a cold recount.
"""
from collections import defaultdict, deque
from datetime import datetime, timezone
import json
import hashlib
import os
import threading

import dialogue
import store

MAX_LOG_BYTES = 64 * 1024 * 1024
AUTHORITIES = ('decision', 'proposal', 'relay', 'FYI')


def change_token(selection, courier_directory):
    """Opaque validator from source metadata; never opens or parses the log."""
    def stamp(path, optional=False):
        try:
            from console_read_cache import file_token
            return file_token(path)
        except FileNotFoundError:
            if optional:
                return None
            raise
    # Registry changes can alter obsolete-notice visibility. Filters and
    # courier configuration are part of the represented snapshot as well.
    facts = ('console-ledger-v1', stamp(store.LOG_FILE),
             stamp(store.STORE_DIR / 'receipts.jsonl', optional=True),
             stamp(store.PARTICIPANTS_FILE, optional=True), selection,
             str(courier_directory) if courier_directory is not None else None)
    return 'W/"' + hashlib.sha256(json.dumps(facts, sort_keys=True).encode()).hexdigest() + '"'


class MessageSnapshot(list):
    """Retained records plus the measured extent of a read-only log snapshot."""

    def __init__(self, rows, snapshot):
        super().__init__(rows)
        self.snapshot = snapshot


_count_lock = threading.Lock()
_count_cache = None


def _observe_count_source(token):
    """Invalidate prefix history on observations that bypass prefix counting.

    A small/empty snapshot still observes replacement or shrinkage. Keeping a
    previous large-file count across that observation would mistake subsequent
    regrowth for an append to the old prefix. None records an unavailable source.
    """
    global _count_cache
    with _count_lock:
        cached = _count_cache
        if cached is not None and (
                token is None
                or cached['key'] != (str(store.LOG_FILE), *token[:2])
                or token[2] < cached['size']
                or (token[2] == cached['size'] and token[3] != cached['mtime'])):
            _count_cache = None


def _scan_records(stream, start, end):
    """Count complete nonblank records with a constant-size scratch buffer."""
    stream.seek(start)
    count, nonblank, remaining = 0, False, end - start
    while remaining:
        chunk = stream.read(min(64 * 1024, remaining))
        if not chunk:
            raise ValueError('ledger snapshot is incomplete')
        remaining -= len(chunk)
        parts = chunk.split(b'\n')
        for part in parts[:-1]:
            count += bool(nonblank or part.strip())
            nonblank = False
        nonblank = nonblank or bool(parts[-1].strip())
    if nonblank:
        raise ValueError('ledger snapshot is incomplete')
    return count


def _count_records(stream, end):
    """Share an incremental prefix count across this process's readers.

    The product appends to log.jsonl (store._append_message_log); it never
    rewrites the existing inode's prefix while growing it. Replacement,
    truncation and same-size edits invalidate this cache. A cold cache scans
    once; unchanged reads reuse it and growth counts only newly omitted bytes.
    Arbitrary same-inode prefix edits combined with growth are outside that
    append-only ownership contract. No index or cursor is written to the store.
    """
    global _count_cache
    with _count_lock:
        stat = os.fstat(stream.fileno())
        key = (str(store.LOG_FILE), stat.st_dev, stat.st_ino)
        cached = _count_cache
        usable = (cached and cached['key'] == key and end >= cached['end']
                  and stat.st_size >= cached['size']
                  and (stat.st_size > cached['size'] or stat.st_mtime_ns == cached['mtime']))
        start, count = (cached['end'], cached['count']) if usable else (0, 0)
        count += _scan_records(stream, start, end) if end > start else 0
        after = os.fstat(stream.fileno())
        if after.st_size < stat.st_size or (after.st_size == stat.st_size and after.st_mtime_ns != stat.st_mtime_ns):
            _count_cache = None
            raise ValueError('ledger changed during prefix count')
        _count_cache = {'key': key, 'end': end, 'count': count,
                        'size': after.st_size, 'mtime': after.st_mtime_ns}
        return count


def read_messages():
    from console_read_cache import read_snapshot
    try:
        cached = read_snapshot(store.LOG_FILE, max_bytes=MAX_LOG_BYTES)
    except OSError:
        _observe_count_source(None)
        raise
    if cached is not None:
        _observe_count_source(cached.token)
        rows = cached.strict_rows()
        participants = store.load_participants()
        visible = [row for row in rows if not store.obsolete_human_notice(row, participants)]
        return MessageSnapshot(visible, {
            'bytes': len(cached.data), 'retained_bytes': len(cached.data),
            'byte_limit': MAX_LOG_BYTES, 'records': len(rows), 'retained_records': len(rows),
            'omitted_records': 0, 'excluded_notices': len(rows) - len(visible), 'truncated': False,
            'scope': 'newest complete records by append position; omitted prefix counted, not parsed',
        })
    # Anchor the extent once; appends belong to the next snapshot. Retain only
    # whole records in the newest byte window. Count the omitted prefix using
    # bounded chunks so the UI can disclose exact physical-record coverage.
    with store.LOG_FILE.open('rb') as stream:
        initial = os.fstat(stream.fileno())
        _observe_count_source((initial.st_dev, initial.st_ino,
                               initial.st_size, initial.st_mtime_ns))
        size = initial.st_size
        start = max(0, size - MAX_LOG_BYTES)
        if start:
            stream.seek(start - 1)
            boundary = stream.read(1) == b'\n'
        else:
            boundary = True
        stream.seek(start)
        data = stream.read(size - start)
        if len(data) != size - start or (data and not data.endswith(b'\n')):
            raise ValueError('ledger snapshot is incomplete')
        if not boundary:
            split = data.find(b'\n') + 1
            start += split
            data = data[split:]
        omitted = _count_records(stream, start) if start else 0
        if start and not data.strip():
            raise ValueError('newest ledger record exceeds the snapshot byte limit')
        final = os.fstat(stream.fileno())
        named = store.LOG_FILE.stat()
        if ((named.st_dev, named.st_ino) != (initial.st_dev, initial.st_ino)
                or final.st_size < size
                or (final.st_size == size and final.st_mtime_ns != initial.st_mtime_ns)):
            raise ValueError('ledger replaced or rewritten during snapshot')
    lines = [line for line in data.split(b'\n') if line.strip()]
    rows = [json.loads(line) for line in lines]
    if any(not isinstance(row, dict) for row in rows):
        raise ValueError('ledger contains a non-object record')
    participants = store.load_participants()
    visible = [row for row in rows if not store.obsolete_human_notice(row, participants)]
    return MessageSnapshot(visible, {
        'bytes': size, 'retained_bytes': len(data), 'byte_limit': MAX_LOG_BYTES,
        'records': omitted + len(rows), 'retained_records': len(rows),
        'omitted_records': omitted, 'excluded_notices': len(rows) - len(visible),
        'truncated': start > 0,
        'scope': 'newest complete records by append position; omitted prefix counted, not parsed',
    })


def _text(value):
    return value if isinstance(value, str) and value else None


def project(message, position, *, recall_edges=None):
    import recall
    message = recall.project(message, edges=recall_edges)
    envelope = message.get('envelope')
    envelope = envelope if isinstance(envelope, dict) else {}
    recipients = message.get('recipients', message.get('to'))
    resolved = (isinstance(recipients, list) and bool(recipients)
                and all(dialogue._explicit_identity(item) for item in recipients))
    sender = message.get('from')
    sender = sender if dialogue._explicit_identity(sender) else None
    authority = envelope.get('authority')
    authority = authority if authority in AUTHORITIES else None
    vet = message.get('vet')
    checks = vet.get('checks', []) if isinstance(vet, dict) else []
    checks = checks if isinstance(checks, list) else []
    # Only the store's credential verifier can attest sender identity. In
    # particular, DROPPED audit rows retain caller-owned meta unchanged.
    identity_checks = [c for c in checks if isinstance(c, dict)
                       and c.get('row') == 'token-seat-identity']
    sender_source = 'recorded; authentication unclassified'
    if any(c.get('result') == 'FAIL' for c in identity_checks):
        sender_source = 'recorded; authentication rejected'
    elif (sender is not None and len(identity_checks) == 1
          and identity_checks[0].get('result') == 'PASS'
          and identity_checks[0].get('disposition') == 'PASS'):
        sender_source = 'authenticated record'
    return {**{k: message[k] for k in ('status', 'superseded_by', 'actionable', 'withdrawal_notices') if k in message},
            'id': _text(message.get('id')), 'position': position,
            'ts': _text(message.get('ts')), 'sender': sender,
            'sender_source': sender_source,
            'recipients': recipients if resolved else None,
            'recorded_destinations': message.get('to'),
            'recipients_source': ('recorded recipients' if 'recipients' in message else 'legacy explicit to') if resolved else 'unclassified',
            're': _text(envelope.get('re')), 'authority': authority,
            'lane': _text(message.get('lane')) or _text(envelope.get('lane')),
            'thread_id': _text(message.get('thread_id')) or _text(envelope.get('thread_id')),
            'reply_to': _text(message.get('reply_to')) or _text(envelope.get('reply_to')),
            'body': message.get('text') if isinstance(message.get('text'), str) else '',
            'body_source': ('derived supersession status' if message.get('actionable') is False
                            else 'literal recorded text' if isinstance(message.get('text'), str) else 'missing text')}


def _order(row):
    try:
        ts = datetime.fromisoformat(row['ts'].replace('Z', '+00:00'))
        if ts.tzinfo is None:
            raise ValueError('timezone unknown')
        stamp = ts.astimezone(timezone.utc).timestamp()
    except (AttributeError, TypeError, ValueError, OverflowError):
        stamp = float('-inf')
    return stamp, row['id'] or '', row['position']


RETIRED_SELECTION = 'the tuple and pair views and the seats parameter are retired: select senders with from= and recipients with to='


def _id_set(raw, option):
    """A comma-separated list of canonical participant ids; empty entries are ignored."""
    ids = {name.strip() for name in (raw or '').split(',') if name.strip()}
    if any(not dialogue._explicit_identity(name) for name in ids):
        raise ValueError(f'{option}: select explicit canonical participant ids')
    return ids


def select(messages, *, senders='', recipients='', view='all', participant=None, thread='', re_only='', lane='', authority='', limit=500):
    """Messages selected by the set of senders (from) and the set of recipients (to), intersected
    with every other filter. A message matches a non-empty from when its recorded sender is in the
    set, and a non-empty to when at least one typed recipient is; an empty set restricts nothing.
    A row whose sender or recipients are unresolved never matches a non-empty set; the unclassified
    view keeps it reachable."""
    if view in {'tuple', 'pair'}:
        raise ValueError(RETIRED_SELECTION)
    if view not in {'all', 'unclassified'}:
        raise ValueError('view must be all or unclassified')
    from_ids = _id_set(senders, 'from')
    to_ids = _id_set(recipients, 'to')
    if authority and authority not in {*AUTHORITIES, 'unclassified'}:
        raise ValueError('unknown authority filter')
    if not 1 <= limit <= 2000:
        raise ValueError('limit must be between 1 and 2000')
    participant_id = None
    if participant is not None:
        names = dialogue.resolve_names(participant, option='participant')
        if len(names) != 1:
            raise ValueError('participant must name exactly one seat')
        participant_id = next(iter(names))
    import recall
    recall_edges = recall.read_graph()
    rows = [project(message, i, recall_edges=recall_edges) for i, message in enumerate(messages)]
    # A known id is a registered participant or a party the ledger records, so every name the
    # pulldowns offer can be chosen and a mistyped one is refused.
    known = set(store.load_participants())
    for row in rows:
        if row['sender'] is not None:
            known.add(row['sender'])
        known.update(row['recipients'] or ())
    for option, ids in (('from', from_ids), ('to', to_ids)):
        unknown = sorted(ids - known)
        if unknown:
            raise ValueError(f'unknown participant id in {option}: {unknown[0]!r}')
    # Explicit graph only. RE similarity never creates a thread edge; RE-only
    # grouping is a separate, visibly named intersection filter.
    ids = {r['id'] for r in rows if r['id']}
    connected = {thread} if thread else set()
    if thread:
        edges = defaultdict(set)
        for row in rows:
            links = {x for x in (row['id'], row['reply_to'], row['thread_id']) if x}
            for link in links:
                edges[link].update(links - {link})
        queue = deque([thread])
        while queue:
            for link in edges[queue.popleft()] - connected:
                connected.add(link)
                queue.append(link)
    for row in rows:
        row['thread_source'] = ('recorded reply link' if row['reply_to'] in ids else 'missing reply target') if row['reply_to'] else (
            'recorded thread id' if row['thread_id'] else 'no recorded links; RE-only grouping is not a thread')
    def matches(row):
        # Use the same recorded addressing as /log, including explicit members
        # of an otherwise incomplete recipient set. Never infer from body text
        # or expand a legacy room/broadcast through today's registry.
        if participant_id is not None and not dialogue.matches(
                messages[row['position']], participant=participant_id):
            return False
        resolved = row['sender'] is not None and row['recipients'] is not None
        if (from_ids or to_ids) and not resolved:
            return False
        if from_ids and row['sender'] not in from_ids:
            return False
        if to_ids and not to_ids.intersection(row['recipients']):
            return False
        if view == 'unclassified' and resolved:
            return False
        if thread and not {x for x in (row['id'], row['reply_to'], row['thread_id']) if x} & connected:
            return False
        return ((not re_only or row['re'] == re_only)
                and (not lane or (row['lane'] is None if lane == 'unclassified' else row['lane'] == lane))
                and (not authority or (row['authority'] is None if authority == 'unclassified' else row['authority'] == authority)))
    kept = sorted((row for row in rows if matches(row)), key=_order, reverse=True)
    snapshot = getattr(messages, 'snapshot', None)
    return {'status': 'ok', 'source': 'message log; no mail consumed',
            'read_at': datetime.now(timezone.utc).isoformat(), 'total': len(rows),
            'matched': len(kept), 'shown': min(limit, len(kept)),
            'truncated': len(kept) > limit or bool(snapshot and snapshot['truncated']),
            'snapshot': snapshot,
            'selection': {'view': view, 'from': sorted(from_ids), 'to': sorted(to_ids), 'participant': participant_id, 'thread': thread,
                          're_only': re_only, 'lane': lane, 'authority': authority},
            'messages': kept[:limit]}
