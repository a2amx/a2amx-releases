"""Phase-A deterministic pre-delivery vetting (ORCH_SPEC_01 D-VET-1..3).

The execution-plane rules in this module inspect only store-owned facts.  The
governance-plane authority decision is supplied as a typed verdict from
``authority.verify``; this module records and mechanically applies its
``disposition`` without interpreting rights.
"""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any


PASS = "PASS"
DROP = "DROP"
QUARANTINE = "QUARANTINE"
FLAG = "FLAG"
_AUTHORITY = frozenset({"decision", "proposal", "relay", "FYI"})
_TRIAGE = frozenset({"skim", "engage"})
_RANK = {PASS: 0, FLAG: 1, QUARANTINE: 2, DROP: 3}


def prose_advisory_checks(message, caller_envelope, *, participants, retired=()):
    """D-CON-11: every store client is classified; prose never refuses here."""
    from message_headers import advisory_checks
    return advisory_checks(message.get("text", ""), caller_envelope,
                           message.get("from"), message.get("recipients", []),
                           participants, retired)



def _check(row: str, result: str, disposition: str, reason: str) -> dict[str, str]:
    return {"row": row, "result": result, "disposition": disposition, "reason": reason}


def _is_string_list(value: Any, *, allow_empty: bool = False) -> bool:
    return (isinstance(value, list) and (allow_empty or bool(value)) and
            all(isinstance(item, str) and bool(item.strip()) for item in value))


def _envelope_error(envelope: Any) -> str | None:
    if not isinstance(envelope, Mapping):
        return "envelope must be an object"
    if envelope.get("v") != 1:
        return "envelope.v must equal 1"
    if not isinstance(envelope.get("re"), str):
        return "envelope.re must be a string"
    if not isinstance(envelope.get("authority"), str) or envelope["authority"] not in _AUTHORITY:
        return "envelope.authority is outside the v1 vocabulary"
    if not isinstance(envelope.get("confirm"), bool):
        return "envelope.confirm must be boolean"
    if not isinstance(envelope.get("triage"), str) or envelope["triage"] not in _TRIAGE:
        return "envelope.triage must be skim or engage"
    bluf = envelope.get("bluf")
    if not isinstance(bluf, str) or len(bluf) > 280:
        return "envelope.bluf must be a string of at most 280 characters"
    if "ack" in envelope and not (
        isinstance(envelope["ack"], str) and envelope["ack"].strip()
    ):
        return "envelope.ack must be a non-empty message id"
    if "claims_recipients" in envelope and not _is_string_list(
        envelope["claims_recipients"], allow_empty=True
    ):
        return "envelope.claims_recipients must be a list of non-empty seat ids"
    return None


def deliverability_checks(
    message: Mapping[str, Any],
    *,
    participants: Mapping[str, Mapping[str, Any]],
    records_by_id: Mapping[str, Mapping[str, Any]],
    authenticated_sender: str | None,
) -> list[dict[str, str]]:
    """Return the deterministic D-VET-2(a) check rows for ``message``."""
    checks: list[dict[str, str]] = []
    envelope = message.get("envelope")
    error = _envelope_error(envelope)
    checks.append(_check(
        "envelope-v1", "FAIL" if error else "PASS", DROP if error else PASS,
        error or "v1 envelope schema is valid",
    ))

    recipients = message.get("recipients")
    recipient_error = None
    if not _is_string_list(recipients):
        recipient_error = "recipient set must be a non-empty list of seat ids"
    else:
        missing = sorted(set(recipients) - set(participants))
        if missing:
            recipient_error = "unknown recipients: " + ", ".join(missing)
    checks.append(_check(
        "recipients-exist-nonempty", "FAIL" if recipient_error else "PASS",
        DROP if recipient_error else PASS,
        recipient_error or "all recipients exist and the set is non-empty",
    ))

    sender = message.get("from")
    identity_error = None
    if not isinstance(sender, str) or not sender.strip():
        identity_error = "sender must be a non-empty seat id"
    elif authenticated_sender != sender:
        identity_error = "token-bound seat does not match message sender"
    elif sender not in participants and sender != "System":
        identity_error = "token-bound sender has no participant record"
    checks.append(_check(
        "token-seat-identity", "FAIL" if identity_error else "PASS",
        DROP if identity_error else PASS,
        identity_error or "message sender matches the token-bound seat",
    ))

    if isinstance(envelope, Mapping) and "claims_recipients" in envelope:
        claims = envelope.get("claims_recipients")
        claims_error = None
        if not _is_string_list(claims, allow_empty=True) or not _is_string_list(recipients):
            claims_error = "recipient claims and recipients must be typed seat-id lists"
        else:
            extra = sorted(set(claims) - set(recipients))
            if extra:
                claims_error = "claimed recipients not in to: " + ", ".join(extra)
        checks.append(_check(
            "claims-recipients-subset", "FAIL" if claims_error else "PASS",
            DROP if claims_error else PASS,
            claims_error or "claims_recipients is a subset of to",
        ))
    else:
        checks.append(_check("claims-recipients-subset", "PASS", PASS,
                             "no typed distribution claim"))

    ack = envelope.get("ack") if isinstance(envelope, Mapping) else None
    ack_error = None
    if ack is not None:
        referenced = records_by_id.get(str(ack))
        if referenced is None:
            ack_error = "ack references an unknown message id"
        else:
            referenced_envelope = referenced.get("envelope")
            if not isinstance(referenced_envelope, Mapping) or \
                    referenced_envelope.get("confirm") is not True:
                ack_error = "unsolicited typed ack: referenced message confirm=false"
    checks.append(_check(
        "typed-ack-solicited", "FAIL" if ack_error else "PASS",
        DROP if ack_error else PASS,
        ack_error or ("referenced message requested confirmation" if ack else "no typed ack"),
    ))

    cites = message.get("cites", [])
    cite_error = None
    advisory: list[str] = []
    if not isinstance(cites, list):
        cite_error = "cites must be a list"
    else:
        missing = []
        for cite in cites:
            if not isinstance(cite, str) or not cite.strip():
                cite_error = "cites entries must be non-empty strings"
                break
            if cite.startswith("msg-") and cite not in records_by_id:
                missing.append(cite)
            elif not cite.startswith("msg-"):
                advisory.append(cite)
        if missing:
            cite_error = "unknown cited message ids: " + ", ".join(sorted(missing))
    checks.append(_check(
        "cited-message-existence", "FAIL" if cite_error else "PASS",
        DROP if cite_error else PASS,
        cite_error or "all cited message ids exist",
    ))
    if isinstance(cites, list):
        import recall
        recalled = [cite for cite in cites if isinstance(cite, str) and cite in recall.graph()]
        if recalled:
            checks.append(_check('recalled-citation', 'FLAG', FLAG,
                                 'ADVISORY: cited message was recalled or withdrawn: ' + ', '.join(recalled)))
    if advisory:
        checks.append(_check(
            "external-locator-resolution", "FLAG", FLAG,
            "external locator support/resolution is advisory in Phase A: " +
            ", ".join(advisory),
        ))
    return checks


def duplicate_delta_check(
    message: Mapping[str, Any], recent: Sequence[Mapping[str, Any]], *,
    min_chars: int,
) -> dict[str, str]:
    """Preserve the existing normalized self-duplicate rule and disposition."""
    if message.get("kind") == "system":
        return _check("duplicate-delta", "PASS", PASS, "system record is delta-exempt")
    if is_typed_interrupt_control(message):
        return _check(
            "duplicate-delta", "PASS", PASS,
            "authenticated typed interrupt control is delta-exempt",
        )
    import norms
    verdict = norms.check(dict(message), [dict(record) for record in recent],
                          min_chars=min_chars)
    if verdict is None:
        return _check("duplicate-delta", "PASS", PASS,
                      "message has a substantive delta or is below the threshold")
    return _check("duplicate-delta", "FAIL", QUARANTINE, verdict["reason"])


def is_typed_interrupt_control(message: Mapping[str, Any]) -> bool:
    """Recognize only the canonical, single-recipient interrupt representation."""
    meta = message.get("meta")
    control = meta.get("control") if isinstance(meta, Mapping) else None
    recipients = message.get("recipients")
    return bool(
        message.get("kind") == "control"
        and isinstance(control, Mapping)
        and set(control) == {"type", "target"}
        and control.get("type") == "interrupt"
        and isinstance(control.get("target"), str)
        and bool(control["target"].strip())
        and recipients == [control["target"]]
    )


def result(checks: Sequence[Mapping[str, str]]) -> dict[str, Any]:
    """Build the stable in-record vet result, applying supplied dispositions verbatim."""
    decisive = max(checks, key=lambda item: _RANK[item["disposition"]], default={
        "disposition": PASS,
    })
    disposition = decisive["disposition"]
    # FLAG is non-blocking: retain it in checks while the record itself passes.
    verdict = {PASS: PASS, FLAG: PASS, QUARANTINE: "QUARANTINED", DROP: "DROPPED"}[disposition]
    return {
        "verdict": verdict,
        "disposition": disposition,
        "reason": decisive.get("reason", "passed"),
        "checks": [dict(item) for item in checks],
    }
