"""Read-only Phase A seat panel producer.

Every value is accompanied by its evidence class.  Runtime observations are
made afresh for each build; no liveness result is persisted or cached.
"""

from __future__ import annotations

import os
import time
from datetime import datetime, timezone
from typing import Any, Callable, Mapping

import receipts
import store
from provision import seat_help
from seat_socket import registered_session, registered_socket
from tmux_bridge import TmuxResult, _run_tmux

DECLARED = "DECLARED"
RUNTIME_VERIFIED = "RUNTIME-VERIFIED"
UNMEASURABLE = "UNMEASURABLE"
WAKE_ADAPTER_PROBE_STATES = frozenset({"reachable", "unreachable"})
PANEL_SEAT_FIELDS = (
    "seat", "vendor_family", "model", "effort", "context_window",
    "workspace_dir", "account", "hosting_kind", "liveness", "pane_state",
    "wake_adapter_status", "last_successful_wake", "pending_count",
    "token_status", "help_status", "help_remedy", "poll_interval_seconds", "staleness_seconds",
)


def _field(value: Any, source: str, *, measured_at: str | None = None,
           detail: str | None = None) -> dict[str, Any]:
    field = {"value": value, "source": source}
    if measured_at is not None:
        field["measured_at"] = measured_at
    if detail is not None:
        field["detail"] = detail
    return field


def _process_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except (OSError, ValueError):
        return False
    return True


def _tmux_liveness(seat: str, registry: Mapping[str, Mapping[str, Any]], measured_at: str,
                   tmux_runner: Callable[..., TmuxResult],
                   process_alive: Callable[[int], bool]) -> dict[str, Any]:
    participant = registry[seat]
    try:
        socket = registered_socket(seat, registry)
        session = registered_session(participant)
    except (OSError, RuntimeError, ValueError) as exc:
        return _field("down", RUNTIME_VERIFIED, measured_at=measured_at,
                      detail=f"registered private target refused: {exc}")
    session_result = tmux_runner("-S", socket, "has-session", "-t", session)
    if not session_result.ok:
        return _field("down", RUNTIME_VERIFIED, measured_at=measured_at,
                      detail="registered private session absent")
    pane_result = tmux_runner(
        "-S", socket, "display-message", "-p", "-t", session, "#{pane_pid}")
    try:
        pane_pid = int(pane_result.stdout)
        pane_alive = pane_result.ok and pane_pid > 0 and process_alive(pane_pid)
    except (TypeError, ValueError):
        pane_alive = False
    return _field("live" if pane_alive else "down", RUNTIME_VERIFIED,
                  measured_at=measured_at,
                  detail="private has-session AND pane process alive")


def _last_successful_wakes(rows: list[dict[str, Any]]) -> dict[str, str]:
    pre_by_event = {row.get("event-id"): row for row in rows
                    if row.get("kind") == "nudge" and row.get("phase") == "pre"}
    found: dict[str, str] = {}
    for row in rows:
        if (row.get("kind") != "nudge" or row.get("phase") != "post"
                or row.get("result") != "success"):
            continue
        pre = pre_by_event.get(row.get("event-id"), {})
        seat = pre.get("target seat")
        timestamp = row.get("ts")
        if isinstance(seat, str) and isinstance(timestamp, str):
            found[seat] = timestamp
    return found


def _token_status(seat: str) -> str:
    session_states = [
        record.get("state")
        for record in store.seat_token_records(seat)
        if record.get("kind") == "session"
    ]
    if "active" in session_states:
        return "active"
    return str(session_states[0]) if session_states else "none"


def _token_expiry(seat: str) -> str:
    records = store.seat_token_records(seat)
    return "; ".join(f"{rec.get('surface')}: expires_in_seconds={rec.get('expires_in_seconds')}"
                     for rec in records if rec.get("kind") == "session" and rec.get("state") == "active")



def _agy_wake_status(seat: str, route: dict[str, Any]) -> dict[str, Any]:
    from desktop_support import optional
    agy_dispatch_status = optional('agy_dispatch_status')
    if agy_dispatch_status is None:
        return _field('unavailable', DECLARED, detail='desktop preview is not included')
    status = agy_dispatch_status.read()
    if not status:
        return _field("unprobed", DECLARED, detail="no valid wake-adapter probe observation (state=missing)")
        
    if status.get("state") != "enabled":
        return _field("unprobed", RUNTIME_VERIFIED, detail=f"dispatcher state is {status.get('state')}")
        
    if status.get("fault"):
        return _field("unprobed", RUNTIME_VERIFIED, detail=f"dispatcher faulted: {status.get('fault')}")
    
    seat_status = status.get("seats", {}).get(seat)
    if not seat_status:
        return _field("unprobed", RUNTIME_VERIFIED, detail="seat absent from agy-dispatch snapshot")
        
    if seat_status.get("route") != route:
        return _field("unprobed", RUNTIME_VERIFIED, detail="stale route in snapshot")
        
    reason = seat_status.get("reason", "")
    detail = ("stored daemon observation, not process liveness: " + reason
              + "; fetch deadline pre+15min; recovery uncertain+15min; exit terminal first-uncertain+30min")
    if reason in {"held_sidecar_silent", "held_uncertain"}:
        agy_wake_route = optional('agy_wake_route')
        if agy_wake_route is None:
            return _field('unavailable', DECLARED, detail='desktop preview is not included')
        generation = agy_wake_route.generation(route)
        holds = [r for r in receipts.rows() if r.get('kind') == 'wake_route_hold'
                 and r.get('seat') == seat and r.get('generation') == generation]
        hold = holds[-1] if holds and reason == 'held_sidecar_silent' else {}
        count = hold.get('attempt_count', 0)
        return {**_field('unreachable' if count >= 5 else 'held', RUNTIME_VERIFIED,
                         measured_at=status.get('ts'), detail=detail),
                'attempt_count': count, 'retry_at': hold.get('retry_at'),
                'remedy': 'inspect sidecar installation; declaration is explicit'}
    if reason in {"awaiting_hook", "awaiting_sidecar", "awaiting_fetch_or_sidecar"}:
        return _field('unprobed', RUNTIME_VERIFIED, measured_at=status.get('ts'), detail=detail)
    if seat_status.get('ok'):
        # A historical success or empty queue never establishes current reachability.
        return _field('declared', RUNTIME_VERIFIED, measured_at=status.get('ts'), detail=detail)
    if reason.startswith('wake_route_dead') or reason == 'retry_scheduled':
        return _field('dead', RUNTIME_VERIFIED, measured_at=status.get('ts'), detail=detail)
    return _field('unreachable', RUNTIME_VERIFIED, measured_at=status.get('ts'), detail=detail)

def _wake_adapter_status(participant: Mapping[str, Any]) -> dict[str, Any]:

    if (store.normalize_family(participant.get("family")) == "codex"
            and participant.get("hosting_kind") != "tmux-hosted"
            and participant.get("wake_route") is None):
        return _field("undeclared", DECLARED, detail="no Codex wake route declared")
    if (store.normalize_family(participant.get('family')) == 'claude'
            and participant.get('hosting_kind') == 'in-app' and participant.get('wake_route') is None):
        return _field('undeclared', DECLARED, detail='no Claude wake route declared')
    state = participant.get("adapter_probe_state")
    measured_at = participant.get("measured_at")
    timestamp_valid = False
    if isinstance(measured_at, str) and measured_at.strip():
        try:
            parsed = datetime.fromisoformat(measured_at)
            timestamp_valid = parsed.tzinfo is not None and parsed.utcoffset() is not None
        except ValueError:
            pass
    if state not in WAKE_ADAPTER_PROBE_STATES or not timestamp_valid:
        state_detail = state if isinstance(state, str) and state else "missing"
        return _field("unprobed", UNMEASURABLE,
                      detail=f"no valid wake-adapter probe observation (state={state_detail})")
    return _field("probed", RUNTIME_VERIFIED, measured_at=measured_at,
                  detail=str(state))


def _codex_wake_status(seat, route):
    from desktop_support import optional
    codex_dispatch = optional('codex_dispatch')
    if codex_dispatch is None:
        return _field('unavailable', DECLARED, detail='desktop preview is not included')
    try:
        observed = codex_dispatch.observation_fields(seat, route)
        state, detail, timestamp = observed["state"], observed["detail"], observed["timestamp"]
    except (OSError, ValueError, KeyError, TypeError):
        return _field("unknown", UNMEASURABLE, detail="Codex route or receipt history unreadable")
    return {**_field(state, RUNTIME_VERIFIED if timestamp else UNMEASURABLE, measured_at=timestamp,
                     detail="stored receipt/daemon observation, not process liveness: " + detail),
            **{key: observed[key] for key in ("attempt_count", "retry_at", "remedy", "requires_requalification", "receipt_evidence")}}


def _inapp_wake_status(seat, route):
    from desktop_support import available
    if not available('inapp_dispatch_status'):
        return _field('unavailable', DECLARED, detail='desktop preview is not included')
    import wake_hook_observation
    try:
        evidence = []
        state, detail, timestamp = wake_hook_observation.inapp_status(seat, route, evidence=evidence)
        return {**_field(state, RUNTIME_VERIFIED if timestamp else UNMEASURABLE,
                      measured_at=timestamp, detail=detail + '; stored observation, not process liveness'),
                'receipt_evidence': evidence}
    except (OSError, ValueError, KeyError, TypeError):
        return _field('unknown', UNMEASURABLE, detail='Claude route or receipt history unreadable')


def non_tmux_liveness():
    return _field(None, UNMEASURABLE,
                  detail="no Phase A runtime probe for this hosting kind")


def _pane_state(seat, registry, observations, clock):
    from pane_state_adapter import binding
    from pane_state import reset_description
    unknown = _field("unknown", UNMEASURABLE, detail="no fresh matching daemon observation")
    if registry[seat].get("hosting_kind") != "tmux-hosted":
        return _field(None, UNMEASURABLE, detail="not a terminal-hosted seat")
    try:
        key = binding(seat, registry)
        row = next((r for r in observations if r["seat"] == seat and r["binding"] == key), None)
        if not row:
            return unknown
        now = time.monotonic()
        age, duration = now - row["measured_at"], now - row["changed_at"]
        from pane_state_socket import MAX_AGE
        if age < 0 or age >= MAX_AGE or duration < age:
            return unknown
        wall = clock().timestamp()
        measured = datetime.fromtimestamp(wall - age, timezone.utc).isoformat()
        changed = datetime.fromtimestamp(wall - duration, timezone.utc).isoformat()
        reset = row.get("reset_time")
        suffix = reset_description(reset)
        detail = f"unchanged for {int(duration)}s; " + (
            "live state unconfirmed" if row["class"] == "unknown" else "bounded input-region match")
        if suffix:
            detail += "; " + suffix
        return {**_field(row["class"], RUNTIME_VERIFIED if row["class"] != "unknown" else UNMEASURABLE,
                         measured_at=measured, detail=detail),
                "changed_at": changed, "since_seconds": int(duration), "reset_time": reset}
    except (OSError, ValueError, TypeError, KeyError, OverflowError):
        return unknown


def build(*, participants: Mapping[str, Mapping[str, Any]] | None = None,
          tmux_runner: Callable[..., TmuxResult] = _run_tmux,
          process_alive: Callable[[int], bool] = _process_alive,
          liveness_probe: Callable[..., dict[str, Any]] | None = None,
          now: Callable[[], datetime] | None = None) -> dict[str, Any]:
    """Build one uncached, fully labeled panel snapshot."""
    clock = now or (lambda: datetime.now(timezone.utc))
    measured_at = clock().astimezone(timezone.utc).isoformat()
    registry = participants if participants is not None else store.load_participants()
    import pane_state_socket
    # One bounded IPC read per build, independent of seat count; never capture here.
    pane_observations = pane_state_socket.read() if any(
        row.get("hosting_kind") == "tmux-hosted" for row in registry.values()) else []
    receipt_rows = receipts.rows()
    wakes = _last_successful_wakes(receipt_rows)
    # D-GOV-2 (f) §3.9: the focus field exists once the feature was switched on;
    # before that the panel is byte-for-byte what it was.
    import focus
    focus_view = focus.status_view()
    seats = []
    for seat in sorted(registry):
        participant = registry[seat]
        if store.inactive_participant(participant) or not store.has_mailbox(participant):
            continue
        hosting = participant.get("hosting_kind")
        if hosting == "tmux-hosted":
            liveness = (liveness_probe(seat, registry, measured_at) if liveness_probe
                        else _tmux_liveness(seat, registry, measured_at, tmux_runner, process_alive))
        else:
            liveness = non_tmux_liveness()
        pending = len(receipts.pending_message_ids(seat))
        wake = wakes.get(seat)
        model = participant.get("recorded_model")
        help_state = seat_help.panel_state(receipt_rows, seat)
        help_source = RUNTIME_VERIFIED if help_state["ts"] else UNMEASURABLE
        # An observed local startup report is attributed, not native health.
        # Keep an existing operator-help request ahead of startup diagnostics.
        if not help_state["ts"] or help_state['state'] == 'clear':
            from desktop_support import optional
            startup = optional('claude_startup_state')
            state = startup.panel_state(receipt_rows, seat, participant) if startup else None
            if state:
                help_state, help_source = state, DECLARED
        seats.append({
            "seat": _field(seat, DECLARED),
            "vendor_family": _field(participant.get("family"), DECLARED),
            "model": (_field(model, DECLARED, detail="registry recorded_model; not runtime verification") if model is not None
                      else _field(None, UNMEASURABLE,
                                  detail="no recorded model; provisioner must record it")),
            "effort": _field(participant.get("effort"), DECLARED),
            "context_window": _field(participant.get("context_window"), DECLARED),
            "workspace_dir": _field(participant.get("workspace_dir"), DECLARED),
            "account": _field(participant.get("account"), DECLARED),
            "hosting_kind": _field(hosting, DECLARED),
            "liveness": liveness,
            "pane_state": _pane_state(seat, registry, pane_observations, clock),
            "wake_adapter_status": (_inapp_wake_status(seat, participant["wake_route"])
                                    if isinstance(participant.get("wake_route"), dict)
                                    and participant["wake_route"].get("kind") == "inapp-socket"
                                    else _codex_wake_status(seat, participant["wake_route"])
                                    if isinstance(participant.get("wake_route"), dict)
                                    and participant["wake_route"].get("kind") == "codex-ipc"
                                    else _agy_wake_status(seat, participant["wake_route"])
                                    if isinstance(participant.get("wake_route"), dict)
                                    and participant["wake_route"].get("kind") == "agy-desktop"
                                    else _wake_adapter_status(participant)),
            "last_successful_wake": (_field(wake, RUNTIME_VERIFIED, measured_at=measured_at)
                                     if wake else _field(None, UNMEASURABLE,
                                                         detail="no successful receipt")),
            "pending_count": _field(pending, RUNTIME_VERIFIED, measured_at=measured_at),
            "token_status": _field(_token_status(seat), RUNTIME_VERIFIED,
                                   measured_at=measured_at, detail=_token_expiry(seat)),
            "help_status": _field(help_state["state"], help_source,
                                  measured_at=help_state["ts"], detail=help_state["reason"]),
            "help_remedy": _field(help_state.get("remedy"), help_source,
                                  measured_at=help_state["ts"]),
            "poll_interval_seconds": _field(participant.get("panel_poll_interval"), DECLARED),
            "staleness_seconds": _field(0, RUNTIME_VERIFIED, measured_at=measured_at),
        })
        if focus_view is not None:
            seats[-1]["focus"] = _field(focus.panel_field(seat, focus_view), RUNTIME_VERIFIED,
                                        measured_at=measured_at,
                                        detail=None if focus_view.get("state") == "active"
                                        else focus_view.get("state"))
    return {"measured_at": measured_at, "seats": seats,
            "retired_count": sum(bool(row.get("retired_at")) for row in registry.values())}
