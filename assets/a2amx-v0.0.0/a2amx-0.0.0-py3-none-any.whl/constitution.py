"""Versioned governance constitution — the TUNABLE knobs a governed mutation may adjust, and the
UNTOUCHABLE invariants a mutation may never weaken (META_HARNESS_PLAN Stage 4, §3.5).

The constitution externalizes the numeric governance knobs (burn-guard caps, norm thresholds,
referee sensitivity) so the PEV mutation gate (commit 4b) can tune them instead of them being
hard-coded. Reading is cheap + cached; a mutation rewrites constitution.json and takes effect on
the next process start. ``validate()`` holds the guardrails self-improvement can never cross — a
proposed constitution that would disarm a core governor is REJECTED, so the system can tune its
governor but never disable it. A leaf module: imports nothing from store/ledger (no cycles)."""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any, Dict, List

_PATH = Path(__file__).resolve().parent / "constitution.json"


def _effective_path() -> Path:
    """The constitution file in effect: ``PSQR_CONSTITUTION`` if set (a sandbox for the mutation
    gate / tests), else the repo's constitution.json."""
    override = os.environ.get("PSQR_CONSTITUTION")
    return Path(override) if override else _PATH

#: The shipped defaults — also the fallback when constitution.json is missing/unreadable, and the
#: baseline a partial proposed diff is merged over.
DEFAULTS: Dict[str, Any] = {
    "version": 1,
    "burn_guard": {
        "max_consecutive": 8, "max_per_window": 20,
        "description": "The consecutive counter resets when the recipient set differs from the sender's previous message; "
                       "eight consecutive messages to the same recipients still trip the guard, "
                       "and the rolling limit remains twenty messages per sixty seconds.",
    },
    "norms": {"enabled": True, "delta_window_sec": 300, "min_delta_chars": 40},
    "referee": {"similarity_flag": 0.6, "min_tokens": 6},
    # G0 approval surface (STAGE3 §2). policy_rules are OPERATOR-ADOPTED — each
    # rule requires explicit operator adoption. validate() refuses rules that could authorize
    # privileged kinds — the policy tier can widen convenience, never authority.
    "approvals": {
        "ttl_sec": 1800,            # pending-item lifetime (G0.3 auto-deny)
        "breaker_threshold": 3,     # identical re-asks after a timeout-deny (G0.4)
        "policy_rules": [
            {"id": "read-only-classifier",
             "type": "effect_kind",
             "effect_kinds": ["read"],
             "description": "classifier-proven read-only tool calls auto-approve "
                            "with a per-action ledger receipt"},
        ],
    },
}

#: CLOSED policy-rule type/kind matrix (reviewer #55 HIGH: forbidden-kind
#: blacklisting still let a mis-adopted {effect_kind: [shell]} rule auto-approve
#: every shell command). Convenience must not be able to become authority even
#: through a bad adoption: each rule TYPE names the only kinds it may govern,
#: and effect_kind rules are limited to intrinsically safe classifier verdicts.
POLICY_RULE_TYPE_MATRIX: Dict[str, frozenset] = {
    "effect_kind": frozenset({"read"}),   # intrinsically safe kinds ONLY
    "gh_api_get": frozenset({"shell"}),   # shell, but only via the closed grammar
}

#: Safe floor: the burn guard can be TUNED but never disabled (caps must stay real).
BURN_FLOOR = 1

_cache: Dict[str, Any] = {}


def _deep_merge(base: Dict[str, Any], over: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(base)
    for k, v in (over or {}).items():
        out[k] = _deep_merge(out[k], v) if isinstance(out.get(k), dict) and isinstance(v, dict) else v
    return out


def load(path: Path | None = None) -> Dict[str, Any]:
    """The effective constitution = constitution.json merged over DEFAULTS (missing keys fall
    back). Never raises — a missing/broken file yields DEFAULTS. The live file is cached; pass an
    explicit ``path`` to read uncached (tests / the mutation sandbox)."""
    if path is not None:
        try:
            return _deep_merge(DEFAULTS, json.loads(Path(path).read_text()))
        except (OSError, ValueError):
            return dict(DEFAULTS)
    if not _cache:
        try:
            _cache.update(_deep_merge(DEFAULTS, json.loads(_effective_path().read_text())))
        except (OSError, ValueError):
            _cache.update(DEFAULTS)
    return _cache


def merge(over: Dict[str, Any]) -> Dict[str, Any]:
    """The current effective constitution with ``over`` merged on top — so a PARTIAL proposal
    becomes a complete constitution (no dropped sections). Does not save; the mutation gate
    validates + gates first."""
    return _deep_merge(load(), over)


def stage(new_constitution: Dict[str, Any]) -> Path:
    """Write ``new_constitution`` to a temp file NEXT TO the effective path (same dir/device) and
    return it — the FAILURE-PRONE step (disk full / permissions). Does not touch the live file, so
    the mutation gate can run this BEFORE consuming the single-use human-Z token (Bugbot PR #40)."""
    target = _effective_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(target.parent), prefix=".constitution.", suffix=".tmp")
    with os.fdopen(fd, "w") as f:
        f.write(json.dumps(new_constitution, indent=2) + "\n")
    return Path(tmp)


def commit(staged: Path) -> None:
    """Atomically replace the effective constitution with a staged temp file and clear the cache.
    The near-infallible step (os.replace, same directory) — run AFTER the human-Z token is consumed
    so a burned token always corresponds to a landed mutation."""
    os.replace(str(staged), str(_effective_path()))
    _cache.clear()


def save(new_constitution: Dict[str, Any]) -> None:
    """Atomic write of the effective constitution (stage + commit) + cache clear. Convenience for
    tests/seeding; the mutation gate splits stage/commit around the token consume."""
    commit(stage(new_constitution))


def value(dotted: str, default: Any = None) -> Any:
    """Dotted-path read, e.g. ``value("norms.delta_window_sec")``."""
    node: Any = load()
    for part in dotted.split("."):
        if not isinstance(node, dict) or part not in node:
            return default
        node = node[part]
    return node


def validate(proposed: Dict[str, Any]) -> List[str]:
    """UNTOUCHABLE invariants — return the list of violations (empty == acceptable). A proposed
    constitution that weakens a core governor is rejected by the mutation gate (commit 4b):
      - burn-guard caps stay ints >= BURN_FLOOR (loop protection can be tuned, never disabled);
      - norm thresholds are non-negative ints; referee.similarity_flag in [0,1]; min_tokens >= 1;
      - no core governor (zgate / burn_guard / policy) may carry an ``enabled: false`` flag."""
    v: List[str] = []
    p = proposed or {}

    # A core section present but not an object is an ERASURE (e.g. burn_guard: null) — reject it
    # rather than silently treating it as {} + DEFAULTS, which would persist a governor-less file.
    for section in ("burn_guard", "norms", "referee"):
        if section in p and not isinstance(p[section], dict):
            v.append(f"{section} must be an object, not {type(p[section]).__name__} "
                     "— erasing a governor section is untouchable-without-human")

    bg = p.get("burn_guard", {}) if isinstance(p.get("burn_guard"), dict) else {}
    for k in ("max_consecutive", "max_per_window"):
        val = bg.get(k, DEFAULTS["burn_guard"][k])
        if not isinstance(val, int) or isinstance(val, bool) or val < BURN_FLOOR:
            v.append(f"burn_guard.{k} must be an int >= {BURN_FLOOR} "
                     f"(the burn guard is untouchable-without-human), got {val!r}")

    nr = p.get("norms", {}) if isinstance(p.get("norms"), dict) else {}
    enabled = nr.get("enabled", DEFAULTS["norms"]["enabled"])
    if not isinstance(enabled, bool):
        v.append(f"norms.enabled must be boolean, got {enabled!r}")
    for k in ("delta_window_sec", "min_delta_chars"):
        val = nr.get(k, DEFAULTS["norms"][k])
        if not isinstance(val, int) or isinstance(val, bool) or val < 0:
            v.append(f"norms.{k} must be a non-negative int, got {val!r}")

    rf = p.get("referee", {}) if isinstance(p.get("referee"), dict) else {}
    sim = rf.get("similarity_flag", DEFAULTS["referee"]["similarity_flag"])
    if not isinstance(sim, (int, float)) or isinstance(sim, bool) or not (0.0 <= float(sim) <= 1.0):
        v.append(f"referee.similarity_flag must be a number in [0,1], got {sim!r}")
    mt = rf.get("min_tokens", DEFAULTS["referee"]["min_tokens"])
    if not isinstance(mt, int) or isinstance(mt, bool) or mt < 1:
        v.append(f"referee.min_tokens must be an int >= 1, got {mt!r}")

    for gov in ("zgate", "burn_guard", "policy", "approvals"):
        sec = p.get(gov)
        if isinstance(sec, dict) and sec.get("enabled") is False:
            v.append(f"{gov}.enabled cannot be set false — core governors are untouchable-without-human")

    # G0 policy tier: auto-approval rules can widen CONVENIENCE, never AUTHORITY.
    # A rule naming a privileged kind (merge/push/history/network/write/edit) or a
    # non-list kinds field is rejected — the operator gate and the Z-gate stay the
    # only paths to those effects, no matter what a mutation proposes.
    ap = p.get("approvals", {}) if isinstance(p.get("approvals"), dict) else {}
    if "approvals" in p and not isinstance(p["approvals"], dict):
        v.append("approvals must be an object — erasing the approval governor is "
                 "untouchable-without-human")
    rules = ap.get("policy_rules")
    if "policy_rules" in ap and rules is not None and not isinstance(rules, list):
        v.append("approvals.policy_rules must be a list (or null to disable the tier)")
        rules = []
    for rule in (rules if isinstance(rules, list) else []):
        if not isinstance(rule, dict):
            v.append(f"approvals.policy_rules entries must be objects, got {type(rule).__name__}")
            continue
        rid = rule.get("id", "?")
        rtype = rule.get("type")
        allowed_kinds = POLICY_RULE_TYPE_MATRIX.get(rtype)
        if allowed_kinds is None:
            v.append(f"policy rule {rid!r} has unknown type {rtype!r} — the "
                     f"type/kind matrix is closed ({sorted(POLICY_RULE_TYPE_MATRIX)})")
            continue
        kinds = rule.get("effect_kinds")
        if not isinstance(kinds, list) or not kinds \
                or not all(isinstance(k, str) for k in kinds):
            v.append(f"policy rule {rid!r} must list explicit string effect_kinds")
            continue
        bad = sorted(set(kinds) - allowed_kinds)
        if bad:
            v.append(f"policy rule {rid!r} (type {rtype!r}) may not govern kinds "
                     f"{bad} — allowed: {sorted(allowed_kinds)}; authority is "
                     "untouchable-without-human")
        if rtype == "gh_api_get":
            prefixes = rule.get("path_prefixes")
            if not isinstance(prefixes, list) or not prefixes \
                    or not all(isinstance(p, str) and p.endswith("/") and "/" in p.rstrip("/")
                               for p in prefixes):
                v.append(f"policy rule {rid!r} needs non-empty string path_prefixes, "
                         "each an org-scoped path ENDING with '/' — a bare "
                         "'repos/org' would prefix-match 'repos/org-evil' "
                         "(segment boundaries are enforced at match time too)")
    return v
