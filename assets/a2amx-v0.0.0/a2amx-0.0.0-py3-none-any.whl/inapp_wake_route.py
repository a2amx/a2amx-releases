"""Self-declared Claude routes; no native credential is read or stored."""
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import uuid

import receipts
import store

FIELDS = {'kind','ref','session_ref','declared_at'}


class DeclarationIndeterminate(RuntimeError):
    """The outcome of registry publication could not be established."""


def validate(route, *, check_path=True):
    if not isinstance(route,dict) or set(route) not in (FIELDS, FIELDS | {'qualification'}) or route.get('kind')!='inapp-socket':
        raise ValueError('invalid inapp-socket route fields')
    if 'qualification' in route:
        import inapp_hookset
        inapp_hookset.validate_qualification(route['qualification'])
    ref=route['ref']
    if (not isinstance(ref,str) or not ref or len(ref)>1000 or any(ord(c)<32 for c in ref)
            or not Path(ref).is_absolute() or str(Path(ref))!=ref or '..' in Path(ref).parts
            or (check_path and str(Path(ref).resolve())!=ref)):
        raise ValueError('inapp socket ref must be canonical and absolute')
    session=route['session_ref']
    if not isinstance(session,str) or not session.startswith('local_') or str(uuid.UUID(session[6:]))!=session[6:]:
        raise ValueError('inapp session_ref must be its local app id')
    stamp=datetime.fromisoformat(route['declared_at'])
    if stamp.utcoffset() is None: raise ValueError('declaration requires an aware timestamp')
    return ref


def generation(route, *, check_path=True):
    validate(route, check_path=check_path)
    return hashlib.sha256(json.dumps(route,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def check_registry_change(seat,actor,before,after):
    if (actor is None or actor.get('participant_id')!=seat
            or getattr(store._registry_actor_local,'wake_route_act',None)!=seat):
        raise store.RegistryMutationRefused('wake_route_self_declaration_required','own authenticated declaration required')
    old,new=before.get(seat),after.get(seat)
    if not isinstance(old,dict) or not isinstance(new,dict): raise ValueError('route cannot create a seat')
    if new.get('kind')!='agent' or store.normalize_family(new.get('family'))!='claude':
        raise ValueError('inapp-socket requires a Claude agent')
    if not {k for k in old.keys()|new.keys() if old.get(k)!=new.get(k)} <= {'wake_route','last_update'}:
        raise ValueError('route cannot change other fields')
    route=new.get('wake_route')
    if route is None: return
    ref=validate(route)
    for other,row in after.items():
        peer=row.get('wake_route')
        if other!=seat and isinstance(peer,dict) and peer.get('kind')=='inapp-socket' and peer.get('ref')==ref:
            raise ValueError('inapp socket ref is already declared')


def change(seat, *, presented_token, ref=None, session_ref=None,
           hook_set_digest=None, hook_set_generation=None, session_start_source=None,
           hook_home=None, previous_generation=None,
           hook_interface_version=None, hook_interface_digest=None, grounding_generation=None):
    qualification = None
    options = (hook_set_digest,hook_set_generation,session_start_source,hook_home,previous_generation)
    if hook_interface_version is not None or hook_interface_digest is not None:
        if (any(value is None for value in options) or hook_interface_version is None
                or hook_interface_digest is None):
            raise ValueError('interface qualification requires both version and digest plus the complete hook set')
    if any(value is not None for value in options):
        if ref is None or any(value is None for value in options):
            raise ValueError('qualified declaration requires digest, record generation, source, home and previous generation')
        qualification = {'digest':hook_set_digest,'generation':hook_set_generation,'source':session_start_source}
        if hook_interface_version is not None:
            qualification.update(interface_version=hook_interface_version, interface_digest=hook_interface_digest)
    if grounding_generation is not None:
        import seat_grounding
        if qualification is None or not seat_grounding.interface.is_digest(grounding_generation):
            raise ValueError('grounding_generation_requires_qualified_declaration')
    def apply(actor):
        parts=store._read_participants_unlocked()
        if seat not in parts: raise ValueError('seat is not registered')
        if ref is not None and qualification is None:
            record = parts[seat].get('inapp_hookset')
            if isinstance(record, dict) and record.get('spec', {}).get('schema') == 'orch.claude-hookset.v2':
                raise ValueError('hook_interface_qualification_required')
        route=None
        if ref is not None:
            stamp=datetime.now(timezone.utc)
            prior=parts[seat].get('wake_route')
            if isinstance(prior,dict): stamp=max(stamp,datetime.fromisoformat(prior['declared_at'])+timedelta(microseconds=1))
            route={'kind':'inapp-socket','ref':str(Path(ref).resolve()),'session_ref':session_ref,
                   'declared_at':stamp.isoformat(timespec='microseconds')}
            if qualification is not None:
                route['qualification'] = qualification
            validate(route)
        candidate={k:dict(v) for k,v in parts.items()}
        candidate[seat].update(wake_route=route,last_update=store.now_iso())
        previous=getattr(store._registry_actor_local,'wake_route_act',None)
        store._registry_actor_local.wake_route_act=seat
        try:
            check_registry_change(seat,store._registry_actor_local.actor,parts,candidate)
            with receipts._nudge_lock():
                if grounding_generation is not None:
                    import seat_grounding
                    if seat_grounding.current(seat)['generation'] != grounding_generation:
                        raise ValueError('grounding_stale_generation')
                if qualification is not None:
                    import inapp_hookset
                    inapp_hookset.check_declaration(seat,parts[seat],qualification,hook_home,previous_generation)
                try:
                    store._write_participants_unlocked(candidate)
                except Exception:
                    # A write can raise after replacement. Never retry an
                    # indeterminate declaration or treat it as receipted.
                    try:
                        current = store._read_participants_unlocked()[seat].get('wake_route')
                    except Exception:
                        raise DeclarationIndeterminate('registry outcome unknown') from None
                    if current == parts[seat].get('wake_route'):
                        raise
                    if current == route:
                        raise store.SeatActWithoutReceipt('wake_declare',seat,
                            'new registry route observed after publication error; dispatch disabled') from None
                    raise DeclarationIndeterminate('registry outcome changed unexpectedly') from None
                try:
                    row=receipts._append({'kind':'wake-route','event':'declared' if route else 'cleared',
                                         'seat':seat,'requester':actor,'route':route,
                                         **({'grounding_generation': grounding_generation} if grounding_generation is not None else {}),
                                         'generation':generation(route) if route else None,'ts':store.now_iso()})
                except Exception as exc:
                    raise store.SeatActWithoutReceipt('wake_declare',seat,'declaration is unreceipted; dispatch disabled') from exc
        finally: store._registry_actor_local.wake_route_act=previous
        return {'route':route,'receipt':row}
    return store.authenticated_registry_act(presented_token,apply,expected_actor=seat)
