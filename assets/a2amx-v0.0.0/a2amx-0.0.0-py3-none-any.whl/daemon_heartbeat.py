"""Daemon process heartbeat, shared by console, status and doctor.

A pulse is process liveness, not proof of delivery progress. A separate worker
keeps the five-second cadence during bounded adapter calls. The held lock and
matching incarnation are required even for a fresh pulse. No host probes.
"""
import json
from datetime import datetime
import math
import os
from pathlib import Path
import stat
import tempfile
import threading
import time

import store

INTERVAL = 5.0
MAX_AGE = 15.0
FILENAME = 'daemon-heartbeat.json'


def _read(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'r', encoding='utf-8') as stream:
        if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
            raise ValueError('not a regular file')
        text = stream.read(8193)
        if len(text) > 8192:
            raise ValueError('runtime record too large')
        return text


def write(root, identity, *, started_at=None):
    """Persist a beat and return its retained first successful write's wall time.

    Pulse owns the first-beat value in memory for one process incarnation. It is
    never recovered from a prior process's file. Failure before completion leaves
    the caller's first successful write unestablished; the next beat tries anew.
    """
    target = Path(root) / FILENAME
    if target.is_symlink():
        raise ValueError('heartbeat is a symlink')
    record = {key: identity[key] for key in ('pid', 'proc_birth', 'instance')}
    record.update(monotonic=time.monotonic(), wall_time=time.time())
    record['started_at'] = record['wall_time'] if started_at is None else started_at
    record['lease_started_at'] = identity.get('started')
    fd, name = tempfile.mkstemp(prefix='.daemon-heartbeat-', dir=root)
    try:
        with os.fdopen(fd, 'w') as stream:
            json.dump(record, stream, sort_keys=True, allow_nan=False)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, target)
        fd = os.open(root, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    finally:
        Path(name).unlink(missing_ok=True)
    return record['started_at']


class Pulse:
    def __init__(self, root, identity, log):
        self.root, self.identity, self.log = root, dict(identity), log
        self.started_at = None
        self.stop = threading.Event()
        self.thread = threading.Thread(target=self._run, name='daemon-heartbeat', daemon=True)

    def _beat(self):
        try:
            self.started_at = write(self.root, self.identity, started_at=self.started_at)
        except (OSError, ValueError):
            self.log('heartbeat unavailable; liveness will read unknown')

    def _run(self):
        while not self.stop.wait(INTERVAL):
            self._beat()

    def __enter__(self):
        self._beat()
        self.thread.start()
        return self

    def __exit__(self, *_):
        self.stop.set()
        self.thread.join()


def snapshot():
    path = store.STORE_DIR / 'daemon.lock'
    result = {'state': 'unknown', 'pid': None, 'detail': 'daemon lock unverified'}
    try:
        try:
            raw = _read(path)
        except FileNotFoundError:
            return {**result, 'state': 'down', 'detail': 'no daemon.lock'}
        lock = store.parse_daemon_lock(raw)
        if lock is not None:
            result['pid'] = lock['pid']
        if not store.daemon_lock_is_held(path, observe=True):
            return {**result, 'state': 'down', 'detail': 'daemon lock not held; recorded pid may be stale'}
        if lock is None:
            return {**result, 'detail': 'daemon lock unparseable'}
    except (OSError, UnicodeError, ValueError):
        return {**result, 'detail': 'daemon lock unreadable'}
    try:
        pulse = json.loads(_read(store.STORE_DIR / FILENAME))
        if not isinstance(pulse, dict):
            raise ValueError('invalid heartbeat')
        for key in ('pid', 'proc_birth', 'instance'):
            value = lock.get(key)
            if (not value or pulse.get(key) != value or
                    (key == 'pid' and type(pulse.get(key)) is not int) or
                    (key != 'pid' and not isinstance(value, str))):
                return {**result, 'detail': 'heartbeat identity does not match daemon lock'}
        if lock.get('store_dir') != str(store.STORE_DIR):
            return {**result, 'detail': 'daemon lock store does not match bound store'}
        ages = []
        for key, now in (('monotonic', time.monotonic()), ('wall_time', time.time())):
            stamp = pulse.get(key)
            if type(stamp) not in (int, float) or not math.isfinite(stamp):
                raise ValueError('invalid heartbeat clock')
            ages.append(now - stamp)
        if any(age < 0 or age >= MAX_AGE for age in ages):
            return {**result, 'detail': 'heartbeat stale or clock changed'}
        # Reject a lock replacement/restart during this observation.
        if _read(path) != raw or not store.daemon_lock_is_held(path, observe=True):
            return {**result, 'detail': 'daemon lock changed during observation'}
        since = lock.get('started')
        try:
            stamp = datetime.fromisoformat(since) if isinstance(since, str) else None
            since = since if stamp is not None and stamp.utcoffset() is not None else None
        except ValueError:
            since = None
        return {**result, 'state': 'up', 'heartbeat_age_seconds': round(max(ages), 3),
                'since': since,
                'detail': 'fresh heartbeat matches held daemon lock'}
    except (OSError, UnicodeError, ValueError, OverflowError):
        return {**result, 'detail': 'heartbeat missing or unreadable'}
