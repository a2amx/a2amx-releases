"""Read-only runtime facts shared with CLI health; switch reports stay historical."""
from desktop_support import optional as optional_desktop
codex_dispatch_status = optional_desktop('codex_dispatch_status')
inapp_dispatch_status = optional_desktop('inapp_dispatch_status')
agy_dispatch_status = optional_desktop('agy_dispatch_status')
import store


def _daemon():
    from daemon_heartbeat import snapshot
    return snapshot()


def _switch(report, declared_routes):
    # Current producers do not publish a family-wide compatibility gate. Its
    # absence is unknown, never inferred from enabled, a pid, or seat successes.
    gate = {'result': 'unknown', 'reason': 'no recorded compatibility gate'}
    if not report:
        return {'last_reported': 'unknown', 'at': None, 'pid': None,
                'declared_routes': declared_routes, 'compatibility_gate': gate}
    state = report.get('state')
    value = ({'enabled': 'on', 'disabled': 'off', 'stopped': 'off'}.get(state, 'unknown')
             if isinstance(state, str) else 'unknown')
    if report.get('phase') == 'stopped':
        value = 'off'
    return {'last_reported': value, 'at': report.get('ts'), 'pid': report.get('pid'),
            'declared_routes': declared_routes, 'compatibility_gate': gate}


def snapshot():
    """No writes, repair, host commands, credentials, or inactive-seat counts."""
    registry = store.load_participants()
    def count(kind):
        return sum(isinstance(row.get('wake_route'), dict)
                   and row['wake_route'].get('kind') == kind
                   for row in registry.values()
                   if not store.inactive_participant(row) and store.has_mailbox(row))
    principal = registry.get(store.OWNER, {})
    authority = (principal.get('label') or store.OWNER
                 if principal and not store.has_mailbox(principal)
                 and not store.inactive_participant(principal) else None)
    modules = {'inapp-socket':inapp_dispatch_status, 'codex-ipc':codex_dispatch_status,
               'agy-desktop':agy_dispatch_status}
    return {'measured_at': store.now_iso(), 'principal_authority': authority,
            'daemon': _daemon(), 'switches': {
                kind: _switch(module.read(), count(kind))
                for kind, module in modules.items() if module is not None}}
