"""Daemon-owned Claude pointer dispatch with asynchronous store-event acceptance.

The observation wait never holds registry or journal locks. All deadlines and
recovery lineage survive restart; successful writes alone never create POKED.
"""
from __future__ import annotations

import os
import math
import time
import uuid

import dispatch_receipts
import inapp_socket
import inapp_wake_route as routes
import receipts
import store
import claude_startup_state

ENABLE_ENV='ORCH_INAPP_SOCKET_ENABLED'
OBSERVATION=720.0
WINDOW=720.0
RETRY_DELAY=30.0
_rows=dispatch_receipts._rows
_append=dispatch_receipts._append


def enabled(): return os.environ.get(ENABLE_ENV)=='1'


def startup_observation_enabled(): return claude_startup_state.enabled()


HELD_POLICY = claude_startup_state.POLICY


def _new_policy(pre):
    return pre.get('recovery_policy') == HELD_POLICY


def _reconciled(history, pre, result=None):
    return next((r for r in reversed(history) if r.get('kind') == 'claude-reconciliation'
                 and r.get('nudge-event-id') == pre['event-id']
                 and (result is None or r.get('result') == result)), None)


def _reconcile(rows, history, pre, result, now, *, hook=None, fetched=None):
    previous = _reconciled(history, pre, result)
    if previous is not None:
        return previous
    row = {'kind':'claude-reconciliation', 'route_kind':'inapp-socket', 'seat':pre['target seat'],
           'generation':pre['generation'], 'nudge-event-id':pre['event-id'],
           'msg-id':pre['msg-id'], 'result':result, 'epoch':now, 'ts':store.now_iso()}
    if hook is not None:
        row.update({'hook-event-id':hook['event-id'], 'observed_epoch':hook['epoch']})
    if fetched is not None:
        row['fetch-txn-id'] = fetched.get('txn-id')
    row = _append(row)
    rows.append(row); history.append(row)
    return row


def _hold(history, pre, state, reason, now):
    old = next((r for r in reversed(history) if r.get('kind') == 'claude-route-hold'
                and r.get('nudge-event-id') == pre['event-id']), None)
    if old is None:
        _append({'kind':'claude-route-hold', 'route_kind':'inapp-socket', 'seat':pre['target seat'],
                 'generation':pre['generation'], 'nudge-event-id':pre['event-id'],
                 'state':state, 'reason':reason, 'epoch':now, 'ts':store.now_iso()})
    return False, old['state'] if old else state


def _dead(seat,route,generation,reason,now,*,terminal=True,event_id=None):
    _append({'kind':'wake_route_dead','route_kind':'inapp-socket','seat':seat,'ref':route['ref'],
             'generation':generation,'reason':reason,'epoch':now,'ts':store.now_iso(),
             'terminal':terminal,'event-id':event_id})
    return False,'wake_route_dead:'+reason


def _post(pre,result,reason,now,**extra):
    return _append({'kind':'nudge','phase':'post','route_kind':'inapp-socket',
                    'event-id':pre['event-id'],'target seat':pre['target seat'],
                    'generation':pre['generation'],'result':result,'reason':reason,
                    'epoch':now,'ts':store.now_iso(),**extra})


def _poked(rows,pre):
    if not any(r.get('event')=='POKED' and r.get('nudge-event-id')==pre['event-id'] for r in rows):
        _append({'kind':'delivery','event':'POKED','adapter':'inapp-socket',
                 'seat':pre['target seat'],'msg-id':pre['msg-id'],
                 'nudge-event-id':pre['event-id'],'ts':store.now_iso()})


def _settle(rows,history,route,now):
    import recall
    recalled = recall.graph(rows)
    pres=[r for r in history if r.get('kind')=='nudge' and r.get('phase')=='pre' and r.get('msg-id') not in recalled]
    posts={r['event-id']:r for r in history if r.get('kind')=='nudge' and r.get('phase')=='post'}
    submissions={r['event-id']:r for r in history if r.get('kind')=='wake-submission'}
    indices={id(r):i for i,r in enumerate(rows)}
    for pre in pres:
        post=posts.get(pre['event-id'])
        modern = _new_policy(pre)
        if post is not None and (not modern or post['result'] in {'accepted','refused'}):
            if post['result']=='accepted': _poked(rows,pre)
            continue
        submission=submissions.get(pre['event-id'])
        deadline=submission['observation_deadline'] if submission else pre['orphan_observation_deadline']
        events=[]
        for i,event in enumerate(rows):
            if (event.get('kind')!='seat_event' or event.get('event')!='UserPromptSubmit'
                    or event.get('seat')!=pre['target seat'] or event.get('generation')!=pre['generation']
                    or event.get('session_ref')!=route['session_ref'] or event.get('pointer')!=pre['exact bytes']
                    or not isinstance(event.get('epoch'),(int,float))
                    or (not modern and event['epoch']>deadline)
                    or (modern and (not math.isfinite(event['epoch'])
                                    or not pre['epoch'] <= event['epoch'] <= now))): continue
            eligible=[p for p in pres if p['exact bytes']==event['pointer'] and indices[id(p)]<i]
            if eligible and eligible[-1]['event-id']==pre['event-id']: events.append(event)
        if events:
            if modern and submission is None and post is None:
                # A matching hook does not repair the missing submission
                # record. Preserve UNKNOWN and do not manufacture POKED.
                _reconcile(rows,history,pre,'hook_observed_orphan',now,hook=events[0])
            elif modern and (post is not None or events[0]['epoch'] > deadline):
                if post is None and submission is not None:
                    post=_post(pre,'uncertain','hook_observation_timeout',deadline)
                _reconcile(rows,history,pre,'hook_observed',now,hook=events[0])
            else:
                post=_post(pre,'accepted','hook_event',events[0]['epoch'],**{'hook-event-id':events[0]['event-id']})
            if not modern or submission is not None or post is not None:
                _poked(rows,pre)
        elif post is None and now>=deadline and submission is not None:
            post=_post(pre,'uncertain','hook_observation_timeout',deadline)
        if post is not None: posts[pre['event-id']]=post
        if modern:
            fetched = next((r for i,r in store.valid_fetched_deliveries(rows)
                            if i>indices[id(pre)] and r.get('seat')==pre['target seat']
                            and r.get('msg-id')==pre['msg-id']), None)
            if fetched is not None:
                _reconcile(rows,history,pre,'fetched',now,fetched=fetched)
    return pres,posts,submissions


def at_chokepoint(*,presented_token,expected_requester,target_seat,msg_id=None,exact_bytes=None,
                  writer=inapp_socket.write,ownership=inapp_socket.owner_check,clock=time.time):
    if not enabled(): return False,'inapp_socket_disabled'
    def act(actor):
        parts=store._read_participants_unlocked()
        caller=store._registry_actor_local.actor
        if (actor!=expected_requester or actor!=store.DAEMON_SEAT or caller.get('role')!='daemon'
                or (parts.get(actor) or {}).get('role')!='system_governor'
                or (parts.get(actor) or {}).get('kind')!='system'):
            return False,'inapp_daemon_only'
        target=parts.get(target_seat) or {}
        route=target.get('wake_route')
        if target.get('kind')!='agent' or store.normalize_family(target.get('family'))!='claude':
            return False,'claude_seat_required'
        try: generation=routes.generation(route)
        except (ValueError,TypeError,OSError,KeyError): return False,'invalid_wake_route'
        if any(seat!=target_seat and isinstance(row.get('wake_route'),dict)
               and row['wake_route'].get('kind')=='inapp-socket' and row['wake_route'].get('ref')==route['ref']
               for seat,row in parts.items()): return False,'duplicate_wake_binding'
        with receipts._nudge_lock():
            # Read strictly before recovery, which must not heal torn history.
            _rows()
            receipts._recover_fetched_transactions_unlocked()
            rows=_rows();now=clock()
            if not any(r.get('kind')=='wake-route' and r.get('event')=='declared'
                       and r.get('seat')==target_seat and r.get('requester')==target_seat
                       and r.get('generation')==generation for r in rows): return False,'unreceipted_wake_route'
            history=[r for r in rows if r.get('generation')==generation and
                     (r.get('seat')==target_seat or r.get('target seat')==target_seat)]
            if any(isinstance(r.get('epoch'),(int,float)) and r['epoch']>now for r in history):
                return False,'clock_regressed'
            # Settlement runs even if the hook already drained the complete batch.
            pres,posts,submissions=_settle(rows,history,route,now)
            # Record observed outcomes for previous writes even if qualification
            # changed since submission. Qualification gates every new write.
            record = target.get('inapp_hookset')
            if (isinstance(record, dict) and record.get('spec', {}).get('schema') == 'orch.claude-hookset.v2'
                    and 'qualification' not in route):
                return False,'hook_interface_qualification_required'
            if 'qualification' in route:
                import inapp_hookset
                try:
                    inapp_hookset.qualified_record(target_seat,target,route['qualification'],rows=rows)
                except inapp_hookset.interface.Refused as exc:
                    return False,str(exc)
                except (ValueError,TypeError,OSError,KeyError):
                    return False,'hookset_qualification_refused'
            if any(r.get('kind')=='wake_route_dead' and r.get('terminal') for r in history):
                return False,'wake_route_dead'
            pending,fetched=dispatch_receipts._delivery(_rows(),target_seat)
            if not pending: return True,'no_pending_pointer'
            current=pending[-1]
            if msg_id is not None and (msg_id!=current or exact_bytes!='mail: '+current):
                return False,'stale_pending_snapshot'
            last=pres[-1] if pres else None
            if last and last['msg-id'] in fetched: last=None
            spent=any(p.get('recovery') is True for p in pres)
            recovery=False;supersedes=None;held_since=None
            if last:
                post=posts.get(last['event-id'])
                submission=submissions.get(last['event-id'])
                outcome=post['result'] if post else 'observing'
                if _new_policy(last) and _reconciled(history,last,'hook_observed'):
                    return True,'coalesced'
                if outcome=='accepted': return True,'coalesced'
                held = next((r for r in reversed(history) if r.get('kind')=='claude-route-hold'
                             and r.get('nudge-event-id')==last['event-id']),None) if _new_policy(last) else None
                if held is not None:
                    return False,held['state']
                if outcome=='observing':
                    deadline=submission['observation_deadline'] if submission else last['orphan_observation_deadline']
                    if now<deadline: return False,'awaiting_hook'
                    # Crash-orphaned pre remains UNKNOWN on the audit surface.
                    origin=deadline
                    outcome='uncertain'
                else: origin=post['epoch']
                if outcome=='refused':
                    if _new_policy(last):
                        if post['reason'] in {'no_process','owner_mismatch'}:
                            return _dead(target_seat,route,generation,post['reason'],now,event_id=last['event-id'])
                        if spent:
                            return _hold(history,last,'held-unreachable',post['reason'],now)
                    if spent: return _dead(target_seat,route,generation,post['reason'],now,event_id=last['event-id'])
                    if now<origin+RETRY_DELAY: return False,'retry_scheduled'
                    recovery=True;supersedes=last['event-id']
                elif outcome=='uncertain':
                    held_since=last['held_since'] if last.get('supersedes_uncertain') else origin
                    if _new_policy(last):
                        if now < origin + WINDOW:
                            return False,'held_uncertain'
                        try:
                            ownership(route)
                        except inapp_socket.Refused as exc:
                            if exc.reason in {'no_process','owner_mismatch'}:
                                return _dead(target_seat,route,generation,exc.reason,now,event_id=last['event-id'])
                            return _hold(history,last,'held-unreachable',exc.reason,now)
                        return _hold(history,last,'held-reconciliation-required','acceptance_unresolved',now)
                    end=held_since+(2*WINDOW if last.get('supersedes_uncertain') else WINDOW)
                    if now<end: return False,'held_uncertain'
                    if last.get('supersedes_uncertain'):
                        return _dead(target_seat,route,generation,'acceptance_unresolved',now,event_id=last['event-id'])
                    try: ownership(route)
                    except inapp_socket.Refused as exc:
                        return _dead(target_seat,route,generation,exc.reason,now,event_id=last['event-id'])
                    if spent: return _dead(target_seat,route,generation,'acceptance_unresolved',now,event_id=last['event-id'])
                    recovery=True;supersedes=last['event-id']
            if not recovery and supersedes is None:
                # D-GOV-2 (f): a focus period defers only a new attempt's pre; the
                # settlement, holds and T/2T records above ran as without focus.
                import focus
                if focus.deferring_unlocked(target_seat, rows, now) is not None:
                    return True,'focus_deferred'
            event_id='evt-'+uuid.uuid4().hex
            pre={'kind':'nudge','phase':'pre','route_kind':'inapp-socket','event-id':event_id,
                 'requester':actor,'role':parts[actor]['role'],'credential_role':'daemon',
                 'target seat':target_seat,'msg-id':current,'exact bytes':'mail: '+current,
                 'generation':generation,'session_ref':route['session_ref'],'epoch':now,
                 'orphan_observation_deadline':now+inapp_socket.WRITE_SECONDS+OBSERVATION,
                 'recovery':recovery,'supersedes':supersedes,
                 'supersedes_uncertain':recovery and held_since is not None,
                 'held_since':held_since,'ts':store.now_iso()}
            if startup_observation_enabled() or (last is not None and _new_policy(last)):
                # Bind recovery semantics durably; toggling the feature flag
                # cannot turn an outstanding uncertain attempt into a replay.
                pre['recovery_policy'] = HELD_POLICY
            _append(pre)
            try:
                result=writer(route,pre['exact bytes'])
            except inapp_socket.Refused as exc:
                result=inapp_socket.WriteResult('refused',exc.reason)
            if result.result=='submitted':
                written=clock()
                _append({'kind':'wake-submission','route_kind':'inapp-socket','event-id':event_id,
                         'target seat':target_seat,'generation':generation,'epoch':written,
                         'observation_deadline':written+OBSERVATION,'ts':store.now_iso()})
                return False,'awaiting_hook'
            if result.result not in {'refused','uncertain'}: raise ValueError('invalid socket outcome')
            post=_post(pre,result.result,result.reason,clock())
            if result.result=='refused':
                if _new_policy(pre):
                    if result.reason in {'no_process','owner_mismatch'}:
                        return _dead(target_seat,route,generation,result.reason,post['epoch'],event_id=event_id)
                    if spent or recovery:
                        return _hold(history,pre,'held-unreachable',result.reason,post['epoch'])
                    return False,'retry_scheduled'
                return _dead(target_seat,route,generation,result.reason,post['epoch'],
                             terminal=spent or recovery,event_id=event_id)
            return False,'held_uncertain'
    try: return store.authenticated_registry_act(presented_token,act,expected_actor=expected_requester)
    except store.RegistryMutationRefused as exc: return False,exc.reason


def sweep(*,presented_token,expected_requester,participants,handled_pairs=None):
    if not enabled(): return []
    rows=_rows();results=[]
    for seat,row in participants.items():
        route=row.get('wake_route')
        if not isinstance(route,dict) or route.get('kind')!='inapp-socket': continue
        pending,_=dispatch_receipts._delivery(rows,seat)
        if handled_pairs is not None: handled_pairs.update((seat,mid) for mid in pending)
        try:
            result=receipts.inject_nudge(presented_token=presented_token,expected_requester=expected_requester,
                                        target_seat=seat,msg_id=None,exact_bytes=None,writer=None,
                                        route_kind='inapp-socket')
        except Exception as exc: result=(False,'seat_fault:'+type(exc).__name__)
        results.append((seat,result))
    return results


import inapp_dispatch_status as status

def observe_pass(*, credential, participants, log, phase="running", handled_pairs=None):
    """Daemon integration boundary: reporting can fail, independent work continues."""
    results, fault = [], None
    if phase == 'running' and credential is not None and startup_observation_enabled():
        try:
            claude_startup_state.observe(credential)
        except Exception as exc:
            fault = 'startup_observation_fault:' + type(exc).__name__
    if enabled() and phase == "running":
        if credential is None:
            fault = "daemon_credential_unavailable"
        else:
            try:
                results = sweep(presented_token=credential, expected_requester=store.DAEMON_SEAT,
                                participants=participants, handled_pairs=handled_pairs)
            except Exception as exc:
                fault = "journal_or_sweep_fault:" + type(exc).__name__
    try:
        status.report(token=credential, enabled=enabled(), participants=participants,
                      results=results, fault=fault, phase=phase, log=log)
    except Exception as exc:
        # No arbitrary payload/error text is exposed by diagnostics.
        key = "diagnostic_write_failed:" + type(exc).__name__
        if getattr(observe_pass, "last_error", None) != key:
            log(key)
        observe_pass.last_error = key
    else:
        observe_pass.last_error = None
    return results
