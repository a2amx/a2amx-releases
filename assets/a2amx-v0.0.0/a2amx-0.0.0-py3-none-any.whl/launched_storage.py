"""Bounded durable metadata for launched hosts; no caller-selected paths.

The caller holds the authenticated registry transaction. Receipt history stays
in the existing core journal. Metadata is not an alternative receipt ledger.
"""
from __future__ import annotations

import os
from pathlib import Path
import stat
import tempfile

import launched_protocol as wire
import store


def directory():
    root = store.require_bound_store() / "launched-v1"
    if root.resolve() != root or root.is_symlink():
        raise wire.Refused("persistence_unknown", "unknown")
    return root


def path(category, identity):
    if category not in {"launch", "intent", "claim", "result", "withdrawn", "fetch", "witness", "declaration"}:
        raise ValueError("invalid launched metadata category")
    # Opaque Id is never interpreted as a pathname, even if it contains '/'.
    wire.text(identity)
    return directory() / (category + "-" + wire.fingerprint(identity) + ".json")


def read(category, identity):
    target = path(category, identity)
    try:
        fd = os.open(target, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except FileNotFoundError:
        return None
    with os.fdopen(fd, "rb") as stream:
        if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
            raise wire.Refused("persistence_unknown", "unknown")
        data = stream.read(wire.MAX_FRAME_BYTES + 1)
    try:
        value = wire.decode(data)
        if type(value) is not dict:
            raise wire.Refused()
    except wire.Refused:
        raise wire.Refused("persistence_unknown", "unknown") from None
    return value


def write(category, identity, value):
    target = path(category, identity)
    data = wire.canonical(value) + b"\n"
    root = target.parent
    root.mkdir(mode=0o700, exist_ok=True)
    store._fsync_dir(root.parent)
    fd, name = tempfile.mkstemp(prefix=".launched-", dir=root)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, target)
        store._fsync_dir(root)
    finally:
        Path(name).unlink(missing_ok=True)


def create(category, identity, value):
    """Idempotent immutable record under the caller's exclusive registry lock."""
    previous = read(category, identity)
    if previous is not None:
        if previous != value:
            raise wire.Refused("persistence_unknown", "unknown")
        return previous
    write(category, identity, value)
    return value
