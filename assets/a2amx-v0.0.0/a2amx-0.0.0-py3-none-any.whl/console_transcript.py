"""D-CON-2 read-only byte snapshots of the registered seat's pane.log."""
from __future__ import annotations

import os
from pathlib import Path
import stat

from seat_socket import registered_socket


class Transcript:
    def __init__(self, fd: int, start: int | None, stop: int | None):
        self.fd = fd
        self.size = os.fstat(fd).st_size
        self.start = min(self.size, max(0, start or 0))
        self.stop = max(self.start, min(self.size, max(0, stop) if stop is not None else self.size))

    def chunks(self):
        try:
            offset = self.start
            while offset < self.stop:
                data = os.pread(self.fd, min(65536, self.stop - offset), offset)
                if not data:
                    break
                offset += len(data)
                yield data
        finally:
            self.close()

    def close(self):
        if self.fd is not None:
            os.close(self.fd)
            self.fd = None


def open_transcript(seat: str, registry, *, start=None, stop=None) -> Transcript:
    """Recheck every path component with openat/O_NOFOLLOW, not a prior stat.

    Pin directory descriptors from / down to the registered socket directory;
    a rename or symlink swap after registry validation cannot redirect the read.
    O_NONBLOCK also makes a substituted FIFO fail without blocking a web worker.
    """
    directory = Path(registered_socket(seat, registry)).parent
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    parent = os.open('/', flags)
    fd = None
    try:
        for component in directory.parts[1:]:
            child = os.open(component, flags, dir_fd=parent)
            os.close(parent)
            parent = child
        fd = os.open('pane.log', os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise ValueError('pane.log must be a regular non-symlink file')
        snapshot = Transcript(fd, start, stop)
        fd = None  # ownership transferred to the response
        return snapshot
    finally:
        os.close(parent)
        if fd is not None:
            os.close(fd)
