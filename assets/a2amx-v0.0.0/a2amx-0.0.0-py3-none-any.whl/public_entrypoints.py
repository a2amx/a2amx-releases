"""The public wheel's closed console-script table.

Validate its packaged identity before importing product code. The private wheel
does not publish these entries; public metadata does not publish private aliases.
"""
import importlib
from importlib import metadata
import sys

from product_identity import ProfileError, load


def _invoke(module):
    try:
        profile = load()
        if not profile.is_public or profile.environment:
            raise ProfileError('public_profile_required_without_environment_settings')
        try:
            distribution = metadata.distribution(profile.distribution)
        except metadata.PackageNotFoundError:
            raise ProfileError('public_distribution_unavailable') from None
        expected = {profile.command(): 'public_entrypoints:main',
                    profile.command('read'): 'public_entrypoints:read',
                    profile.command('hook_claude'): 'public_entrypoints:hook_claude'}
        entries = [e for e in distribution.entry_points if e.group == 'console_scripts']
        if len(entries) != len(expected) or {e.name: e.value for e in entries} != expected:
            raise ProfileError('public_entrypoints_profile_mismatch')
        import product
        if (product.COMMAND != profile.command() or product.DISTRIBUTION != profile.distribution
                or product.installed_build() is None):
            raise ProfileError('public_build_origin_invalid_or_missing')
        implementation = importlib.import_module(module)
        if load().sha256 != profile.sha256:
            raise ProfileError('product_profile_changed_during_import')
        return (implementation.main(brand=profile.display_name) if module == 'public_hook_claude'
                else implementation.main())
    except ProfileError as exc:
        print('product configuration refused: '+str(exc), file=sys.stderr)
        return 78


def main():
    return _invoke('orch_cli')


def read():
    return _invoke('orch_read')


def hook_claude():
    return _invoke('public_hook_claude')
