"""D-CON-3 canonical dialogue predicates shared by CLI and HTTP.

Dialogue is addressed traffic (sender == X OR X in recorded recipients).
The filtered wake predicate also notices mentions; this read view deliberately
does not turn mentions into addressing or expand legacy rooms/broadcasts today.
"""
from collections import deque
import json
import os

import store


def _explicit_identity(value):
    return (isinstance(value, str) and bool(value) and value.strip() == value
            and not value.startswith('#')
            and value.casefold() not in {'all', 'everyone', 'everybody'})


def safe_record(message, *, recall_edges=None):
    """A read projection only; malformed identities never invent recipients.

    Preserve legacy display destinations, but only explicit string identities
    participate in the predicate. A present malformed recipients field becomes
    empty, never falls back to the displayed `to`. The permanent row is intact.
    """
    import recall
    result = dict(recall.project(message, edges=recall_edges))
    if not _explicit_identity(result.get('from')):
        result['from'] = None
    targets = result.get('to', [])
    result['to'] = [t for t in targets if isinstance(t, str) and t.strip()] if isinstance(targets, list) else []
    if 'recipients' in result:
        targets = result['recipients']
        result['recipients'] = [t for t in targets if _explicit_identity(t)] if isinstance(targets, list) else []
    return result


def participant_ids(message):
    # An explicitly recorded empty list remains empty. Legacy rows with no
    # recipients field use only their recorded explicit `to`, never today's room.
    recipients = message.get('recipients', message.get('to', []))
    ids = {pid for pid in recipients if _explicit_identity(pid)} if isinstance(recipients, list) else set()
    sender = message.get('from')
    if _explicit_identity(sender):
        ids.add(sender)
    return ids


def matches(message, *, participant=None, among=None, subset=False):
    identities = participant_ids(message)
    identities.discard(None)
    if participant is not None and participant not in identities:
        return False
    if among is not None:
        return identities <= among if subset else identities == among
    return True


def resolve_names(raw: str, *, option: str) -> set[str]:
    registry = store.load_participants()
    resolved = set()
    for name in (item.strip() for item in raw.split(',')):
        if not name:
            continue
        # Preserve the existing --among precedence for an exact registered ID.
        if name in registry:
            resolved.add(name)
            continue
        found = {pid for pid, row in registry.items()
                 if name.casefold() in {pid.casefold(), str(row.get('label') or pid).casefold()}}
        if len(found) != 1:
            reason = 'ambiguous' if found else 'unknown'
            raise ValueError(f'{reason} participant name in {option}: {name!r}')
        resolved.update(found)
    if not resolved:
        raise ValueError(f'{option} requires at least one participant name')
    return resolved


def select(*, limit=30, offset=0, predicate=None, visible=None):
    """Filter BEFORE the tail; return the cursor from the same scan for follow.

    Visibility is applied before the limit, inside the existing bounded byte
    window for unfiltered views or the full scan for explicit dialogue filters.
    Canonical append order (and each record id) is preserved. UUID ids are not
    sortable timestamps. read_jsonl's bounded batches cannot hide older matches.
    """
    import recall
    recall_edges = recall.graph()
    if predicate is None and offset == 0:
        return _unfiltered_tail(limit, visible=visible, recall_edges=recall_edges)
    kept = deque(maxlen=max(0, limit))
    while True:
        batch, next_offset = store.read_jsonl(store.LOG_FILE, offset)
        kept.extend(row for row in (safe_record(row, recall_edges=recall_edges) for row in batch)
                    if (predicate is None or predicate(row))
                    and (visible is None or visible(row)))
        if next_offset == offset:
            return list(kept), offset
        offset = next_offset


def _unfiltered_tail(limit, *, visible=None, recall_edges=None):
    """One bounded byte window and a resumable byte anchor.

    Take size from the opened file, exclude any torn leading/trailing record,
    and leave a trailing append for follow. An all-partial window returns its
    starting anchor; read_since resolves the containing record during follow.
    Filtered reads still scan from the start before tailing. Like the previous unfiltered tail, a record larger
    than the window is not displayed by this bounded snapshot.
    """
    from console_read_cache import scoped_snapshot
    cached = scoped_snapshot(store.LOG_FILE)
    if cached is not None:
        return cached.tail(limit, visible, lambda row: safe_record(row, recall_edges=recall_edges), store.TAIL_READ_BYTES)
    try:
        with store.LOG_FILE.open('rb') as source:
            size = os.fstat(source.fileno()).st_size
            start = max(0, size - store.TAIL_READ_BYTES)
            source.seek(start)
            data = source.read(size - start)
    except FileNotFoundError:
        return [], 0
    last_newline = data.rfind(b'\n')
    if last_newline < 0:
        # The bounded window may be wholly inside an unfinished giant record.
        # Keep its byte anchor, not the start of the permanent history. Following
        # resolves the containing record separately, preserving it on completion.
        return [], start
    cursor = start + last_newline + 1
    first = data.find(b'\n') + 1 if start else 0
    kept = deque(maxlen=max(0, limit))
    for raw in data[first:last_newline + 1].splitlines():
        try:
            row = json.loads(raw)
        except (ValueError, UnicodeDecodeError):
            continue
        if isinstance(row, dict):
            row = safe_record(row, recall_edges=recall_edges)
            if visible is None or visible(row):
                kept.append(row)
    return list(kept), cursor


def project_records(records):
    """Bind one recall graph across an entire follow batch."""
    import recall
    edges = recall.graph()
    return [safe_record(row, recall_edges=edges) for row in records]


def read_since(offset):
    """Follow a snapshot anchor, including one inside an oversized record.

    Ordinary cursors are already immediately after a newline. Only an interior
    anchor needs backward alignment to its containing record's start. This work
    belongs to following, not the bounded snapshot. read_jsonl then waits for a
    complete line, keeping that record and subsequent records exactly once.
    """
    try:
        with store.LOG_FILE.open('rb') as source:
            if offset > 0:
                source.seek(offset - 1)
                if source.read(1) != b'\n':
                    stop = offset
                    while stop > 0:
                        start = max(0, stop - store.TAIL_READ_BYTES)
                        source.seek(start)
                        data = source.read(stop - start)
                        newline = data.rfind(b'\n')
                        if newline >= 0:
                            offset = start + newline + 1
                            break
                        stop = start
                    else:
                        offset = 0
    except FileNotFoundError:
        return [], offset
    return store.read_jsonl(store.LOG_FILE, offset)
