"""Authenticated usage policy, durable intake/retry and explicit archival retention.

Lock order: registry authentication locks -> usage mutex -> flock(store directory).
The existing directory inode is this subsystem's dedicated cross-process fence;
reads create no lock file. Publication holds it through the consumer callback.
Same-UID edits outside these commands and already delivered data are not fenced.
"""
from contextlib import contextmanager, ExitStack
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import threading
import uuid

import account_usage as usage
import store
from console_files import directory, read

PENDING = 'account_usage_pending.json'
RETENTION_PENDING = 'account_usage_retention_pending.json'
MAX_ARCHIVES = 32
PUBLICATION_SEND_TIMEOUT = 5.0
QUALIFICATION = '9b9868dae73a1b8b2ad2aefb5aedf1be9e4e4d4723c1700fffbcaa61e4a8e9e3'
SOURCE = ('Codex', 'codex-desktop-limits', 'qualification-v1')
_mutex = threading.RLock()


def encode(value):
    return (json.dumps(value, ensure_ascii=False, allow_nan=False) + '\n').encode()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


@contextmanager
def fence():
    with _mutex, directory(store.STORE_DIR) as fd:
        fcntl.flock(fd, fcntl.LOCK_EX)
        try:
            yield fd
        finally:
            fcntl.flock(fd, fcntl.LOCK_UN)


def optional(fd, name, limit):
    try:
        return read(fd, name, limit=limit)
    except FileNotFoundError:
        return b''


def atomic(fd, name, raw):
    """Private same-directory replace, durable before the caller publishes success."""
    temp = '.usage-' + uuid.uuid4().hex
    target = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=fd)
    try:
        with os.fdopen(target, 'wb') as stream:
            stream.write(raw); stream.flush(); os.fsync(stream.fileno())
        os.replace(temp, name, src_dir_fd=fd, dst_dir_fd=fd)
        os.fsync(fd)
    finally:
        try:
            os.unlink(temp, dir_fd=fd)
        except FileNotFoundError:
            pass


def remove(fd, name):
    os.unlink(name, dir_fd=fd)
    os.fsync(fd)


def policy_document():
    with directory(store.STORE_DIR) as fd:
        raw = optional(fd, usage.POLICY, usage.MAX_REPORT)
    if not raw:
        return None
    document = usage._json(raw)
    if not isinstance(document, dict):
        raise ValueError('invalid usage policy')
    if document.get('schema') == 'account_usage_bindings.v1':
        usage._object(document, ('schema', 'bindings'))
    elif document.get('schema') == 'account_usage_bindings.v2':
        usage._object(document, ('schema', 'operator', 'bindings', 'authorizations', 'written_by', 'written_at'))
        usage._id(document['operator']); usage._id(document['written_by']); usage._time(document['written_at'])
        if not isinstance(document['authorizations'], list) or len(document['authorizations']) > 64:
            raise ValueError('invalid usage authorizations')
        ids = set()
        for row in document['authorizations']:
            usage._object(row, ('id','reporter','reporter_role','family','account_ref','source_id','source_version',
                                'authorized_by','authority_ref','revoked'))
            for key in ('id','reporter','authorized_by','account_ref','source_id','source_version'):
                usage._id(row[key])
            usage._text(row['authority_ref'])
            if row['id'] in ids or type(row['revoked']) is not bool or row['reporter_role'] not in store.PARTICIPANT_ROLES:
                raise ValueError('invalid usage authorization')
            ids.add(row['id'])
    else:
        raise ValueError('invalid usage policy schema')
    usage._validate_bindings(document['bindings'])
    if document['schema'].endswith('.v2'):
        for binding in document['bindings']:
            if binding['reporter_kind'] == 'operator':
                if binding['reporter'] != document['operator']:
                    raise ValueError('operator differs from CoS designation')
            else:
                auth = [a for a in document['authorizations'] if a['id'] == binding['authorization_ref'] and not a['revoked']]
                fields = ('reporter','reporter_role','family','account_ref','source_id','source_version')
                if len(auth) != 1 or any(auth[0][k] != binding[k] for k in fields):
                    raise ValueError('seat binding lacks its explicit authorization row')
    return document


def _terminal(token):
    credential, _ = store._verdict_unlocked(token, store._read_tokens_unlocked())
    if credential is None or credential['surface'] != 'terminal':
        raise ValueError('usage act requires terminal credential')


def _role(seat):
    row = store._read_participants_unlocked().get(seat)
    if not row or row.get('parked_at') or row.get('role') not in store.PARTICIPANT_ROLES:
        raise ValueError('usage actor is absent, parked or lacks current role')
    return row['role']


def _operator(document, actor):
    if not document or document['schema'] != 'account_usage_bindings.v2' or document['operator'] != actor:
        raise ValueError('retention requires the CoS-designated operator')
    rows = [b for b in document['bindings'] if b['reporter']==actor and b['reporter_kind']=='operator']
    if len(rows)!=1 or rows[0]['reporter_role'] != _role(actor):
        raise ValueError('operator binding is absent or current role changed')
    return rows[0]


def _reporter_role(seat):
    role = _role(seat)
    if store._read_participants_unlocked()[seat].get('kind') != 'agent':
        raise ValueError('usage reporter must be a registered agent seat')
    return role


def policy_act(action, *, presented_token, reporter=None, account_ref=None, authority_ref=None, authorization_id=None):
    """Only a live CoS writes designations/authorization rows; references grant no rights."""
    def apply(actor):
        _terminal(presented_token)
        if _role(actor) != 'chief_of_staff':
            raise ValueError('usage policy requires current Chief of Staff')
        with fence() as fd:
            recover(fd)
            doc = policy_document()
            if action == 'operator':
                # A CoS designates the operator by this act, not by reporter input.
                if doc and (doc['schema'] != 'account_usage_bindings.v2' or doc['bindings']):
                    raise ValueError('operator initialization requires no active bindings')
                usage._id(reporter); usage._text(authority_ref)
                if not isinstance(account_ref,str) or not re.fullmatch('[a-f0-9]{64}',account_ref):
                    raise ValueError('qualified account reference required')
                row = dict(reporter=reporter,reporter_kind='operator',reporter_role=_reporter_role(reporter),
                           authorization_ref=authority_ref,family=SOURCE[0],account_ref=account_ref,
                           source_id=SOURCE[1],source_version=SOURCE[2],qualification_ref=QUALIFICATION)
                doc = dict(schema='account_usage_bindings.v2',operator=reporter,bindings=[row],authorizations=[])
            else:
                if not doc or doc['schema'] != 'account_usage_bindings.v2':
                    raise ValueError('the first binding must be the operator designation')
                if action == 'authorize-seat':
                    operator = _operator(doc,doc['operator'])
                    usage._id(reporter);usage._text(authority_ref)
                    if reporter == doc['operator']:
                        raise ValueError('operator already has a designation')
                    row = {k:operator[k] for k in ('family','account_ref','source_id','source_version')}
                    row.update(id='usage-auth-'+uuid.uuid4().hex,reporter=reporter,reporter_role=_reporter_role(reporter),
                               authorized_by=actor,authority_ref=authority_ref,revoked=False)
                    doc['authorizations'].append(row)
                elif action == 'seat':
                    operator = _operator(doc,doc['operator'])
                    matches = [a for a in doc['authorizations'] if a['id']==authorization_id and a['reporter']==reporter and not a['revoked']]
                    if len(matches)!=1: raise ValueError('explicit seat authorization missing or revoked')
                    auth=matches[0]
                    if auth['reporter_role']!=_role(reporter) or any(auth[k]!=operator[k] for k in ('family','account_ref','source_id','source_version')):
                        raise ValueError('seat authorization differs from qualified account/source/current role')
                    if any(b['reporter']==reporter for b in doc['bindings']): raise ValueError('reporter already bound')
                    row={k:auth[k] for k in ('reporter','reporter_role','family','account_ref','source_id','source_version')}
                    row.update(reporter_kind='seat',authorization_ref=auth['id'],qualification_ref=QUALIFICATION)
                    doc['bindings'].append(row)
                elif action == 'revoke':
                    usage._id(reporter)
                    if not any(b['reporter']==reporter for b in doc['bindings']) and not any(a['reporter']==reporter and not a['revoked'] for a in doc['authorizations']):
                        raise ValueError('no active reporter binding or authorization')
                    doc['bindings']=[b for b in doc['bindings'] if b['reporter']!=reporter]
                    for auth in doc['authorizations']:
                        if auth['reporter']==reporter:auth['revoked']=True
                    row={'reporter':reporter}
                else: raise ValueError('unsupported usage policy act')
            doc.update(written_by=actor,written_at=store.now_iso())
            raw=encode(doc)
            if len(raw)>usage.MAX_REPORT or len(doc['bindings'])>64 or len(doc['authorizations'])>64:
                raise ValueError('usage policy bound exceeded')
            atomic(fd,usage.POLICY,raw)  # policy linearization: durable replacement under the fence
            return {'action':action,'reporter':row['reporter'],'authorization_id':row.get('id'),
                    'policy_sha256':digest(raw),'written_by':actor}
    return store.authenticated_registry_act(presented_token,apply)


def journal(fd):
    return optional(fd,usage.REPORTS,usage.MAX_HISTORY)


def parse_journal(raw):
    if raw and not raw.endswith(b'\n'):raise ValueError('incomplete usage receipt')
    rows=[usage._json(line) for line in raw.splitlines()]
    if any(not isinstance(row,dict) for row in rows):raise ValueError('invalid usage journal row')
    checkpoint=None
    if rows and rows[0].get('kind')=='account-usage-checkpoint':
        checkpoint=rows.pop(0)
        usage._object(checkpoint,('kind','archives','seeds','plan_sha256','retained_by','retained_at'))
        usage._id(checkpoint['retained_by'])
        if not usage._time(checkpoint['retained_at']):raise ValueError('retention attribution missing')
        if not isinstance(checkpoint['archives'],list) or len(checkpoint['archives'])>MAX_ARCHIVES:
            raise ValueError('archive chain bound')
        if not isinstance(checkpoint['seeds'],list) or len(checkpoint['seeds'])>64:raise ValueError('invalid retention seeds')
        for seed in checkpoint['seeds']:
            usage._object(seed,('row','comparison'));usage._text(seed['comparison'])
        for ref in checkpoint['archives']:
            usage._object(ref,('path','sha256'))
            if not isinstance(ref['path'],str) or len(ref['path'])>4096 or not isinstance(ref['sha256'],str) or len(ref['sha256'])!=64:
                raise ValueError('invalid archive reference')
    if any(not isinstance(row,dict) or row.get('kind')!='account-usage-report' for row in rows):
        raise ValueError('invalid usage journal')
    return checkpoint,rows


def projection(raw,policy):
    # A checkpoint winner is not sufficient after a supported policy change.
    # Re-run the unchanged selector over verified history in original order.
    return usage.project(all_receipts(raw),policy)


def archive_read(ref):
    path=Path(ref['path'])
    if not path.is_absolute() or path.resolve()!=path or path.is_relative_to(store.STORE_DIR.resolve()):
        raise ValueError('archive must be explicit and outside the store')
    with directory(path.parent) as fd:
        parent=os.fstat(fd)
        if parent.st_uid!=os.getuid() or stat.S_IMODE(parent.st_mode)&0o077:
            raise ValueError('archive directory must be owner-private')
        raw=read(fd,path.name,limit=usage.MAX_HISTORY)
        mode=os.stat(path.name,dir_fd=fd,follow_symlinks=False)
        if mode.st_uid!=os.getuid() or stat.S_IMODE(mode.st_mode)&0o077:
            raise ValueError('archive must be private and owner-controlled')
    if digest(raw)!=ref['sha256']:raise ValueError('archive verification failed')
    return raw


def all_receipts(raw):
    """Replay each archived generation once, then active rows, without seed copies."""
    checkpoint,rows=parse_journal(raw)
    history=[]
    if checkpoint:
        paths=set()
        for index,ref in enumerate(checkpoint['archives']):
            if ref['path'] in paths:raise ValueError('duplicate archive path')
            paths.add(ref['path'])
            previous,old_rows=parse_journal(archive_read(ref))
            ancestors=previous['archives'] if previous else []
            if ancestors!=checkpoint['archives'][:index]:
                raise ValueError('archive lineage differs from ordered history')
            history.extend(old_rows)
    return history+rows


def receipt_meta(row):
    return {k:row[k] for k in ('receipt_id','observed_at','reporter','assurance')}


def recover(fd):
    """Complete durable intents only; never repair arbitrary corruption on reads."""
    retention=optional(fd,RETENTION_PENDING,usage.MAX_HISTORY*2)
    if retention:
        txn=usage._json(retention)
        archive_read(txn['archive'])
        if digest(optional(fd,usage.POLICY,usage.MAX_REPORT))!=txn['policy_sha256']:
            raise ValueError('policy changed across pending retention')
        current=journal(fd); replacement=txn['replacement'].encode()
        if digest(current) not in (txn['before_sha256'],digest(replacement)):
            raise ValueError('journal changed across pending retention')
        if current!=replacement:atomic(fd,usage.REPORTS,replacement)
        remove(fd,RETENTION_PENDING)
    pending=optional(fd,PENDING,usage.MAX_REPORT*2)
    if not pending:return
    txn=usage._json(pending);raw=journal(fd);cut=txn['before_bytes'];row=txn['row'];payload=encode(row)
    if len(raw)<cut or digest(raw[:cut])!=txn['before_sha256'] or not payload.startswith(raw[cut:]):
        raise ValueError('journal differs from durable submission intent')
    if raw[cut:]!=payload:
        # Both quarantine and recovery intent are durable before replacing the torn tail.
        proof=encode({'kind':'usage-tail-recovery','receipt_id':row['receipt_id'],
                      'before_sha256':txn['before_sha256'],'tail_hex':raw[cut:].hex(),
                      'target_sha256':digest(raw[:cut]+payload)})
        name='account_usage_recovery-'+row['receipt_id']+'.json'
        previous=optional(fd,name,usage.MAX_REPORT*4)
        if previous and previous!=proof:raise ValueError('recovery evidence differs')
        if not previous:atomic(fd,name,proof)
        atomic(fd,usage.REPORTS,raw[:cut]+payload)
    else:
        target=os.open(usage.REPORTS,os.O_RDONLY|os.O_NOFOLLOW,dir_fd=fd)
        try:os.fsync(target)
        finally:os.close(target)
    remove(fd,PENDING)


def submit(report, *, presented_token, submission_key=None):
    raw=json.dumps(report,allow_nan=False).encode()
    if len(raw)>usage.MAX_REPORT:raise ValueError('usage report exceeds limit')
    report=usage.validate_report(usage._json(raw))
    if submission_key is not None:usage._id(submission_key)
    def apply(actor):
        _terminal(presented_token)
        with fence() as fd:
            policy=usage.bindings()
            matches=[b for b in policy if usage._match(b,actor,report)]
            if len(matches)!=1:raise ValueError('reporter/account/source lacks an explicit qualified binding')
            binding=matches[0]
            if _role(actor)!=binding['reporter_role']:raise ValueError('current reporter role differs from authorized binding')
            if tuple(report[k] for k in ('family','source_id','source_version'))==SOURCE and report['freshness']!='unknown':
                raise ValueError('qualified desktop source cannot claim freshness')
            if usage._time(report.get('reported_at')) and usage._time(report['reported_at'])>usage.datetime.now(usage.timezone.utc):
                raise ValueError('usage source time is in the future')
            recover(fd)
            prior=journal(fd);rows=all_receipts(prior)
            report_sha=usage._digest(report)
            if submission_key is not None:
                existing=[r for r in rows if r.get('reporter')==actor and r.get('submission_key')==submission_key]
                if existing:
                    if any(r.get('report_sha256')!=report_sha or usage._digest(r['report'])!=report_sha for r in existing):
                        raise ValueError('submission key already identifies a different report')
                    if len({r['receipt_id'] for r in existing})!=1:raise ValueError('ambiguous prior submission')
                    return receipt_meta(existing[0])
            row=dict(kind='account-usage-report',receipt_id='usage-'+uuid.uuid4().hex,observed_at=store.now_iso(),
                     reporter=actor,assurance='reported',binding_sha256=usage._digest(binding),
                     qualification_ref=binding['qualification_ref'],report=report)
            if submission_key is not None:row.update(submission_key=submission_key,report_sha256=report_sha)
            payload=encode(row)
            if len(prior)+len(payload)>usage.MAX_HISTORY:raise ValueError('usage history limit reached; operator retention required')
            if policy!=usage.bindings():raise ValueError('usage qualification changed during intake')
            atomic(fd,PENDING,encode({'before_sha256':digest(prior),'before_bytes':len(prior),'row':row}))
            # Durable intent is the commit decision. Retry completes this same receipt.
            target=os.open(usage.REPORTS,os.O_WRONLY|os.O_APPEND|os.O_CREAT|os.O_NOFOLLOW|os.O_NONBLOCK,0o600,dir_fd=fd)
            with os.fdopen(target,'a',encoding='utf-8') as stream:
                if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):raise ValueError('usage receipt destination must be regular')
                store._append_jsonl_to_locked_file(stream,row)
            os.fsync(fd);remove(fd,PENDING)
            return receipt_meta(row)
    return store.authenticated_registry_act(presented_token,apply)


def publish(consumer):
    """Keep policy writers fenced until the caller finishes emitting the snapshot."""
    error={'status':'error','accounts':[],'error':'Usage source unreadable, changed or incomplete','read_at':store.now_iso()}
    with ExitStack() as stack:
        try:
            fd=stack.enter_context(fence())
        except (OSError,ValueError):
            return consumer(error)
        try:
            if optional(fd,PENDING,usage.MAX_REPORT*2) or optional(fd,RETENTION_PENDING,usage.MAX_HISTORY*2):
                raise ValueError('usage transaction awaiting recovery')
            policy=usage.bindings();result=projection(journal(fd),policy)
            if policy!=usage.bindings():raise ValueError('usage policy changed during read')
        except (OSError,ValueError,TypeError,UnicodeError,KeyError):
            result=error
        # Only source errors become error snapshots. A consumer error must not
        # trigger a second send, especially after the first response has started.
        return consumer(result)  # publication linearizes while this fence remains held


def selection(snapshot):
    return [{k:v for k,v in a.items() if k not in ('history',)} | {
        'selected':({k:v for k,v in a['selected'].items() if k!='position'} if a['selected'] else None)
    } for a in snapshot['accounts']]


def make_plan(fd,doc):
    if optional(fd,PENDING,usage.MAX_REPORT*2) or optional(fd,RETENTION_PENDING,usage.MAX_HISTORY*2):raise ValueError('pending transaction requires recovery before plan')
    raw=journal(fd);checkpoint,rows=parse_journal(raw)
    archives=checkpoint['archives'] if checkpoint else []
    for ref in archives:archive_read(ref)
    if len(archives)>=MAX_ARCHIVES:raise ValueError('archive chain bound reached')
    view=projection(raw,doc['bindings'])
    seeds=[]
    for account in view['accounts']:
        row=account['selected']
        if row:
            seeds.append({'row':{k:v for k,v in row.items() if k not in ('position','comparison')},'comparison':row['comparison']})
    summary=dict(schema='account_usage_retention_plan.v1',journal_sha256=digest(raw),
                 policy_sha256=digest(optional(fd,usage.POLICY,usage.MAX_REPORT)),before_bytes=len(raw),
                 active_rows=len(rows),retained_accounts=len(seeds),archives=len(archives),
                 selection_sha256=usage._digest(selection(view)))
    summary['plan_sha256']=usage._digest(summary)
    return summary,seeds,archives,raw


def retention_plan(*,presented_token):
    def apply(actor):
        _terminal(presented_token)
        with fence() as fd:
            doc=policy_document();_operator(doc,actor)
            return make_plan(fd,doc)[0]
    return store.authenticated_registry_act(presented_token,apply)


def retention_apply(plan,archive_path,*,presented_token):
    plan=usage._json(json.dumps(plan,allow_nan=False))
    path=Path(archive_path).absolute()
    if path.resolve()!=path or path.is_relative_to(store.STORE_DIR.resolve()):raise ValueError('archive must be explicit and outside the store')
    def apply(actor):
        _terminal(presented_token)
        with fence() as fd:
            doc=policy_document();_operator(doc,actor);recover(fd)
            checkpoint,_=parse_journal(journal(fd))
            if checkpoint and checkpoint['plan_sha256']==plan.get('plan_sha256'):
                if checkpoint['archives'][-1]['path']!=str(path):raise ValueError('retention retry archive differs')
                archive_read(checkpoint['archives'][-1])
                return {'plan_sha256':plan['plan_sha256'],'archive':str(path),'replayed':True}
            current,seeds,archives,raw=make_plan(fd,doc)
            if plan!=current:raise ValueError('retention plan no longer matches journal or policy')
            ref={'path':str(path),'sha256':digest(raw)}
            compact=encode(dict(kind='account-usage-checkpoint',archives=archives+[ref],seeds=seeds,
                                plan_sha256=plan['plan_sha256'],retained_by=actor,retained_at=store.now_iso()))
            if len(compact)>=len(raw) or len(compact)>usage.MAX_HISTORY:raise ValueError('retention would not free bounded history space')
            with directory(path.parent) as archive_dir:
                parent=os.fstat(archive_dir)
                if parent.st_uid!=os.getuid() or stat.S_IMODE(parent.st_mode)&0o077:
                    raise ValueError('archive directory must be owner-private')
                if shutil.disk_usage(path.parent).free<len(raw)+len(compact)*3+4096:raise ValueError('insufficient archive space')
                if shutil.disk_usage(store.STORE_DIR).free<len(compact)*3+4096:raise ValueError('insufficient journal space')
                try:target=os.open(path.name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=archive_dir)
                except FileExistsError:
                    archive_read(ref)
                    target=os.open(path.name,os.O_RDONLY|os.O_NOFOLLOW,dir_fd=archive_dir)
                    try:os.fsync(target)
                    finally:os.close(target)
                    os.fsync(archive_dir)
                else:
                    with os.fdopen(target,'wb') as stream:
                        stream.write(raw);stream.flush();os.fsync(stream.fileno())
                    os.fsync(archive_dir)
            archive_read(ref)
            if usage._digest(selection(projection(compact,doc['bindings'])))!=plan['selection_sha256']:
                raise ValueError('retention changes selected observations or comparisons')
            if digest(journal(fd))!=plan['journal_sha256'] or digest(optional(fd,usage.POLICY,usage.MAX_REPORT))!=plan['policy_sha256']:
                raise ValueError('retention input changed before commit')
            atomic(fd,RETENTION_PENDING,encode(dict(archive=ref,policy_sha256=plan['policy_sha256'],
                                                   before_sha256=digest(raw),replacement=compact.decode())))
            atomic(fd,usage.REPORTS,compact)  # archive verified, intent durable, replacement atomic
            remove(fd,RETENTION_PENDING)
            return {'plan_sha256':plan['plan_sha256'],'archive':str(path),'before_bytes':len(raw),'after_bytes':len(compact),'replayed':False}
    return store.authenticated_registry_act(presented_token,apply)
