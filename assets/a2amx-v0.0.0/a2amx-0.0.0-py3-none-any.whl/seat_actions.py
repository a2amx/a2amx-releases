"""Principal console action facade, first refusing implementation.

The session/capability backend is not installed in this cut. Every syntactically
valid call therefore refuses before reading any binding or action history. An
absent backend is not permission to use a seat bearer, asserted actor or fake
principal. This module has no native action, credential or store dependency.
"""
from __future__ import annotations

from datetime import datetime, timezone
import re
from typing import Literal
import uuid

__all__ = ["ConsoleAuthorityRef", "inspect_binding", "launch_terminal",
           "open_terminal", "read_action"]

_SEAT = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,31}")


class ConsoleAuthorityRef:
    """Reserved opaque type; the real principal backend owns future issuance.

    There is no public minting constructor, deserializer, verifier argument or
    registration callback. Even an instance forged through object.__new__ is
    refused: an instance check alone never establishes authority.
    """
    __slots__ = ()

    def __new__(cls):
        raise TypeError("principal_console_unavailable")

    def __init_subclass__(cls, **kwargs):
        raise TypeError("console_authority_not_subclassable")

    def __reduce_ex__(self, protocol):
        raise TypeError("console_authority_not_serializable")

    def __repr__(self):
        return "<ConsoleAuthorityRef: opaque>"


def _timestamp():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _valid_seat(value):
    # The canonical participant-ID syntax; existence is a privileged lookup
    # and cannot be established until the real authority backend exists.
    return type(value) is str and _SEAT.fullmatch(value) is not None


def _valid_generation(value):
    # Opaque to the consumer. In particular it is not required to be a hash.
    if type(value) is not str or not value:
        return False
    try:
        value.encode("utf-8")
    except UnicodeError:
        return False
    return True


def _valid_id(value):
    if type(value) is not str:
        return False
    try:
        return str(uuid.UUID(value)) == value
    except ValueError:
        return False


def _refusal(code):
    return {"code": code, "facts": {}}


def _read_refused(code):
    return {"v": 1, "status": "refused", "value": None,
            "refusal": _refusal(code), "observed_at": _timestamp()}


def _action_refused(operation, window, code):
    # Identity remains null because authority and the authoritative target have
    # not been validated. No unauthenticated request or replay record is made.
    launch = "not_started" if operation == "launch_terminal" else "not_requested"
    wants_window = operation == "open_terminal" or (type(window) is str and window == "open")
    return {"v": 1, "operation": operation, "seat": None,
            "binding_generation": None, "request_id": None, "status": "refused",
            "refusal": _refusal(code),
            "launch": {"state": launch, "receipt_ref": None, "refusal": None},
            "window": {"state": "not_opened" if wants_window else "not_requested",
                       "receipt_ref": None, "refusal": None},
            "replayed": False, "observed_at": _timestamp()}


def inspect_binding(seat: str, *, authority: ConsoleAuthorityRef) -> dict:
    """ReadResult[Binding]; no generation or private endpoint is invented."""
    if not _valid_seat(seat):
        return _read_refused("invalid_request")
    return _read_refused("principal_console_unavailable")


def launch_terminal(seat: str, *, expected_binding_generation: str,
                    request_id: str, window: Literal["open", "none"],
                    authority: ConsoleAuthorityRef) -> dict:
    """ActionResult; refusal schedules neither a launch nor a window."""
    if (not _valid_seat(seat) or not _valid_generation(expected_binding_generation)
            or not _valid_id(request_id) or type(window) is not str or window not in {"open", "none"}):
        return _action_refused("launch_terminal", window, "invalid_request")
    return _action_refused("launch_terminal", window, "principal_console_unavailable")


def open_terminal(seat: str, *, expected_binding_generation: str,
                  request_id: str, window: Literal["open"],
                  authority: ConsoleAuthorityRef) -> dict:
    """ActionResult; never starts an agent as an Open fallback."""
    if (not _valid_seat(seat) or not _valid_generation(expected_binding_generation)
            or not _valid_id(request_id) or type(window) is not str or window != "open"):
        return _action_refused("open_terminal", window, "invalid_request")
    return _action_refused("open_terminal", window, "principal_console_unavailable")


def read_action(seat: str, request_id: str, *, authority: ConsoleAuthorityRef) -> dict:
    """ReadResult[ActionResult]; no fabricated absence and no recovery effects."""
    if not _valid_seat(seat) or not _valid_id(request_id):
        return _read_refused("invalid_request")
    return _read_refused("principal_console_unavailable")
