"""Trace Ledger — Stage 0 of the meta-harness (see docs/META_HARNESS_PLAN.md).

An append-only, normalized event stream at ``store/ledger.jsonl``: the durable,
inspectable substrate the governor, convergence oracles, telemetry, and the
"orch-Verified" artifact all read from. This module is deliberately *substrate-free*
(no vendor SDK). Mirror failures are observable separately from canonical delivery.

Design (from META_HARNESS_PLAN Stage 0 + the concrete-schema appendix):

* **One universal envelope** per line so telemetry/governor parse the stream without
  understanding each payload::

      {schema_version, id, ts, kind, task_id, actor_id, role,
       corr_id?, causation_id?, room?, payload}

  ``id`` is a time-sortable ULID; ``corr_id`` pairs a result with its call
  (tool_result -> tool_call); ``causation_id`` links the event that prompted an actor.
* **Closed ``kind`` vocabulary** (:data:`KINDS`) and **closed ``role`` vocabulary**
  (:data:`ROLES`).
* **Reuse, don't reinvent:** appends via ``store.append_jsonl`` and replays via
  ``store.read_jsonl`` — the same offset/torn-tail-tolerant helpers the task log uses.
* **Wiring without a circular module-load import:** ``store`` lazily imports
  ``ledger``, which registers its post-send hook at import (:func:`install`).
  Failed mirror-bootstrap imports and hooks append ``trace-mirror-loss`` diagnostics to the
  existing receipt journal; ``orch doctor`` counts those signals. A hook can
  fail after its append, so the mirror outcome is unconfirmed, not proved absent.
  If the diagnostic cannot persist, a fixed stderr warning is attempted.
  Neither failure changes the canonical message's delivery result. Mandatory
  canonical schema checks retain their existing fail-closed behavior.

**Authorization is NOT the ledger.** The ``human_approval`` event is an audit *receipt*
that an approval happened — it never *grants* anything. Authorization is decided against
the protected single-use token store (Stage 1), never by reading this append-only log
(a persisted ``Allow`` line is both replayable and forgeable). Keep the two separate.

**A2A alignment (decision 2026-06-26):** A2A *federation* is deferred, but the bus is
shaped A2A-compliant from day one — the envelope already carries ``role`` + ``task_id``
(A2A Task correlation) and ``room_message`` payloads carry A2A-style typed ``parts``, so
an external A2A-compliant agent maps cleanly when federation lands. Full A2A JSON-RPC
method framing is deferred until the spec is pinned.
"""
from __future__ import annotations

import fcntl
import hashlib
import secrets
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import store

LEDGER_FILE = store.STORE_DIR / "ledger.jsonl"
SCHEMA_VERSION = 1
_verified_schema_cutovers: Dict[str, Dict[str, Any]] = {}
_schema_cutover_mutex = threading.Lock()

#: Closed event-kind vocabulary (META_HARNESS_PLAN Stage 0).
KINDS = frozenset({
    "room_message", "tool_call", "tool_result", "permission_request",
    "permission_decision", "human_approval", "convergence_signal",
    "norm_check", "harness_mutation",
    # G0 approval surface (STAGE3 §2; approvals.py): item lifecycle, the policy
    # tier's auto-approved-but-ledgered actions ("nothing unrecorded, only
    # unprompted" — the operator 07-12), the G0.4 breaker trip, and single-use
    # authorization consumption.
    "approval_item_created", "policy_auto_approval", "circuit_breaker",
    "approval_consumed", "approval_timeout_denied",
    # G1.1 runtime ownership (docs/G1_RUNTIME_OWNERSHIP_DESIGN.md, adopted
    # the operator Z 2026-07-13; runtime_registry.py): the durable intent receipt
    # BEFORE any claim/spawn, promotion of a proven runtime, proven stop, and
    # every fail-closed outcome. Payloads carry seat + generation + runtime_id
    # + attempt_id, never handle values (handles live only in the 0600 registry).
    "runtime_claim_intent", "runtime_promoted", "runtime_stopped",
    "runtime_failed", "runtime_intent_closed", "runtime_exited",
    "runtime_escapees_cleared", "runtime_resume",
})

#: Closed actor-role vocabulary (envelope ``role``) — single source of truth is the
#: participant registry's vocabulary (store.PARTICIPANT_ROLES, Stage 1).
ROLES = frozenset(store.PARTICIPANT_ROLES)

# Legacy participant records (pre-Stage-1, no ``role`` field) are defaulted through
# store._default_role — the SAME logic new records get at creation, so the two paths
# can't diverge (Bugbot #40: a duplicated partial map here sent unknown-family agents
# to human_authority while the registry would have said reviewer).

# Reserved sender ids that ARE the harness/system (burn-guard alerts, join/leave/rename
# notices all originate here). Role is bound to the *sender*, never to a message's kind —
# so an agent sending kind="system" keeps its own role rather than being tagged governor.
SYSTEM_ACTORS = frozenset({"System"})

# ULID base32 alphabet, for a dependency-free, time-sortable ULID (128-bit: 48-bit ms + 80-bit random).
_ULID_BASE32 = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"

# Monotonic ULID state: within the same millisecond the random component is incremented
# (per the ULID monotonic spec) so ids are *strictly* increasing within a process — lexical
# order == append order. Cross-process order still holds at ms granularity; the flock-
# serialized file append remains the authoritative order regardless.
_ulid_lock = threading.Lock()
_ulid_last_ms = 0
_ulid_last_rand = 0


def _ulid() -> str:
    """A monotonic, time-sortable ULID with an ``evt_`` prefix (lexical order == time order)."""
    global _ulid_last_ms, _ulid_last_rand
    with _ulid_lock:
        ms = int(time.time() * 1000)
        if ms <= _ulid_last_ms:                       # same ms (or clock went back): step the random part
            ms = _ulid_last_ms
            _ulid_last_rand += 1
            if _ulid_last_rand >= (1 << 80):          # 80-bit overflow (astronomically unlikely): roll to next ms
                ms += 1
                _ulid_last_rand = secrets.randbits(80)
        else:
            _ulid_last_rand = secrets.randbits(80)
        _ulid_last_ms = ms
        n = (ms << 80) | _ulid_last_rand
    chars = []
    for _ in range(26):
        chars.append(_ULID_BASE32[n & 0x1F])
        n >>= 5
    return "evt_" + "".join(reversed(chars))


def new_event_id() -> str:
    """Mint an event id AHEAD of its append, for a writer that must name a record before
    the record exists: ``store.register_store`` fsyncs the prepare row's id into the temp
    locator BEFORE it appends the ``store_registration_prepared`` row, so the committed
    locator can later be matched to exactly that prepare and to no other (ts, registrant
    and log hash all repeat when an unchanged store is re-registered within one second).
    Pass the id straight back as ``emit(..., event_id=...)``: minting and appending are one
    sequential act, so the ledger's id order remains its append order."""
    return _ulid()


def _valid_event_id(event_id: str) -> bool:
    return (len(event_id) == 30 and event_id.startswith("evt_")
            and all(ch in _ULID_BASE32 for ch in event_id[4:]))


def _now_iso_ms() -> str:
    """ISO-8601 UTC with millisecond precision and a ``Z`` suffix."""
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


#: How a role was arrived at. **The distinction is load-bearing and must not be collapsed:**
#: an ``explicit`` role is a decision someone recorded; a ``derived`` one is a default nobody
#: reviewed. :func:`role_for` deliberately returns the same string for both — which is correct
#: for *labelling* an actor and wrong for *licensing* one. A family-derived role can be writable
#: (Claude currently derives ``coder``), and role tables can evolve; see the containment guard in
#: ``harness/adapter_codex.sandbox_preset_for_role_source``.
ROLE_SOURCES = frozenset({"explicit", "system", "derived", "unregistered"})


def role_from_record(rec: Optional[Dict[str, Any]], *, actor_id: str = "") -> tuple[str, str]:
    """``(role, source)`` for an already-loaded participant record.

    The classifier lives here, once. Callers that already hold a participant record can use it
    without re-implementing provenance — two classifiers would drift, and the one that drifts
    permissive is the one that grants.
    """
    rec = rec if isinstance(rec, dict) else {}
    if (actor_id and actor_id in SYSTEM_ACTORS) or rec.get("kind") == "system":
        return "system_governor", "system"
    recorded = rec.get("role")
    if recorded in ROLES:
        source = rec.get("role_source")
        return recorded, source if source in {"explicit", "derived"} else "derived"
    if rec:
        return store._default_role(rec.get("kind") or "human", rec.get("family")), "derived"
    return "human_authority", "unregistered"


def role_with_source(actor_id: str) -> tuple[str, str]:
    """``(role, source)`` — :func:`role_for`'s answer plus HOW it was reached.

    ``source`` is one of :data:`ROLE_SOURCES`. Callers that merely *record* an actor want
    :func:`role_for`; callers that *grant capability* from a role want this, because a role
    nobody assigned is not evidence that anybody intended the privilege it now implies.
    """
    try:
        rec = store.load_participants().get(actor_id) or {}
    except Exception:
        rec = {}
    return role_from_record(rec, actor_id=actor_id)


def role_for(actor_id: str) -> str:
    """Best-effort role for an actor. Prefers an explicit participant ``role`` (Stage 1),
    else infers from the participant record.

    Delegates to :func:`role_with_source` so the two can never disagree about the role while
    disagreeing about nothing else — one resolution path, two views of it.

    ``system_governor`` is reserved for genuine system actors (:data:`SYSTEM_ACTORS`, or a
    participant explicitly marked ``kind=="system"``) — bound to the *sender*, never to a
    message's kind. Unknown/unregistered senders default to ``human_authority``, NOT
    ``system_governor``: agents are always in the roster (seeded in DEFAULT_PARTICIPANTS or
    spawned with a record), so a sender with no record is a human operator identifying via
    ``--as``/UI who isn't registered yet (e.g. a fresh-store CLI broadcast). Since Stage 1
    the participant record carries an explicit ``role`` (preferred below); legacy records
    fall back to ``store._default_role`` — the same defaulting new records get, so the two
    paths can't diverge. Authenticated role binding at write time is Stage 3."""
    return role_with_source(actor_id)[0]


def emit(kind: str, *, actor_id: str, role: Optional[str] = None,
         payload: Optional[Dict[str, Any]] = None, task_id: Optional[str] = None,
         room: Optional[str] = None, corr_id: Optional[str] = None,
         causation_id: Optional[str] = None,
         ledger_file: Optional[Path] = None,
         event_id: Optional[str] = None) -> Dict[str, Any]:
    """Append one event to the ledger and return the written record.

    ``kind`` must be in :data:`KINDS`; ``role`` (inferred if omitted) must be in
    :data:`ROLES`. Optional envelope fields are only written when set.

    ``ledger_file`` names a ledger EXPLICITLY (the registration receipt of
    ``store.register_store`` goes into the ledger of the store being registered, which
    is not necessarily the one this process is bound to — or this process may be
    unbound). Default: the bound store's ledger.

    ``event_id`` names the record with an id pre-minted by :func:`new_event_id` — for a
    writer that had to fsync the id somewhere before the append (the locator carries its
    prepare's id); anything not minted there is refused.
    """
    if event_id is not None and not (isinstance(event_id, str) and _valid_event_id(event_id)):
        raise ValueError(f"event_id must be minted by new_event_id(): {event_id!r}")
    if kind not in KINDS:
        raise ValueError(f"unknown ledger kind: {kind!r} (allowed: {sorted(KINDS)})")
    role = role or role_for(actor_id)
    if role not in ROLES:
        raise ValueError(f"unknown ledger role: {role!r} (allowed: {sorted(ROLES)})")
    rec: Dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "id": event_id if event_id is not None else _ulid(),
        "ts": _now_iso_ms(),
        "kind": kind,
        "task_id": task_id,
        "actor_id": actor_id,
        "role": role,
        "payload": payload or {},
    }
    # actor_id/role are bound by the caller from the authenticated channel — a
    # self-declared role in a message proves nothing (store.py: identity is local today).
    if room is not None:
        rec["room"] = room
    if corr_id is not None:
        rec["corr_id"] = corr_id
    if causation_id is not None:
        rec["causation_id"] = causation_id
    if ledger_file is None:
        store.ensure_store()
        ledger_file = LEDGER_FILE
    store.append_jsonl(Path(ledger_file), rec)
    return rec


def _schema_cutover_receipt(ledger_file: Path, log_file: Path) -> Optional[Dict[str, Any]]:
    """Return the durable A.8 M1 receipt for ``log_file``, if one exists."""
    offset = 0
    resolved = str(log_file.resolve())
    while True:
        rows, new_offset = store.read_jsonl(ledger_file, offset)
        for row in rows:
            payload = row.get("payload") or {}
            if (row.get("kind") == "harness_mutation"
                    and payload.get("action") == "message_schema_cutover"
                    and payload.get("log_path") == resolved):
                return row
        if new_offset == offset:
            return None
        offset = new_offset


def _verify_legacy_log_segment(receipt: Dict[str, Any], log_file: Path) -> None:
    """Fail closed unless the receipt still matches the pinned log prefix."""
    payload = receipt.get("payload") or {}
    byte_length = payload.get("byte_length")
    expected_sha256 = payload.get("sha256")
    if not isinstance(byte_length, int) or byte_length < 0 or not isinstance(expected_sha256, str):
        raise ValueError("invalid legacy log segment receipt")
    try:
        with log_file.open("rb") as source:
            raw = source.read(byte_length)
    except FileNotFoundError:
        raw = b""
    if len(raw) != byte_length:
        raise ValueError("legacy log segment length mismatch")
    if not secrets.compare_digest(hashlib.sha256(raw).hexdigest(), expected_sha256):
        raise ValueError("legacy log segment SHA-256 mismatch")


def ensure_legacy_log_segment(*, log_file: Optional[Path] = None,
                              ledger_file: Optional[Path] = None) -> Dict[str, Any]:
    """Hash-pin the pre-A.8 log prefix before any v1-envelope append.

    M1 defines the legacy segment as the exact byte prefix ending at
    ``byte_length``. The file is not moved or rewritten: later additive records
    are appended after that boundary. The receipt is fsynced before return.
    """
    log_file = Path(log_file or store.LOG_FILE)
    ledger_file = Path(ledger_file or LEDGER_FILE)
    cache_key = f"{log_file.resolve()}::{ledger_file.resolve()}"
    if cache_key in _verified_schema_cutovers:
        receipt = _verified_schema_cutovers[cache_key]
        _verify_legacy_log_segment(receipt, log_file)
        return receipt

    lock_file = log_file.with_suffix(".schema-cutover.lock")
    lock_file.parent.mkdir(parents=True, exist_ok=True)
    with _schema_cutover_mutex, lock_file.open("a") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        try:
            receipt = _schema_cutover_receipt(ledger_file, log_file)
            if receipt is None:
                raw = log_file.read_bytes() if log_file.exists() else b""
                if raw and not raw.endswith(b"\n"):
                    raise ValueError("legacy log has a partial final line; refusing schema cutover")
                line_count = raw.count(b"\n")
                newest_msg_id = None
                offset = 0
                while True:
                    rows, new_offset = store.read_jsonl(log_file, offset)
                    if rows:
                        newest_msg_id = rows[-1].get("id")
                    if new_offset == offset:
                        break
                    offset = new_offset
                receipt = emit(
                    "harness_mutation", actor_id="System", role="system_governor",
                    ledger_file=ledger_file,
                    payload={
                        "action": "message_schema_cutover",
                        "legacy_segment": "log.jsonl-prefix",
                        "log_path": str(log_file.resolve()),
                        "byte_length": len(raw),
                        "line_count": line_count,
                        "newest_msg_id": newest_msg_id,
                        "sha256": hashlib.sha256(raw).hexdigest(),
                        "next_schema": "message-envelope-v1",
                    },
                )
            _verify_legacy_log_segment(receipt, log_file)
            _verified_schema_cutovers[cache_key] = receipt
            return receipt
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


# --- convenience emitters (kinds the Z-gate + later stages need) ---

def record_room_message(msg: Dict[str, Any], *,
                        authenticated_actor: str | None = None) -> Dict[str, Any]:
    """Mirror a ``store.send()`` message record into a ``room_message`` event.

    The payload is A2A-shaped: ``content``/``format`` plus a typed ``parts`` list so an
    external A2A agent maps cleanly. ``reply_to`` is kept in the payload (it is a *message*
    id, a different id-space from ledger ``causation_id``, which links ledger events)."""
    text = msg.get("text", "")
    payload: Dict[str, Any] = {
        "content": text,
        "format": "text/markdown",
        "parts": [{"kind": "text", "text": text}],           # A2A-style parts
        "recipients": msg.get("recipients", msg.get("to", [])),
        "hub_kind": msg.get("kind", "message"),               # original store kind
        "msg_id": msg.get("id"),
    }
    if msg.get("reply_to"):
        payload["reply_to"] = msg["reply_to"]
    claimed_actor = msg.get("from") or "unknown"
    if authenticated_actor == claimed_actor:
        actor_id, role = authenticated_actor, None
        payload["authentication"] = "validated_principal"
    else:
        # Canonical rejected rows are still mirrored, but an unverified claim
        # can never select a privileged ledger role (especially the reserved
        # System -> system_governor mapping).
        actor_id, role = "unverified", "reviewer"
        payload["authentication"] = "rejected_unverified"
        payload["claimed_actor"] = claimed_actor
    # task_id travels in meta for task-kind traffic (orch_cli sends kind="task",
    # meta={"task_id": ...}); fall back to it so task turns aren't left unbound.
    task_id = msg.get("task_id") or (msg.get("meta") or {}).get("task_id")
    # Only a credential-validated actor reaches role_for.  Rejected/unverified
    # claims retain their claimed id in payload evidence but receive an explicit
    # non-governor role, independent of message kind.
    return emit("room_message", actor_id=actor_id, role=role,
                payload=payload, task_id=task_id, room=msg.get("room"))


def emit_tool_call(actor_id: str, tool_name: str, args: Dict[str, Any], *,
                   policy_tier: Optional[str] = None, status: str = "proposed",
                   vendor_tool_id: Optional[str] = None, task_id: Optional[str] = None,
                   role: Optional[str] = None) -> Dict[str, Any]:
    """Action-seam event. ``vendor_tool_id`` is stored in-payload so the call<->result
    correlation is rebuildable by replay (never only an in-memory dict)."""
    payload: Dict[str, Any] = {"tool_name": tool_name, "args": args, "status": status}
    if policy_tier is not None:
        payload["policy_tier"] = policy_tier
    if vendor_tool_id is not None:
        payload["vendor_tool_id"] = vendor_tool_id
    return emit("tool_call", actor_id=actor_id, role=role, payload=payload, task_id=task_id)


def emit_tool_result(actor_id: str, corr_id: str, *, ok: bool,
                     output: Any = None, task_id: Optional[str] = None,
                     role: Optional[str] = None) -> Dict[str, Any]:
    """Result event; ``corr_id`` is the originating ``tool_call``'s universal id."""
    return emit("tool_result", actor_id=actor_id, role=role, corr_id=corr_id,
                payload={"ok": bool(ok), "output": output}, task_id=task_id)


def emit_human_approval(actor_id: str, *, decision: str, fingerprint: Dict[str, Any],
                        token_hash: Optional[str] = None,
                        auth_source: str = "operator_token",
                        override_reason: Optional[str] = None,
                        task_id: Optional[str] = None) -> Dict[str, Any]:
    """The audit *receipt* that an approval happened (NOT the authorization check —
    that is the Stage-1 token store). ``override_reason`` non-null = a human forced a
    merge past a failing sensor, surfaced loudly."""
    if decision not in ("Allow", "Deny"):
        raise ValueError(f"decision must be 'Allow' or 'Deny', got {decision!r}")
    payload = {
        "decision": decision,
        "auth_source": auth_source,
        "fingerprint": fingerprint,
        "token_hash": token_hash,
        "override_reason": override_reason,
    }
    return emit("human_approval", actor_id=actor_id, role="human_authority",
                payload=payload, task_id=task_id)


# --- read side (replay the append-only stream) ---

def read_events(offset: int = 0) -> Tuple[List[Dict[str, Any]], int]:
    """All complete events past byte ``offset``, and the new offset (torn-tail tolerant).

    ``store.read_jsonl`` returns at most one ``READ_BATCH_BYTES`` (4 MB) batch per call,
    so we loop until the offset stops advancing — otherwise a replay from 0 would silently
    drop every event past the first batch. A caller tailing incrementally passes the
    returned offset back on the next call and gets only the new events."""
    all_records: List[Dict[str, Any]] = []
    while True:
        records, new_offset = store.read_jsonl(LEDGER_FILE, offset)
        all_records.extend(records)
        if new_offset == offset:      # no forward progress -> EOF (or a torn in-flight tail)
            return all_records, offset
        offset = new_offset


def tail(n: int = 50) -> List[Dict[str, Any]]:
    """The last ``n`` events (bounded read from the file end)."""
    return store.tail_jsonl(LEDGER_FILE, n)


# --- activation: register the send->ledger mirror hook (idempotent) ---

_INSTALLED = False


def _on_send(msg: Dict[str, Any], *, authenticated_actor: str | None = None) -> None:
    record_room_message(msg, authenticated_actor=authenticated_actor)


def install() -> bool:
    """Register the post-send mirror into ``store._post_send_hooks``. Idempotent;
    returns True the first time it registers. Called at import so ``import ledger``
    is all a process needs to start mirroring the message bus into the ledger."""
    global _INSTALLED
    if _INSTALLED:
        return False
    if _on_send not in store._post_send_hooks:
        store._post_send_hooks.append(_on_send)
    _INSTALLED = True
    return True


install()
