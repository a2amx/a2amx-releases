"""Account usage reports: explicit operator intake and read-only projection.

The qualified desktop importer reads only an explicitly supplied raw JSON file.
CoS-owned bindings grant intake; absence grants nobody access.
Private report receipts never enter the ordinary message/delivery logs.
"""
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
import hashlib
import json
import math
from pathlib import Path
import re

import store
from console_files import directory, read

POLICY = 'account_usage_bindings.json'
REPORTS = 'account_usage_reports.jsonl'
MAX_REPORT = 65536
MAX_HISTORY = 16 * 1024 * 1024
FAMILIES = {'Codex', 'Claude'}


def _object(value, required, optional=()):
    if not isinstance(value, dict) or set(value) - set(required) - set(optional) or set(required) - set(value):
        raise ValueError('usage object has missing or unsupported fields')
    return value


def _text(value, limit=160):
    if not isinstance(value, str) or not value.strip() or len(value) > limit or any(ord(c) < 32 for c in value):
        raise ValueError('usage text must be bounded nonempty printable text')
    return value


def _id(value):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:-]{0,63}', value):
        raise ValueError('usage identifiers must be opaque bounded aliases')
    return value


def _time(value):
    if value is None:
        return None
    _text(value, 64)
    try:
        result = datetime.fromisoformat(value)
    except ValueError:
        raise ValueError('usage timestamp must be ISO-8601 with timezone') from None
    if result.tzinfo is None or result.utcoffset() is None:
        raise ValueError('usage timestamp requires timezone')
    return result


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate usage JSON key')
        result[key] = value
    return result


def _json(data):
    try:
        return json.loads(data, object_pairs_hook=_pairs,
                          parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite usage value')))
    except RecursionError:
        raise ValueError('usage JSON nesting exceeds supported bounds') from None


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def validate_report(report):
    """Validate a whole source snapshot; callers cannot supply receipt provenance."""
    _object(report, ('schema', 'family', 'account_ref', 'source_id', 'source_version',
                     'availability', 'freshness', 'windows'), ('reported_at', 'reason'))
    if report['schema'] != 'account_usage_report.v1' or report['family'] not in FAMILIES:
        raise ValueError('unsupported usage schema or family')
    for field in ('account_ref', 'source_id', 'source_version'):
        _id(report[field])
    if report['availability'] not in {'available', 'unavailable', 'error'} or report['freshness'] not in {'current', 'stale', 'unknown'}:
        raise ValueError('invalid usage availability or freshness')
    _time(report.get('reported_at'))
    if 'reason' in report:
        _text(report['reason'])
    windows = report['windows']
    if not isinstance(windows, list) or len(windows) > 32:
        raise ValueError('usage windows must be a bounded list')
    if report['availability'] != 'available' and windows:
        raise ValueError('unavailable/error report cannot carry active values')
    seen = set()
    for window in windows:
        _object(window, ('bucket_id', 'label', 'metric', 'duration_mins', 'value', 'unit', 'semantics'),
                ('period_start', 'period_end', 'reset_at'))
        _id(window['bucket_id']); _text(window['label'])
        if window['metric'] not in {'plan_limit', 'extra_usage'}:
            raise ValueError('unsupported usage metric')
        key = (window['bucket_id'], window['metric'])
        if key in seen:
            raise ValueError('duplicate usage bucket/metric')
        seen.add(key)
        duration = window['duration_mins']
        if duration is not None and (type(duration) is not int or not 0 < duration <= 527040):
            raise ValueError('invalid usage window duration')
        start, end = _time(window.get('period_start')), _time(window.get('period_end'))
        _time(window.get('reset_at'))
        if bool(start) != bool(end) or (start and end <= start):
            raise ValueError('usage period must have ordered start and end')
        if start and duration and (end-start).total_seconds() != duration*60:
            raise ValueError('usage period contradicts duration')
        value, unit, semantics = window['value'], window['unit'], window['semantics']
        if window['metric'] == 'extra_usage' and semantics != 'spent':
            raise ValueError('extra usage requires spent semantics')
        if unit in {'percent', 'tokens'}:
            if semantics not in {'consumed', 'remaining'} or window['metric'] != 'plan_limit':
                raise ValueError('plan usage needs consumed/remaining semantics')
            if value is not None and (type(value) not in {int, float} or not math.isfinite(value)
                                      or value < 0 or (unit == 'percent' and value > 100)
                                      or (unit == 'tokens' and type(value) is not int)):
                raise ValueError('invalid numeric usage value')
        elif isinstance(unit, str) and re.fullmatch(r'[A-Z]{3}', unit):
            if semantics != 'spent' or window['metric'] != 'extra_usage':
                raise ValueError('currency requires extra-usage spent semantics')
            if value is not None:
                try:
                    if not isinstance(value, str) or not re.fullmatch(r'\d{1,16}(\.\d{1,8})?', value) or Decimal(value) < 0:
                        raise ValueError('currency value must be a nonnegative decimal string')
                except InvalidOperation:
                    raise ValueError('invalid currency value') from None
        else:
            raise ValueError('unit must be percent, tokens or an ISO currency code')
    return report


def _validate_bindings(rows):
    if not isinstance(rows, list) or len(rows) > 64:
        raise ValueError('invalid usage qualification policy')
    seen = set()
    for row in rows:
        _object(row, ('reporter', 'reporter_kind', 'reporter_role', 'authorization_ref',
                      'family', 'account_ref', 'source_id', 'source_version', 'qualification_ref'))
        for key in ('reporter', 'account_ref', 'source_id', 'source_version'):
            _id(row[key])
        for key in ('authorization_ref', 'qualification_ref'):
            _text(row[key])
        if row['family'] not in FAMILIES or row['reporter_kind'] not in {'operator', 'seat'} or row['reporter_role'] not in store.PARTICIPANT_ROLES:
            raise ValueError('invalid usage reporter binding')
        key = tuple(row[k] for k in ('reporter', 'family', 'account_ref', 'source_id', 'source_version'))
        if key in seen:
            raise ValueError('duplicate usage reporter binding')
        seen.add(key)
    return rows


def bindings():
    """Read the store-owned qualification without installing or repairing it."""
    from account_usage_control import policy_document
    policy = policy_document()
    return policy['bindings'] if policy else []


def _match(row, actor, report):
    return row['reporter'] == actor and all(row[k] == report[k] for k in ('family', 'account_ref', 'source_id', 'source_version'))


def submit(report, *, presented_token, submission_key=None):
    """Authenticate intake with durable intent and explicit-key replay protection."""
    from account_usage_control import submit as intake
    return intake(report, presented_token=presented_token, submission_key=submission_key)


def report_file(path, *, presented_token, submission_key=None):
    """Explicit file intake only; no native reader or account query."""
    path = Path(path).absolute()
    with directory(path.parent) as fd:
        raw = read(fd, path.name, limit=MAX_REPORT)
    return submit(_json(raw), presented_token=presented_token, submission_key=submission_key)


def _comparability(report):
    windows = report['windows']
    if not windows or any(not (w.get('period_start') and w.get('period_end')) for w in windows):
        return None
    return sorted((w['bucket_id'], w['metric'], w['duration_mins'], w['unit'], w['semantics'],
                   _time(w['period_start']).astimezone(timezone.utc).isoformat(),
                   _time(w['period_end']).astimezone(timezone.utc).isoformat()) for w in windows)


def project(rows, policy, *, seed_comparisons=None):
    """One whole report per account/family; retain conflicts, never sum reporters."""
    groups = {(p['family'], p['account_ref']): [] for p in policy}
    rejected = 0
    for position, row in enumerate(rows):
        try:
            _object(row, ('kind', 'receipt_id', 'observed_at', 'reporter', 'assurance',
                          'binding_sha256', 'qualification_ref', 'report'), ('submission_key', 'report_sha256'))
            report = validate_report(row['report'])
            if 'submission_key' in row or 'report_sha256' in row:
                _id(row['submission_key'])
                if row['report_sha256'] != _digest(report):
                    raise ValueError('usage replay digest mismatch')
            if row['kind'] != 'account-usage-report' or row['assurance'] != 'reported' or not _time(row['observed_at']):
                raise ValueError('untrusted usage receipt')
            valid = [p for p in policy if _match(p, row['reporter'], report) and _digest(p) == row['binding_sha256']
                     and p['qualification_ref'] == row['qualification_ref']]
            if len(valid) != 1:
                raise ValueError('usage receipt no longer has a qualified binding')
            groups[(report['family'], report['account_ref'])].append({**row, 'position': position})
        except (KeyError, TypeError, ValueError):
            rejected += 1
    accounts = []
    for (family, account), history in sorted(groups.items()):
        selected = None
        for row in history:
            row['comparison'] = (seed_comparisons or {}).get(row['receipt_id'], 'not comparable / first observation')
            if selected:
                a, b = selected['report'], row['report']
                comparable = _comparability(a) is not None and _comparability(a) == _comparability(b)
                if comparable:
                    row['comparison'] = 'same period; conflict' if a['windows'] != b['windows'] else 'same period; agrees'
                    if a.get('reported_at') and b.get('reported_at') and _time(b['reported_at']) < _time(a['reported_at']):
                        row['comparison'] += '; out of order, retained as history'
                        continue
            selected = row
        report = selected['report'] if selected else None
        windows = report['windows'] if report and report['availability'] == 'available' else []
        items = []
        metrics = [('Seven-day usage', 'plan_limit', 10080)] if family == 'Codex' else [('Plan limits', 'plan_limit', None), ('Extra usage', 'extra_usage', None)]
        for label, metric, duration in metrics:
            matches = [w for w in windows if w['metric'] == metric and (duration is None or w['duration_mins'] == duration)]
            items.append({'label': label, 'availability': 'available' if matches else 'unavailable', 'windows': matches})
        accounts.append({'family': family, 'account_ref': account, 'selected': selected, 'items': items,
                         'history': history, 'selection': 'latest comparable source time; otherwise receipt order; whole snapshots only'})
    for family in sorted(FAMILIES - {a['family'] for a in accounts}):
        labels = ['Seven-day usage'] if family == 'Codex' else ['Plan limits', 'Extra usage']
        accounts.append({'family': family, 'account_ref': None, 'selected': None, 'history': [],
                         'items': [{'label': label, 'availability': 'unavailable', 'windows': []} for label in labels]})
    return {'status': 'ok', 'accounts': accounts, 'rejected_receipts': rejected, 'read_at': store.now_iso(),
            'notice': 'Reports are observations, not account queries. No cap or automatic action.'}


def snapshot():
    """Read-only projection under the usage policy fence; never repair on read."""
    from account_usage_control import publish
    return publish(lambda result: result)
