"""Read-only qualification of an installer's embedded interpreter.

Run imports, never a CLI operation. Isolated mode, a minimal environment and
disabled bytecode keep the probe independent of the operator's store and token.
This binds the entry modules, not every library or future runtime byte.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess

from claude_session_start import Stop, bounded_command, interpreter_identity

MODULES = ('orch_cli', 'agy_sidecar', 'wake_hook_agy')
ROOT = Path(__file__).resolve().parent


def qualify(python, *, modules=MODULES, root=ROOT):
    """Import the fixed product entry modules selected by the calling installer."""
    executable = Path(python)
    if not executable.is_absolute():
        raise ValueError('interpreter_path_invalid')
    try:
        resolved, sha = interpreter_identity(executable)
    except Stop as exc:
        raise ValueError(str(exc)) from None
    expected = {name: {'path': str(root / (name + '.py')),
                       'sha256': hashlib.sha256((root / (name + '.py')).read_bytes()).hexdigest()}
                for name in modules}
    # No store locator, credential, app environment or user Python search path
    # is inherited. /dev/null is intentionally not a home directory.
    code = ('import hashlib,importlib,json; from pathlib import Path; '
            'names=' + repr(modules) + '; '
            'mods={n:Path(importlib.import_module(n).__file__).resolve() for n in names}; '
            'print(json.dumps({n:{"path":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()} '
            'for n,p in mods.items()},sort_keys=True))')
    try:
        raw = bounded_command([str(executable), '-I', '-B', '-c', code], cwd=root,
                              env={'HOME': '/dev/null', 'PATH': '/usr/bin:/bin',
                                   'LANG': 'C', 'LC_ALL': 'C'}, timeout=5)
        observed = json.loads(raw)
    except (OSError, ValueError, Stop, subprocess.SubprocessError):
        raise ValueError('interpreter_product_import_failed') from None
    if observed != expected:
        raise ValueError('interpreter_product_origin_mismatch')
    try:
        after = interpreter_identity(executable)
    except Stop as exc:
        raise ValueError(str(exc)) from None
    if after != (resolved, sha):
        raise ValueError('interpreter_changed_during_probe')
    return {'python': str(executable), 'python_realpath': str(resolved),
            'python_sha256': sha, 'modules': expected}
