"""Daemon's bounded pane read: only a state class escapes the capture boundary."""
import hashlib
import json
import time

import store
import tmux_bridge
from pane_state import StateMemory, ScreenState, analyze, MAX_SCREEN_CHARS
from seat_socket import registered_session, registered_socket

memory = StateMemory()
sampled_at = None


def eligible(row):
    return (row.get("hosting_kind") == "tmux-hosted" and store.has_mailbox(row)
            and not store.inactive_participant(row))


def binding(seat, registry):
    row = registry[seat]
    if not eligible(row):
        raise ValueError("not an active terminal seat")
    value = [seat, registered_socket(seat, registry), registered_session(row),
             store.normalize_family(row.get("family")), row.get("hosting_declared_at"),
             row.get("provisioned_home"), row.get("workspace_dir")]
    return hashlib.sha256(json.dumps(value, separators=(",", ":"), sort_keys=True).encode()).hexdigest()


def read_observation(seat, registry):
    """No attach, no keystroke, no history export, and no raw diagnostic return.

    capture-pane takes only the current screen (start row 0), not scrollback.
    Matching is further bounded to the last 20 nonempty lines / 16 KiB.
    Probe failures are unknown, not proof that the process is dead.
    """
    try:
        socket = registered_socket(seat, registry)
        session = registered_session(registry[seat])
        result = tmux_bridge._run_tmux("-S", socket, "has-session", "-t", session)
        if not result.ok:
            # tmux's standard absence, not any transport error, proves dead.
            state = "dead" if not result.timed_out and (
                result.stderr.startswith("can't find session:")
                or result.stderr.startswith("no server running on ")) else "unknown"
            return ScreenState(state)
        result = tmux_bridge._run_tmux("-S", socket, "capture-pane", "-p", "-t", session, "-S", "0")
        if not result.ok or len(result.stdout) > MAX_SCREEN_CHARS:
            return ScreenState("unknown")
        return analyze(store.normalize_family(registry[seat].get("family")), result.stdout)
    except (OSError, ValueError, TypeError, KeyError, OverflowError):
        return ScreenState("unknown")


def read_class(seat, registry):
    return read_observation(seat, registry).state


def observe(seat, registry):
    try:
        key = binding(seat, registry)
    except (OSError, ValueError, TypeError, KeyError, OverflowError):
        return "unknown"
    observed = read_observation(seat, registry)
    return memory.observe(seat, key, observed.state, time.monotonic(),
        input_region_found=observed.input_region_found, reset_time=observed.reset_time).state


def report_limit(seat, registry):
    """Only called by the credential-checked daemon; the sole durable exception."""
    import receipts
    try:
        key = binding(seat, registry)
    except (OSError, ValueError, TypeError, KeyError, OverflowError):
        return
    episode = memory.limit_notice_due(seat, key)
    if episode is not None:
        # Claim before the write: an uncertain fsync result must not cause a
        # duplicate notice or repeated retries. No pointer is enabled by failure.
        memory.mark_reported(seat, key, episode)
        try:
            receipts.append_durable({"kind": "pane-limit", "seat": seat, "class": "limit", "ts": store.now_iso()})
        except (OSError, ValueError):
            # Static diagnostic only; never an exception containing captured text.
            print("pane-state notice outcome unavailable", flush=True)


def refresh(registry, *, report=False):
    global sampled_at
    seats = {seat for seat, row in registry.items() if eligible(row)}
    memory.retain(seats)
    for seat in sorted(seats):
        observe(seat, registry)
        if report:
            report_limit(seat, registry)
    sampled_at = time.monotonic()


def projection(registry):
    # Preserve startup progress evidence without persisting the old runtime file.
    if sampled_at is None or not 0 <= time.monotonic() - sampled_at < 15:
        raise ValueError("daemon observation pass unavailable")
    rows = []
    for seat in sorted(registry):
        try:
            key = binding(seat, registry)
        except (OSError, ValueError, TypeError, KeyError, OverflowError):
            continue
        item = memory.current(seat, key)
        if item:
            rows.append({"seat": seat, "binding": key, "class": item.state,
                         "changed_at": item.changed_at, "measured_at": item.measured_at,
                         "reset_time": item.reset_time})
    return rows
