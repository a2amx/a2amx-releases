"""One bounded, authenticated observation of a seat's unread inbox.

The command never fetches mail, creates locks, repairs a journal, or emits a
seat-act. Existing authentication and delivery predicates remain authoritative.
"""
from __future__ import annotations

from contextlib import ExitStack, contextmanager
import fcntl
import json
import math
import os
from pathlib import Path
import stat
import time

import store

POLL_SECONDS = 5.0
MAX_TIMEOUT_SECONDS = 7200
MAIL = 0
TIMEOUT = 3
ERROR = 1
AUTH_ERROR = 77
SMALL_LIMIT = 1024 * 1024
JOURNAL_LIMIT = 64 * 1024 * 1024  # Unconsumed inbox suffix.
RECEIPT_JOURNAL_LIMIT = 256 * 1024 * 1024


class Refused(Exception):
    def __init__(self, reason, code=ERROR):
        self.reason, self.code = reason, code


class Busy(Exception):
    pass


@contextmanager
def _existing_lock(path, *, optional=False):
    """Join the writer's fence without creating a file or waiting under a lock."""
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except FileNotFoundError:
        if not optional:
            raise Refused('store_lock_missing') from None
        yield
        return
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise Refused('store_lock_invalid')
        try:
            fcntl.flock(fd, fcntl.LOCK_SH | fcntl.LOCK_NB)
        except BlockingIOError:
            raise Busy() from None
        yield fd
    finally:
        os.close(fd)


def _bytes(path, limit, *, missing=None, offset=0, secret=False, opened_fd=None):
    try:
        fd = (os.dup(opened_fd) if opened_fd is not None else
              os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK))
    except FileNotFoundError:
        if missing is not None:
            return missing
        raise Refused('file_missing') from None
    with os.fdopen(fd, 'rb') as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode):
            raise Refused('file_invalid')
        if secret and (info.st_uid != os.getuid() or info.st_mode & 0o077):
            raise Refused('token_file_invalid', AUTH_ERROR)
        # Match inbox rotation handling; the retained seen ids still dedupe.
        if offset > info.st_size:
            offset = 0
        stream.seek(offset)
        raw = stream.read(limit + 1)
    if len(raw) > limit:
        raise Refused('read_limit')
    return raw


def _json(path, *, missing=None):
    raw = _bytes(path, SMALL_LIMIT, missing=missing)
    return json.loads(raw)


def _rows(path, *, offset=0, limit=JOURNAL_LIMIT, append_lock=False):
    if append_lock:
        with _existing_lock(path, optional=True) as fd:
            if fd is None:
                # Observe absence once. Reopening here could race initial
                # creation and read an append without having joined its lock.
                return []
            raw = _bytes(path, limit, offset=offset, opened_fd=fd)
    else:
        raw = _bytes(path, limit, missing=b'', offset=offset)
    if raw and not raw.endswith(b'\n'):
        raise Refused('incomplete_journal')
    rows = [json.loads(line) for line in raw.splitlines() if line.strip()]
    if any(not isinstance(row, dict) for row in rows):
        raise Refused('invalid_journal')
    return rows


def unread(presented_token, seat):
    """Read under the existing launch/token/registry -> cursor -> receipt order.

    Missing cursor/receipt locks are tolerated without creation. Inbox and
    receipt reads join the append lock on the exact descriptor read, with Busy on
    contention and an empty snapshot for a not-yet-created inbox. Like any
    readiness check, the result reserves no delivery for its caller.
    """
    import receipts
    import recall
    store.require_bound_store()
    with ExitStack() as stack:
        for path in (store.RUNTIME_LAUNCH_FENCE_LOCK, store.TOKENS_LOCK, store.REGISTRY_LOCK):
            stack.enter_context(_existing_lock(path))
        # Reject a missing/damaged registry instead of the legacy seed fallback.
        participants = _json(store.PARTICIPANTS_FILE)
        tokens = _json(store.TOKENS_FILE)
        if not isinstance(participants, dict) or not isinstance(tokens, dict):
            raise Refused('invalid_auth_state', AUTH_ERROR)
        rec, _ = store._verdict_unlocked(presented_token, tokens)
        if (rec is None or rec.get('participant_id') != seat
                or rec.get('scope') != store.SEAT_SCOPE or rec.get('surface') != 'terminal'):
            raise Refused('identity_refused', AUTH_ERROR)
        if not isinstance(participants.get(seat), dict) or not store.has_mailbox(participants[seat]):
            raise Refused('mailbox_required', AUTH_ERROR)
        stack.enter_context(_existing_lock(store.cursor_path(seat).with_suffix('.lock'), optional=True))
        stack.enter_context(_existing_lock(receipts.path().with_suffix('.nudge.lock'), optional=True))
        cursor = _json(store.cursor_path(seat), missing=b'{"offset":0}')
        offset = cursor.get('offset') if isinstance(cursor, dict) else None
        if type(offset) is not int or offset < 0:
            raise Refused('invalid_cursor')
        seen = _json(store._seen_path(seat), missing=b'[]')
        if not isinstance(seen, list) or any(not isinstance(mid, str) for mid in seen):
            raise Refused('invalid_seen_state')
        candidates = [row for row in _rows(store.inbox_path(seat), offset=offset, limit=JOURNAL_LIMIT, append_lock=True)
                      if isinstance(row.get('id'), str) and row['id']
                      and row['id'] not in seen and seat in store.mailbox_targets(row)
                      and row.get('actionable') is not False]
        if not candidates:
            return False
        journal = _rows(receipts.path(), limit=RECEIPT_JOURNAL_LIMIT, append_lock=True)
        # Reuse the receipt path's committed-batch handling, including the crash
        # window before per-message FETCHED rows have materialized. No recovery.
        fetched = {mid for mid, row in receipts._delivery_transitions(journal)
                   if row.get('seat') == seat and row.get('event') == 'FETCHED'}
        edges = recall.graph(journal)
        return any(row['id'] not in fetched and not store.delivery_blocked(row, recall_edges=edges)
                   for row in candidates)


def wait(token_file, seat, timeout, *, clock=time.monotonic, sleep=time.sleep, observe=unread):
    if not isinstance(seat, str) or not store.PARTICIPANT_ID_RE.fullmatch(seat):
        raise Refused('invalid_seat')
    try:
        seconds = float(timeout)
    except (ValueError, TypeError, OverflowError):
        raise Refused('invalid_timeout') from None
    if not math.isfinite(seconds) or not 0 <= seconds <= MAX_TIMEOUT_SECONDS:
        raise Refused('invalid_timeout')
    if not token_file:
        raise Refused('token_file_required', AUTH_ERROR)
    token = _bytes(Path(token_file).expanduser(), 4096, secret=True).decode('utf-8').strip()
    if not token:
        raise Refused('token_file_empty', AUTH_ERROR)
    deadline = clock() + seconds
    busy = False
    while True:
        poll_started = clock()
        try:
            if observe(token, seat):
                return MAIL, 'wait: mail'
            busy = False
        except Busy:
            busy = True
        remaining = deadline - clock()
        if remaining <= 0:
            if busy:
                raise Refused('snapshot_busy')
            return TIMEOUT, 'wait: timeout'
        # Never poll more frequently than once per five seconds, including the
        # last partial interval. A timeout is an observation, never a fetch.
        next_poll = poll_started + POLL_SECONDS
        sleep(max(0, min(next_poll, deadline) - clock()))
        if clock() < next_poll:
            if busy:
                raise Refused('snapshot_busy')
            return TIMEOUT, 'wait: timeout'


def run(args):
    try:
        code, line = wait(args.token_file, args.seat, args.timeout)
    except Refused as exc:
        code, line = exc.code, 'wait: error ' + exc.reason
    except KeyboardInterrupt:
        code, line = 130, 'wait: error interrupted'
    except Exception:
        # File contents, paths, user input and exception text can contain secrets.
        code, line = ERROR, 'wait: error observation_unavailable'
    print(line)
    return code
