"""Seat installation facade; private desktop implementation is optional.

CLI installation belongs to the common product. Desktop render/remove code is
kept outside its export; invoking that capability requires the private module.
"""
from desktop_support import optional, require
import stage1_features


def refusal_reason(error):
    if isinstance(error, stage1_features.NotOffered):
        raise error
    implementation = optional('inapp_install')
    return implementation.refusal_reason(error) if implementation is not None else 'desktop_not_offered'


def claude_install(**kwargs):
    return require('inapp_install').claude_install(**kwargs)


def codex_install(**kwargs):
    return require('inapp_install').codex_install(**kwargs)


def claude_remove(**kwargs):
    return require('inapp_install').claude_remove(**kwargs)


def codex_remove(**kwargs):
    return require('inapp_install').codex_remove(**kwargs)


def _private_entry(module):
    implementation = optional(module)
    if implementation is None:
        import sys
        print('desktop hook not offered in this installation', file=sys.stderr)
        return 1
    return implementation.main()


def agy_hook_main():
    """Keep the desktop console alias functional only with its implementation."""
    return _private_entry('wake_hook_agy')


def agy_install_main():
    """Preserve the private legacy installer's own refusal when it is supplied."""
    return _private_entry('wake_hook_install_agy')
