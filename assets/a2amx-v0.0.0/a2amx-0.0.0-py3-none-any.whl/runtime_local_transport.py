"""Local JSONL/stdio implementation of :mod:`runtime_transport`.

This is the only B-C1 module allowed to know that the peer is a subprocess.
It owns Popen, pid/birth/process-group evidence, pipes, reader/EOF state and
local teardown.  Those details are translated into an opaque, authenticated
``PeerIdentityReceipt`` before the location-neutral protocol host sees them.

B-C1 is dormant: this class is exercised only with the fake app-server.  It is
not wired into ``runtime_supervisor.launch`` and does not arm a real adapter.
An exact environment map prevents ambient inheritance but is not a readable-
root boundary; Codex credential containment remains an explicit B-C4 blocker.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import queue
import select
import subprocess
import threading
import time
from dataclasses import dataclass
from typing import Callable, Dict, Mapping, Sequence

from runtime_transport import (
    JsonObject,
    PeerIdentityReceipt,
    TransportError,
    TransportHealth,
    TransportTimeout,
    require_deadline,
)


MESSAGE_MAX_BYTES = 1_048_576
MESSAGE_QUEUE_MAX = 256
READ_CHUNK_BYTES = 65_536


def _reject_json_constant(value: str) -> None:
    raise ValueError(f"non-finite JSON constant {value!r}")


def _strict_json_float(value: str) -> float:
    parsed = float(value)
    if not math.isfinite(parsed):
        raise ValueError("non-finite JSON number")
    return parsed


def _strict_json_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON object key {key!r}")
        result[key] = value
    return result


@dataclass(frozen=True)
class LocalPeerIdentityEvidence:
    """Concrete evidence consumed only by the trusted local registrar."""

    pid: int
    process_birth: str
    process_group: int
    command_sha256: str

    @property
    def binding_sha256(self) -> str:
        raw = json.dumps({
            "command_sha256": self.command_sha256,
            "pid": self.pid,
            "process_birth": self.process_birth,
            "process_group": self.process_group,
        }, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hashlib.sha256(raw).hexdigest()


PeerEvidenceRegistrar = Callable[
    [LocalPeerIdentityEvidence, float], PeerIdentityReceipt]
IdentityProbe = Callable[
    [int, Sequence[str], float], LocalPeerIdentityEvidence]


def _clean_command(argv: Sequence[str]) -> tuple[str, ...]:
    if isinstance(argv, (str, bytes)) or not argv:
        raise ValueError("argv must be a non-empty sequence")
    clean = tuple(argv)
    if not all(isinstance(arg, str) and arg and "\0" not in arg for arg in clean):
        raise ValueError("argv entries must be non-empty strings without NUL")
    return clean


def _command_sha256(argv: Sequence[str]) -> str:
    raw = json.dumps(list(argv), separators=(",", ":"),
                     ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _default_identity_probe(pid: int, argv: Sequence[str],
                            deadline: float) -> LocalPeerIdentityEvidence:
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise TransportTimeout("peer identity deadline expired")
    out = subprocess.run(
        ["ps", "-o", "lstart=", "-p", str(pid)],
        capture_output=True, text=True, timeout=min(5.0, remaining), check=False,
        env={"PATH": os.environ.get("PATH", "/usr/bin:/bin")},
    )
    birth = out.stdout.strip() if out.returncode == 0 else ""
    if not birth:
        raise TransportError("local peer died before identity evidence")
    try:
        group = os.getpgid(pid)
    except OSError as exc:
        raise TransportError("local peer group identity is unavailable") from exc
    return LocalPeerIdentityEvidence(
        pid=pid, process_birth=birth, process_group=group,
        command_sha256=_command_sha256(argv),
    )


class LocalJsonlStdioTransport:
    """Bounded JSONL channel over one locally-owned subprocess."""

    def __init__(self, argv: Sequence[str], *,
                 evidence_registrar: PeerEvidenceRegistrar,
                 cwd: str | None = None,
                 env: Mapping[str, str] | None = None,
                 identity_probe: IdentityProbe = _default_identity_probe,
                 max_message_bytes: int = MESSAGE_MAX_BYTES,
                 max_queued_messages: int = MESSAGE_QUEUE_MAX) -> None:
        self._argv = _clean_command(argv)
        if cwd is not None and (not isinstance(cwd, str) or not os.path.isabs(cwd)):
            raise ValueError("local transport cwd must be absolute")
        self._cwd = cwd
        supplied_env = {} if env is None else dict(env)
        if not all(isinstance(k, str) and k and "=" not in k and "\0" not in k
                   and isinstance(v, str) and "\0" not in v
                   for k, v in supplied_env.items()):
            raise ValueError("local transport env must contain clean string pairs")
        self._env: Dict[str, str] = supplied_env
        if not callable(evidence_registrar):
            raise ValueError("evidence_registrar is required")
        self._registrar = evidence_registrar
        self._identity_probe = identity_probe
        if isinstance(max_message_bytes, bool) or max_message_bytes <= 0:
            raise ValueError("max_message_bytes must be positive")
        if isinstance(max_queued_messages, bool) or max_queued_messages <= 0:
            raise ValueError("max_queued_messages must be positive")
        self._max_message_bytes = int(max_message_bytes)
        self._messages: queue.Queue[JsonObject] = queue.Queue(
            maxsize=int(max_queued_messages))
        self._process: subprocess.Popen[bytes] | None = None
        self._reader: threading.Thread | None = None
        self._receipt: PeerIdentityReceipt | None = None
        self._failure: str | None = None
        self._closing = False
        self._state_lock = threading.Lock()
        self._write_lock = threading.Lock()

    def _set_failure(self, detail: str) -> None:
        with self._state_lock:
            if self._failure is None and not self._closing:
                self._failure = detail

    def _get_failure(self) -> str | None:
        with self._state_lock:
            return self._failure

    def open(self, *, deadline: float) -> PeerIdentityReceipt:
        deadline = require_deadline(deadline)
        if time.monotonic() >= deadline:
            raise TransportTimeout("open deadline expired")
        if self._process is not None:
            raise TransportError("transport is already open")
        try:
            process = subprocess.Popen(
                list(self._argv), cwd=self._cwd, env=self._env,
                stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL, bufsize=0,
            )
            self._process = process
            evidence = self._identity_probe(process.pid, self._argv, deadline)
            if time.monotonic() >= deadline:
                raise TransportTimeout("peer identity deadline expired")
            receipt = self._registrar(evidence, deadline)
            if time.monotonic() >= deadline:
                raise TransportTimeout("peer evidence registration deadline expired")
            if not isinstance(receipt, PeerIdentityReceipt):
                raise TransportError("peer evidence registrar returned no receipt")
            if receipt.binding_sha256 != evidence.binding_sha256:
                raise TransportError("peer evidence receipt is not bound to observed identity")
            if process.poll() is not None:
                raise TransportError("local peer exited before transport activation")
            if process.stdin is None or process.stdout is None:
                raise TransportError("local peer pipes are unavailable")
            os.set_blocking(process.stdin.fileno(), False)
            self._receipt = receipt
            self._reader = threading.Thread(
                target=self._read_messages, name="orch-local-jsonl-reader", daemon=True)
            self._reader.start()
            return receipt
        except Exception:
            # Opening and rollback share one caller-supplied absolute budget.
            self._teardown(deadline)
            raise

    def _read_messages(self) -> None:
        process = self._process
        if process is None or process.stdout is None:
            self._set_failure("reader started without a peer pipe")
            return
        fd = process.stdout.fileno()
        buffered = bytearray()
        try:
            while True:
                chunk = os.read(fd, READ_CHUNK_BYTES)
                if not chunk:
                    if buffered:
                        self._set_failure("peer EOF split a JSONL frame")
                    else:
                        self._set_failure("peer EOF")
                    return
                buffered.extend(chunk)
                if len(buffered) > self._max_message_bytes and b"\n" not in buffered:
                    self._set_failure("peer JSONL frame exceeds size bound")
                    return
                while True:
                    newline = buffered.find(b"\n")
                    if newline < 0:
                        break
                    if newline > self._max_message_bytes:
                        self._set_failure("peer JSONL frame exceeds size bound")
                        return
                    raw = bytes(buffered[:newline])
                    del buffered[:newline + 1]
                    if not raw:
                        self._set_failure("peer emitted an empty JSONL frame")
                        return
                    try:
                        message = json.loads(
                            raw, parse_constant=_reject_json_constant,
                            parse_float=_strict_json_float,
                            object_pairs_hook=_strict_json_object)
                    except (UnicodeDecodeError, json.JSONDecodeError, ValueError):
                        self._set_failure("peer emitted non-strict JSON")
                        return
                    if not isinstance(message, dict):
                        self._set_failure("peer JSONL frame is not an object")
                        return
                    try:
                        self._messages.put_nowait(message)
                    except queue.Full:
                        self._set_failure("peer message queue overflow")
                        return
                if len(buffered) > self._max_message_bytes:
                    self._set_failure("peer JSONL frame exceeds size bound")
                    return
        except OSError as exc:
            self._set_failure(f"peer reader failed: {type(exc).__name__}")

    def send(self, message: JsonObject, *, deadline: float) -> None:
        deadline = require_deadline(deadline)
        if not isinstance(message, dict):
            raise TypeError("transport messages must be objects")
        try:
            body = json.dumps(message, separators=(",", ":"),
                              ensure_ascii=False, allow_nan=False).encode("utf-8") + b"\n"
        except (TypeError, ValueError) as exc:
            raise TransportError("message is not strict JSON") from exc
        if len(body) - 1 > self._max_message_bytes:
            raise TransportError("outbound JSONL frame exceeds size bound")
        process = self._process
        if process is None or process.stdin is None or self._receipt is None:
            raise TransportError("transport is not open")
        failure = self._get_failure()
        if failure is not None:
            raise TransportError(failure)
        with self._write_lock:
            offset = 0
            fd = process.stdin.fileno()
            while offset < len(body):
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    self._set_failure("outbound request deadline expired")
                    raise TransportTimeout("send deadline expired")
                if process.poll() is not None:
                    self._set_failure("peer exited during send")
                    raise TransportError("peer exited during send")
                try:
                    _, writable, _ = select.select([], [fd], [], remaining)
                except OSError as exc:
                    self._set_failure("peer pipe failed during send")
                    raise TransportError("peer pipe failed during send") from exc
                if not writable:
                    self._set_failure("outbound request deadline expired")
                    raise TransportTimeout("send deadline expired")
                try:
                    offset += os.write(fd, body[offset:])
                except BlockingIOError:
                    continue
                except (BrokenPipeError, OSError) as exc:
                    self._set_failure("peer pipe failed during send")
                    raise TransportError("peer pipe failed during send") from exc

    def receive(self, *, deadline: float) -> JsonObject:
        deadline = require_deadline(deadline)
        if self._process is None or self._receipt is None:
            raise TransportError("transport is not open")
        while True:
            try:
                return self._messages.get_nowait()
            except queue.Empty:
                pass
            failure = self._get_failure()
            if failure is not None:
                raise TransportError(failure)
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TransportTimeout("receive deadline expired")
            try:
                return self._messages.get(timeout=min(remaining, 0.05))
            except queue.Empty:
                continue

    def health(self) -> TransportHealth:
        failure = self._get_failure()
        if failure is not None:
            return TransportHealth(False, failure)
        process = self._process
        reader = self._reader
        if process is None or self._receipt is None:
            return TransportHealth(False, "not open")
        if process.poll() is not None:
            return TransportHealth(False, "peer exited")
        if reader is None or not reader.is_alive():
            return TransportHealth(False, "reader stopped")
        return TransportHealth(True)

    def close(self, *, deadline: float) -> None:
        self._teardown(require_deadline(deadline))

    def _teardown(self, deadline: float) -> None:
        with self._state_lock:
            self._closing = True
        process = self._process
        if process is None:
            return
        if process.stdin is not None:
            try:
                process.stdin.close()
            except OSError:
                pass
        if not self._wait_process(process, deadline):
            try:
                process.terminate()
            except ProcessLookupError:
                pass
            if not self._wait_process(process, deadline, cap=0.5):
                try:
                    process.kill()
                except ProcessLookupError:
                    pass
                self._wait_process(process, deadline, cap=0.5)
        if process.stdout is not None:
            try:
                process.stdout.close()
            except OSError:
                pass
        reader = self._reader
        if reader is not None and reader is not threading.current_thread():
            reader.join(timeout=max(0.0, min(0.5, deadline - time.monotonic())))
        self._receipt = None

    @staticmethod
    def _wait_process(process: subprocess.Popen, deadline: float,
                      *, cap: float | None = None) -> bool:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return process.poll() is not None
        timeout = remaining if cap is None else min(cap, remaining)
        try:
            process.wait(timeout=timeout)
            return True
        except subprocess.TimeoutExpired:
            return False
