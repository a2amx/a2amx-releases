#!/usr/bin/env python3
"""orch-read — the standard read of a seat's store mail: FETCH (consume), FILE, DIGEST.

Runs `orch --token-file PATH inbox <Seat> --json --save-home [HOME]`. The authenticated
store command saves a complete 0600 batch under the registered seat home's .orch/inbox
before committing FETCHED or the cursor. The wrapper then prints one line naming the saved
batch and, as one JSON array, each message's delivery view (delivery_view.py): the record
without its repeated envelope lines and without a validator report that is all PASS. The
saved batch keeps every record whole. It never consumes mail before filing it. Use it
after each wake.

Usage: orch-read --token-file PATH <Seat> [--seat-home DIR] [--peek] [--no-body]
  --peek     look without consuming (no delivery receipt; nothing filed) — for a deliberate check only, never the habit
  --no-body  the delivery views without each message's text
Env: ORCH_BIN overrides the orch executable. The token path passes through untouched and is never read here.
"""
import json, os, subprocess, sys
from pathlib import Path

import delivery_view
import product_identity

def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    token = None; seat = None; home = None; peek = False; body = True
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == '--token-file': token = argv[i + 1]; i += 2; continue
        if a == '--seat-home': home = argv[i + 1]; i += 2; continue
        if a == '--peek': peek = True; i += 1; continue
        if a == '--no-body': body = False; i += 1; continue
        if a.startswith('-'): print(f'error: unknown option {a}', file=sys.stderr); return 1
        seat = a; i += 1
    if not token or not seat:
        print(f'usage: {product_identity.command("read")} --token-file PATH <Seat> [--seat-home DIR] [--peek] [--no-body]', file=sys.stderr); return 1
    home = str(Path(home).expanduser().resolve()) if home else None
    profile = product_identity.load()
    command = ([sys.executable, '-I', '-m', 'orch_cli'] if profile.is_public else
               [os.environ.get('ORCH_BIN', profile.command())])
    cmd = [*command, '--token-file', token, 'inbox', seat, '--json'] + (['--peek'] if peek else [])
    if not peek:
        cmd += ['--save-home'] + ([home] if home else [])
        from harness_facts import collect
        report = collect(os.environ)
        if report is not None:
            cmd += ['--harness-json', json.dumps(report)]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        sys.stderr.write(proc.stderr); return proc.returncode
    try:
        result = json.loads(proc.stdout)
        msgs = result if peek else result['messages']
        saved = None if peek else result['inbox_path']
        if not isinstance(msgs, list) or (not peek and not isinstance(saved, str)):
            raise ValueError('invalid saved inbox result')
    except (ValueError, TypeError, KeyError):
        print('error: unparsable inbox output; check the seat inbox for the durable batch', file=sys.stderr)
        return 1
    if not peek:
        print(f'{seat}: fetched {len(msgs)} message(s) → {saved}')
    else:
        print(f'{seat}: {len(msgs)} message(s) (peek; nothing consumed, nothing filed)')
    # One JSON array, as the hook prints it, empty included: a text's line ends and quotes stay
    # escaped, so no message can print a line that reads as another message or another sender.
    shown = msgs if body else [{k: v for k, v in m.items() if k != 'text'}
                               if isinstance(m, dict) else m for m in msgs]
    print(delivery_view.dumps(shown))
    return 0

if __name__ == '__main__': sys.exit(main(sys.argv[1:]))
