"""Governance-plane message authority verification (ORCH_SPEC_01 D-VET-4).

This module owns the authority-row policy and the FAIL-to-disposition mapping.
The store gate may call :func:`verify`, record the returned typed verdict, and
apply its disposition mechanically; it must not duplicate these rights rules.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Mapping


PASS = "PASS"
FAIL = "FAIL"
DISPOSITIONS = frozenset({"PASS", "DROP", "QUARANTINE", "FLAG"})
DECISION_ROLES = frozenset({"chief_of_staff", "human_authority"})


def recall_bytes(payload):
    import rfc8785
    return b"orch.recall.v1\x00" + rfc8785.dumps(payload)


def verify_recall(*, actor, credential, original, participants, request, reason, unread_only, now):
    """D-ENV-6: same authenticated author, or a scoped principal signature.

    A human-authority token/role alone is not a signed record. The signature
    binds the exact original bytes, store, options, invoker and short expiry.
    """
    from recall import Refused
    signed_original = original.get('object_class') == 'authority' or original.get('signature_class') in {'tier-2', 'tier-3'}
    if actor == original.get('from') and not signed_original:
        return
    row = participants.get(actor, {})
    if (credential.get('role') != 'human_authority' or row.get('role') != 'human_authority'
            or row.get('kind') != 'human' or row.get('retired_at') or row.get('parked_at')):
        raise Refused('not_the_sender')
    import base64
    import quarantine
    from cryptography.exceptions import InvalidSignature, UnsupportedAlgorithm
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    expected = {'v': 1, 'kind': 'message-recall', 'actor': actor, 'key_id': row.get('signing_key_id'),
                'message_id': original['id'], 'message_sha256': quarantine.fingerprint(original),
                'store_ref': quarantine.store_ref(), 'reason': reason, 'unread_only': unread_only}
    try:
        if type(request) is not dict or set(request) != {'payload', 'signature'}:
            raise ValueError()
        payload = request['payload']
        if (type(payload) is not dict or set(payload) != {*expected, 'expires_at'}
                or type(payload['v']) is not int or type(payload['unread_only']) is not bool
                or any(payload[k] != v for k, v in expected.items())
                or not isinstance(payload['key_id'], str) or not payload['key_id']
                or type(payload['expires_at']) is not int or not now <= payload['expires_at'] <= now + 300):
            raise ValueError()
        key = serialization.load_pem_public_key(row['signing_key'].encode('ascii'))
        if not isinstance(key, Ed25519PublicKey):
            raise ValueError()
        key.verify(base64.b64decode(request['signature'], validate=True), recall_bytes(payload))
    except (KeyError, AttributeError, TypeError, ValueError, InvalidSignature, UnsupportedAlgorithm):
        raise Refused('principal_signed_record_required') from None


class GovernanceKeyRefused(ValueError):
    """A quarantine act did not prove the registered CoS governance key."""


def quarantine_bytes(payload):
    """Domain-separated canonical bytes; never interchangeable with a seat token."""
    import rfc8785
    return b"orch.quarantine.v1\x00" + rfc8785.dumps(payload)


def verify_quarantine(request, *, participants, action, message_id,
                      message_sha256, store_ref, now):
    """D-POKE-2c/D-VET-3: verify the current registered governance key.

    The execution caller holds the registry fence through admission. No token
    role, caller-supplied signature-valid boolean or provisioner helper grants
    this authority. Registration itself remains governance-owned provisioning.
    """
    import base64
    import re
    from cryptography.exceptions import InvalidSignature, UnsupportedAlgorithm
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

    fields = {"v", "kind", "action", "message_id", "message_sha256", "store_ref",
              "actor", "key_id", "request_id", "expires_at"}
    if type(request) is not dict or set(request) != {"payload", "signature"}:
        raise GovernanceKeyRefused("governance_signature_required")
    payload = request["payload"]
    if type(payload) is not dict or set(payload) != fields:
        raise GovernanceKeyRefused("governance_request_invalid")
    expected = {"v": 1, "kind": "quarantine-disposition", "action": action,
                "message_id": message_id, "message_sha256": message_sha256,
                "store_ref": store_ref}
    if type(payload["v"]) is not int or any(payload[k] != v for k, v in expected.items()):
        raise GovernanceKeyRefused("governance_scope_mismatch")
    if action not in {"release", "discard"}:
        raise GovernanceKeyRefused("governance_action_invalid")
    if any(not isinstance(payload[k], str) or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,128}", payload[k])
           for k in ("actor", "key_id", "request_id")):
        raise GovernanceKeyRefused("governance_identity_invalid")
    if type(payload["expires_at"]) is not int or not now <= payload["expires_at"] <= now + 300:
        raise GovernanceKeyRefused("governance_request_expired_or_unbounded")
    actor = participants.get(payload["actor"], {})
    if (actor.get("role") != "chief_of_staff" or actor.get("kind") != "agent"
            or actor.get("retired_at") or actor.get("parked_at")):
        raise GovernanceKeyRefused("governance_actor_not_current_chief")
    if actor.get("signing_key_id") != payload["key_id"]:
        raise GovernanceKeyRefused("governance_key_not_registered")
    try:
        key = serialization.load_pem_public_key(actor["signing_key"].encode("ascii"))
        if not isinstance(key, Ed25519PublicKey):
            raise ValueError()
        signature = base64.b64decode(request["signature"], validate=True)
        key.verify(signature, quarantine_bytes(payload))
    except (KeyError, AttributeError, TypeError, ValueError, InvalidSignature, UnsupportedAlgorithm):
        raise GovernanceKeyRefused("governance_signature_invalid") from None
    return {**_verdict("quarantine-governance-key", PASS, PASS,
                      "current CoS registered Ed25519 governance key verified"),
            "actor": payload["actor"], "key_id": payload["key_id"]}


def allowed_authorities(role: str | None) -> list[str]:
    """Served Phase-A vocabulary; the gate uses this same role decision."""
    return [value for value in ("FYI", "proposal", "relay", "decision")
            if value != "decision" or role in DECISION_ROLES]


def _verdict(row: str, result: str, disposition: str, basis: str) -> dict[str, str]:
    """Construct and validate one typed authority verdict."""
    if result not in {PASS, FAIL} or disposition not in DISPOSITIONS:
        raise ValueError("invalid authority verdict")
    return {"row": row, "result": result, "disposition": disposition, "basis": basis}


def _participants() -> Mapping[str, Mapping[str, Any]]:
    """Load the current governance-owned participant facts lazily."""
    # Import lazily: store is the data owner, while authority remains the only
    # owner of rights interpretation and is independently testable.
    import store
    return store.load_participants()


def _active_expiry(value: Any) -> bool:
    """Return whether an ISO-8601 expiry is timezone-aware and still active."""
    if not isinstance(value, str):
        return False
    try:
        expiry = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return False
    return expiry.tzinfo is not None and expiry > datetime.now(timezone.utc)


def verify(message: Mapping[str, Any], *,
           participants: Mapping[str, Mapping[str, Any]] | None = None,
           superseded: Mapping[str, Any] | None = None) -> dict[str, str]:
    """Return the typed verdict for the applicable authority row.

    ``participants`` and ``superseded`` are injectable snapshots for callers
    and tests.  The Phase-A gate will supply the original record when it wires
    the supersession row; until then a claimed target without that record is
    flagged rather than guessed at.
    """
    if not isinstance(message, Mapping):
        return _verdict("authority-input", FAIL, "DROP", "message is not an object")
    registry = participants if participants is not None else _participants()
    sender = message.get("from")
    envelope = message.get("envelope")
    envelope = envelope if isinstance(envelope, Mapping) else {}

    if message.get("object_class") == "authority":
        boolean_facts = ("signature_valid", "scope_well_formed", "authority_schema_valid")
        invalid = [name for name in boolean_facts if message.get(name) is not True]
        if not _active_expiry(message.get("expiry")):
            invalid.append("expiry")
        if invalid:
            return _verdict("authority-record-admission", FAIL, "DROP",
                            "deterministic authority-record check failed: " + ", ".join(invalid))
        return _verdict("authority-record-admission", PASS, "PASS",
                        "schema, signature, scope, and expiry are mechanically valid")

    applicable: list[dict[str, str]] = []
    signature_class = message.get("signature_class")
    if signature_class in {"tier-2", "tier-3"}:
        valid = message.get("signature_valid") is True
        if signature_class == "tier-3":
            valid = valid and message.get("cosignature_valid") is True
        applicable.append(_verdict(
            "instruction-signature-class", PASS if valid else FAIL,
            "PASS" if valid else "DROP",
            f"{signature_class} signature class " + ("verified" if valid else "invalid")))

    if envelope.get("authority") == "decision":
        role = registry.get(str(sender), {}).get("role")
        # Signed authority objects do not exist in Phase A, so there is no
        # caller-asserted escape hatch here.  A later verifier may add a
        # mechanically verified coverage fact when that object class lands.
        allowed = "decision" in allowed_authorities(role)
        applicable.append(_verdict(
            "decision-authority-consistency", PASS if allowed else FAIL,
            "PASS" if allowed else "QUARANTINE",
            (f"registry role {role!r} may issue decisions" if allowed
             else f"registry role {role!r} has no decision right")))

    if message.get("supersedes") is not None:
        if superseded is None or superseded.get("id") != message.get("supersedes"):
            applicable.append(_verdict(
                "supersedes-write-authority", FAIL, "FLAG",
                "matching superseded record was not supplied for an ownership check"))
        elif not (
            isinstance(sender, str) and sender.strip()
            and isinstance(superseded.get("from"), str)
            and superseded["from"].strip()
        ):
            applicable.append(_verdict(
                "supersedes-write-authority", FAIL, "FLAG",
                "requesting sender and superseded author must be non-empty strings"))
        else:
            role = registry.get(str(sender), {}).get("role")
            allowed = superseded.get("from") == sender or role == "human_authority"
            applicable.append(_verdict(
                "supersedes-write-authority", PASS if allowed else FAIL,
                "PASS" if allowed else "QUARANTINE",
                "same author or principal role required"))

    if not applicable:
        return _verdict("authority-not-applicable", PASS, "PASS",
                        "message carries no authority-class operation")
    # A message may exercise several authority operations.  None may be
    # skipped: return the strongest non-PASS disposition, or a composite PASS.
    rank = {"PASS": 0, "FLAG": 1, "QUARANTINE": 2, "DROP": 3}
    decisive = max(applicable, key=lambda verdict: rank[verdict["disposition"]])
    if len(applicable) == 1:
        return decisive
    failed = decisive["disposition"] != "PASS"
    return _verdict(
        "authority-composite", FAIL if failed else PASS, decisive["disposition"],
        "; ".join(f"{item['row']}: {item['basis']}" for item in applicable))
