"""Pane-attention detection — the ONE definition, imported by both scanners.

`delivery.py` and `psqr_orchestrator.py` each carried a private copy of the
pattern list and the scanning loop, under a standing "TODO dedupe into one
shared module" and a comment asking future editors to keep them in sync by
hand. They drifted exactly the way that invites: a fix landed in one shape and
both copies inherited its defects, and the test that was supposed to guard the
behaviour re-implemented the loop a THIRD time, so it could not have detected
drift in either. One definition removes the whole class.
"""

from __future__ import annotations

from typing import List, Optional

# Distinctive LIVE-prompt / approval-menu strings ONLY.
#
# THE MEMBERSHIP RULE, which is a contract and not a preference: a string belongs
# here only if its presence means a human decision is BLOCKING the agent. Status
# chrome — mode hints, key legends, footers — never qualifies, however reliably it
# sits next to real prompts. A genuine approval prompt always carries its own
# confirmation text; that is what makes it blocking. So a chrome pattern is
# redundant on every real prompt and harmful on every idle pane.
#
# Three strings have been REMOVED under that rule, each after a real false positive:
#   "Action Required"          — matched Gemma's idle "Standing Down — No Action
#                                Required", flagging her red with nothing pending
#   "Press enter to continue"  — over-generic, matched agents' own output
#   "Shift+Tab to accept"      — the Gemini/Claude MODE-TOGGLE footer: permanent
#                                status chrome, never a pending approval (07-31)
#
# THE THIRD ONE IS THE INSTRUCTIVE CASE. It was not removed but SUBTRACTED BACK OUT
# with an exclusion (`ATTENTION_EXCLUDE = ("accept edits",)`), and that one decision
# produced two defects at once:
#   * the exclusion INHERITED THE FOOTER'S WRAP SENSITIVITY — a pane narrow enough to
#     split "accept edits" leaves "…Shift+Tab to accept" matching with nothing to
#     exclude it, so an idle seat lights up permanently; and
#   * it dropped the WHOLE LINE, so a real prompt sharing a line with the footer was
#     skipped entirely — a FALSE NEGATIVE on a pending approval, which this code's
#     own comments called worse than the false positive it was patched for.
# Both are downstream of subtracting a footer out of a list that should never have
# matched it. DELETE THE PATTERN; never exclude around one.
ATTENTION_PATTERNS: List[str] = [
    "Do you want to proceed?",
    "Allow execution",
    "Do you trust",
    "Enter to confirm",
    "Allow once",
    "Yes, and don't ask",
    "YOLO Ctrl+Y",
]

# Only scan the live prompt region — a real approval prompt persists at the bottom
# of the pane, while incidental mentions sit up in scrollback.
ATTENTION_TAIL_LINES = 15


def scan_pane(text: str) -> Optional[str]:
    """Return the pattern proving a pending approval, or None if the pane is idle.

    Blank lines are stripped BEFORE tailing. Gemini leaves a run of blank lines
    below a rendered dialog, so tail-then-filter can slice a window that is
    entirely empty while a prompt sits just above it — a false negative on a
    pending approval. Measured on a live pane: 20 trailing blank lines with a
    dialog pending (Pittman).

    There is deliberately NO exclusion step. Anything that must not fire is kept
    out of ATTENTION_PATTERNS in the first place; see the membership rule above.
    """
    lines = [line for line in text.splitlines() if line.strip()]
    for line in lines[-ATTENTION_TAIL_LINES:]:
        for pattern in ATTENTION_PATTERNS:
            if pattern in line:
                return pattern
    return None
