"""Norm pipeline — deterministic HARD rules at the conversation seam (META_HARNESS_PLAN Stage 4).

Runs inside ``store.send`` before the canonical append and before recipient delivery.
A hard-rule failure is then appended with its in-record vet result for audit, while
recipients never see it (fanout is skipped — invisible via per-recipient cursors)
and the **author** is handed a
structured reason in their own inbox. Never silent: the author always learns why (Appendix K).

Hard rules are DETERMINISTIC (no LLM, no network) — soft/semantic rules (uncredited-restatement,
dissent-smoothing, …) are the referee's job and only ever FLAG, never block (Stage 4 commit 2).

The pipeline is ON by construction.  Its only kill-switch is the receipted
``constitution.json`` setting ``norms.enabled`` (default true).  Rate/loop and
recipient/permission are already enforced upstream; this module preserves the
duplicate-delta rule.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from mirror_diagnostics import record_failure
import constitution

#: Delta rule: look back this far for a self-duplicate, and exempt trivial short messages (acks
#: like "ok"/"done" legitimately repeat — the rule targets re-posted substantive content / loops).
DELTA_WINDOW_SEC = constitution.value("norms.delta_window_sec", 300)
MIN_DELTA_CHARS = constitution.value("norms.min_delta_chars", 40)


def enabled() -> bool:
    """Return the constitution's receipted kill-switch (default ON)."""
    # Only the explicit boolean False is the governed kill-switch. Missing or
    # malformed state must fail closed with vetting enabled.
    return constitution.value("norms.enabled", True) is not False


def _normalize(text: str) -> str:
    """Whitespace- and case-insensitive form for duplicate comparison."""
    return " ".join((text or "").split()).lower()


def check(msg: Dict[str, Any], recent: List[Dict[str, Any]], *,
          min_chars: int | None = None) -> Optional[Dict[str, str]]:
    """Apply the deterministic hard rules to a just-appended ``msg`` given the ``recent`` log
    records (within DELTA_WINDOW_SEC). Returns None if it passes, else a verdict
    ``{rule, reason}`` describing the first violation. Pure — no I/O, no store/ledger import.

    Rules:
      - **delta**: a non-trivial message must not be a normalized-exact duplicate of one of the
        SENDER's OWN recent messages (anti-loop / re-post). Trivial short messages are exempt.
    """
    text = msg.get("text", "") or ""
    threshold = MIN_DELTA_CHARS if min_chars is None else min_chars
    if len(text.strip()) < threshold:
        return None                                  # trivial ack — exempt
    sender = msg.get("from")
    mid = msg.get("id")
    norm = _normalize(text)
    for rec in recent:
        if (rec.get("from") == sender and rec.get("id") != mid
                and _normalize(rec.get("text", "")) == norm):
            return {"rule": "delta",
                    "reason": ("identical to your recent message "
                               f"{rec.get('id')} — add a substantive delta; this turn was not "
                               "broadcast (norm: delta)")}
    return None


def record_block(msg: Dict[str, Any], verdict: Dict[str, str], *,
                 authenticated_actor: str | None = None) -> None:
    """Mirror a quarantine to the ledger as ``norm_check{verdict:block}`` (audit). Isolated — a
    ledger failure never changes the quarantine outcome (same principle as the send mirror)."""
    try:
        import ledger
        claimed_actor = msg.get("from") or "unknown"
        payload = {
            "verdict": verdict.get("disposition", "QUARANTINE").lower(),
            "rule": verdict.get("rule"), "reason": verdict.get("reason"),
            "msg_id": msg.get("id"), "recipients": msg.get("recipients", []),
        }
        if authenticated_actor == claimed_actor:
            actor_id, role = authenticated_actor, None
            payload["authentication"] = "validated_principal"
        else:
            # The caller-selected claim is evidence only.  It must never enter
            # role derivation for a rejected identity (especially System or an
            # unknown id, whose legacy defaults are privileged).
            actor_id, role = "unverified", "reviewer"
            payload["authentication"] = "rejected_unverified"
            payload["claimed_actor"] = claimed_actor
        ledger.emit("norm_check", actor_id=actor_id, role=role, payload=payload)
    except Exception as exc:
        record_failure('norms', exc)


def rejection_record(msg: Dict[str, Any], verdict: Dict[str, str],
                     new_id, now_iso) -> Dict[str, Any]:
    """A ``System`` -> author message carrying the structured reason, to append to the author's
    OWN inbox (never sent through send() — no recursion, and kind='system' keeps it off the guard).
    ``new_id``/``now_iso`` are passed in so this stays store-free/testable."""
    return {
        "id": new_id("msg"),
        "ts": now_iso(),
        "from": "System",
        "to": [msg.get("from")],
        "recipients": [msg.get("from")],
        "kind": "system",
        "text": f"[vet:{verdict.get('disposition', 'QUARANTINE').lower()}:"
                f"{verdict.get('rule')}] {verdict.get('reason')}",
        "meta": {"norm_block": True, "rule": verdict.get("rule"),
                 "vet_disposition": verdict.get("disposition", "QUARANTINE"),
                 "quarantined_msg_id": msg.get("id")},
    }
