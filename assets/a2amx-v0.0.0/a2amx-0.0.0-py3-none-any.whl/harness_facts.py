"""Last-reported harness facts, attributed by an authenticated seat act.

No launch-profile inference, transcript reads, native probes, or unread ledger.
Reports replace the entire previous observation; missing values become unknown.
"""
from datetime import datetime, timezone
import json
import math
import re

FIELDS = frozenset({'model', 'effort', 'context_window', 'context_used_pct', 'reported_at'})


def validate(value):
    if not isinstance(value, dict) or set(value) - FIELDS:
        raise ValueError('invalid harness facts')
    result = dict.fromkeys(FIELDS)
    result.update(value)
    for field in ('model', 'effort'):
        item = result[field]
        if item is not None and (not isinstance(item, str) or
                re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._:/+ -]{0,127}', item) is None):
            raise ValueError('invalid harness text')
    window = result['context_window']
    if window is not None and (type(window) is not int or not 0 < window <= 10**12):
        raise ValueError('invalid context window')
    used = result['context_used_pct']
    # Bound integers before isfinite's float conversion (DJK-HARNESS-1).
    if used is not None and (type(used) not in (int, float) or not 0 <= used <= 100 or not math.isfinite(used)):
        raise ValueError('invalid context usage')
    stamp = result['reported_at']
    if not isinstance(stamp, str) or len(stamp) > 64:
        raise ValueError('reported_at required')
    try:
        parsed = datetime.fromisoformat(stamp)
    except ValueError:
        raise ValueError('invalid reported_at') from None
    if parsed.tzinfo is None:
        raise ValueError('reported_at must name a timezone')
    return result


def collect(environ, metadata=None):
    """Only explicitly supplied metadata; never read a path or native session.

    ORCH_HARNESS_FACTS is an optional JSON environment bridge for qualified
    readers. Native callers can supply the same field set, or a latestModel
    projection. No supplied metadata means no report, never a configured/default
    model guess.
    Absent/invalid optional metadata produces no report and cannot erase an
    earlier observation. Explicit null fields can report newly unavailable facts.
    """
    result = {}
    raw = environ.get('ORCH_HARNESS_FACTS')
    try:
        if raw is not None:
            if len(raw) > 2048:
                raise ValueError('metadata too large')
            result = json.loads(raw)
        if isinstance(metadata, dict):
            result = {**result, **{k: v for k, v in metadata.items() if k in FIELDS}}
            if 'model' not in result and 'latestModel' in metadata:
                result['model'] = metadata['latestModel']
        if not result:
            return None
        result = {**result, 'reported_at': result.get('reported_at') or datetime.now(timezone.utc).isoformat()}
        return validate(result)
    except (TypeError, ValueError, RecursionError):
        return None


def append_act(actor, command, facts):
    """Caller already holds authenticated_registry_act; actor comes from bearer."""
    import receipts
    import store
    value = validate(facts)
    with receipts._nudge_lock():
        receipts._append({'kind': 'seat-act', 'seat': actor, 'command': command,
                          'ts': store.now_iso(), 'harness': value})


def snapshot(participants):
    import receipts
    import store
    allowed = {seat for seat, row in participants.items()
               if row.get('kind') != 'human' and not store.inactive_participant(row)}
    result = {}
    for row in receipts.rows():
        # File order is observation order; a seat's reported clock cannot reorder
        # another report. Refused events and daemon observations never count.
        if (row.get('kind') != 'seat-act' or not isinstance(row.get('seat'), str) or row.get('seat') not in allowed
                or row.get('command') not in {'inbox', 'hook-fetch'} or 'harness' not in row):
            continue
        try:
            result[row['seat']] = validate(row['harness'])
        except ValueError:
            continue
    return result


def percentage(value):
    # The browser uses the same integer rounding, including zero and ties.
    rounded = math.floor(value * 100 + 0.5) / 100
    return format(rounded, '.2f').rstrip('0').rstrip('.') + '%'


def line(facts=None):
    f = facts or {}
    return ' · '.join([f.get('model') or '—', f.get('effort') or '—',
        str(f['context_window']) + ' tokens' if f.get('context_window') is not None else '—',
        percentage(f['context_used_pct']) if f.get('context_used_pct') is not None else '—'])
