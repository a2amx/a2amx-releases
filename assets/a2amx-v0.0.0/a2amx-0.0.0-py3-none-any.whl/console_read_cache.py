"""Bounded, read-only console JSONL snapshots, invalidated by source metadata.

Only explicit console scopes use this cache. Writers, delivery, recovery and
ordinary CLI reads retain their original uncached paths. A source is owned by
append-only product writers; replacement/shrinkage/mtime changes invalidate it.
The cache holds at most two files of at most 64 MiB and 100,000 complete lines
apiece. Larger inputs use the existing uncached reader, without a new limit on
store history. Parsed values are immutable so view enrichment cannot poison a
later request. Locks protect loading only, never response streaming.
"""
from bisect import bisect_left, bisect_right
from collections import OrderedDict
from contextlib import contextmanager
from contextvars import ContextVar
from functools import wraps
import inspect
import fcntl
import json
import os
from pathlib import Path
import threading

MAX_BYTES = 64 * 1024 * 1024
MAX_LINES = 100_000
_MAX_FILES = 2
_lock = threading.RLock()
_cache = OrderedDict()
_frame = ContextVar('console_read_frame', default=None)


def _immutable(*args, **kwargs):
    raise TypeError('console snapshot records are read-only')


class _Dict(dict):
    __slots__ = ()
    __setitem__ = __delitem__ = clear = pop = popitem = setdefault = update = __ior__ = _immutable


class _List(list):
    __slots__ = ()
    __setitem__ = __delitem__ = append = clear = extend = insert = pop = remove = reverse = sort = __iadd__ = __imul__ = _immutable


def _freeze(value):
    if isinstance(value, dict):
        return _Dict((key, _freeze(item)) for key, item in value.items())
    if isinstance(value, list):
        return _List(_freeze(item) for item in value)
    return value


def clear():
    """Drop process-local snapshots without changing any stored source."""
    with _lock:
        _cache.clear()


def _after_fork():
    global _lock
    _lock = threading.RLock()
    _cache.clear()
    _frame.set(None)


if hasattr(os, 'register_at_fork'):
    os.register_at_fork(after_in_child=_after_fork)


def file_token(path):
    """The shared cheap change token; it never opens or parses the source."""
    stat = Path(path).stat()
    return stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns


class Snapshot:
    def __init__(self, data, token):
        self.data, self.token = data, token
        self.ends, self.values, self.tail_values = [], [], []
        self.invalid = False
        end = 0
        for raw in data.split(b'\n')[:-1]:
            end += len(raw) + 1
            self.ends.append(end)
            value = None
            raw_valid = True
            if raw.strip():
                try:
                    parsed = json.loads(raw.strip())
                    # The store reader strips outer whitespace, while the
                    # strict ledger/receipt readers do not. Preserve both.
                    if raw != raw.strip():
                        try:
                            json.loads(raw)
                        except (ValueError, UnicodeError):
                            self.invalid = True
                            raw_valid = False
                    if isinstance(parsed, dict):
                        value = _freeze(parsed)
                    else:
                        self.invalid = True
                except (ValueError, UnicodeError):
                    self.invalid = True
            self.values.append(value)
            self.tail_values.append(value if raw_valid else None)
        self.complete_end = end

    def strict_rows(self):
        if self.complete_end != len(self.data):
            raise ValueError('JSONL snapshot has an incomplete record')
        if self.invalid:
            raise ValueError('JSONL snapshot has an invalid or non-object record')
        return [row for row in self.values if row is not None]

    def batch(self, offset, max_bytes):
        """Match read_jsonl's complete-line batching at an aligned cursor."""
        cursor = bisect_left(self.ends, offset)
        if offset != 0 and (cursor == len(self.ends) or self.ends[cursor] != offset):
            return None
        first = bisect_right(self.ends, offset)
        if first == len(self.ends):
            return [], offset
        boundary = offset + max_bytes
        if self.ends[first] > boundary:
            boundary = offset + ((self.ends[first] - offset + max_bytes - 1) // max_bytes) * max_bytes
        stop = bisect_right(self.ends, boundary)
        rows = [value for value in self.values[first:stop] if value is not None]
        return rows, self.ends[stop - 1] if stop > first else offset

    def tail(self, limit, visible, safe_record, window):
        """Preserve dialogue's existing byte window and first-line exclusion."""
        from collections import deque
        start = max(0, len(self.data) - window)
        first = bisect_right(self.ends, start) + 1 if start else 0
        if self.complete_end <= start:
            return [], start
        kept = deque(maxlen=max(0, limit))
        for value in self.tail_values[first:]:
            if value is not None:
                row = safe_record(value)
                if visible is None or visible(row):
                    kept.append(row)
        return list(kept), self.complete_end


def read_snapshot(path, *, max_bytes=MAX_BYTES):
    """Read one bounded immutable snapshot, or decline caching a larger input."""
    path = Path(path)
    key = str(path)
    with _lock:
        try:
            token = file_token(path)
        except OSError:
            _cache.pop(key, None)
            raise
        cached = _cache.get(key)
        if cached is not None and cached.token != token:
            _cache.pop(key)
            cached = None
        if token[2] > min(max_bytes, MAX_BYTES):
            return None
        if cached is not None:
            _cache.move_to_end(key)
            return cached
    # A slow source must not stall a warm read of the other source. Duplicate
    # cold loads may run concurrently; publication compares generations below.
    with path.open('rb') as source:
        fcntl.flock(source.fileno(), fcntl.LOCK_SH)
        try:
            stat = os.fstat(source.fileno())
            token = (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns)
            if token[2] > min(max_bytes, MAX_BYTES):
                return None
            data = source.read(token[2])
        finally:
            fcntl.flock(source.fileno(), fcntl.LOCK_UN)
    if len(data) != token[2] or data.count(b'\n') > MAX_LINES:
        return None
    snapshot = Snapshot(data, token)
    # Inspect the named generation while holding only the short cache lock.
    # A stale loader may return its anchored view but cannot erase a newer one.
    with _lock:
        try:
            current = file_token(path)
        except OSError:
            current = None
        cached = _cache.get(key)
        if current == token:
            if cached is not None and cached.token == token:
                snapshot = cached
            else:
                _cache[key] = snapshot
            _cache.move_to_end(key)
            while len(_cache) > _MAX_FILES:
                _cache.popitem(last=False)
        elif cached is not None and cached.token == token:
            _cache.pop(key, None)
        return snapshot


@contextmanager
def scope(paths):
    previous = _frame.set({'paths': {Path(p) for p in paths}, 'snapshots': {}, 'memo': {}})
    try:
        yield
    finally:
        _frame.reset(previous)


def scoped_snapshot(path):
    frame = _frame.get()
    path = Path(path)
    if frame is None or path not in frame['paths']:
        return None
    if path not in frame['snapshots']:
        try:
            frame['snapshots'][path] = read_snapshot(path)
        except FileNotFoundError:
            frame['snapshots'][path] = None
    return frame['snapshots'][path]


def batch(path, offset, max_bytes):
    snapshot = scoped_snapshot(path)
    return snapshot.batch(offset, max_bytes) if snapshot is not None and max_bytes > 0 else None


def strict_rows(path):
    snapshot = scoped_snapshot(path)
    return snapshot.strict_rows() if snapshot is not None else None


def memo(key, factory):
    frame = _frame.get()
    if frame is None:
        return None
    if key not in frame['memo']:
        frame['memo'][key] = factory()
    return frame['memo'][key]


def state_snapshot(function):
    """Opt only the authenticated state handler into read-only source reuse."""
    @wraps(function)
    def wrapped(*args, **kwargs):
        import store
        with scope((store.LOG_FILE, store.STORE_DIR / 'receipts.jsonl')):
            return function(*args, **kwargs)
    wrapped.__signature__ = inspect.signature(function, eval_str=True)
    return wrapped
