"""Append-only recall, ordered with FETCHED by the existing journal fence.

The receipt journal owns admission. Log/inbox copies and wake settlement are
recoverable materializations of that event, never a second decision source.
"""
from __future__ import annotations

import time

import receipts
import store


class Refused(ValueError):
    def __init__(self, reason, *, readers=None):
        self.reason, self.readers = reason, readers or {}
        super().__init__('recall_refused: ' + reason)


def graph(rows=None):
    """First admitted no-replacement supersession wins; ordinary sends cannot recall."""
    if rows is None:
        from console_read_cache import memo
        cached = memo(('recall-graph', str(receipts.path())), lambda: graph(receipts.rows()))
        return cached if cached is not None else graph(receipts.rows())
    result = {}
    for row in rows:
        if (row.get('kind') in {'recall', 'withdraw'} and row.get('replacement') is None
                and row.get('v') == 1 and isinstance(row.get('supersedes'), str)):
            result.setdefault(row['supersedes'], row)
    return result


def read_graph():
    """One bounded generation-aware journal view for a ledger selection.

    Mutation paths keep using graph() and authoritative uncached reads. An
    oversized source falls back to one full scan for the whole projection.
    """
    from console_read_cache import read_snapshot, scoped_snapshot
    snapshot = scoped_snapshot(receipts.path())
    if snapshot is None:
        try:
            snapshot = read_snapshot(receipts.path())
        except FileNotFoundError:
            return {}
    return graph(snapshot.strict_rows()) if snapshot is not None else graph()


def project(message, *, edges=None):
    event = (graph() if edges is None else edges).get(message.get('id'))
    if event is None:
        return message
    state = 'recalled' if event['kind'] == 'recall' else 'withdrawn'
    # Never put the original instruction into a hook's turn after recall won.
    # The original bytes remain in the canonical log for evidence/citations.
    return {**message, 'kind': state, 'status': state, 'actionable': False,
            'superseded_by': event['id'], 'supersession_reason': event['reason'],
            'envelope': {'re': state + ' ' + message['id'], 'authority': 'FYI'},
            'text': f"{state} {message['id']} (record {event['id']}): {event['reason']}",
            'withdrawal_notices': [n['id'] for n in event.get('notices', [])]}


def readers_at(rows, mid, recipients):
    """Include durable committed fetches even before individual materialization."""
    aborted = {r.get('txn-id') for r in rows
               if r.get('kind') == 'delivery-transaction' and r.get('phase') == 'abort'}
    prepared, result = {}, {}
    for row in rows:
        txn = row.get('txn-id')
        if row.get('kind') == 'delivery-transaction':
            if row.get('phase') == 'prepare':
                prepared[txn] = row
            elif row.get('phase') == 'commit' and txn not in aborted:
                prep = prepared.get(txn, {})
                if (prep.get('event') == 'FETCHED' and mid in prep.get('msg-ids', [])
                        and prep.get('seat') in recipients):
                    result.setdefault(prep['seat'], row.get('ts', prep.get('ts')))
        elif (row.get('kind') == 'delivery' and row.get('event') == 'FETCHED'
              and txn is None and row.get('msg-id') == mid and row.get('seat') in recipients):
            result.setdefault(row['seat'], row.get('ts'))
    return result


def settled_attempts(rows):
    """Attempt ids whose message has an admitted recall/withdrawal."""
    edges = graph(rows)
    return {r['event-id'] for r in rows if r.get('kind') == 'nudge'
            and r.get('phase') == 'pre' and r.get('msg-id') in edges}


def _notice(event, recipient):
    mid = store.new_id('msg')
    text = (f"TO: {recipient} · FROM: {event['from']} · RE: withdrawal of {event['supersedes']}"
            f" · AUTHORITY: FYI\n\nWithdrawn {event['supersedes']}: {event['reason']}\n\n"
            "If you are not the addressee: treat as FYI; act on nothing; do not forward as authority.")
    return store._prepare_message_record({
        'id': mid, 'ts': event['ts'], 'from': event['from'], 'to': [recipient],
        'recipients': [recipient], 'mailbox_recipients': [recipient], 'kind': 'message',
        'text': text, 'supersedes': event['supersedes'], 'withdrawal_record': event['id'],
    }, {'re': 'withdrawal of ' + event['supersedes'], 'authority': 'FYI'})


def _materialize(event, rows):
    """Caller owns nudge.lock. Every append has a stable journal-owned identity."""
    log_ids = {r.get('id') for r in store._read_from_to_eof(0)}
    if event['id'] not in log_ids:
        store._append_message_log({k: v for k, v in event.items() if k not in {'notices', 'authorization'}})
    for notice in event.get('notices', []):
        if notice['id'] not in log_ids:
            store._append_message_log(notice)
        seat = notice['recipients'][0]
        if not any(r.get('kind') == 'delivery' and r.get('msg-id') == notice['id']
                   and r.get('seat') == seat for r in rows):
            receipts.journal(notice['id'], seat, 'QUEUED')
        inbox = receipts._read_all(store.inbox_path(seat))
        if not any(r.get('id') == notice['id'] for r in inbox):
            store.append_jsonl(store.inbox_path(seat), notice)
    posts = {r.get('event-id'): r for r in rows
             if r.get('kind') == 'nudge' and r.get('phase') == 'post'}
    reconciled = {r.get('event-id', r.get('nudge-event-id')) for r in rows
                  if r.get('kind') in {'recall-reconciliation', 'wake-reconciled', 'claude-reconciliation'}
                  and r.get('result') in {'recalled', 'accepted', 'fetched', 'hook_observed', 'refused'}}
    reconciled.update(r.get('event-id') for r in rows
                      if r.get('kind') == 'wake_route_dead' and r.get('terminal'))
    for pre in rows:
        if pre.get('kind') != 'nudge' or pre.get('phase') != 'pre' or pre.get('msg-id') != event['supersedes']:
            continue
        eid = pre['event-id']
        post = posts.get(eid)
        if pre.get('route_kind') == 'agy-desktop':
            from wake_intent_records import withdraw_recalled
            withdraw_recalled(pre, event['epoch'])
        if eid in reconciled or (post is not None and post.get('result') not in {'uncertain', 'held'}):
            continue
        row = {'event-id': eid, 'target seat': pre['target seat'], 'seat': pre['target seat'],
               'msg-id': pre['msg-id'], 'route_kind': pre.get('route_kind', 'tmux'),
               'generation': pre.get('generation'), 'result': 'recalled', 'reason': 'message_superseded',
               'recall-id': event['id'], 'epoch': event['epoch'], 'ts': event['ts']}
        if post is None:
            row.update(kind='nudge', phase='post')
        else:
            row.update(kind='recall-reconciliation')
        receipts.append_durable(row)


def recover_unlocked():
    rows = receipts.strict_rows()
    complete = {r.get('recall-id') for r in rows if r.get('kind') == 'recall-complete'}
    for event in graph(rows).values():
        if event['id'] in complete:
            continue
        _materialize(event, rows)
        receipts.append_durable({'kind': 'recall-complete', 'recall-id': event['id'], 'ts': store.now_iso()})
        rows = receipts.strict_rows()


def recover():
    with receipts._nudge_lock():
        recover_unlocked()


def recall(mid, *, presented_token, reason='', unread_only=False, authorization=None, clock=time.time):
    if (not isinstance(reason, str) or len(reason) > 500
            or any(ord(c) < 32 or c in '\x85\u2028\u2029' for c in reason)):
        raise Refused('reason_must_be_one_line_at_most_500_characters')
    def act(actor):
        parts = store._read_participants_unlocked()
        with receipts._nudge_lock():
            rows = receipts.strict_rows()
            original = receipts._select_messages({mid}).get(mid)
            if original is None:
                raise Refused('unknown_message')
            if original.get('kind') in {'recall', 'withdraw'} or original.get('object_class') == 'receipt':
                raise Refused('not_a_message')
            import authority
            authority.verify_recall(actor=actor, credential=store._registry_actor_local.actor,
                original=original, participants=parts, request=authorization,
                reason=reason, unread_only=unread_only, now=clock())
            existing = graph(rows).get(mid)
            if existing is not None:
                recover_unlocked()
                return {**existing, 'changed': False}
            targets = original.get('recipients', original.get('to', []))
            readers = readers_at(rows, mid, targets)
            if readers and unread_only:
                raise Refused('already_read', readers=readers)
            event = {'v': 1, 'id': store.new_id('recall'), 'kind': 'withdraw' if readers else 'recall',
                     'from': actor, 'to': list(targets), 'recipients': list(targets), 'mailbox_recipients': [],
                     'supersedes': mid, 'replacement': None, 'reason': reason, 'readers': readers,
                     'ts': store.now_iso(), 'epoch': clock(), 'notices': [],
                     'unread_recipients': [s for s in targets if s not in readers],
                     'pointers_recomputed': sum(mid in receipts.pending_message_ids(s) for s in targets)}
            event['text'] = f"{event['kind']} {mid}: {reason}"
            event = store._prepare_message_record(event, {'re': event['kind'] + ' ' + mid, 'authority': 'FYI'})
            event['notices'] = [_notice(event, seat) for seat in readers]
            if authorization is not None:
                event['authorization'] = authorization
            receipts.append_durable(event)  # The sole admission / fetch-order boundary.
            # D-GOV-2 (f) §3.4: a withdrawal ends the focus period of each seat that
            # fetched the message, once, at admission; recovery replays never do.
            import focus
            focus.withdrawal_unlocked(event)
            recover_unlocked()
            return {**event, 'changed': True}
    return store.authenticated_registry_act(presented_token, act)
