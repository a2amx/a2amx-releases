"""Bounded adapter-host control and observation-artifact primitives.

The runtime supervisor owns both capabilities in this protocol:

* one private ``AF_UNIX`` socketpair endpoint used for framed control; and
* one already-open per-attempt directory descriptor used for the host's single
  observation artifact.

Paths, ambient environment variables, and the adapter host's stdin are never
control channels.  The bootstrap frame transfers a transient attempt key over
the private socket; directional subkeys authenticate every subsequent frame.
The key authenticates *which manifest-pinned host reported an observation*.
It is deliberately distinct from the registry capability and does not turn a
host observation into vendor-signed provenance.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import math
import os
import select
import stat
import struct
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Optional

import store


PROTOCOL_VERSION = 1
MAX_FRAME_BYTES = 4096
CONTROL_FD_FLAG = "--runtime-host-control-fd"
ARTIFACT_DIR_FD_FLAG = "--runtime-artifact-dir-fd"
ARTIFACT_ROOT_NAME = "runtime_hosts"
ARTIFACT_FINAL_NAME = "claude-session-observed.json"
ARTIFACT_TEMP_NAME = "claude-session-observed.tmp"
OBSERVATION_SCHEMA = 1

_DIRECTIONS = frozenset({"host_to_supervisor", "supervisor_to_host"})
_KINDS_BY_DIRECTION = {
    "host_to_supervisor": frozenset({
        "OBSERVATION_READY", "TURN_START", "TURN_RESULT"}),
    "supervisor_to_host": frozenset({
        "ACTIVATE", "TURN_START_ACK", "TURN_RESULT_ACK"}),
}
_FRAME_KEYS = frozenset({
    "schema_version", "direction", "kind", "sequence", "seat",
    "attempt_id", "runtime_id", "generation", "payload", "auth_tag",
})
_BOOTSTRAP_KEYS = frozenset({
    "schema_version", "kind", "seat", "attempt_id", "runtime_id",
    "generation", "resource", "attempt_config", "attempt_sha256",
    "control_key_b64",
})
_OBSERVATION_KEYS = frozenset({
    "schema_version", "type", "seat", "attempt_id", "runtime_id",
    "generation", "attempt_sha256", "family", "host_pid", "vendor_pid",
    "vendor_birth", "vendor_pgid", "transport_kind", "protocol_version",
    "launch_mode", "handle", "proof_ref", "session_id_assurance",
    "residual", "auth_tag",
})

SESSION_ID_ASSURANCE = "OBSERVED_NOT_INDEPENDENTLY_VERIFIED"
SESSION_ID_RESIDUAL = (
    "SDK-encapsulation: session-id is observed-not-independently-verified")


class HostControlError(RuntimeError):
    """A host-control or observation-artifact contract failed closed."""


def _strict_object(raw: bytes, *, label: str) -> Dict[str, Any]:
    def pairs(items):
        out = {}
        for key, value in items:
            if key in out:
                raise HostControlError(f"{label} contains duplicate key {key!r}")
            out[key] = value
        return out

    try:
        value = json.loads(raw.decode("utf-8"), object_pairs_hook=pairs,
                           parse_constant=lambda value: (_ for _ in ()).throw(
                               HostControlError(
                                   f"{label} contains non-finite number {value}")))
    except HostControlError:
        raise
    except Exception as exc:
        raise HostControlError(f"{label} is not strict UTF-8 JSON: {exc}") from exc
    if not isinstance(value, dict):
        raise HostControlError(f"{label} must be a JSON object")
    return value


def canonical_json(value: Any) -> bytes:
    try:
        return json.dumps(value, sort_keys=True, separators=(",", ":"),
                          ensure_ascii=False, allow_nan=False).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise HostControlError(f"value is not strict JSON: {exc}") from exc


def _clean_string(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value or any(c in value for c in "\r\n\0"):
        raise HostControlError(f"{label} must be a clean non-empty string")
    return value


def _positive_int(value: Any, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise HostControlError(f"{label} must be a positive integer")
    return value


def _sha256(value: Any, label: str) -> str:
    if not isinstance(value, str) or len(value) != 64 \
            or any(c not in "0123456789abcdef" for c in value):
        raise HostControlError(f"{label} must be a lowercase SHA-256 digest")
    return value


def _deadline(timeout: float) -> float:
    if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) \
            or not math.isfinite(timeout) or timeout <= 0 or timeout > 300:
        raise HostControlError("control timeout must be finite in (0, 300]")
    return time.monotonic() + float(timeout)


def _wait(fd: int, *, writing: bool, end: float) -> None:
    remaining = end - time.monotonic()
    if remaining <= 0:
        raise HostControlError("host-control frame deadline expired")
    ready = select.select([], [fd], [], remaining)[1] if writing \
        else select.select([fd], [], [], remaining)[0]
    if not ready:
        raise HostControlError("host-control frame deadline expired")


def _read_exact(fd: int, count: int, end: float) -> bytes:
    chunks = bytearray()
    while len(chunks) < count:
        _wait(fd, writing=False, end=end)
        try:
            chunk = os.read(fd, count - len(chunks))
        except BlockingIOError:
            continue
        if not chunk:
            raise HostControlError("host-control channel closed mid-frame")
        chunks.extend(chunk)
    return bytes(chunks)


def read_raw_frame(fd: int, *, timeout: float) -> Dict[str, Any]:
    """Read one length-prefixed frame with one deadline across prefix+payload.

    The four-byte length is rejected before allocating or reading the payload.
    """
    end = _deadline(timeout)
    prefix = _read_exact(fd, 4, end)
    size = struct.unpack(">I", prefix)[0]
    if size <= 0 or size > MAX_FRAME_BYTES:
        raise HostControlError(
            f"host-control frame length {size} is outside [1,{MAX_FRAME_BYTES}]")
    return _strict_object(_read_exact(fd, size, end), label="host-control frame")


def write_raw_frame(fd: int, value: Dict[str, Any], *, timeout: float) -> None:
    raw = canonical_json(value)
    if not raw or len(raw) > MAX_FRAME_BYTES:
        raise HostControlError("host-control frame exceeds the bounded size")
    data = memoryview(struct.pack(">I", len(raw)) + raw)
    end = _deadline(timeout)
    while data:
        _wait(fd, writing=True, end=end)
        try:
            written = os.write(fd, data)
        except BlockingIOError:
            continue
        if written <= 0:
            raise HostControlError("host-control channel closed during write")
        data = data[written:]


def encode_control_key(key: bytes) -> str:
    if not isinstance(key, bytes) or len(key) != 32:
        raise HostControlError("control key must be exactly 32 bytes")
    return base64.b64encode(key).decode("ascii")


def decode_control_key(value: Any) -> bytes:
    if not isinstance(value, str):
        raise HostControlError("control_key_b64 must be a string")
    try:
        key = base64.b64decode(value, validate=True)
    except Exception as exc:
        raise HostControlError("control_key_b64 is not canonical base64") from exc
    if len(key) != 32 or encode_control_key(key) != value:
        raise HostControlError("control_key_b64 must encode exactly 32 bytes")
    return key


def directional_key(master: bytes, direction: str) -> bytes:
    if direction not in _DIRECTIONS:
        raise HostControlError("unknown host-control direction")
    if not isinstance(master, bytes) or len(master) != 32:
        raise HostControlError("control master key must be exactly 32 bytes")
    return hmac.new(master, (f"runtime-host-control-v1:{direction}").encode("ascii"),
                    hashlib.sha256).digest()


def _frame_payload(frame: Dict[str, Any]) -> bytes:
    return canonical_json({k: frame[k] for k in sorted(_FRAME_KEYS - {"auth_tag"})})


def sign_frame(frame: Dict[str, Any], key: bytes) -> str:
    if not isinstance(key, bytes) or len(key) != 32:
        raise HostControlError("directional frame key must be exactly 32 bytes")
    return hmac.new(key, _frame_payload(frame), hashlib.sha256).hexdigest()


def make_frame(*, direction: str, kind: str, sequence: int,
               identity: Dict[str, Any], payload: Dict[str, Any],
               key: bytes) -> Dict[str, Any]:
    if direction not in _DIRECTIONS:
        raise HostControlError("unknown frame direction")
    if kind not in _KINDS_BY_DIRECTION[direction]:
        raise HostControlError("unknown host-control frame kind")
    _positive_int(sequence, "frame sequence")
    if not isinstance(payload, dict):
        raise HostControlError("frame payload must be an object")
    frame = {
        "schema_version": PROTOCOL_VERSION,
        "direction": direction,
        "kind": kind,
        "sequence": sequence,
        "seat": _clean_string(identity.get("seat"), "frame seat"),
        "attempt_id": _clean_string(identity.get("attempt_id"), "frame attempt_id"),
        "runtime_id": _clean_string(identity.get("runtime_id"), "frame runtime_id"),
        "generation": _positive_int(identity.get("generation"), "frame generation"),
        "payload": payload,
    }
    frame["auth_tag"] = sign_frame(frame, key)
    if len(canonical_json(frame)) > MAX_FRAME_BYTES:
        raise HostControlError("authenticated host-control frame exceeds size cap")
    return frame


def validate_frame(frame: Any, *, direction: str, kind: str, sequence: int,
                   identity: Dict[str, Any], key: bytes) -> Dict[str, Any]:
    if not isinstance(frame, dict) or set(frame) != _FRAME_KEYS:
        raise HostControlError("authenticated host-control frame has non-closed shape")
    if direction not in _DIRECTIONS \
            or kind not in _KINDS_BY_DIRECTION[direction]:
        raise HostControlError("unknown expected host-control frame kind")
    if len(canonical_json(frame)) > MAX_FRAME_BYTES:
        raise HostControlError("authenticated host-control frame exceeds size cap")
    if frame.get("schema_version") != PROTOCOL_VERSION \
            or frame.get("direction") != direction or frame.get("kind") != kind \
            or frame.get("sequence") != sequence:
        raise HostControlError("host-control protocol/direction/kind/sequence mismatch")
    for name in ("seat", "attempt_id", "runtime_id", "generation"):
        if frame.get(name) != identity.get(name):
            raise HostControlError(f"host-control {name} crossed attempts")
    if not isinstance(frame.get("payload"), dict):
        raise HostControlError("host-control payload must be an object")
    tag = frame.get("auth_tag")
    if not isinstance(tag, str) or len(tag) != 64 \
            or not hmac.compare_digest(tag, sign_frame(frame, key)):
        raise HostControlError("host-control authentication failed")
    return frame["payload"]


def validate_bootstrap(value: Any) -> Dict[str, Any]:
    if not isinstance(value, dict) or set(value) != _BOOTSTRAP_KEYS:
        raise HostControlError("BOOTSTRAP frame has non-closed shape")
    if value.get("schema_version") != PROTOCOL_VERSION \
            or value.get("kind") != "BOOTSTRAP":
        raise HostControlError("BOOTSTRAP schema/kind mismatch")
    for key in ("seat", "attempt_id", "runtime_id"):
        _clean_string(value.get(key), f"BOOTSTRAP.{key}")
    _positive_int(value.get("generation"), "BOOTSTRAP.generation")
    _sha256(value.get("attempt_sha256"), "BOOTSTRAP.attempt_sha256")
    decode_control_key(value.get("control_key_b64"))
    if not isinstance(value.get("resource"), dict) \
            or set(value["resource"]) != {"kind", "value"}:
        raise HostControlError("BOOTSTRAP.resource must be a closed ResourceTag")
    if not isinstance(value.get("attempt_config"), dict):
        raise HostControlError("BOOTSTRAP.attempt_config must be an object")
    return value


def _artifact_payload(value: Dict[str, Any]) -> bytes:
    return canonical_json({k: value[k] for k in sorted(_OBSERVATION_KEYS - {"auth_tag"})})


def sign_observation(value: Dict[str, Any], key: bytes) -> str:
    return hmac.new(key, _artifact_payload(value), hashlib.sha256).hexdigest()


def validate_observation(value: Any, *, identity: Dict[str, Any],
                         attempt_sha256: str, key: bytes) -> Dict[str, Any]:
    if not isinstance(value, dict) or set(value) != _OBSERVATION_KEYS:
        raise HostControlError("Claude observation artifact has non-closed shape")
    if len(canonical_json(value)) > MAX_FRAME_BYTES:
        raise HostControlError("Claude observation artifact exceeds size cap")
    if value.get("schema_version") != OBSERVATION_SCHEMA \
            or value.get("type") != "CLAUDE_SESSION_OBSERVED":
        raise HostControlError("Claude observation schema/type mismatch")
    for name in ("seat", "attempt_id", "runtime_id", "generation"):
        if value.get(name) != identity.get(name):
            raise HostControlError(f"Claude observation {name} crossed attempts")
    if value.get("attempt_sha256") != _sha256(
            attempt_sha256, "expected attempt_sha256"):
        raise HostControlError("Claude observation attempt digest mismatch")
    if store.normalize_family(value.get("family")) != "claude" or value.get("transport_kind") != "claude_sdk":
        raise HostControlError("Claude observation crossed adapter transports")
    for name in ("host_pid", "vendor_pid", "vendor_pgid"):
        _positive_int(value.get(name), f"Claude observation {name}")
    for name in ("vendor_birth", "protocol_version", "proof_ref"):
        _clean_string(value.get(name), f"Claude observation {name}")
    if value.get("launch_mode") not in ("NEW", "RESUME"):
        raise HostControlError("Claude observation launch_mode is invalid")
    if value.get("session_id_assurance") != SESSION_ID_ASSURANCE \
            or value.get("residual") != SESSION_ID_RESIDUAL:
        raise HostControlError("Claude observation omits the named SDK residual")
    if not isinstance(value.get("handle"), dict) \
            or set(value["handle"]) != {"kind", "ref"} \
            or value["handle"].get("kind") != "session_uuid":
        raise HostControlError("Claude observation handle must be a closed session_uuid")
    _clean_string(value["handle"].get("ref"), "Claude observation handle.ref")
    tag = value.get("auth_tag")
    if not isinstance(tag, str) or len(tag) != 64 \
            or not hmac.compare_digest(tag, sign_observation(value, key)):
        raise HostControlError("Claude observation artifact authentication failed")
    return value


def write_observation_artifact(dir_fd: int, value: Dict[str, Any]) -> str:
    raw = canonical_json(value) + b"\n"
    if len(raw) > MAX_FRAME_BYTES:
        raise HostControlError("Claude observation artifact exceeds size cap")
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC
    fd = os.open(ARTIFACT_TEMP_NAME, flags, 0o600, dir_fd=dir_fd)
    try:
        view = memoryview(raw)
        while view:
            written = os.write(fd, view)
            if written <= 0:
                raise HostControlError("short write of Claude observation artifact")
            view = view[written:]
        os.fsync(fd)
    finally:
        os.close(fd)
    try:
        # linkat is an atomic no-replace publication on this same directory:
        # an existing final raises EEXIST instead of being overwritten.
        os.link(ARTIFACT_TEMP_NAME, ARTIFACT_FINAL_NAME,
                src_dir_fd=dir_fd, dst_dir_fd=dir_fd,
                follow_symlinks=False)
    except Exception:
        try:
            os.unlink(ARTIFACT_TEMP_NAME, dir_fd=dir_fd)
        except OSError:
            pass
        raise
    os.unlink(ARTIFACT_TEMP_NAME, dir_fd=dir_fd)
    os.fsync(dir_fd)
    return hashlib.sha256(raw).hexdigest()


def read_observation_artifact(dir_fd: int, *, expected_sha256: str) -> Dict[str, Any]:
    _sha256(expected_sha256, "notified artifact digest")
    try:
        names = os.listdir(dir_fd)
    except OSError as exc:
        raise HostControlError(f"cannot enumerate observation directory: {exc}") from exc
    if names != [ARTIFACT_FINAL_NAME]:
        raise HostControlError(
            f"observation directory must contain only {ARTIFACT_FINAL_NAME!r}")
    fd = os.open(ARTIFACT_FINAL_NAME,
                 os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK,
                 dir_fd=dir_fd)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_uid != os.geteuid() \
                or stat.S_IMODE(before.st_mode) != 0o600:
            raise HostControlError("observation artifact must be owned regular mode 0600")
        if before.st_size <= 0 or before.st_size > MAX_FRAME_BYTES:
            raise HostControlError("observation artifact size is outside the bound")
        os.set_blocking(fd, True)
        raw = os.read(fd, MAX_FRAME_BYTES + 1)
        after = os.fstat(fd)
    finally:
        os.close(fd)
    identity_before = (before.st_dev, before.st_ino, before.st_size,
                       before.st_mtime_ns, before.st_ctime_ns)
    identity_after = (after.st_dev, after.st_ino, after.st_size,
                      after.st_mtime_ns, after.st_ctime_ns)
    if identity_before != identity_after or len(raw) != before.st_size:
        raise HostControlError("observation artifact changed while being read")
    if hashlib.sha256(raw).hexdigest() != expected_sha256:
        raise HostControlError("observation artifact digest differs from notification")
    return _strict_object(raw, label="Claude observation artifact")


def _component_digest(identity: Dict[str, Any]) -> str:
    selected = {key: identity[key] for key in
                ("seat", "attempt_id", "runtime_id", "generation")}
    return hashlib.sha256(canonical_json(selected)).hexdigest()


@dataclass
class AttemptArtifactDirectory:
    root_fd: int
    dir_fd: int
    basename: str

    def cleanup(self) -> bool:
        """Remove only the two protocol-owned names, then the exact directory.

        Unexpected entries are never recursively traversed or deleted.  They
        make ``rmdir`` fail and keep the directory visible for recovery.
        """
        ok = True
        for name in (ARTIFACT_TEMP_NAME, ARTIFACT_FINAL_NAME):
            try:
                os.unlink(name, dir_fd=self.dir_fd)
            except FileNotFoundError:
                pass
            except OSError:
                ok = False
        try:
            os.fsync(self.dir_fd)
        except OSError:
            ok = False
        try:
            os.close(self.dir_fd)
        except OSError:
            ok = False
        self.dir_fd = -1
        try:
            os.rmdir(self.basename, dir_fd=self.root_fd)
        except OSError:
            ok = False
        try:
            os.close(self.root_fd)
        except OSError:
            ok = False
        self.root_fd = -1
        return ok


def create_attempt_artifact_directory(identity: Dict[str, Any]) \
        -> AttemptArtifactDirectory:
    for key in ("seat", "attempt_id", "runtime_id"):
        _clean_string(identity.get(key), f"artifact identity {key}")
    _positive_int(identity.get("generation"), "artifact identity generation")
    store.ensure_store()
    root = Path(store.STORE_DIR) / ARTIFACT_ROOT_NAME
    try:
        root.mkdir(mode=0o700)
    except FileExistsError:
        pass
    st = os.lstat(root)
    if not stat.S_ISDIR(st.st_mode) or st.st_uid != os.geteuid():
        raise HostControlError("runtime-host artifact root is not a trusted directory")
    if stat.S_IMODE(st.st_mode) != 0o700:
        raise HostControlError("runtime-host artifact root mode must be exactly 0700")
    root_fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    basename = "attempt-" + _component_digest(identity)
    try:
        os.mkdir(basename, 0o700, dir_fd=root_fd)
        dir_fd = os.open(basename,
                         os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                         dir_fd=root_fd)
        st_dir = os.fstat(dir_fd)
        if st_dir.st_uid != os.geteuid() or stat.S_IMODE(st_dir.st_mode) != 0o700:
            raise HostControlError("per-attempt artifact directory is not owned mode 0700")
        return AttemptArtifactDirectory(root_fd=root_fd, dir_fd=dir_fd,
                                        basename=basename)
    except Exception:
        try:
            os.rmdir(basename, dir_fd=root_fd)
        except OSError:
            pass
        os.close(root_fd)
        raise
