"""Names selected by the packaged product profile, never by the environment.

The public exporter supplies its reviewed profile before building the wheel.
Internal Python module names and seat credential-directory names are not product
entry points. Importing this module neither selects a store nor reads a token.
"""
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import re
import stat
from types import MappingProxyType
from typing import Mapping


class ProfileError(ValueError):
    """A fixed reason code; never include profile/configuration values."""


@dataclass(frozen=True)
class Profile:
    edition: str
    display_name: str
    distribution: str
    commands: Mapping[str, str]
    home_directory: str
    environment: Mapping[str, str]
    sha256: str

    @property
    def is_public(self):
        return self.edition == 'public'

    def command(self, role='main'):
        try:
            return self.commands[role]
        except KeyError:
            raise ProfileError('product_command_unknown') from None

    def state_root(self, home=None):
        return (Path.home() if home is None else Path(home))/self.home_directory

    def environment_name(self, internal):
        try:
            return self.environment[internal]
        except KeyError:
            # Public help must not silently print an unclassified private name.
            raise ProfileError('product_environment_unclassified') from None

    def internal_environment(self, environment):
        """Return a copy with the declared public aliases bound for internal code.

        Nothing changes os.environ implicitly. Matching dual names are allowed;
        conflicting values refuse without printing either value. Names absent
        from the explicit table are untouched, never mass-renamed by prefix.
        """
        result = dict(environment)
        for internal, public in self.environment.items():
            if public not in environment or public == internal:
                continue
            if internal in environment and environment[internal] != environment[public]:
                raise ProfileError('product_environment_conflict')
            result[internal] = environment[public]
        return result


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ProfileError('product_profile_duplicate_key')
        result[key] = value
    return result


def parse(raw):
    """Strict data-only profile; command strings cannot contain shell syntax."""
    if not isinstance(raw, bytes) or len(raw) > 16384:
        raise ProfileError('product_profile_bytes_required')
    try:
        value = json.loads(raw, object_pairs_hook=_object)
    except ProfileError:
        raise
    except (ValueError, UnicodeError, TypeError):
        raise ProfileError('product_profile_invalid_json') from None
    required = {'schema', 'edition', 'display_name', 'distribution', 'commands',
                'home_directory', 'environment'}
    if not isinstance(value, dict) or set(value) != required or value['schema'] != 'product.profile.v1':
        raise ProfileError('product_profile_shape')
    if value['edition'] not in {'private', 'public'}:
        raise ProfileError('product_edition_invalid')
    display = value['display_name']
    if not isinstance(display, str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9 .-]{0,63}', display):
        raise ProfileError('product_display_name_invalid')
    distribution = value['distribution']
    if not isinstance(distribution, str) or not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', distribution):
        raise ProfileError('product_distribution_invalid')
    commands = value['commands']
    if not isinstance(commands, dict) or set(commands) != {'main', 'read', 'hook_claude'}:
        raise ProfileError('product_commands_shape')
    if any(not isinstance(v, str) or not re.fullmatch(r'[a-z][a-z0-9-]{0,63}', v)
           for v in commands.values()) or len(set(commands.values())) != len(commands):
        raise ProfileError('product_command_invalid')
    if commands['read'] != commands['main']+'-read' or commands['hook_claude'] != commands['main']+'-hook-claude':
        raise ProfileError('product_commands_inconsistent')
    directory = value['home_directory']
    if not isinstance(directory, str) or not re.fullmatch(r'\.[a-z][a-z0-9-]{0,63}', directory):
        raise ProfileError('product_home_directory_invalid')
    environment = value['environment']
    if (not isinstance(environment, dict) or len(environment) > 64
            or any(not isinstance(v, str) or not re.fullmatch(r'[A-Z][A-Z0-9_]{0,79}', v)
                   for pair in environment.items() for v in pair)
            or len(set(environment.values())) != len(environment)):
        raise ProfileError('product_environment_invalid')
    # Aliases may map to themselves, but may not change another alias's input.
    if any(public in environment and public != internal for internal, public in environment.items()):
        raise ProfileError('product_environment_alias_cycle')
    return Profile(value['edition'], display, distribution, MappingProxyType(dict(commands)), directory,
                   MappingProxyType(dict(environment)), hashlib.sha256(raw).hexdigest())


def load(path=None):
    """Read the installed sibling profile. An optional path is for source tooling.

    There is deliberately no env-var or CLI profile selector. A missing profile
    is a broken build, not permission to fall back to another installation.
    """
    path = Path(__file__).with_name('product_profile.json') if path is None else Path(path)
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(fd, 'rb') as source:
            before = os.fstat(source.fileno())
            if (not stat.S_ISREG(before.st_mode)
                    or before.st_uid not in {0, os.getuid()} or before.st_mode & 0o022):
                raise ProfileError('product_profile_file_unsafe')
            raw = source.read(16385)
            after = os.fstat(source.fileno())
            if (len(raw) > 16384 or (before.st_dev, before.st_ino, before.st_size,
                    before.st_mtime_ns, before.st_ctime_ns) != (after.st_dev, after.st_ino,
                    after.st_size, after.st_mtime_ns, after.st_ctime_ns)):
                raise ProfileError('product_profile_file_changed_or_large')
    except ProfileError:
        raise
    except OSError:
        raise ProfileError('product_profile_unavailable') from None
    return parse(raw)


def command(role='main'):
    return load().command(role)


def state_root(home=None):
    return load().state_root(home)


def is_public():
    return load().is_public


def hook_brand():
    profile = load()
    return profile.display_name if profile.is_public else profile.command().upper()


def diagnostic(private, public):
    """Keep estate diagnostics; public instructions never ask for a variable."""
    return public if is_public() else private


def html_shell(source):
    """Supply non-secret display metadata at response time, not in the wheel.

    The committed build remains reproducible. Only the title, the two named
    meta fields and the classic page's state-root label are product-name fields.
    """
    import html
    profile = load()
    if source.count('</head>') != 1 or 'name="product-display-name"' in source:
        raise ProfileError('product_html_shell_invalid')
    metadata = (f'<meta name="product-display-name" content="{html.escape(profile.display_name, quote=True)}">\n'
                f'<meta name="product-home-directory" content="{html.escape(profile.home_directory, quote=True)}">\n')
    result = source.replace('</head>', metadata+'</head>', 1)
    result, count = re.subn(r'<title>[^<]*</title>', '<title>'+html.escape(profile.display_name)+'</title>', result)
    if count != 1:
        raise ProfileError('product_html_title_invalid')
    return result.replace('<span data-product-state-root>.quovisto</span>',
                          '<span data-product-state-root>'+html.escape(profile.home_directory)+'</span>')


def inherited_setting(name, environment=None):
    """Public account binding never inherits private owner/store selectors."""
    if is_public() and name in {'PSQR_OWNER', 'PSQR_STORE_DIR'}:
        return None
    return (os.environ if environment is None else environment).get(name)


def manifest_shell(raw):
    """Select display names without changing icons, scope, or launch URLs."""
    profile = load()
    value = json.loads(raw)
    if not isinstance(value, dict):
        raise ProfileError('product_manifest_invalid')
    value['name'] = profile.display_name
    value['short_name'] = profile.display_name
    return value
