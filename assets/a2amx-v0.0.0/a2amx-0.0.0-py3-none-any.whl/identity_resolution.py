"""Pure ID/label resolution against the caller's existing registry snapshot."""
from collections.abc import Mapping
from typing import Any


def label_index(participants: Mapping[str, Mapping[str, Any]]) -> dict[str, list[str]]:
    """Keep the store's existing lower-case label matching and insertion order."""
    labels: dict[str, list[str]] = {}
    for pid, row in participants.items():
        labels.setdefault((row.get("label") or pid).lower(), []).append(pid)
    return labels


def resolve_id_or_label(name: str, participants: Mapping[str, Mapping[str, Any]],
                        *, labels=None) -> set[str] | None:
    """Exact ID, then unique label; empty means ambiguous, None means unknown.

    Callers retain their own retirement, broadcast and role policies. An
    ambiguous label must not fall through to a role with the same spelling.
    """
    labels = label_index(participants) if labels is None else labels
    if name in participants:
        return {name}
    matches = labels.get(name.lower())
    if not matches:
        return None
    return set(matches) if len(matches) == 1 else set()
