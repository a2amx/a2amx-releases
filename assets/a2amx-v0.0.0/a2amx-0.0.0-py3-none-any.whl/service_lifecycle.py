"""Infrastructure leases: verified process incarnations, never PID-only teardown.

Used by the product up/down commands. A released lease does not prove death;
an unavailable process probe does not prove absence. Neither permits a signal.
"""
from contextlib import contextmanager
import fcntl
import hmac
import json
import os
from pathlib import Path
import signal
import stat
import struct
import subprocess
import sys
import time

import store

SOURCE = Path(__file__).resolve().parent
PROBE_ENV = {'PATH': os.defpath, 'LC_ALL': 'C', 'TZ': 'UTC'}


def readiness_proof(token, pid, challenge):
    """Prove the expected server knows the key, without sending the key first."""
    message = f'orch-first-run-readiness-v1:{pid}:{challenge}'.encode()
    return hmac.digest(token.encode(), message, 'sha256').hex()


class Refused(RuntimeError):
    pass


class ProcessToolUnavailable(OSError):
    """The process tool could not run; identity remains unverified."""


def private_file(path, flags=os.O_RDONLY):
    """Open an existing owned regular 0600 file, refusing links and special files."""
    fd = os.open(path, flags | os.O_NOFOLLOW | os.O_NONBLOCK)
    info = os.fstat(fd)
    if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
            or stat.S_IMODE(info.st_mode) != 0o600 or info.st_nlink != 1):
        os.close(fd)
        raise Refused(f'{path.name}: expected an owned regular 0600 file with one link')
    return fd


def daemon_lease_file(path):
    """Read non-secret legacy daemon metadata without changing its permissions.

    Older daemons created this file under umask 022. Only that exact 0644 form
    joins 0600 here; credential files and web leases still require 0600.
    """
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    info = os.fstat(fd)
    if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
            or stat.S_IMODE(info.st_mode) not in (0o600, 0o644) or info.st_nlink != 1):
        os.close(fd)
        raise Refused(f'{path.name}: expected an owned regular 0600/0644 daemon lease with one link')
    return fd


def process(pid, *, timeout=5):
    """Return a measured identity, None ONLY for a successful absence observation."""
    try:
        result = subprocess.run(
            ['ps', '-ww', '-p', str(pid), '-o', 'uid=,stat=,lstart=,command='],
            capture_output=True, text=True, timeout=timeout, env=PROBE_ENV)
    except (OSError, subprocess.SubprocessError) as exc:
        raise ProcessToolUnavailable(
            'process_tool_unavailable: ps cannot provide process identity; verification refused') from exc
    if result.returncode == 1 and not result.stdout.strip() and not result.stderr.strip():
        return None
    if result.returncode or result.stderr.strip():
        raise Refused('process metadata unavailable')
    fields = result.stdout.strip().split(None, 7)
    if len(fields) != 8 or not fields[0].isdigit():
        raise Refused('process metadata malformed')
    return {'uid': int(fields[0]), 'state': fields[1],
            'birth': ' '.join(fields[2:7]), 'command': fields[7]}


def command_matches(kind, command):
    """Accept only this installation's exact resolved Python service command."""
    script = 'delivery.py' if kind == 'daemon' else 'psqr_orchestrator.py'
    executables = {Path(sys.executable).resolve()}
    # macOS framework Python's bin/python launcher execs this sibling binary.
    # Bind it to this interpreter's base prefix, never accept arbitrary Python.
    if sys.platform == 'darwin':
        framework = Path(sys.base_prefix) / 'Resources/Python.app/Contents/MacOS/Python'
        if framework.is_file():
            executables.add(framework.resolve())
    # ps renders an unquoted command string. Compare the whole expected prefix;
    # shlex parsing would break legitimate install paths containing spaces.
    for executable in executables | {Path(sys.executable)}:
        prefix = f'{executable} -B {SOURCE / script}'
        if kind == 'daemon' and command == prefix:
            return True
        prefix += ' serve --host 127.0.0.1 --port '
        if kind == 'web' and command.startswith(prefix):
            port = command[len(prefix):]
            if port.isdigit() and 0 < int(port) < 65536:
                return True
    return False


class Lease:
    def __init__(self, root, kind, *, observe=False):
        self.root, self.kind = Path(root), kind
        self.path = self.root / ('daemon.lock' if kind == 'daemon' else 'web-server.lock')
        self.fd = daemon_lease_file(self.path) if kind == 'daemon' else private_file(self.path)
        self.info = os.fstat(self.fd)
        self.record = None
        self.observe = observe

    def close(self):
        os.close(self.fd)

    def unchanged(self):
        info = self.path.lstat()
        if (info.st_dev, info.st_ino) != (self.info.st_dev, self.info.st_ino):
            raise Refused(f'{self.kind}: lease replaced during observation')
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                or stat.S_IMODE(info.st_mode) not in ((0o600, 0o644) if self.kind == 'daemon' else (0o600,))
                or stat.S_IMODE(info.st_mode) != stat.S_IMODE(self.info.st_mode)
                or info.st_nlink != 1):
            raise Refused(f'{self.kind}: lease permissions changed during observation')

    def held(self):
        self.unchanged()
        if self.observe:
            held = observed_flock(self.fd)
            self.unchanged()
            return held
        try:
            fcntl.flock(self.fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return True
        fcntl.flock(self.fd, fcntl.LOCK_UN)
        return False

    def read(self):
        self.unchanged()
        os.lseek(self.fd, 0, os.SEEK_SET)
        raw = os.read(self.fd, 8193)
        if len(raw) > 8192:
            raise Refused(f'{self.kind}: oversized lease')
        try:
            record = json.loads(raw)
        except (ValueError, UnicodeError):
            raise Refused(f'{self.kind}: malformed lease') from None
        if (not isinstance(record, dict) or type(record.get('pid')) is not int
                or record['pid'] <= 1 or not isinstance(record.get('proc_birth'), str)
                or not record['proc_birth'] or record.get('store_dir') != str(self.root)
                or (self.kind == 'web' and record.get('kind') != 'orch-web')):
            raise Refused(f'{self.kind}: lease identity unproven')
        return record

    def verify(self):
        bound, _ = store.read_locator()
        if bound != self.root:
            raise Refused(f'{self.kind}: store binding changed')
        record = self.read()
        if self.record is not None and record != self.record:
            raise Refused(f'{self.kind}: lease incarnation changed')
        self.record = record
        seen = process(record['pid'])
        if (seen is None or seen['uid'] != os.getuid() or seen['state'].startswith('Z')
                or seen['birth'] != record['proc_birth']
                or not command_matches(self.kind, seen['command']) or not self.held()
                or self.read() != record):
            raise Refused(f'{self.kind}: live process ownership unproven')
        self.observed = seen
        return record


def _linux_flock_identity(fd):
    """Bind fstat to a direct, local inode before interpreting /proc/locks.

    Layered/network filesystems may lock an underlying inode with a different
    identity or lock implementation. A missing table match is not evidence of
    freedom there. Support direct ext and tmpfs mappings; refuse other mounts.
    """
    info = os.fstat(fd)
    fields = {}
    with open(f'/proc/self/fdinfo/{fd}', encoding='ascii') as source:
        for line in source:
            key, _, value = line.partition(':')
            if key in ('mnt_id', 'ino'):
                if key in fields:
                    raise ValueError('ambiguous descriptor identity')
                fields[key] = int(value.strip())
    if fields.get('ino') != info.st_ino or 'mnt_id' not in fields:
        raise ValueError('unmapped descriptor identity')
    mounts = []
    with open('/proc/self/mountinfo', encoding='ascii') as source:
        for line in source:
            before, separator, after = line.partition(' - ')
            columns = before.split()
            if columns and columns[0] == str(fields['mnt_id']):
                if not separator or len(columns) < 6 or not after.split():
                    raise ValueError('malformed mount identity')
                mounts.append((columns[2], after.split()[0]))
    target = (os.major(info.st_dev), os.minor(info.st_dev), info.st_ino)
    if (len(mounts) != 1 or mounts[0][1] not in {'ext2', 'ext3', 'ext4', 'tmpfs'}
            or mounts[0][0] != f'{target[0]}:{target[1]}'):
        raise ValueError('unmapped Linux flock filesystem identity')
    return target


def observed_flock(fd):
    """Read lock state without taking a lock that can defeat a service's claim.

    Darwin F_GETLK sees BSD flock conflicts (pid -1). Linux record locks are
    independent of flock: use the kernel's FLOCK table, never F_GETLK there.
    Unavailable observations refuse; they must not fall back to a locking probe.
    """
    try:
        if sys.platform == 'darwin':
            query = struct.pack('qqihh', 0, 0, 0, fcntl.F_WRLCK, os.SEEK_SET)
            result = fcntl.fcntl(fd, fcntl.F_GETLK, query)
            kind = struct.unpack('qqihh', result)[3]
            if kind not in (fcntl.F_UNLCK, fcntl.F_RDLCK, fcntl.F_WRLCK):
                raise ValueError('unknown lock type')
            return kind != fcntl.F_UNLCK
        if sys.platform.startswith('linux'):
            target = _linux_flock_identity(fd)
            with open('/proc/locks', encoding='ascii') as locks:
                for line in locks:
                    fields = line.split()
                    if len(fields) > 1 and fields[1] == '->':
                        continue  # a waiting request, not a held lock
                    if len(fields) != 8:
                        raise ValueError('malformed lock table')
                    if fields[1] != 'FLOCK':
                        continue
                    major, minor, inode = fields[5].split(':')
                    identity = (int(major, 16), int(minor, 16), int(inode))
                    if fields[3] not in ('READ', 'WRITE') or fields[6:] != ['0', 'EOF']:
                        raise ValueError('malformed flock record')
                    if identity == target:
                        return True
            return False
        raise ValueError('unsupported platform')
    except (OSError, ValueError, struct.error) as exc:
        raise Refused('read-only lease observation unavailable') from exc


@contextmanager
def lease(root, kind, *, observe=False):
    try:
        found = Lease(root, kind, observe=observe)
    except FileNotFoundError:
        yield None
        return
    try:
        yield found
    finally:
        found.close()


def clean_empty_web_lease(root):
    """Startup recovery only: unlink an unchanged, private, empty, free lease.

    This exclusive lock performs cleanup; it is never a readiness probe. The
    claimant rechecks its named inode after locking, so an already-open child
    cannot publish ownership on an inode this cleanup unlinked.
    """
    with lease(root, 'web') as owned:
        if owned is None or os.fstat(owned.fd).st_size:
            return False
        try:
            fcntl.flock(owned.fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return False
        try:
            owned.unchanged()
            if os.fstat(owned.fd).st_size:
                return False
            owned.path.unlink()
            return True
        finally:
            fcntl.flock(owned.fd, fcntl.LOCK_UN)


def verified_web_port(root):
    """Read the port from the current owned web process, never a stale PID."""
    with lease(root, 'web', observe=True) as owned:
        if owned is None or not owned.held():
            return None
        owned.verify()
        # verify() accepts only this installation's exact web command and a valid port.
        return int(owned.observed['command'].rsplit(' ', 1)[-1])


def stop(root, kind, *, timeout=30.0, expected_pid=None, reap=None):
    """TERM once, then require process absence AND release of the same lease."""
    try:
        with lease(root, kind) as owned:
            if owned is None:
                if expected_pid is not None:
                    raise Refused(f'{kind}: started child has no verifiable lease; no signal sent')
                return True, f'{kind}: no recorded service'
            if not owned.held():
                record = owned.read()
                seen = process(record['pid'])
                if seen is not None:
                    raise Refused(f'{kind}: lease released but recorded process still exists; no signal sent')
                return True, f'{kind}: process absent and lease released'
            record = owned.verify()
            if expected_pid is not None and record['pid'] != expected_pid:
                raise Refused(f'{kind}: not the child started by this invocation')
            # Repeat immediately at the signal boundary, not just at command entry.
            owned.verify()
            try:
                os.kill(record['pid'], signal.SIGTERM)
            except ProcessLookupError:
                pass
            deadline = time.monotonic() + timeout
            while True:
                if reap is not None:
                    reap()
                seen = process(record['pid'])
                held = owned.held()
                if seen is None and not held:
                    return True, f'{kind}: stopped; process absent and lease released'
                if seen is not None and seen['birth'] != record['proc_birth']:
                    raise Refused(f'{kind}: PID reused during stop; no further signal sent')
                if owned.read() != record:
                    raise Refused(f'{kind}: lease changed during stop; no further signal sent')
                if time.monotonic() >= deadline:
                    raise Refused(f'{kind}: stop timed out; death and lease release not both verified')
                time.sleep(0.25)
    except (OSError, ValueError, Refused, subprocess.SubprocessError) as exc:
        return False, f'{kind}: refused: {exc}'
