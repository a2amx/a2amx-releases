#!/usr/bin/env python3
"""orch — the single entry point for the PSQR orchestrator.

Run with no arguments for the interactive menu (status, read, direct message,
assign — everything the operator does). Subcommands cover the same actions
non-interactively for agents and scripts. Stdlib only: starts instantly,
no venv needed (the web server, which needs FastAPI, is spawned via uv).

Identity: hub-acting commands (send, inbox, join, invite, …) DERIVE it from the seat
token — --token-file, else $ORCH_TOKEN_FILE, else $ORCH_TOKEN, else the nearest
.orch/token at or above the cwd (the seat's own workspace). --as / $ORCH_AGENT are inert
for them (Phase A A.4, ORCH_SPEC_01 D-IDT-1) and only name a read-only/local view
(status, log, tasks board …), else the operator.
"""

from __future__ import annotations

import stage1_features

import argparse
import json
import os
import re
import select
import shlex
import shutil
import stat
import subprocess
import sys
import time
from datetime import date, datetime, time as datetime_time, timezone
from pathlib import Path

import store
import product_identity
import product
import dialogue
from launch_environment import sanitized_env
import panel as seat_panel
from launch_profiles import (CODER, coder_role_precondition_error,
                             launch_profile_for_seat)
import reviewer_hub_policy
import seat as seat_launcher
from notify import one_line
from tmux_bridge import (kill_registered_server, kill_session, list_sessions,
                         new_session, pane_ready, registered_session_exists, registered_pane_ready,
                         send_prompt, send_registered_prompt, session_exists,
                         wait_for_pane_ready, wait_for_registered_pane_ready)

SCRIPT_DIR = Path(__file__).resolve().parent
SERVER_LOG = store.STORE_DIR / "server.log"
SERVER_PORT = int(os.environ.get("PSQR_PORT", "8020"))

# Tmux rebirth uses the same role-aware, fail-closed resolver as the web
# Add-Agent path. The canonical behavioral contract and fixed vendor commands
# live in launch_profiles.py; this path never derives write access from family.

# Per-agent rebirth prompt resolution order (first non-empty wins):
#   1. participant "rebirth_prompt" registry field (absolute path)
#   2. store/rebirth/<pid>.md   — machine-local override (gitignored)
#   3. rebirth/<pid>.md in the repo — CANONICAL, tracked, clone-durable
# (3) is the source of truth that survives a fresh clone/machine; (2) lets an
# operator override locally without editing the repo.
REBIRTH_DIR = store.STORE_DIR / "rebirth"          # local override (gitignored)
REBIRTH_REPO_DIR = SCRIPT_DIR / "rebirth"          # canonical, repo-tracked
REBIRTH_VINTAGE_STATUS = REBIRTH_REPO_DIR / "VINTAGE_STATUS.json"
PANE_BOOT_TIMEOUT = 30.0   # max wait for a freshly-launched CLI to accept input
PANE_BOOT_SETTLE = 4.0     # extra settle after the pane reports ready


def _tracked_rebirth_prompt_is_current(pid: str) -> bool:
    """Fail closed unless the tracked prompt has an explicit CURRENT review."""
    try:
        payload = json.loads(REBIRTH_VINTAGE_STATUS.read_text(encoding="utf-8"))
        status = payload["prompts"][pid]["status"]
    except (FileNotFoundError, OSError, KeyError, TypeError, ValueError, json.JSONDecodeError):
        return False
    return status == "CURRENT"


def rebirth_prompt_for(pid: str, participant: dict) -> str | None:
    """Return the rebirth prompt text for pid, or None if none is configured."""
    override = participant.get("rebirth_prompt")
    candidates: list[tuple[Path, bool]] = []
    if override:
        candidates.append((Path(override).expanduser(), False))
    candidates.append((REBIRTH_DIR / f"{pid}.md", False))
    candidates.append((REBIRTH_REPO_DIR / f"{pid}.md", True))
    for path, is_tracked in candidates:
        if is_tracked and not _tracked_rebirth_prompt_is_current(pid):
            continue
        try:
            text = path.read_text(encoding="utf-8").strip()
        except (FileNotFoundError, OSError):
            continue
        if text:
            return text
    return None

BOLD, DIM, RESET = "\033[1m", "\033[2m", "\033[0m"
GREEN, YELLOW, RED, CYAN = "\033[32m", "\033[33m", "\033[31m", "\033[36m"


def fmt_ts(ts: str) -> str:
    return ts[11:16] if len(ts) >= 16 else ts


# --- process helpers ---

# ONE lock parser and ONE flock probe — store.py's, shared with the registration act's
# orphan guard — so health, teardown and registration read the same evidence.
_parse_daemon_lock = store.parse_daemon_lock
_lock_is_held = store.daemon_lock_is_held


def daemon_health(*, facts: dict | None = None) -> tuple[str, str, int | None]:
    """The same heartbeat evidence as the console; process probes only govern teardown.

    The legacy facts argument remains accepted, but cannot substitute for the
    shared heartbeat observation.
    """
    from daemon_heartbeat import snapshot
    observed = snapshot()
    reason = observed['detail']
    if observed['state'] == 'up':
        reason = f"pid {observed['pid']} · heartbeat {observed['heartbeat_age_seconds']:.0f}s ago"
    return observed['state'].upper(), reason, observed['pid']


def _daemon_lock_facts() -> dict:
    """Every measurable fact about daemon.lock, probed ONCE, so health (strict) and
    teardown (permissive about identity metadata, strict about pid ownership) read the
    same evidence. ``birth_ok``/``store_ok`` are True/False/None (None = not recorded)."""
    f: dict = {"lock_exists": False, "rec": None, "pid": None, "alive": False, "held": False,
               "birth_ok": None, "store_ok": None, "error": None}
    lock_path = store.STORE_DIR / "daemon.lock"
    if not lock_path.exists():
        return f
    f["lock_exists"] = True
    try:
        f["rec"] = _parse_daemon_lock(lock_path.read_text())
    except OSError as exc:
        f["error"] = f"daemon.lock unreadable: {exc.strerror}"
        return f
    if f["rec"] is None:
        return f
    pid = f["pid"] = f["rec"]["pid"]
    from runtime_registry import os_proc_birth, proc_identity_ok
    f["alive"] = os_proc_birth(pid) is not None
    if not f["alive"]:
        return f
    try:
        f["held"] = _lock_is_held(lock_path)
    except OSError as exc:
        f["error"] = f"daemon.lock flock probe failed: {exc.strerror}"
        return f
    if not f["held"]:
        return f
    birth = f["rec"].get("proc_birth")
    f["birth_ok"] = proc_identity_ok(pid, birth) if birth else None
    recorded = f["rec"].get("store_dir")
    f["store_ok"] = store._same_dir(Path(recorded), store.STORE_DIR) if recorded else None
    return f


def daemon_pid() -> int | None:
    """The delivery daemon's pid ONLY when it is provably UP (see daemon_health)."""
    state, _, pid = daemon_health()
    return pid if state == "UP" else None


def daemon_pid_for_teardown() -> int | None:
    """The pid that OWNS daemon.lock, for `orch down`/`shutdown`: alive, holding the flock,
    and not proven to be a DIFFERENT incarnation. A legacy lock (no birth recorded) or a
    store-mismatched daemon is still ours to stop; a reused pid (birth mismatch) is
    somebody else's process and is never signalled. Health stays strict (UP only);
    teardown must not strand a live daemon behind a lock that cannot prove UP."""
    f = _daemon_lock_facts()
    if f["error"] or not f["alive"] or not f["held"] or f["birth_ok"] is False:
        return None
    return f["pid"]


def daemon_health_line(health: tuple[str, str, int | None] | None = None) -> str:
    state, reason, _ = health if health is not None else daemon_health()
    colour = {"UP": GREEN, "DOWN": RED}.get(state, YELLOW)
    return f"{colour}{state} ({reason}){RESET}"


def server_alive(port: int | None = None) -> bool:
    import urllib.error
    import urllib.request
    try:
        selected = SERVER_PORT if port is None else port
        with urllib.request.urlopen(f"http://127.0.0.1:{selected}/state", timeout=1):
            return True
    except urllib.error.HTTPError as exc:
        return exc.code == 401  # auth-protected server is still a live server
    except Exception:
        return False


def stop_daemon() -> None:
    pid = daemon_pid_for_teardown()
    if pid and pid > 0:
        try:
            os.kill(pid, 15)
        except ProcessLookupError:
            pass


# --- commands ---

def cmd_status(args) -> int:
    from collections import Counter
    unread_ledger = store.unread_ledger()
    unread_by_seat = Counter(row["recipient"] for row in unread_ledger["rows"])
    if unread_ledger["cutover"] is None:
        print("Receipts cutover not recorded; unread ledger unavailable.")
    parts = store.load_participants()
    import harness_facts
    reported = harness_facts.snapshot(parts)
    print(f"\n{BOLD}{product_identity.load().display_name}{RESET}  "
          f"daemon: {daemon_health_line()}"
          f"{DIM} · web: {'up' if server_alive() else 'down'} · store: {store.STORE_DIR}{RESET}\n")
    for pid, p in parts.items():
        if store.inactive_participant(p):
            continue
        if not store.has_mailbox(p):
            print(f"  {p.get('label', pid):10} {DIM}authority{RESET}")
            continue
        unread = unread_by_seat[pid]
        hand = f" {YELLOW}✋ {p.get('hand_message', '')}{RESET}" if p.get("hand_raised") else ""
        chan = p.get("channel", "?")
        from console_observation import observe
        observation = observe(pid, parts)
        liveness = observation.get('liveness')
        if isinstance(liveness, dict):
            liveness = liveness.get('value')
        live = (f" {GREEN}●{RESET}" if observation['alive'] else
                f" {DIM if observation['hosting'] == 'none' else RED}○ {liveness or 'unmeasurable'}{RESET}")
        unread_s = f" {CYAN}{unread} unread{RESET}" if unread else ""
        print(f"  {p.get('label', pid):10} {DIM}{p.get('kind', ''):6} via {chan:6}{RESET}{live}{unread_s}{hand}")
        if p.get('kind') != 'human':
            facts = reported.get(pid)
            stamp = facts['reported_at'] if facts else 'never'
            print(f"    {harness_facts.line(facts)} (last reported: {stamp})")
    print(f"\n{DIM}Recent dialogue:{RESET}")
    recent, _ = dialogue.select(
        limit=5, visible=lambda row: not store.obsolete_human_notice(row, parts))
    for m in recent:
        if store.inactive_participant(parts.get(m.get('from'), {})):
            continue
        print(f"  [{fmt_ts(m.get('ts', ''))}] {m.get('from', '?'):10} {one_line(m.get('text', ''), 90)}")
    open_tasks = [t for t in store.task_board() if t["status"] == "open"
                  and not store.inactive_participant(parts.get(t.get("assignee"), {}))]
    if open_tasks:
        print(f"\n{DIM}Open tasks:{RESET}")
        for t in open_tasks:
            print(f"  [{t['id'][-4:]}] → {t['assignee'] or 'unassigned'}: {one_line(t['title'], 80)}")
    print(f"retired: {sum(bool(p.get('retired_at')) for p in parts.values())}")
    return 0


def _print_messages(msgs, as_json: bool) -> None:
    if as_json:
        print(json.dumps(msgs, indent=2, ensure_ascii=False))
        return
    if not msgs:
        print("(no new messages)")
        return
    for m in msgs:
        to = ",".join(m.get("to", []))
        print(f"\n{BOLD}[{m.get('ts', '')}] {m.get('from', '?')} → {to}{RESET}"
              f"{DIM} ({m.get('id', '')}){RESET}")
        print(m.get("text", ""))
    print()


def cmd_inbox(args) -> int:
    pid = args.participant or args.identity
    if not store.has_mailbox(store.load_participants().get(pid, {})):
        _print_messages([], args.json)
        return 0
    if getattr(args, 'harness_json', None) is not None:
        import harness_facts
        try:
            if args.peek or len(args.harness_json) > 2048:
                raise ValueError('invalid reporting fetch')
            args.harness = harness_facts.validate(json.loads(args.harness_json))
        except (TypeError, ValueError, RecursionError):
            print('invalid harness facts; inbox unchanged', file=sys.stderr)
            return 1
    if getattr(args, 'save_home', None) is not None:
        if args.peek:
            print('a peek cannot save a consuming fetch', file=sys.stderr)
            return 1
        import wake_hook_store
        try:
            saved = wake_hook_store.fetch(presented_token=args.presented_token,
                expected_actor=args.identity, home=args.save_home or None, session_ref=None, via='inbox')
        except (OSError, ValueError):
            print('saved inbox fetch failed; check the seat inbox for any durable batch', file=sys.stderr)
            return 1
        if args.json:
            print(json.dumps(saved, ensure_ascii=False))
        else:
            _print_messages(saved['messages'], False)
            print('inbox: ' + saved['inbox_path'])
        return 0
    msgs = store.drain_inbox(pid, peek=args.peek)
    _print_messages(msgs, args.json)
    return 0


def cmd_seat_event(args) -> int:
    import wake_hook_store
    try:
        result = wake_hook_store.post(json.load(sys.stdin), presented_token=args.presented_token,
                                      expected_actor=args.identity)
        print(json.dumps(result))
        return 0 if result['accepted'] else 1
    except Exception:
        # Input/error strings can contain arbitrary prompt text or credentials.
        print('hook event refused', file=sys.stderr)
        return 1


def cmd_hook_fetch(args) -> int:
    import wake_hook_store
    try:
        value = json.load(sys.stdin)
        if (not isinstance(value, dict) or not {'home', 'session_ref'} <= set(value)
                or set(value) - {'home', 'session_ref', 'harness'}):
            raise ValueError('invalid hook fetch request')
        result = wake_hook_store.fetch(presented_token=args.presented_token,
                                       expected_actor=args.identity, **value)
        print(json.dumps(result, ensure_ascii=False))
        return 0
    except Exception:
        print('hook fetch failed', file=sys.stderr)
        return 1


def cmd_agy_hook_fetch(args) -> int:
    import wake_hook_store
    try:
        value=json.loads(sys.stdin.buffer.read(65537))
        if not isinstance(value,dict) or set(value)!={'home','session_ref','agy_invocation'}:
            raise ValueError('invalid AGY hook request')
        if type(value['agy_invocation']) is not int or value['agy_invocation'] < 0:
            raise ValueError('invalid AGY invocation')
        result=wake_hook_store.fetch(presented_token=args.presented_token,
                                    expected_actor=args.identity,**value)
        print(json.dumps(result,ensure_ascii=False))
        return 0
    except Exception:
        print('AGY hook fetch failed',file=sys.stderr)
        return 1


def cmd_agy_hook_emitted(args) -> int:
    from desktop_support import require
    agy_recovery = require('agy_recovery')
    try:
        value=json.loads(sys.stdin.buffer.read(65537))
        if not isinstance(value,dict) or set(value)!={'msg_ids'} or not isinstance(value['msg_ids'],list):
            raise ValueError('invalid emission record')
        result=agy_recovery.emitted(presented_token=args.presented_token,
                                   expected_actor=args.identity,**value)
        print(json.dumps(result))
        return 0
    except Exception:
        print('AGY emission record failed; recovery retained',file=sys.stderr)
        return 1


def cmd_agy_read(args) -> int:
    from desktop_support import require
    agy_recovery = require('agy_recovery')
    try:
        def output(text):
            sys.stdout.write(text);sys.stdout.flush()
        result=agy_recovery.explicit_read(presented_token=args.presented_token,
            expected_actor=args.identity,msg_ids=args.msg_ids,seat=args.seat,
            acknowledge=args.command=='agy-ack',output=output)
        if args.command=='agy-ack':
            print(json.dumps(result))
        return 0
    except Exception:
        print('AGY recovery read refused; recovery retained',file=sys.stderr)
        return 1


def cmd_agy_sidecar(args) -> int:
    from desktop_support import require
    agy_sidecar = require('agy_sidecar')
    try:
        return agy_sidecar.run(args)
    except Exception:
        print('AGY sidecar stopped; no native retry of a claimed intent',file=sys.stderr)
        return 1


def cmd_mail(args) -> int:
    import receipts
    try:
        result = receipts.fetch(args.msg_id, args.identity)
    except (KeyError, PermissionError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


def cmd_recall(args) -> int:
    import recall
    try:
        authorization = None
        if args.authorization_file:
            from pathlib import Path
            from console_files import directory, read
            path = Path(args.authorization_file).absolute()
            with directory(path.parent) as fd:
                authorization = json.loads(read(fd, path.name, limit=65536))
        result = recall.recall(args.msg_id, presented_token=args.presented_token,
                               reason=args.reason, unread_only=args.unread_only,
                               authorization=authorization)
    except recall.Refused as exc:
        for seat, timestamp in exc.readers.items():
            print(f"read by {seat}: {timestamp}")
        print(str(exc), file=sys.stderr)
        return 1
    except (OSError, ValueError, TypeError):
        print('recall_refused: invalid input or unavailable journal; retry observes any committed event', file=sys.stderr)
        return 1
    state = 'withdrawn' if result['kind'] == 'withdraw' else 'recalled'
    import receipts
    attempts = sum(r.get('recall-id') == result['id'] and r.get('result') == 'recalled'
                   for r in receipts.strict_rows())
    print(f"{state} {args.msg_id}: unread by {len(result['unread_recipients'])} recipients, "
          f"{result['pointers_recomputed']} pointers recomputed, {attempts} attempts reconciled")
    for seat, timestamp in result['readers'].items():
        print(f"read by {seat}: {timestamp}")
    return 0


def cmd_await(args) -> int:
    pid = args.participant or args.identity
    if args.filtered:
        return _await_filtered(pid, heartbeat_hours=args.heartbeat_hours,
                               as_json=args.json)
    msgs = store.await_inbox(pid, timeout=args.timeout)
    _print_messages(msgs, args.json)
    return 0 if msgs else 2


# Filtered watcher (wake-economy norm, ORG_CLAUDE) — promoted from reviewer's
# reviewer_watcher.py prototype (design + first implementation: reviewer, 2026-07).
# Tails the append-only log.jsonl READ-ONLY (never consumes the inbox) and
# returns only when a message actually needs the seat: 'to' names it, or the
# text mentions it (case-insensitive). Broadcasts that don't mention the seat
# accumulate silently for batch drain at the next legitimate wake.
#
# Exit codes: 0 = relevant message (printed) · 2 = heartbeat elapsed (batch-
# sweep the inbox and re-arm) · 1 = error (log missing/unreadable).
#
# Offset state lives in store/watch/<pid>.offset so restarts never replay
# history (first run starts at end-of-file); a truncated/rotated log resyncs
# to its new end rather than replaying.
WATCH_POLL_SEC = 2.0


def _watch_offset_path(pid: str) -> Path:
    d = store.STORE_DIR / "watch"
    d.mkdir(parents=True, exist_ok=True)
    return d / f"{pid}.offset"


def _write_offset(state: Path, off: int) -> None:
    """Atomic offset persist (reviewer #48 LOW): a crash mid-write must never
    leave a torn state file — that would read as first-run and silently skip
    unread history to EOF. tmp + os.replace is atomic on POSIX."""
    tmp = state.with_name(state.name + ".tmp")
    tmp.write_text(str(off))
    os.replace(tmp, state)


def _watch_relevant(rec: dict, pid: str) -> bool:
    if store.delivery_blocked(rec):
        return False
    if rec.get("from") == pid:
        return False
    kind = rec.get("kind")
    if kind == "control":
        import vetting
        return vetting.is_typed_interrupt_control(rec) and pid in (rec.get("to") or [])
    if kind not in (None, "message"):
        return False
    if pid in (rec.get("to") or []):
        return True
    # WORD-BOUNDARY mention only (reviewer #48 HIGH): an unanchored substring
    # match let ordinary prose force-wake short-named seats ("Ed" in "edited")
    # and made broadcast mention-stuffing a cheap Denial-of-Wallet. Boundaries
    # fix the false positives; deliberate mention-floods stay bounded by the
    # send-side burn guard. Explicit participant lists now make addressed
    # multi-seat sends visible without any room transport.
    return re.search(rf"\b{re.escape(pid)}\b", rec.get("text") or "",
                     re.IGNORECASE) is not None


def _await_filtered(pid: str, *, heartbeat_hours: float, as_json: bool,
                    log_path: Path | None = None,
                    poll_sec: float = WATCH_POLL_SEC) -> int:
    log = log_path if log_path is not None else store.LOG_FILE
    if not log.exists():
        print(f"error: store log not found: {log}", file=sys.stderr)
        return 1
    state = _watch_offset_path(pid)
    try:
        offset = int(state.read_text().strip())
    except (OSError, ValueError):
        offset = log.stat().st_size          # first run: skip history
    heartbeat_sec = heartbeat_hours * 3600
    started = time.time()
    while True:
        try:
            size = log.stat().st_size
        except OSError as exc:
            print(f"error: log stat failed: {exc}", file=sys.stderr)
            return 1
        if size < offset:                    # rotated/truncated — resync, never replay
            offset = size
            _write_offset(state, offset)
        if size > offset:
            with log.open("rb") as f:
                f.seek(offset)
                chunk = f.read(size - offset)
            end = chunk.rfind(b"\n")         # only complete lines; keep the torn tail
            if end >= 0:
                line_start = offset
                for raw in chunk[: end + 1].split(b"\n")[:-1]:
                    line_end = line_start + len(raw) + 1   # +1 = the newline
                    rec = None
                    if raw.strip():
                        try:
                            rec = json.loads(raw)
                        except json.JSONDecodeError:
                            pass             # torn/corrupt line — skip, offset advances
                    if rec is not None and _watch_relevant(rec, pid):
                        # persist only PAST THIS LINE (reviewer #48 / Bugbot #48):
                        # later relevant lines in the same chunk wake the next
                        # arm instead of being silently skipped if the agent
                        # dies before draining its inbox
                        _write_offset(state, line_end)
                        slim = {k: rec.get(k) for k in ("id", "ts", "from", "to", "text")}
                        if as_json:
                            print(json.dumps(slim, ensure_ascii=False))
                        else:
                            print(f"relevant message for {pid}:")
                            print(json.dumps(slim, ensure_ascii=False, indent=2))
                        return 0
                    line_start = line_end
                offset = line_start
                _write_offset(state, offset)
        if heartbeat_sec > 0 and time.time() - started > heartbeat_sec:
            print(f"heartbeat: no {pid}-relevant traffic in the window; "
                  "batch-drain the inbox and re-arm.")
            return 2
        time.sleep(poll_sec)


def _read_send_text(args) -> str:
    """Choose one body source; file input preserves UTF-8 text and line endings."""
    path = getattr(args, "body_file", None)
    if path is None:
        return " ".join(args.text) if args.text else sys.stdin.read()
    if args.text:
        raise ValueError("cannot combine --body-file with a positional body")
    if not sys.stdin.isatty():
        try:
            descriptor = sys.stdin.fileno()
        except (AttributeError, OSError):
            incoming = sys.stdin.read(1)  # In-memory streams have no blocking fd.
        else:
            # A launcher may leave an empty pipe open. Never wait for its EOF.
            incoming = select.select([descriptor], [], [], 0)[0] and os.read(descriptor, 1)
        if incoming:
            raise ValueError("cannot combine --body-file with stdin data")
    descriptor = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
    with os.fdopen(descriptor, "r", encoding="utf-8", newline="") as source:
        if not stat.S_ISREG(os.fstat(source.fileno()).st_mode):
            raise ValueError("--body-file requires a regular file")
        return source.read()


def cmd_message_file(args) -> int:
    from cli_outbox import prepare, MAX_BODY_BYTES
    from hook_io import read_bytes
    try:
        value=read_bytes(sys.stdin.fileno(),limit=MAX_BODY_BYTES,timeout=2).decode('utf-8')
        result=prepare(value,presented_token=args.presented_token,expected_actor=args.identity)
    except store.RegistryMutationRefused as exc:
        return _refuse_identity('message-file',exc.reason,str(exc))
    except (OSError,ValueError,TypeError,TimeoutError):
        print('message-file refused: invalid input, identity or private outbox state',file=sys.stderr)
        return 1
    print(json.dumps(result,sort_keys=True))
    return 0


def cmd_send(args) -> int:
    positional = getattr(args, "to", None)
    option = getattr(args, "to_option", None)
    raw_to = ",".join(value for value in (positional, option) if value)
    if not raw_to:
        print(f"error: explicit recipients are required ({product_identity.command()} send --to A,B ...)", file=sys.stderr)
        return 1
    to = [t.strip() for t in raw_to.split(",")]
    try:
        text = _read_send_text(args)
    except (OSError, UnicodeError, ValueError) as exc:
        print(f"error: --body-file: {exc}", file=sys.stderr)
        return 1
    participants = store.load_participants()
    binding_error = reviewer_hub_policy.sender_binding_error(
        args.identity, participants
    )
    if binding_error:
        print(f"error: reviewer hub identity refused: {binding_error}", file=sys.stderr)
        return 1
    try:
        import message_headers
        recipients = store.resolve_recipients(to, args.identity)
        envelope = getattr(args, "envelope", None)
        comparison = message_headers.validate(text, envelope, args.identity, recipients)
        if comparison["verdict"] == "refused":
            print("error: " + json.dumps(comparison, ensure_ascii=False), file=sys.stderr)
            return 1
        msg = store.send(args.identity, recipients, text, envelope=envelope,
                         presented_token=getattr(args, "presented_token", None),
                         validate_client_headers=True, refuse_invalid_ack=True)
    except store.TypedAckRefused as exc:
        print(f"error: typed-ack-solicited: {exc}; not stored; do not retry this --ack",
              file=sys.stderr)
        return 1
    except message_headers.ClientHeaderRefused as exc:
        print("error: " + json.dumps(exc.comparison, ensure_ascii=False), file=sys.stderr)
        return 1
    except (store.RecipientPolicyError, store.UnreadMailRefused, store.UnreadStateBusy) as exc:
        print(f"error: {json.dumps(exc.detail, ensure_ascii=False, sort_keys=True)}",
              file=sys.stderr)
        return 1
    except KeyError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    except store.BurnGuardTripped as exc:
        print(f"{RED}burn-guard: {exc}{RESET}", file=sys.stderr)
        return 3
    if _report_send_result(msg):
        return 1
    if not daemon_pid():
        print(f"{YELLOW}note: delivery daemon is down — message stored, no push until '{product_identity.command()} up'{RESET}")
    return 0


def _parse_send_tokens(tokens: list[str]) -> tuple[str | None, str | None, list[str]]:
    """Split the send tail without argparse's optional/`nargs=*` ambiguity."""
    literal = []
    if "--" in tokens:
        index = tokens.index("--")
        tokens, literal = tokens[:index], tokens[index + 1:]
        if not tokens:
            return (literal[0] if literal else None), None, literal[1:]
    option_indexes = [i for i, token in enumerate(tokens)
                      if token == "--to" or token.startswith("--to=")]
    if len(option_indexes) > 1:
        raise ValueError("--to may be specified only once")
    if not option_indexes:
        return (tokens[0] if tokens else None), None, tokens[1:] + literal

    index = option_indexes[0]
    before = tokens[:index]
    if len(before) > 1:
        raise ValueError("message text must follow --to; at most one positional recipient may precede it")
    token = tokens[index]
    if token == "--to":
        if index + 1 >= len(tokens):
            raise ValueError("--to requires a comma-separated recipient list")
        option = tokens[index + 1]
        text = tokens[index + 2:]
    else:
        option = token.split("=", 1)[1]
        if not option:
            raise ValueError("--to requires a comma-separated recipient list")
        text = tokens[index + 1:]
    return (before[0] if before else None), option, text + literal


def _extract_send_body_file(tokens: list[str]) -> tuple[list[str], str | None]:
    """Accept a file option around recipients, leaving the literal -- tail alone."""
    remaining, path, index = [], None, 0
    value_options = {"--re", "--authority", "--bluf", "--triage", "--ack",
                     "--claims-recipients", "--to"}
    while index < len(tokens):
        token = tokens[index]
        if token == "--":
            remaining.extend(tokens[index:])
            break
        if token in value_options:
            remaining.extend(tokens[index:index + 2])
            index += 2
            continue
        key, separator, value = token.partition("=")
        if key == "--body-file":
            if path is not None:
                raise ValueError("--body-file may be specified only once")
            if not separator:
                index += 1
                if index >= len(tokens) or tokens[index].startswith("--"):
                    raise ValueError("--body-file requires a path")
                value = tokens[index]
            if not value:
                raise ValueError("--body-file requires a path")
            path = value
        else:
            remaining.append(token)
        index += 1
    return remaining, path


def _parse_send_envelope(tokens: list[str]):
    """Envelope options precede the first recipient; the remainder is the A.1 grammar."""
    envelope, index = {}, 0
    fields = {"--re", "--authority", "--confirm", "--bluf", "--triage", "--ack", "--claims-recipients"}
    while index < len(tokens):
        token = tokens[index]
        key, separator, value = token.partition("=")
        if key not in fields:
            if key.startswith("--") and key not in {"--", "--to"}:
                raise ValueError(f"unknown send option: {key}")
            break
        field = key[2:].replace("-", "_")
        if field in envelope:
            raise ValueError(f"{key} may be specified only once")
        if key == "--confirm":
            if separator:
                raise ValueError("--confirm is a boolean flag, not a value option")
            value = True
        elif not separator:
            index += 1
            if index >= len(tokens) or tokens[index].startswith("--"):
                raise ValueError(f"{key} requires a value")
            value = tokens[index]
        if key == "--claims-recipients":
            value = [name.strip() for name in value.split(",")]
            if not all(value):
                raise ValueError("--claims-recipients requires explicit comma-separated ids")
        envelope[field] = value
        index += 1
    return (*_parse_send_tokens(tokens[index:]), envelope)


class _CommandParser(argparse.ArgumentParser):
    def parse_known_args(self, args=None, namespace=None):
        # argparse.REMAINDER alone rejects a leading --to/--re. Send has its
        # own ordered grammar; preserve its complete argv instead of reordering
        # parse_known_args' unknown options around the positional body.
        if getattr(self, "raw_send", False) and list(args or []) not in (["--help"], ["-h"]):
            namespace = namespace or argparse.Namespace()
            namespace.send_tokens = list(args or [])
            return namespace, []
        return super().parse_known_args(args, namespace)


def cmd_broadcast(args) -> int:
    print(f"{product_identity.command()} broadcast is retired; use: {product_identity.command()} send --to A,B,C <message>")
    return 2


def _send_was_deliverable(message: dict) -> bool:
    """A PASS vet, or an empty vet under the receipted kill-switch, was delivered."""
    verdict = (message.get("vet") or {}).get("verdict")
    return verdict in (None, "PASS")


def cmd_focus(args) -> int:
    """D-GOV-2 (f): the focus period. Every act is the token's; refusals are typed."""
    import focus
    try:
        if args.focus_cmd == "start":
            result = focus.declare(presented_token=args.presented_token, minutes=args.minutes,
                                   reason=args.reason, seat=args.seat)
            print(f"focus {result['period-id']}: {result['seat']} until "
                  f"{focus._iso(result['end_epoch'])} ({result['minutes']} min)")
            if result["listed_pre"]:
                print("carried, pre with no post: " + ", ".join(result["listed_pre"]))
        elif args.focus_cmd == "release":
            result = focus.release(presented_token=args.presented_token)
            print(f"focus {result['period-id']}: {result['seat']} released")
        elif args.focus_cmd == "break":
            result = focus.break_period(presented_token=args.presented_token, seat=args.seat,
                                        reason=args.reason)
            print(f"focus {result['period-id']}: {result['seat']} broken by {result['actor']}")
        elif args.focus_cmd == "show":
            print(json.dumps(focus.show(args.seat), indent=2, sort_keys=True))
        elif args.focus_cmd == "policy":
            if args.policy_cmd == "show":
                view = focus.show()
                print(json.dumps({k: view.get(k) for k in ("state", "maximum_minutes", "policy_generation")},
                                 indent=2, sort_keys=True))
            else:
                result = focus.set_policy(presented_token=args.presented_token,
                                          maximum=None if args.inactive else args.maximum,
                                          expected_generation=args.expected_generation,
                                          reason=args.reason)
                print(json.dumps({k: result[k] for k in ("state", "maximum_minutes", "generation")},
                                 indent=2, sort_keys=True))
        return 0
    except focus.Refused as exc:
        print(f"focus_refused: {exc}", file=sys.stderr)
        return 1
    except store.RegistryMutationRefused as exc:
        return _refuse_identity(args.command, exc.reason, str(exc))


def _read_password(prompt: str = "Password: ") -> str:
    """The principal's password from this terminal, echo off; anything else is refused."""
    import getpass
    import warnings
    stage1_features.require_private('principal_credentials')
    import principal_password as pw
    if not sys.stdin.isatty():
        raise pw.Refused("password_through_pipe", "the password is typed at a terminal, never piped")
    with warnings.catch_warnings():
        warnings.simplefilter("error", getpass.GetPassWarning)
        try:
            return getpass.getpass(prompt)
        except getpass.GetPassWarning:
            raise pw.Refused("no_terminal", "echo cannot be turned off on this terminal") from None


def cmd_login(args) -> int:
    """CREDENTIALS_01 D-CRED-3: the principal signs in with his password on this terminal.

    Typed at a terminal with no echo; never on a command line, in an environment
    variable, through a pipe, in a file or in a message, each refused by name; never
    from anything but the local machine. Waits for the credentials migration's marker."""
    stage1_features.require_private('principal_credentials')
    import principal_password as pw
    try:
        if not pw.migrated():
            raise pw.Refused("credentials_not_migrated",
                             "the principal password waits for the credentials migration")
        if args.password is not None:
            raise pw.Refused("password_on_command_line", "a password is never given on a command line")
        if args.password_file is not None:
            raise pw.Refused("password_in_file", "a password is never read from a file")
        if args.password_stdin:
            raise pw.Refused("password_through_pipe", "the password is typed at a terminal, never piped")
        pw.check_channel()
        identity = args.principal
        if identity is None:
            principals = pw.principal_identities()
            if len(principals) != 1:
                raise pw.Refused("identity_required", "name the identity to sign in")
            identity = principals[0]
        password = _read_password()
        result = store.login_seat_token(identity, password, seat_home_override=args.seat_home)
        print(f"signed in: {result['seat']} (terminal); session {result['token_id']} "
              f"placed at {result['path']}")
        return 0
    except pw.Refused as exc:
        print(f"login_refused: {exc}", file=sys.stderr)
        return 1
    except (store.SeatTokenNotPlaced, store.SeatCredentialPlacementIndeterminate,
            store.SeatCredentialPlacedAfterCallbackError, store.SeatActWithoutReceipt) as exc:
        # The sign-in committed: the session exists; say where it is, as `orch token claim` does.
        print(f"{YELLOW}{exc} — the session is committed; `{product_identity.command()} token place <identity>` "
              f"is the locked repair{RESET}", file=sys.stderr)
        return 74
    except (store.SeatCredentialCommitIndeterminate, store.SeatUncommittedStageNotRemoved) as exc:
        print(f"{YELLOW}{exc}{RESET}", file=sys.stderr)
        return 74
    except store.RegistryMutationRefused as exc:
        return _refuse_identity(args.command, exc.reason, str(exc))


def cmd_principal(args) -> int:
    """The principal's credential acts. CRED-C carries `password measure` (the cost rule);
    `password set` and `recover` are D-CRED-4's one recoverable operation (CRED-D)."""
    stage1_features.require_private('principal_credentials')
    import principal_password as pw
    try:
        if args.principal_cmd == "password" and args.password_cmd == "measure":
            print(json.dumps(pw.measure_and_receipt(), indent=2, sort_keys=True))
            return 0
        if args.principal_cmd == "recover":
            return _principal_operation(args, "recover")
        if args.principal_cmd == "password" and args.password_cmd == "set":
            return _principal_operation(args, "set")
        raise pw.Refused("unsupported", f"{args.principal_cmd} {getattr(args, 'password_cmd', '')}")
    except pw.Refused as exc:
        print(f"principal_refused: {exc}", file=sys.stderr)
        return 1


def _read_new_password() -> str:
    stage1_features.require_private('principal_credentials')
    first = _read_password("New password: ")
    if _read_password("New password, again: ") != first:
        import principal_password as pw
        raise pw.Refused("passwords_differ", "the two entries differ; nothing was written")
    return first


def _principal_operation(args, kind: str) -> int:
    """CREDENTIALS_01 D-CRED-4 (docs/PRINCIPAL_RECOVERY.md): `recover` by the store's filesystem
    owner, `password set` by the holder of the identity's live session; `--resume` finishes an
    incomplete operation on the journal and the terminal alone. Exit 74 is incomplete."""
    stage1_features.require_private('principal_credentials')
    import principal_credential_ops as ops
    import principal_password as pw
    if not pw.migrated():
        raise pw.Refused("credentials_not_migrated",
                         "the principal's password waits for the credentials migration")
    if args.password is not None:
        raise pw.Refused("password_on_command_line", "a password is never given on a command line")
    if args.password_file is not None:
        raise pw.Refused("password_in_file", "a password is never read from a file")
    if args.password_stdin:
        raise pw.Refused("password_through_pipe", "the password is typed at a terminal, never piped")
    pw.check_channel()
    by = ops.invoker()
    try:
        if args.resume is not None:
            result = ops.resume(args.resume, by=by, identity=args.principal, kind=kind)
        else:
            identity = args.principal
            if identity is None:
                principals = pw.principal_identities()
                if len(principals) != 1:
                    raise pw.Refused("identity_required", "name the identity")
                identity = principals[0]
            presented = None
            if kind == "set":
                # The authorizing session is presented by its credential file only: --token-file,
                # the path in $ORCH_TOKEN_FILE, or the nearest .orch/token; a token value exported
                # into the environment is refused by name (docs/PRINCIPAL_RECOVERY.md, reading 8).
                if os.environ.get(store.TOKEN_ENV):
                    raise pw.Refused("session_token_in_environment",
                                     f"a session token value in ${store.TOKEN_ENV} is refused; present "
                                     "the session's file (--token-file, $ORCH_TOKEN_FILE or .orch/token)")
                found = store.find_presented_token(args.token_file)
                if found["error"]:
                    raise pw.Refused("no_live_session", found["error"])
                presented = found["token"]
            context = ops.preflight(kind, identity, by=by, presented=presented)
            current = _read_password("Current password: ") if context["needs_current"] else None
            result = ops.start(context, _read_new_password(), by=by, presented=presented,
                               current_password=current)
    except ops.Incomplete as exc:
        print(f"{YELLOW}incomplete: {exc}{RESET}", file=sys.stderr)
        return 74
    except ops.Held as exc:
        print(f"{YELLOW}held: {exc}{RESET}", file=sys.stderr)
        return 74
    if result.get("already"):
        print(f"complete: operation {result['operation_id']} finished before; nothing was written")
    else:
        print(f"complete: {result['operation']} of {result['identity']}, operation {result['operation_id']}; "
              f"generation {result['generation']}; sign in with `{product_identity.command()} login {result['identity']}`")
        print(json.dumps({k: result[k] for k in ("receipts", "revoked", "resumed")}, indent=2, sort_keys=True))
    return 0


def _report_send_result(message: dict) -> int:
    """One user-visible result for the command and interactive store-send path."""
    if not _send_was_deliverable(message):
        print(f"error: {message['id']} not delivered: {message['vet']['disposition']}", file=sys.stderr)
        return 1
    print(f"sent {message['id']} → {', '.join(message['recipients'])} "
          f"({message.get('vet', {}).get('disposition', 'PASS')})")
    for seat, period in (message.get("focus") or {}).items():
        print(f"focus: {seat}'s wake is deferred until {period['until']} ({period['period-id']})")
    return 0


def cmd_interrupt(args) -> int:
    """Operator: break an agent's runaway loop / get its attention. The message
    itself comes from a human, so it also resets the agent's consecutive-run
    burn-guard counter (someone else has now spoken).

    Administrative-trust only (reviewer PR#12 LOW): like all hub-acting commands it
    relies on the explicit --as/ORCH_AGENT identity, which is unauthenticated under
    the local CLI trust boundary today; #19 (per-user tokens) is the real role gate.
    """
    reason = " ".join(args.reason) if args.reason else \
        "stop your current activity and await instructions"
    try:
        recipients = store.resolve_recipients([args.agent], args.identity)
        target = recipients[0]
        msg = store.send(
            args.identity, recipients,
            f"⛔ INTERRUPT from {args.identity}: {reason}",
            kind="control",
            meta={"control": {"type": "interrupt", "target": target}},
            presented_token=getattr(args, "presented_token", None),
            validate_client_headers=True,
        )
    except (KeyError, PermissionError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    if not _send_was_deliverable(msg):
        print(f"error: interrupt was not delivered ({msg['vet']['verdict']})",
              file=sys.stderr)
        return 1
    print(f"interrupted {args.agent} → {msg['id']}")
    return 0


def _resolve_log_names(raw: str) -> set[str]:
    return dialogue.resolve_names(raw, option="--among")


def _log_bound(raw: str, *, until: bool) -> datetime:
    try:
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", raw):
            day = date.fromisoformat(raw)
            edge = datetime_time.max if until else datetime_time.min
            return datetime.combine(day, edge, tzinfo=timezone.utc)
        value = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value.astimezone(timezone.utc)
    except ValueError as exc:
        raise ValueError(f"invalid {'--until' if until else '--since'} timestamp: {raw!r}") from exc


def _log_matches(msg: dict, among: set[str] | None, subset: bool,
                 since: datetime | None, until: datetime | None, participant=None) -> bool:
    if not dialogue.matches(msg, participant=participant, among=among, subset=subset):
        return False
    if since is not None or until is not None:
        try:
            stamp = datetime.fromisoformat(str(msg["ts"]).replace("Z", "+00:00"))
            stamp = stamp.replace(tzinfo=timezone.utc) if stamp.tzinfo is None else stamp.astimezone(timezone.utc)
        except (KeyError, TypeError, ValueError):
            return False
        if since is not None and stamp < since:
            return False
        if until is not None and stamp > until:
            return False
    return True


def _legacy_log_label(msg: dict) -> str:
    targets = msg.get("to") or []
    if targets == ["all"]:
        return " legacy-broadcast"
    if len(targets) == 1 and isinstance(targets[0], str) and targets[0].startswith("#"):
        return " legacy-room"
    return ""


def cmd_log(args) -> int:
    try:
        among = _resolve_log_names(args.among) if args.among else None
        participant = None
        if getattr(args, "participant", None):
            selected = dialogue.resolve_names(args.participant, option="--participant")
            if len(selected) != 1 or among is not None:
                raise ValueError("--participant names one seat and is mutually exclusive with --among")
            participant = selected.pop()
        since = _log_bound(args.since, until=False) if args.since else None
        until = _log_bound(args.until, until=True) if args.until else None
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    if args.subset and among is None:
        print("error: --subset requires --among", file=sys.stderr)
        return 1
    filtered = any(value is not None for value in (among, participant, since, until))
    predicate = (lambda row: _log_matches(row, among, args.subset, since, until, participant)) if filtered else None
    parts = store.load_participants()
    msgs, follow_offset = dialogue.select(
        limit=args.tail, predicate=predicate,
        visible=lambda row: not store.obsolete_human_notice(row, parts))
    for m in msgs:
        print(f"[{m.get('ts', '')}] {m.get('from') or '?':10} → {','.join(m.get('to', [])):10}"
              f"{_legacy_log_label(m)} "
              f"{one_line(m.get('text', ''), 110)}")
    if args.follow:
        offset = follow_offset
        print(f"{DIM}— following (Ctrl+C to stop) —{RESET}")
        try:
            while True:
                new, offset = (dialogue.read_since(offset) if predicate is None
                               else store.read_jsonl(store.LOG_FILE, offset))
                for m in (row for row in dialogue.project_records(new)
                          if predicate is None or predicate(row)):
                    if store.obsolete_human_notice(m, store.load_participants()):
                        continue
                    print(f"[{m.get('ts', '')}] {m.get('from') or '?':10} → "
                          f"{','.join(m.get('to', [])):10}{_legacy_log_label(m)} "
                          f"{one_line(m.get('text', ''), 110)}")
                time.sleep(0.3)
        except KeyboardInterrupt:
            pass
    return 0


def cmd_assign(args) -> int:
    title = " ".join(args.title)
    task_id = store.new_id("task")
    try:
        sent = store.send(
            args.identity, [args.assignee], f"[TASK {task_id}] {title}", kind="task",
            meta={"task_id": task_id},
            presented_token=getattr(args, "presented_token", None),
            validate_client_headers=True,
        )
    except (KeyError, PermissionError) as exc:
        print(f"error: task assignment was not created: {exc}", file=sys.stderr)
        return 1
    if not _send_was_deliverable(sent):
        print(f"error: task assignment was not created ({sent['vet']['verdict']})",
              file=sys.stderr)
        return 1
    store.task_event(
        "created", task_id=task_id, actor=args.identity, title=title,
        assignee=args.assignee,
    )
    store.task_event(
        "assigned", task_id=task_id, actor=args.identity, assignee=args.assignee,
    )
    print(f"task {task_id} assigned to {args.assignee}")
    return 0


def cmd_tasks(args) -> int:
    if args.done:
        store.task_event("done", task_id=args.done, actor=args.identity)
        print(f"task {args.done} marked done")
        return 0
    if args.reopen:
        store.task_event("reopened", task_id=args.reopen, actor=args.identity)
        print(f"task {args.reopen} reopened")
        return 0
    board = store.task_board()
    if not board:
        print("(no tasks)")
        return 0
    for t in board:
        mark = "✓" if t["status"] == "done" else "·"
        print(f" {mark} {t['id']}  → {t['assignee'] or 'unassigned':10} {t['title']}"
              f"  {DIM}{t['created_by']} {fmt_ts(t['created_at'])}{RESET}")
    return 0


def cmd_reviews(args) -> int:
    """Operator surface for convergence reviews (Stage 2): view state, run the consensus
    oracle, or clear (the human Z). Read-only by default."""
    from harness import convergence

    if args.evaluate:
        r = convergence.evaluate_consensus(args.evaluate)
        print(f"review {args.evaluate}: {r['state']}")
        return 0
    if args.clear:
        try:
            r = convergence.clear(args.clear, cleared_by=args.identity,
                                  override_reason=args.override)
        except ValueError as e:
            print(f"cannot clear: {e}")
            return 1
        print(f"review {args.clear}: {r['state']}")
        return 0
    if args.show:
        r = convergence.review_status(args.show)
        if r is None:
            print("(no such review)")
            return 1
        fp = r["fingerprint"] or {}
        print(f"{r['task_id']}  [{r['state']}]  opener={r['opener']}")
        print(f"  snapshot: {fp.get('repo')} {str(fp.get('base_sha'))[:12]}.."
              f"{str(fp.get('head_sha'))[:12]}   reviewers: {', '.join(r['reviewers'])}")
        for v in r["verdicts"]:
            tag = f"{DIM}(stale){RESET}" if v["stale"] else ""
            tests = " +tests" if v["tests_authored"] else ""
            print(f"   - {v['reviewer']:10} {v['verdict']}{tests} {tag}")
        return 0

    reviews = convergence.list_reviews()
    if not reviews:
        print("(no reviews)")
        return 0
    _mark = {"converged": "✓", "contested": "⚠", "cleared": "★", "open": "·"}
    for r in reviews:
        t = convergence.live_tally(r)   # oracle-consistent (latest per reviewer, self-test excluded)
        tally = f"{t['approve']}✓/{t['block']}✗"
        fp = r["fingerprint"] or {}
        print(f" {_mark.get(r['state'], '·')} {r['task_id']}  {r['state']:9} {tally:6}"
              f"  {DIM}{fp.get('repo','')} {str(fp.get('head_sha',''))[:10]}{RESET}")
    return 0


def cmd_raise(args) -> int:
    msg = " ".join(args.message)
    store.update_participant(args.identity, hand_raised=True, hand_message=msg,
                             presented_token=args.presented_token)
    print(f"hand raised for {args.identity}")
    return 0


def cmd_lower(args) -> int:
    store.update_participant(args.identity, hand_raised=False, hand_message="",
                             presented_token=args.presented_token)
    print(f"hand lowered for {args.identity}")
    return 0


def cmd_join(args) -> int:
    metadata = {key: getattr(args, key) for key in
                ("kind", "channel", "family", "tmux_session") if getattr(args, key) is not None}
    try:
        row = store.join_participant(args.name, presented_token=args.presented_token, **metadata)
    except store.RegistryMutationRefused:
        raise  # Keep the shared identity-refusal diagnostic and exit status.
    except ValueError as exc:
        print(f"error: join: {exc}", file=sys.stderr)
        return 1
    print(f"{args.name} registered (kind={row['kind']}, channel={row['channel']})")
    return 0


def _launch_cleanup_note(session: str, *, seat: str | None = None,
                         participants=None) -> str:
    """Remove a partially launched rebirth session; report cleanup failure."""
    cleanup = (kill_registered_server(seat, participants) if seat is not None
               else kill_session(session))
    return "" if cleanup.ok else f"; tmux cleanup failed: {cleanup.stderr}"


def _rebirth_agent(pid: str, p: dict, work_dir: Path, participants=None,
                   *, presented_token=None) -> str:
    """Keep provisioning authorization through launch and command delivery."""
    def apply(actor):
        durable = store.load_participants()
        registry = participants if participants is not None else durable
        current = registry.get(pid)
        if current is None or pid not in durable:
            return f"{pid}: no longer registered — skipped"
        if (store.inactive_participant(current)
                or store.inactive_participant(durable.get(pid, {}))):
            return f"{pid}: inactive seat — skipped; ask the Chief of Staff"
        if current.get("channel") != "tmux":
            return f"{pid}: no longer a tmux seat — skipped"
        return _rebirth_agent_locked(pid, current, work_dir, registry,
                                     presented_token=presented_token)
    try:
        return store.authenticated_registry_act(presented_token, apply, provisioning=True)
    except store.RegistryMutationRefused as exc:
        return f"{pid}: rebirth refused: {exc}"


def _rebirth_agent_locked(pid: str, p: dict, work_dir: Path, registry,
                          *, presented_token) -> str:
    """Launch one tmux agent's CLI and paste its rebirth prompt. Returns a
    short status string. Readiness-gated so the paste lands in the live CLI."""
    private = p.get("hosting_kind") == "tmux-hosted"
    session = p.get("tmux_session") or pid.lower()
    family = (p.get("family") or "").lower()
    try:
        profile = launch_profile_for_seat(pid, family)
    except ValueError as exc:
        return f"{pid}: {exc} — skipped"
    cli = profile.command
    # A1: private seats activate in their declared seat workspace, including a
    # seat-home override. Legacy launches use the conventional seat home. No
    # inherited authoring credential or selector is handed to the vendor CLI.
    launch_home = p.get('workspace_dir') if private else None
    token_path = store.seat_token_path(pid, launch_home)
    cli = store.seat_launch_line(pid, cli, home=launch_home)
    token_note = "" if token_path.is_file() else \
        f" {YELLOW}(no seat token at {token_path} — hub-acting commands will refuse until " \
        f"the CoS provisions it){RESET}"
    if family == "codex" and pid in reviewer_hub_policy.CODEX_REVIEWER_SEND_SEATS:
        # Plain `orch` inside these Codex seats must resolve to the isolated,
        # path-bound launcher installed alongside their exec-policy rule.  A
        # model-selected PATH cannot substitute another executable because the
        # authoritative host path is checked again by Codex execpolicy.
        reviewer_bin = reviewer_hub_policy.reviewer_command_path().parent
        cli = f"export PATH={shlex.quote(str(reviewer_bin))}:\"$PATH\" && {cli}"

    def activate_cli() -> str | None:
        exists = (registered_session_exists(pid, registry) if private
                  else session_exists(session))
        if exists:
            return f"{pid}: '{session}' already running — left alone"
        # Session starts in work_dir via -c; the CLI command is from a fixed
        # table (never interpolate work_dir into a shell line).
        if private:
            try:
                seat_launcher.launch(pid, presented_token=presented_token)
                launched = None
            except (OSError, RuntimeError, ValueError) as exc:
                return f"{RED}{pid}: private tmux session launch failed: {exc}{RESET}"
        else:
            launched = new_session(session, working_dir=str(work_dir))
        if launched is not None and not launched.ok:
            return f"{RED}{pid}: tmux session launch failed: {launched.stderr}{RESET}"
        try:
            command_sent = store.authenticated_registry_act(
                presented_token, lambda actor: (
                    send_registered_prompt(pid, registry, cli) if private
                    else send_prompt(session, cli)), provisioning=True)
        except store.RegistryMutationRefused as exc:
            cleanup_note = _launch_cleanup_note(
                session, seat=pid if private else None, participants=registry)
            return f"{pid}: CLI activation refused: {exc}{cleanup_note}"
        if not command_sent.ok:
            cleanup_note = _launch_cleanup_note(
                session, seat=pid if private else None, participants=registry)
            return (f"{RED}{pid}: CLI launch command failed: {command_sent.stderr}"
                    f"{cleanup_note}{RESET}")
        return None

    if profile.role == CODER:
        # update_participant takes this same cross-process fence. Hold it from
        # the durable-role read through command delivery, the point at which
        # the write-capable CLI is activated. A downgrade cannot interleave
        # between authorization and activation.
        with store.runtime_launch_fence():
            try:
                durable_participant = store.load_participants().get(pid)
            except Exception as exc:
                return (f"{pid}: cannot verify durable role before coder spawn: "
                        f"{exc} — skipped")
            role_error = coder_role_precondition_error(
                pid, profile, durable_participant)
            if role_error:
                return f"{pid}: {role_error} — skipped"
            activation_error = activate_cli()
    else:
        activation_error = activate_cli()
    if activation_error:
        return activation_error

    ready = (wait_for_registered_pane_ready(
        pid, registry, timeout=PANE_BOOT_TIMEOUT) if private
        else wait_for_pane_ready(session, timeout=PANE_BOOT_TIMEOUT))
    if not ready:
        cleanup_note = _launch_cleanup_note(
            session, seat=pid if private else None, participants=registry)
        return (f"{RED}{pid}: CLI never became ready"
                f"{cleanup_note}{RESET}")
    # Coder authority was proved before new_session and is never granted or
    # rewritten as a launch side effect. Reviewer metadata may be repaired only
    # after the read-only CLI is ready because that cannot increase authority.
    if profile.role != CODER:
        try:
            store.update_participant(pid, role=profile.role, presented_token=presented_token)
        except Exception as exc:  # registry commit failed: roll back the new process
            cleanup_note = _launch_cleanup_note(
                session, seat=pid if private else None, participants=registry)
            return (f"{RED}{pid}: role persistence failed: {exc}"
                    f"{cleanup_note}{RESET}")
    prompt = rebirth_prompt_for(pid, p)
    if prompt is None:
        return (f"{YELLOW}{pid}: launched BARE (no rebirth prompt at "
                f"{REBIRTH_DIR / (pid + '.md')}) — ungrounded{RESET}")
    time.sleep(PANE_BOOT_SETTLE)  # let the CLI finish UI init before pasting
    result = (send_registered_prompt(pid, registry, prompt) if private
              else send_prompt(session, prompt))
    if result.ok:
        return f"{GREEN}{pid}: reborn ({len(prompt)} char prompt){RESET}{token_note}"
    cleanup_note = _launch_cleanup_note(
        session, seat=pid if private else None, participants=registry)
    return f"{RED}{pid}: prompt paste failed: {result.stderr}{cleanup_note}{RESET}"


def cmd_up(args) -> int:
    from first_run import up
    return up(args)


def cmd_setup(args) -> int:
    from first_setup import setup
    return setup(args)


def _teardown(label: str = "infrastructure down; seats and history retained") -> int:
    """Checkpoint shutdown shares down's verified infrastructure stop.

    It never terminates seat sessions or selects processes by command pattern.
    A refused or incomplete stop remains a nonzero result.
    """
    from first_run import down
    result = down(None)
    if result == 0:
        print(label)
    return result


def cmd_down(args) -> int:
    from first_run import down
    return down(args)


def cmd_shutdown(args) -> int:
    """Request checkpoints, then verify the infrastructure stop; preserve seats."""
    grace = args.grace
    warning = (f"⚠️ CHECKPOINT — {product_identity.command()} is shutting down in {grace}s. Commit AND push "
               f"your work, update your session seed/memory, then idle. The durable "
               f"store and your sessions remain; `{product_identity.command()} up` restarts infrastructure only. "
               f"Reply 'checkpoint-ack' when safe to stop.")
    sender = args.identity
    try:
        recipients = [pid for pid, row in store.load_participants().items()
                      if pid != sender and not store.inactive_participant(row)]
        sent = store.send(
            sender, recipients, warning, kind="system",
            presented_token=getattr(args, "presented_token", None),
            validate_client_headers=True,
        ) if recipients else None
    except Exception as exc:
        print(f"{YELLOW}could not broadcast checkpoint warning: {exc}{RESET}")
        return 1
    if sent is not None and not _send_was_deliverable(sent):
        print(f"{YELLOW}could not broadcast checkpoint warning: "
              f"vetted {sent['vet']['verdict']}{RESET}")
        return 1
    if recipients:
        print(f"broadcast checkpoint warning; grace window {grace}s "
              f"(Ctrl-C to abort before teardown)...")
    else:
        print("no active recipients for checkpoint warning")
    # Surface any checkpoint-acks that arrive during the window.
    acked: set[str] = set()
    deadline = time.monotonic() + grace
    try:
        while time.monotonic() < deadline:
            for m in store.drain_inbox(sender):
                if "checkpoint-ack" in m.get("text", "").lower():
                    acked.add(m.get("from", "?"))
            remaining = int(deadline - time.monotonic())
            print(f"\r  {len(acked)} acked ({', '.join(sorted(acked)) or '—'}); "
                  f"{remaining}s left   ", end="", flush=True)
            time.sleep(2)
    except KeyboardInterrupt:
        print(f"\n{YELLOW}shutdown aborted by operator — stack left UP{RESET}")
        return 1
    print()
    return _teardown(label=f"{product_identity.command()} infrastructure stopped; seat sessions and history retained.")


def _runtime_doctor(parts: dict) -> bool:
    """PR-2b S-C (design §5): READ-ONLY runtime-registry health. Goes RED (never
    yellow) for a seat whose ownership record is unsound — a missing/drifted
    handle, a lost or unprovable lease, a stuck STOPPING, a work_dir/store drift,
    or participants↔roster_runtime drift. Mutates NOTHING (doctor never claims,
    stops, or clears — those are the operator-gated routes). A registry that
    cannot even be read (corrupt/torn) is itself RED."""
    import runtime_registry as rr
    try:
        seats = [rec for rec in rr.list_seats()  # raises on integrity failure
                 if not store.inactive_participant(parts.get(rec.get("seat"), {}))]
    except Exception as e:
        print(f"  {RED}✗ runtime registry UNREADABLE — {e}{RESET}")
        return False
    if not seats:
        return True                      # no owned runtimes yet — nothing to check
    ok = True
    seat_map = {rec.get("seat"): rec for rec in seats if rec.get("seat")}

    def red(seat, msg):
        nonlocal ok
        ok = False
        print(f"  {RED}✗ runtime {seat}: {msg}{RESET}")

    this_boot = rr.host_boot_id()
    for rec in seats:
        for issue in rr.runtime_health_issues(
                rec, participants=parts, seats=seat_map, this_boot=this_boot,
                store_dir=str(store.STORE_DIR)):
            red(rec.get("seat"), issue)
    if ok:
        n = sum(1 for r in seats if r.get("launch_state"))
        print(f"  {GREEN}✓ runtime registry: {len(seats)} seat(s), {n} with a launch state, all sound{RESET}")
    return ok


def _adapter_doctor_line(family: str, availability) -> str:
    """Render exactly one coherent diagnosis for one native-SDK adapter."""
    if getattr(availability, "installed", False) and not getattr(
            availability, "version_ok", True):
        return (f"  {YELLOW}! adapter {family}: SDK VERSION DRIFT — "
                f"{availability.detail}{RESET}")
    if getattr(availability, "installed", False) and getattr(
            availability, "authed", False):
        return f"  {GREEN}✓ adapter {family}: installed + authed{RESET}"
    if getattr(availability, "installed", False):
        return (f"  {YELLOW}! adapter {family}: installed, NOT authed — "
                f"{availability.detail}{RESET}")
    return (f"  {YELLOW}! adapter {family}: not installed — "
            f"{availability.detail}{RESET}")


def _registry_roles_doctor(parts):
    chiefs = sorted(pid for pid, row in parts.items()
                    if row.get("kind") == "agent" and not store.inactive_participant(row)
                    and row.get("role") == "chief_of_staff")
    if len(chiefs) > 1:
        print(f"  {YELLOW}! registry roles: multiple current agent chief_of_staff rows: "
              f"{', '.join(chiefs)}; expected at most one{RESET}")
    else:
        print(f"  {GREEN}✓ registry roles: {len(chiefs)} current agent chief_of_staff row(s) "
              f"(at most one){RESET}")


def _doctor_trace_mirror() -> bool:
    try:
        counts = store.trace_mirror_loss_counts()
    except (OSError, ValueError, TypeError):
        print(f"trace ledger       {YELLOW}mirror_loss_observation_unavailable{RESET}")
        return False
    if counts['total']:
        print(f"trace ledger       {YELLOW}{counts['total']} recorded mirror-loss signal(s): "
              f"import={counts['ledger_import']}, hook={counts['hook']}, "
              f"unknown={counts['unknown']}; mirror outcome unconfirmed{RESET}")
        return False
    else:
        print('trace ledger       no recorded mirror-loss signals (not a completeness check)')
        return True


def _doctor_web(port: int | None = None) -> bool:
    """Report the owned service's port; an explicit mismatch is not a healthy probe."""
    from service_lifecycle import ProcessToolUnavailable, Refused, verified_web_port
    try:
        observed = verified_web_port(store.STORE_DIR)
    except ProcessToolUnavailable as exc:
        print(f"web server         {YELLOW}{exc}{RESET}")
        return False
    except (OSError, ValueError, Refused, subprocess.SubprocessError):
        print(f"web server         {YELLOW}service_identity_unverified: process or lease metadata unavailable{RESET}")
        return False
    if port is not None and observed is not None and port != observed:
        print(f"web server :{observed}   {YELLOW}port_mismatch: requested :{port}{RESET}")
        return False
    selected = port if port is not None else observed if observed is not None else SERVER_PORT
    alive = server_alive(selected)
    detail = 'up' if alive else 'down (optional)'
    if alive and observed is None:
        detail += ' (listener only; no verified service lease)'
    print(f"web server :{selected}   {detail}")
    return True


def _doctor_tmux(parts) -> bool:
    """Probe each active tmux seat's declared private target, never the default server."""
    okay = True
    for pid, participant in parts.items():
        if store.inactive_participant(participant) or participant.get('channel') != 'tmux':
            continue
        session = participant.get('tmux_session')
        if not registered_session_exists(pid, parts):
            print(f"  {RED}✗ {pid}: registered private tmux target unavailable{RESET}")
            okay = False
        elif not registered_pane_ready(pid, parts):
            print(f"  {YELLOW}! {pid}: registered pane is a bare shell or readiness is unknown{RESET}")
        else:
            print(f"  {GREEN}✓ {pid}: '{session}' alive on its private socket, agent running{RESET}")
    return okay


def _doctor_prerequisites() -> None:
    """Stage 1's runtime requirement (B1), shown, never scored: doctor diagnoses the stack, and
    only the first run refuses on a missing piece, so a Linux host's doctor still reads clean."""
    import prerequisites
    checks = prerequisites.run()
    print(f"prerequisites      {sum(c.ok for c in checks)} of {len(checks)} for the macOS desktop release")
    for check in checks:                      # a missing one is information here: no warning mark
        print(f"  {GREEN}✓ {check.found}{RESET}" if check.ok else f"  · {check.missing}")
    notes = prerequisites.environment_notes()
    print("environment        " + (f"{len(notes)} variable(s) noted, as information" if notes
                                    else product_identity.diagnostic("no PSQR_ or vendor-key variable set", "no inherited shell settings noted")))
    for note in notes:
        print(f"  {CYAN}· {note}{RESET}")


def cmd_doctor(args) -> int:
    port = getattr(args, 'port', None)
    if port is not None and not 0 < port < 65536:
        print('doctor: port must be between 1 and 65535', file=sys.stderr)
        return 2
    import product
    print(product.version_line())
    _doctor_prerequisites()
    # Presence is not import health. Import each supplied kind normally even
    # when no seat currently uses it; a broken module must fail visibly.
    from desktop_support import optional
    missing = [kind for kind, module in (
        ('codex-ipc', 'codex_dispatch'), ('inapp-socket', 'inapp_dispatch'),
        ('agy-desktop', 'agy_dispatch')) if optional(module) is None]
    if missing:
        print('desktop routes     not offered: ' + ', '.join(missing))
    ok = True
    health = daemon_health()                     # one probe, rendered once
    print(f"store dir          {store.STORE_DIR} {'(exists)' if store.STORE_DIR.exists() else RED + 'MISSING' + RESET}")
    print(f"delivery daemon    {daemon_health_line(health)}")
    if health[0] != "UP":
        ok = False
    if not _doctor_web(port):
        ok = False
    # daemon_health_line already reports the validated heartbeat age. The legacy
    # tmux snapshot arrives after a full pass and is not a daemon readiness clock.
    parts = store.load_participants()
    _registry_roles_doctor(parts)             # warning only; does not turn health red
    mirror_clear = _doctor_trace_mirror()    # diagnostic only, not a delivery gate
    from desktop_support import optional
    agy_module = optional('agy_install')
    agy_observations = list(agy_module.doctor_lines(parts)) if agy_module else []
    # Installation/claim observations cannot certify native process readiness.
    # An uninstalled seat is also expected before the first authorized pilot.
    for available, detail in agy_observations:
        label = 'informational' if available else 'informational, unavailable'
        print(f'AGY bridge         [{label}] {detail}')
    if not _doctor_tmux(parts):
        ok = False
    pending_file = store.STORE_DIR / "pending_nudges.json"
    if pending_file.exists():
        try:
            pending = json.loads(pending_file.read_text())
        except json.JSONDecodeError:
            pending = {}
        for pid, a in pending.items():
            if store.inactive_participant(parts.get(pid, {})):
                continue
            if isinstance(a, dict) and a.get("count"):
                print(f"  {YELLOW}! {a['count']} undelivered nudge(s) for {pid}{RESET}")
    for pid in parts:
        if store.inactive_participant(parts[pid]) or not store.has_mailbox(parts[pid]):
            continue
        n = store.unread_count(pid)
        if n:
            print(f"  {CYAN}{pid}: {n} unread{RESET}")
    if not _runtime_doctor(parts):
        ok = False

    # --- E1/WS4: governance + packaging health (design §2.4, PSQ-257) ----------
    try:
        from provision import run as prov
        configured = {store.normalize_family(p.get("family")) for p in parts.values()
                      if p.get("kind") == "agent" and not store.inactive_participant(p)}
        if "codex" in configured:
            reviewer_rule_ok, reviewer_rule_detail = prov.codex_reviewer_rule_state()
            if reviewer_rule_ok:
                print(f"  {GREEN}✓ Codex reviewer hub output: {reviewer_rule_detail}{RESET}")
            else:
                print(f"  {RED}✗ Codex reviewer hub output MUTED: {reviewer_rule_detail} — "
                      f"run `{product_identity.command()} provision --only install-codex-reviewer-hub-rule`, then "
                      f"restart Codex reviewer seats{RESET}")
                ok = False
            from provision import machine
            for healthy, detail in machine.doctor_lines(parts):
                print(f"  {GREEN if healthy else YELLOW}{'✓' if healthy else '!'} {detail}{RESET}")
                if not healthy:
                    ok = False
        else:
            print(f"  {DIM}Codex reviewer hub output / machine seat rules: not configured (no active Codex seats){RESET}")
        # Stage 1 explicitly offers desktop integration only. It must not import
        # executable SDK adapters or infer success from their absence.
        if product_identity.is_public():
            print(f"  {DIM}SDK adapters: not offered by this desktop release{RESET}")
        else:
            try:
                stage1_features.require_private('sdk_adapters')
                from harness.adapter_registry import ADAPTER_BY_FAMILY
                for family, cls in ADAPTER_BY_FAMILY.items():
                    if family not in configured:
                        print(f"  {DIM}adapter {family}: not configured (no active seats){RESET}")
                        continue
                    try:
                        av = cls.availability()
                    except Exception as e:  # noqa: BLE001 — a probe crash is itself a finding
                        print(f"  {YELLOW}! adapter {family}: probe failed: {e}{RESET}")
                        continue
                    print(_adapter_doctor_line(family, av))
            except Exception as e:  # noqa: BLE001
                print(f"  {YELLOW}! adapter registry unavailable: {e}{RESET}")
        # license / gateway — stubs until E2/E3 wire them
        print(f"  {DIM}license: see LICENSE for permitted use and the future Apache 2.0 grant{RESET}")
        print(f"  {DIM}credit gateway: not configured (optional){RESET}")
    except Exception as e:  # noqa: BLE001 — doctor must never crash on a partial install
        # ...but governance checks that could not RUN are governance UNVERIFIED —
        # that must not read as "all clear" (Bugbot #44 High).
        print(f"  {RED}✗ governance/packaging health checks could not run: {e}{RESET}")
        ok = False

    caveats = []
    if agy_observations:
        caveats.append('AGY bridge readiness is not certified')
    if not mirror_clear:
        caveats.append('trace mirror observation requires inspection')
    clear = 'required checks clear; ' + '; '.join(caveats) if caveats else 'all clear'
    print(GREEN + clear + RESET if ok else YELLOW + "issues found — see above" + RESET)
    return 0 if ok else 1


def cmd_store(args) -> int:
    """Phase 0 W0.2 — `orch store candidates` MEASURES every known candidate store and
    chooses none; `orch store register <abs-path>` records the one decision somebody
    else took (DP-1) as the locator plus a ledger receipt. Both run unbound."""
    if args.store_cmd == "candidates":
        rows = store.store_candidates(args.paths, scan=args.scan)
        if args.json:
            print(json.dumps(rows, indent=2, ensure_ascii=False))
            return 0
        if not rows:
            print(product_identity.diagnostic(
                "no candidate store found (pass paths, --scan DIR, set PSQR_STORE_DIR, or register one)",
                "no candidate store found (pass paths, --scan DIR, or register one)"))
            return 0
        print(f"{BOLD}candidate stores — measured, none chosen{RESET}")
        for i, r in enumerate(rows, 1):
            print(f"\n[{i}] {r['path']}  {DIM}({', '.join(r['sources'])}){RESET}")
            if not r.get("exists"):
                print(f"     {RED}no log.jsonl{RESET}")
                continue
            if r.get("error"):
                print(f"     {RED}{r['error']}{RESET}")
                continue
            print(f"     lines   {r['lines']}")
            print(f"     newest  {r['newest_msg_id'] or '-'}")
            print(f"     mtime   {r['mtime']}")
            print(f"     sha256  {r['sha256']}")
            reg = r.get("registration") or {}
            state = reg.get("state", "none")
            if reg.get("durability") == "unconfirmed":
                state, colour = "completed (durability unconfirmed)", YELLOW
            elif state == "committed_unreceipted":
                state, colour = "COMMITTED, receipt MISSING", YELLOW
            else:
                colour = {"completed": GREEN, "dangling": YELLOW, "failed": RED}.get(state, DIM)
            detail = (f" {reg.get('ts', '')} by {reg.get('registrant', '?')}"
                      if reg.get("state") in ("completed", "failed", "dangling",
                                              "committed_unreceipted") else "")
            print(f"     ledger  {colour}registration {state}{detail}{RESET}"
                  + (f" — {reg['note']}" if reg.get("note") else ""))
        try:
            bound, comment = store.read_locator()
            print(f"\n{DIM}locator {store.locator_path()} -> {bound}  {comment}{RESET}")
        except store.StoreUnbound:
            print(f"\n{DIM}locator {store.locator_path()}: none bound{RESET}")
        return 0
    if args.store_cmd == "register":
        try:
            result = store.register_store(args.path, registrant=args.identity)
        except store.StoreRegisteredWithoutReceipt as exc:
            # committed but unreceipted — never "refused"; exit 74 (EX_IOERR), distinct from
            # a refusal (78) and success (0), so a caller can tell the three apart
            print(f"{YELLOW}store register: COMMITTED WITHOUT RECEIPT — {exc}{RESET}",
                  file=sys.stderr)
            return exc.exit_code
        except (ValueError, OSError) as exc:
            print(f"{RED}error: store register refused: {exc}{RESET}", file=sys.stderr)
            return 1
        if result.get("warning"):
            # Exit 0, deliberately: the binding IS committed and visible, so a caller that
            # treated this as failure would act on a false premise. The fact is on stderr
            # and in the ledger (store_registration_durability_unconfirmed); re-registering
            # retries the fsync.
            print(f"{YELLOW}warning: {result['warning']} — re-run the registration to retry "
                  f"the fsync{RESET}", file=sys.stderr)
        if args.json:
            print(json.dumps(result, indent=2, ensure_ascii=False))
        else:
            m = result["measurement"]
            print(f"registered {result['store_dir']}")
            print(f"  locator  {result['locator']}")
            print(f"  log      {m['lines']} lines · newest {m['newest_msg_id'] or '-'} · "
                  f"sha256 {m['sha256']}")
            print(f"  receipt  {result['receipt']['id']} in {result['store_dir']}/ledger.jsonl")
        env = result.get("shell_override")      # measured by register_store, never resolved here
        if env is not None:
            print(f"{YELLOW}note: {store.STORE_ENV_OVERRIDE}={env!r} is set in this shell and "
                  f"does not equal the registered store {result['store_dir']} — the override "
                  f"must be ABSOLUTE and equal to the locator's store; every command in this "
                  f"shell will refuse until you unset it or set it to "
                  f"{result['store_dir']}.{RESET}", file=sys.stderr)
        return 0
    return 2


def cmd_rooms(args) -> int:
    print(f"{product_identity.command()} rooms/room are retired; use: {product_identity.command()} log --among A,B [--subset]")
    return 2


cmd_room = cmd_rooms


def cmd_quarantine(args) -> int:
    """List history or apply a registered-governance-key disposition."""
    import authority
    import quarantine
    command = getattr(args, "quarantine_cmd", "list")
    if command != "list":
        if getattr(args, "token_file", None):
            print("quarantine refused: a registered CoS governance key is required; tokens cannot authorize this act", file=sys.stderr)
            return IDENTITY_REFUSAL_EXIT
        mid = getattr(args, "msg_id", None)
        key = getattr(args, "governance_key", None)
        request_path = getattr(args, "authorization_file", None)
        if not mid or bool(key) == bool(request_path):
            print("quarantine requires a message id and exactly one of --governance-key or --authorization-file", file=sys.stderr)
            return 2
        try:
            request = quarantine.sign(command, mid, key) if key else quarantine._read(Path(request_path))
            result = quarantine.dispose(command, mid, request)
        except quarantine.ItemRefused as exc:
            print(f"quarantine outcome incomplete: {exc}; inspect the disposition and retry the same action",
                  file=sys.stderr)
            return 1
        except (authority.GovernanceKeyRefused, quarantine.Refused) as exc:
            print(f"quarantine refused: {exc}", file=sys.stderr)
            return IDENTITY_REFUSAL_EXIT
        except (OSError, ValueError, TypeError, KeyError):
            print("quarantine outcome incomplete or unavailable; inspect the disposition and retry the same action; no token fallback", file=sys.stderr)
            return 1
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
        return 0
    rows = store.read_log_to_eof()
    queued = [row for row in rows
              if (row.get("vet") or {}).get("verdict") == "QUARANTINED"]
    queued = [{**row, "quarantine_disposition": quarantine.status(row)} for row in queued]
    if args.json:
        print(json.dumps(queued, indent=2, ensure_ascii=False))
        return 0
    if not queued:
        print("(no quarantined messages)")
        return 0
    for row in queued:
        vet = row.get("vet") or {}
        disposition = row['quarantine_disposition']
        print(f"{row.get('id')} state={disposition['state']} from={row.get('from')} reason={disposition.get('reason', vet.get('reason', ''))}")
    return 0


# --- Phase A A.4: seat tokens — provisioning acts and the identity binding --------------

def cmd_registry(args) -> int:
    if args.registry_cmd == "roles":
        print(json.dumps(store.registry_roles(), indent=2, ensure_ascii=False))
        return 0
    if args.registry_cmd == "set-role":
        try:
            result = store.set_participant_role(
                args.seat, args.role, presented_token=args.presented_token,
                approved_by_principal=args.approved_by_principal,
                approved_by_principal_sha256=args.approved_by_principal_sha256)
        except store.RegistryMutationRefused:
            raise
        except (store.RegistryRoleIncomplete, store.SeatActCleanupUnconfirmed) as exc:
            print(str(exc), file=sys.stderr)
            return 74
        except (ValueError, OSError) as exc:
            print(f"error: registry set-role: {exc}", file=sys.stderr)
            return 1
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0
    if args.registry_cmd in {"parked", "retired"}:
        field = "parked" if args.registry_cmd == "parked" else "retired"
        rows = store.load_participants()
        for seat, row in sorted(rows.items()):
            if row.get(field + "_at") and (field != "parked" or not row.get("retired_at")):
                print(f"{seat}: {row[field + '_at']} by {row.get(field + '_by', 'unknown')}")
        return 0
    if args.registry_cmd in {"park", "unpark"}:
        try:
            if args.registry_cmd == "park":
                result = store.park_participant(args.seat, presented_token=args.presented_token)
                state = "already parked" if result["already_parked"] else "parked"
                print(f"{result['seat']}: {state} at {result['parked_at']} by {result['parked_by']}")
            else:
                result = store.unpark_participant(args.seat, channel=args.channel,
                                                   presented_token=args.presented_token)
                print(f"{result['seat']}: unparked; channel {result['channel']}; fresh invite and provisioning are separate")
        except (store.SeatActWithoutReceipt, store.SeatActCleanupUnconfirmed) as exc:
            print(str(exc), file=sys.stderr)
            return 74
        return 0
    if args.registry_cmd == "retire":
        try:
            result = store.retire_participant(args.seat, presented_token=args.presented_token)
        except store.SeatActWithoutReceipt as exc:
            print(str(exc), file=sys.stderr)
            return 74
        state = "already retired" if result["already_retired"] else "retired"
        print(f"{result['seat']}: {state} at {result['retired_at']} by {result['retired_by']}")
        return 0
    try:
        found = store.find_presented_token(args.token_file) if args.apply else {"token": None}
        result = store.normalise_registry_roles(
            apply=args.apply, plan_sha256=args.plan_sha256,
            presented_token=found["token"], approved_by_principal=args.approved_by_principal,
            approved_by_principal_sha256=args.approved_by_principal_sha256)
    except store.RegistryMutationRefused:
        raise
    except (ValueError, OSError) as exc:
        print(f"error: registry normalise-roles: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


def cmd_invite(args) -> int:
    """CoS: issue a seat-scoped invite. The plaintext goes to <seat home>/.orch/invite
    (0600) for the seat to claim from its own pane — never to stdout, argv, or mail."""
    try:
        r = store.issue_seat_invite(args.seat, issuer=args.identity, auth=args.auth,
                                    role=args.role, seat_home_override=args.seat_home,
                                    ttl_sec=args.ttl, bootstrap=(args.auth == "bootstrap"),
                                    presented_token=getattr(args, "presented_token", None))
    except store.RegistryMutationRefused as exc:
        return _refuse_identity(args.command, exc.reason, str(exc))
    except store.BootstrapClosed as exc:
        # decided inside the issuing transaction — a concurrent bootstrap got there first
        return _refuse_identity(args.command, "bootstrap_closed", str(exc))
    except store.SeatInviteNotPlaced as exc:
        print(f"{YELLOW}{exc}{RESET}", file=sys.stderr)   # committed and receipted as not placed
        return 74
    except (store.SeatCredentialCommitIndeterminate,
            store.SeatCredentialPlacementIndeterminate,
            store.SeatCredentialPlacedAfterCallbackError,
            store.SeatUncommittedStageNotRemoved) as exc:
        print(f"{YELLOW}{exc}{RESET}", file=sys.stderr)   # durable state is explicit; never a refusal
        return 74
    except store.SeatActWithoutReceipt as exc:
        print(f"{YELLOW}{exc} — the invite stands; the ledger row is missing{RESET}",
              file=sys.stderr)
        return 74
    except (ValueError, OSError) as exc:
        print(f"{RED}error: {exc} — no invite was committed{RESET}", file=sys.stderr)
        return 1
    print(f"invite {r['token_id']} issued for {r['seat']} (role={r['role']}, "
          f"expires {r['expires_at']}) → {r['path']}")
    print(f"  claim it AS the seat, from the seat's own workspace:  {product_identity.command()} token claim {r['seat']}")
    return 0


def _token_claim(args) -> int:
    path = None
    try:
        if args.invite_stdin:
            source, plain = "stdin", sys.stdin.read().strip()
        else:
            path = (Path(args.invite_file).expanduser() if args.invite_file
                    else store.seat_invite_path(args.seat, args.seat_home))
            source, plain = str(path), store.read_secret_file(path)
    except OSError as exc:
        print(f"{RED}error: cannot read the invite: {exc}{RESET}", file=sys.stderr)
        return 1
    if not plain:
        print(f"{RED}error: no invite at {source}{RESET}", file=sys.stderr)
        return 1
    committed_but = None     # a committed claim that could not be fully reported/placed
    r = None
    try:
        r = store.claim_seat_token(args.seat, plain, seat_home_override=args.seat_home)
    except store.SeatCredentialPlacedAfterInterruption as exc:
        # The original KeyboardInterrupt still propagates. This subtype proves the claim
        # committed and placed, so remove only its consumed invite source first.
        if path is not None:
            try:
                path.unlink()
            except FileNotFoundError:
                pass
            except OSError as cleanup_error:
                exc.add_note(f"could not remove consumed invite file {path}: {cleanup_error}")
        raise
    except store.SeatTokenNotPlaced as exc:
        # committed, on disk at the staged path, not at its final name: say exactly that
        print(f"{YELLOW}{exc}{RESET}", file=sys.stderr)
        committed_but = "not placed"
    except (store.SeatCredentialPlacementIndeterminate,
            store.SeatCredentialPlacedAfterCallbackError) as exc:
        # Both outcomes are committed, so the consumed invite source must not linger even
        # though the placement outcome is exceptional.
        print(f"{YELLOW}{exc}{RESET}", file=sys.stderr)
        committed_but = "exceptional placement"
    except (store.SeatCredentialCommitIndeterminate,
            store.SeatUncommittedStageNotRemoved) as exc:
        # Commit is unknown or known absent. Keep the invite source so a provably
        # unconsumed invite remains recoverable.
        print(f"{YELLOW}{exc}{RESET}", file=sys.stderr)
        return 74
    except store.SeatActWithoutReceipt as exc:
        # committed and placed; only the ledger row is missing — the invite IS consumed,
        # so its file goes like on success (CodeRabbit PR #222 round 3)
        print(f"{YELLOW}{exc} — the token stands; the ledger row is missing{RESET}",
              file=sys.stderr)
        committed_but = "unreceipted"
    except (ValueError, OSError) as exc:
        # nothing consumed: the invite and the seat's current token are as they were
        print(f"{RED}error: {exc} — nothing was consumed; the invite is still claimable{RESET}",
              file=sys.stderr)
        return 1
    removed = ""
    if path is not None:
        # consumed: the file must not linger as a phantom credential
        try:
            path.unlink()
            removed = "; the invite file was removed"
        except OSError as exc:
            removed = f"; could not remove the consumed invite file: {exc}"
    if committed_but is not None or r is None:
        return 74
    print(f"token claimed for {r['seat']} ({r['token_id']}, role={r['role']}, "
          f"expires {r['expires_at']}) → {r['path']} (0600){removed}")
    return 0


def _token_status(args) -> int:
    """Validity of the token in hand (exit 0 iff valid), or the token RECORDS of a seat —
    ids, roles, states, timestamps. The value is never displayed (GA.10)."""
    if args.seat:
        recs = store.seat_token_records(args.seat)
        live = any(r["kind"] == "session" and r["state"] == "active" for r in recs)
        if args.json:
            print(json.dumps({"seat": args.seat, "valid": live, "records": recs}, indent=2))
        elif not recs:
            print(f"{args.seat}: no token records")
        else:
            print(f"{args.seat}: token {'valid' if live else 'NONE live'}")
            for r in recs:
                print(f"  {r['kind']:8} {r['id']:16} {r['state']:8} role={r.get('role')} "
                      f"surface={r.get('surface')} created={r.get('created')} expires={r.get('expires_at')} "
                      f"expires_in_seconds={r.get('expires_in_seconds')}")
        return 0 if live else 1
    found = store.find_presented_token(args.token_file)
    if found["error"]:
        verdict = {"valid": False, "reason": "unusable", "detail": found["error"]}
    elif not found["token"]:
        verdict = {"valid": False, "reason": "none", "looked": found["looked"]}
    else:
        rec, why = store.token_verdict(found["token"])
        if rec is None:
            verdict = {"valid": False, "reason": why, "source": found["source"]}
        else:
            verdict = {"valid": True, "seat": rec["participant_id"], "role": rec.get("role"),
                       "id": rec["id"], "scope": rec.get("scope"),
                       "expires_at": rec.get("expires_at"), "expires_in_seconds": store.token_seconds_remaining(rec),
                       "surface": rec.get("surface"), "source": found["source"]}
    if args.json:
        print(json.dumps(verdict))
    elif verdict["valid"]:
        print(f"token: valid — seat={verdict['seat']} role={verdict['role']} id={verdict['id']} "
              f"expires={verdict['expires_at']} expires_in_seconds={verdict['expires_in_seconds']} "
              f"source={verdict['source']}")
    elif verdict["reason"] == "none":
        print("token: NONE (looked: " + "; ".join(verdict["looked"]) + ")")
    elif verdict["reason"] == "unusable":
        print(f"token: UNUSABLE — {verdict['detail']}")
    else:
        print(f"token: INVALID ({verdict['reason']}) from {verdict['source']}")
    return 0 if verdict["valid"] else 1


def _token_revoke(args) -> int:
    try:
        n = store.retire_seat_tokens(args.seat, actor=args.identity, auth=args.auth,
                                     presented_token=args.presented_token)
    except store.RegistryMutationRefused as exc:
        return _refuse_identity(args.command, exc.reason, str(exc))
    except store.SeatActWithoutReceipt as exc:
        print(f"{YELLOW}{exc} — the revocation stands; the ledger row is missing{RESET}",
              file=sys.stderr)
        return 74
    print(f"revoked {n} token record(s) of {args.seat}; its next presentation is refused")
    return 0


def _token_place(args) -> int:
    """The locked repair after a claim that committed but was not placed."""
    try:
        r = store.place_staged_token(args.seat, seat_home_override=args.seat_home)
    except store.SeatActWithoutReceipt as exc:
        print(f"{YELLOW}{exc} — placement stands; the ledger row is missing{RESET}", file=sys.stderr)
        return 74
    except ValueError as exc:
        print(f"{RED}error: {exc}{RESET}", file=sys.stderr)
        return 1
    except OSError as exc:
        print(f"{RED}error: {exc}{RESET}", file=sys.stderr)
        return 1
    removed = f"; removed {len(r['removed'])} dead staged file(s)" if r["removed"] else ""
    print(f"token placed for {args.seat} ({r['token_id']}, role={r['role']}, "
          f"expires {r['expires_at']}) → {r['placed']} (0600){removed}")
    return 0


def cmd_token(args) -> int:
    if args.token_cmd == "migrate-surfaces":
        try:
            found = store.find_presented_token(args.token_file)
            if found["error"]:
                raise ValueError(found["error"])
            result = store.migrate_legacy_surfaces(apply=args.apply, plan_sha256=args.plan_sha256,
                                                   presented_token=found["token"])
        except (OSError, ValueError) as exc:
            print(f"migration refused: {exc}", file=sys.stderr)
            return 1
        print(json.dumps(result, indent=2))
        return 1 if result["state"] == "halted" else 0
    if args.token_cmd == "claim":
        return _token_claim(args)
    if args.token_cmd == "status":
        return _token_status(args)
    if args.token_cmd == "place":
        return _token_place(args)
    return _token_revoke(args)


def cmd_usage(args) -> int:
    """Qualified file intake and explicitly authenticated policy/retention acts."""
    import account_usage as usage
    import account_usage_control as control
    try:
        if args.usage_cmd == 'report':
            result = usage.report_file(args.file, presented_token=args.presented_token,
                                       submission_key=args.submission_key)
        elif args.usage_cmd == 'codex':
            from desktop_support import require
            result = require('account_usage_codex').import_file(args.file, submission_key=args.submission_key,
                                 presented_token=args.presented_token)
        elif args.usage_cmd == 'binding':
            result = control.policy_act(args.binding_cmd, presented_token=args.presented_token,
                                        reporter=args.reporter, account_ref=getattr(args,'account_ref',None),
                                        authority_ref=getattr(args,'authority_ref',None),
                                        authorization_id=getattr(args,'authorization_id',None))
        elif args.retention_cmd == 'plan':
            result = control.retention_plan(presented_token=args.presented_token)
        else:
            from console_files import directory, read
            path = Path(args.plan).absolute()
            with directory(path.parent) as fd:
                plan = usage._json(read(fd, path.name, limit=usage.MAX_REPORT))
            result = control.retention_apply(plan, args.archive, presented_token=args.presented_token)
    except (OSError, ValueError, TypeError, UnicodeError, KeyError):
        print('usage act refused: check private input, qualification, current authority and transaction state', file=sys.stderr)
        return 2
    print(json.dumps(result, sort_keys=True))
    return 0


# Commands that ACT on the hub as someone. Identity for these is derived from the seat
# token, never asserted (Phase A A.4; ORCH_SPEC_01 D-IDT-1/-2). `store register` stays
# --as-identified: it is the store's own bootstrap act and its receipt names the registrant
# (Phase 0 G0.7) — no token can exist before a store is bound.
HUB_ACTING = {"recall", "focus", "usage", "seat-event", "hook-fetch", "agy-hook-fetch", "agy-hook-emitted", "agy-read", "agy-ack", "send", "broadcast", "interrupt", "raise", "lower", "assign", "mail",
              "join", "room", "inbox", "await", "invite", "shutdown", "message-file"}
# EX_NOPERM — distinct from every code a hub-acting command returns on its own (await's
# 2 = heartbeat/empty, send's 1/3, store's 74/78): a watcher that re-arms on exit 2 must
# not loop on an identity refusal (CodeRabbit PR #222).
IDENTITY_REFUSAL_EXIT = getattr(os, "EX_NOPERM", 77)


def _is_provisioning(args) -> bool:
    """Issuing and retiring seat tokens — the CoS's and the principal's acts."""
    if args.command == "provision":
        return bool(args.seat or args.seat_home_map)
    if args.command == "up":
        return False  # product up starts infrastructure only, never seat sessions
    if args.command == "registry":
        return args.registry_cmd in {"retire", "park", "unpark", "set-role"}
    return args.command in {"invite"} or (args.command == "token" and args.token_cmd == "revoke") \
        or (args.command == "seat" and args.seat_cmd in {"declare", "launch", "set-model", "wake-hookset-record", "help-clear", "wake-revive", "wake-hook-interface-policy"})


def _is_hub_acting(args) -> bool:
    if args.command == "provision":
        return bool(args.seat or args.seat_home_map)
    if args.command == "up":
        return False  # product up never launches or provisions seats
    if args.command == "seat":
        return args.seat_cmd in {"declare", "launch", "set-model", "wake-declare", "wake-clear",
                                 "wake-hookset-record", "wake-hookset-show", "help-clear", "wake-revive", "wake-hook-interface-policy", "wake-hook-interface-show"}
    if args.command == "registry":
        return args.registry_cmd in {"retire", "park", "unpark", "set-role"}
    if args.command in HUB_ACTING:
        return True
    if args.command == "tasks":
        return bool(args.done or args.reopen)
    if args.command == "reviews":
        return bool(args.clear)
    if args.command == "token":
        return args.token_cmd == "revoke"
    return False


def _refuse_identity(command: str, reason: str, detail: str) -> int:
    print(f"{RED}refusing to run '{command}': {detail} (reason={reason}){RESET}",
          file=sys.stderr)
    return IDENTITY_REFUSAL_EXIT


def _bind_hub_identity(args) -> int:
    """Derive args.identity from the presented seat token. Returns 0, or the refusal exit
    code after ONE diagnostic. --as / $ORCH_AGENT are inert here: a differing assertion is
    noted on stderr and ignored (GA.9). The one exception is `orch invite --bootstrap`: the
    very first token of a store is issued on an asserted identity, and only while NO seat
    token exists in the store."""
    found = store.find_presented_token(args.token_file)
    bootstrap = None
    if args.command == "invite" and args.bootstrap:
        bootstrap = store.bootstrap_state()
    if bootstrap is not None and bootstrap["open"]:
        # The store's ONE asserted-identity transition (reviewer DJK-A4-1: monotonic — the
        # marker is written in the same transaction as the invite by create_invite, and the
        # decision is re-made there; this early check only shapes the refusal). Decided on
        # the STORE's state alone: whatever this shell presents — a leftover $ORCH_TOKEN, a
        # walk-up .orch/token of another store, an unreadable named file — cannot be a seat
        # token of a store that has none (Bugbot round 2); it is noted, not used.
        if not args.asserted:
            return _refuse_identity(args.command, "bootstrap_needs_identity",
                                    "--bootstrap needs --as NAME (the asserted issuer of "
                                    "the very first token)")
        if found["token"] or found["error"]:
            print(f"{DIM}note: ignoring the presented token ({found['source'] or found['error']}) "
                  f"for --bootstrap — this store has no seat credential yet{RESET}", file=sys.stderr)
        args.identity, args.auth = args.asserted, "bootstrap"
        return 0
    if bootstrap is not None:
        # --bootstrap on a CLOSED store: a valid presented token proceeds as that token (the
        # flag is inert); anything else is refused for the operative reason — the bootstrap
        # is consumed and never reopens — not for whatever the shell happened to present.
        verdict = store.token_verdict(found["token"])[0] if found["token"] and not found["error"] else None
        if verdict is None:
            m = bootstrap.get("marker") or {}
            how = (f"consumed at {m.get('consumed_at')} by {m.get('by')} for seat {m.get('seat')}"
                   if m else "this store already carries seat credentials")
            return _refuse_identity(args.command, "bootstrap_closed",
                                    f"the bootstrap of this store is {how}; it never reopens "
                                    f"(not on revocation, not on expiry) — present your own token")
    if found["error"]:
        return _refuse_identity(args.command, "seat_token_unusable",
                                f"the named seat token file cannot be used — {found['error']}")
    token = found["token"]
    if not token:
        if product_identity.is_public():
            return _refuse_identity(args.command, 'no_seat_token',
                                    'no seat identity is available; use the registered agent workspace')
        return _refuse_identity(
            args.command, "no_seat_token",
            "no seat token presented (looked: " + "; ".join(found["looked"]) + "). Identity "
            "is derived from the seat token (ORCH_SPEC_01 D-IDT-1); --as and $ORCH_AGENT no "
            "longer identify hub-acting commands. Provision: `orch invite <seat> --role "
            "<registry role>` by the CoS, then in the seat's own workspace "
            "`orch token claim <seat>`; a store's very first token: "
            "`orch --as <you> invite <you> --bootstrap`, then `orch token claim <you>`")
    rec, why = store.token_verdict(token)
    if rec is None:
        return _refuse_identity(args.command, "seat_token_invalid",
                                f"the seat token from {found['source']} is not valid ({why})")
    args.identity = rec["participant_id"]
    args.token_bound = True
    args.token_id = rec["id"]
    args.token_role = rec.get("role")
    args.auth = "token"
    # Kept in process memory only; never printed or persisted in a message.
    # store.send revalidates it at the action boundary.
    args.presented_token = token
    if args.asserted and args.asserted != args.identity:
        assertion = '--as' if product_identity.is_public() else '--as/$ORCH_AGENT'
        print(f"{DIM}note: {assertion} '{args.asserted}' is inert for '{args.command}' — "
              f"identity is derived from the seat token: {args.identity}{RESET}",
              file=sys.stderr)
    # Invites validate their exact target inside create_invite's locked transaction;
    # a targetless preflight would reject the bounded roleless-principal self repair.
    if _is_provisioning(args) and args.command != "invite":
        try:
            store.authenticated_registry_act(token, lambda actor: None, provisioning=True)
        except store.RegistryMutationRefused as exc:
            return _refuse_identity(args.command, exc.reason, str(exc))
    if args.command in ("inbox", "await"):
        other = getattr(args, "participant", None)
        if other and other != args.identity:
            # `inbox --peek` reads without moving a cursor; every other form — a drain, a
            # blocking await, and `await --filtered`, which persists watch/<seat>.offset —
            # moves that seat's state (Bugbot PR #222)
            read_only = args.command == "inbox" and args.peek
            if not read_only:
                return _refuse_identity(
                    args.command, "other_seat_inbox",
                    f"{args.identity} may not consume or advance the inbox of {other}; only "
                    f"`inbox --peek` may name another seat")
    return 0


# `orch obligations`: the exit codes and the one JSON object each invocation prints on stdout.
OBLIGATIONS_EXIT_REFUSED = 1      # the store refused: the switch, the credential's authentication, the
                                  # writer, reader or operator rule, a check, or a damaged journal
OBLIGATIONS_EXIT_INPUT = 2        # the event file is not one JSON object; nothing reached the store
OBLIGATIONS_EXIT_CREDENTIAL = IDENTITY_REFUSAL_EXIT  # no credential path; nothing reached the store
OBLIGATIONS_EXIT_IO = getattr(os, "EX_IOERR", 74)   # an I/O failure; its note says what was done
OBLIGATIONS_EVENT_LIMIT = 4 * 1024 * 1024


def _obligations_print(result: dict) -> None:
    print(json.dumps(result, sort_keys=True, ensure_ascii=False))


def _obligations_refusal(check: str, reason: str, detail: str = "") -> dict:
    return {"error": "obligation_refused", "check": check, "reason": reason, "detail": detail}


def _obligations_credential(args):
    """The credential by its path only: --token-file, $ORCH_TOKEN_FILE, or the seat's own
    .orch/token at or above the cwd. A token given by value ($ORCH_TOKEN) is refused, never used.
    Returns (token, None) or (None, refusal)."""
    if not (args.token_file or os.environ.get(store.TOKEN_FILE_ENV)) and os.environ.get(store.TOKEN_ENV):
        return None, _obligations_refusal(
            "credential", "credential_by_value_refused",
            f"${store.TOKEN_ENV} holds a token value; present the credential by its path "
            f"(--token-file or ${store.TOKEN_FILE_ENV})")
    named = args.token_file or os.environ.get(store.TOKEN_FILE_ENV)
    origin = "--token-file" if args.token_file else (f"${store.TOKEN_FILE_ENV}" if named else "the seat's own .orch/token")
    try:
        found = store.find_presented_token(
            args.token_file, env={k: v for k, v in os.environ.items() if k != store.TOKEN_ENV})
    except ValueError:
        # Not UTF-8 text, for one (LSK-OJS2-2): refused inside the command's result, its content never printed.
        return None, _obligations_refusal("credential", "credential_unusable",
                                          f"{origin}: the file is not a readable text credential")
    if found["error"]:
        if named and not os.path.isfile(os.path.expanduser(named)):
            # A name that is not a regular file (missing, a directory, a dangling link) may be a token
            # value given where its path belongs (--token abbreviates --token-file): it is never
            # printed (LSK-OJS2-4).
            return None, _obligations_refusal("credential", "credential_unusable",
                                              f"{origin}: no regular file by that name (the name is not printed)")
        return None, _obligations_refusal("credential", "credential_unusable", found["error"])
    if not found["token"]:
        return None, _obligations_refusal("credential", "no_credential",
                                          "looked: " + "; ".join(found["looked"]))
    return found["token"], None


def _obligations_event(path_text: str):
    """One JSON object from a private, bounded read of the named file that follows no symlink in
    any component of its path: each directory from the root down, then the file, is opened
    relative to the one before with O_NOFOLLOW, so no check can be raced before the open
    (LSK-OJS2-3). Strict JSON, so a repeated key, NaN or Infinity is refused here, before the store.
    A refusal names the path only as the operator gave it."""
    from console_files import directory, read
    path = Path(path_text).absolute()
    parent = path.parent.relative_to(path.anchor)
    try:
        with directory(path.anchor, None if parent == Path(".") else parent.as_posix()) as fd:
            raw = read(fd, path.name, limit=OBLIGATIONS_EVENT_LIMIT)
    except (OSError, ValueError) as exc:
        return None, _obligations_refusal("input", "event_file_unreadable",
                                          f"{path_text}: {getattr(exc, 'strerror', None) or exc}")

    def pairs(items):
        keys = [key for key, _ in items]
        if len(keys) != len(set(keys)):
            raise ValueError("a key is repeated")
        return dict(items)

    def constant(name):
        raise ValueError(f"{name} is not JSON")
    try:
        event = json.loads(raw.decode("utf-8"), object_pairs_hook=pairs, parse_constant=constant)
    except (UnicodeDecodeError, ValueError) as exc:
        return None, _obligations_refusal("input", "event_not_json", f"{path_text}: {exc}")
    except RecursionError:
        return None, _obligations_refusal("input", "event_not_json", f"{path_text}: nested too deep")
    if not isinstance(event, dict):
        return None, _obligations_refusal("input", "event_not_an_object", path_text)
    return event, None


def cmd_obligations(args) -> int:
    """The Chief of Staff's command over the obligations journal (section OBL, slice 2).

    Every act checks the switch first, before any credential or file is read; with the switch off,
    `append` and `repair-tail` refuse as the journal does and `show` reports the journal inactive.
    Identity comes from the credential, presented by its path only; --as is inert.
    """
    import obligations
    if args.obligations_cmd == "show" and not obligations.enabled():
        _obligations_print({"active": False, "reason": "obligations_disabled",
                            "detail": f"{obligations.ENABLE_ENV} is not 1: the journal does not exist"})
        return 0
    try:
        obligations.require_enabled()
    except obligations.ObligationRefused as refused:
        _obligations_print(refused.as_dict())
        return OBLIGATIONS_EXIT_REFUSED
    token, refusal = _obligations_credential(args)
    if refusal:
        _obligations_print(refusal)
        return OBLIGATIONS_EXIT_CREDENTIAL
    try:
        if args.obligations_cmd == "append":
            event, refusal = _obligations_event(args.file)
            if refusal:
                _obligations_print(refusal)
                return OBLIGATIONS_EXIT_INPUT
            result = obligations.append(event, presented_token=token)
        elif args.obligations_cmd == "show":
            result = obligations.show(presented_token=token)
        else:
            result = obligations.repair_torn_tail(presented_token=token)
    except obligations.ObligationRefused as refused:
        _obligations_print(refused.as_dict())
        return OBLIGATIONS_EXIT_REFUSED
    except OSError as failure:
        result = {"error": "obligations_io_error", "detail": failure.strerror or str(failure),
                  "notes": list(getattr(failure, "__notes__", []))}
        if isinstance(getattr(failure, "outcome", None), dict):
            result["outcome"] = failure.outcome  # what the act had done when it failed
        _obligations_print(result)
        return OBLIGATIONS_EXIT_IO
    _obligations_print(result)
    return 0


def cmd_migrate(args) -> int:
    n = 0
    for legacy in [SCRIPT_DIR / "orchestration.json", SCRIPT_DIR.parent / "orchestrator" / "orchestration.json"]:
        try:
            imported = store.migrate_legacy(legacy, channel_owner=getattr(args, 'legacy_owner', None))
        except ValueError as exc:
            print(f'migrate refused: {exc}', file=sys.stderr)
            return 1
        if imported:
            print(f"imported {imported} records from {legacy}")
        n += imported
    if not n:
        print("nothing to migrate")
    return 0


def cmd_serve(args) -> int:
    os.chdir(SCRIPT_DIR)
    os.execvpe("uv", ["uv", "run", "python", "psqr_orchestrator.py", "serve",
                     "--port", str(args.port), "--host", args.host], sanitized_env(server=True))


def cmd_attach(args) -> int:
    try:
        argv = seat_launcher.attach_argv(args.name)
        os.execvp("tmux", argv)
    except (OSError, RuntimeError, ValueError) as exc:
        print(f"error: cannot attach to {args.name}: {exc}", file=sys.stderr)
        return 1


def cmd_install(args) -> int:
    bin_dir = Path.home() / ".local" / "bin"
    command = product_identity.command()
    target = bin_dir / command
    shim = SCRIPT_DIR / "bin" / command
    # A packaged (`uv tool install`) layout has no bin/orch shim and already put a
    # working `orch` console entrypoint on PATH — symlinking to a nonexistent shim
    # would replace it with a DANGLING link (Bugbot #42 High). Refuse in that case,
    # but VERIFY the entrypoint actually exists rather than assuming (Bugbot MED).
    if not shim.exists():
        found = shutil.which(command)
        if found:
            print(f"no shim at {shim} — packaged `{command}` already on PATH ({found}); nothing to do")
            return 0
        print(f"no shim at {shim} AND no `{command}` on PATH — the packaged entrypoint "
              f"is missing (broken install)", file=sys.stderr)
        return 1
    bin_dir.mkdir(parents=True, exist_ok=True)
    if target.exists() or target.is_symlink():
        target.unlink()
    target.symlink_to(shim)
    print(f"installed: {target} → {shim}")
    return 0


def _seat_new(args) -> int:
    """Provisioner: one receipted act per Claude desktop seat. The seat's credential goes
    into its home and never to stdout, stderr, argv or a receipt."""
    import seat_new
    try:
        found = store.find_presented_token(args.token_file)
    except ValueError:  # a credential file that is not text: refused, its bytes never shown
        found = {'error': 'credential_undecodable', 'token': None}
    if found['error'] or not found['token']:
        return _refuse_identity('seat', 'provisioner_credential_required',
                                'seat new requires a current provisioner credential')
    try:
        if args.remove:
            seat_new.check_kind(args.kind)
            if any(value is not None for value in (args.home, args.role, args.approval_record_id,
                                                   args.approval_record_sha256, args.commission_file)):
                raise seat_new.Refused('remove_options_invalid', 'removal takes only --dry-run')
            result = seat_new.remove(args.seat, presented_token=found['token'], dry_run=args.dry_run)
        else:
            approval = None
            if args.approval_record_id is not None or args.approval_record_sha256 is not None:
                approval = (args.approval_record_id, args.approval_record_sha256)
            commission = (seat_new.read_commission(args.commission_file)
                          if args.commission_file is not None else None)
            result = seat_new.provision(args.seat, kind=args.kind, home=args.home,
                                        presented_token=found['token'], role=args.role,
                                        approval=approval, commission_text=commission,
                                        dry_run=args.dry_run)
    except seat_new.Refused as exc:
        if exc.reason in seat_new.CREDENTIAL_REASONS:
            return _refuse_identity('seat', exc.reason, exc.detail)
        print(f'seat new refused: {exc.detail} (reason={exc.reason})', file=sys.stderr)
        return 1
    except seat_new.COMMITTED_EXCEPTIONS as exc:
        print(f'seat new incomplete: {exc}; inspect the receipts before retrying', file=sys.stderr)
        return 74
    print(json.dumps(result, sort_keys=True))
    if not args.remove and not args.dry_run:
        print('human act: ' + result['human_act'])
    return 0


def cmd_seat(args) -> int:
    """Operate a registry-declared seat without using the default tmux server."""
    if args.seat_cmd in {'grounding-record', 'grounding-show'}:
        import seat_grounding
        try:
            found = store.find_presented_token(args.token_file)
            if found['error'] or not found['token']:
                raise PermissionError('credential required')
            if args.seat_cmd == 'grounding-show':
                result = seat_grounding.inspect_own(args.seat, presented_token=found['token'])
            else:
                result = seat_grounding.record(args.seat, presented_token=found['token'],
                    expected_generation=args.expected_generation, norms_sha256=args.norms_sha256,
                    standard_revision=args.standard_revision, addenda=args.addenda, basis=args.basis)
            print(json.dumps(result, sort_keys=True))
            return 0
        except store.RegistryMutationRefused as exc:
            return _refuse_identity('seat', exc.reason, str(exc))
        except seat_grounding.Refused as exc:
            print(str(exc), file=sys.stderr)
            return 1
        except (OSError, ValueError, TypeError):
            print('grounding act refused or uncertain; inspect receipts before retrying', file=sys.stderr)
            return 1
    if args.seat_cmd == 'new':
        return _seat_new(args)
    if args.seat_cmd == 'install':
        from desktop_support import require
        import seat_install
        import seat_grounding
        try:
            found=store.find_presented_token(args.token_file)
            if found['error'] or not found['token']:
                raise PermissionError('install_provisioner_credential_required')
            startup_recovery = getattr(args, 'claude_startup_recovery', None)
            if startup_recovery is not None and (args.kind != 'claude' or args.remove):
                raise ValueError('Claude startup recovery is a desktop install-only option')
            if args.kind in {'claude-cli','codex-cli','gemini-cli'}:
                stage1_features.require_private('terminal_agents')
                import cli_kit
                if any((args.project_id,args.app_config_dir,args.app_data_dir,args.allow_sidecar_install)):
                    raise ValueError('AGY-only options')
                result=cli_kit.install(presented_token=found['token'],seat=args.seat,kind=args.kind,
                    dry_run=args.dry_run,replace=args.replace,remove=args.remove,
                    vendor_profile_dir=args.vendor_profile_dir,clear_vendor_profile=args.clear_vendor_profile)
            elif args.kind == 'agy-desktop':
                if args.vendor_profile_dir is not None or args.clear_vendor_profile:
                    raise ValueError('Claude CLI-only vendor profile')
                agy_install = require('agy_install')
                if not args.seat or not args.project_id:
                    raise ValueError('AGY seat and project id required')
                result=agy_install.install(presented_token=found['token'],seat=args.seat,
                    project_id=args.project_id,
                    app_config_dir=args.app_config_dir or str(Path.home()/'.gemini'/'config'),
                    app_data_dir=args.app_data_dir or str(Path.home()/'.gemini'/'antigravity'/'sidecar_data'),
                    dry_run=args.dry_run,remove=args.remove,
                    install_word=args.allow_sidecar_install,replace=args.replace)
            else:
                if any((args.project_id, args.app_config_dir, args.app_data_dir,
                        args.allow_sidecar_install,args.vendor_profile_dir,args.clear_vendor_profile)):
                    raise ValueError('AGY-only options')
                if args.remove:
                    installer = seat_install.codex_remove if args.kind == 'codex' else seat_install.claude_remove
                else:
                    installer = seat_install.codex_install if args.kind == 'codex' else seat_install.claude_install
                options = {'startup_recovery': startup_recovery} if startup_recovery is not None else {}
                result = installer(presented_token=found['token'], seat=args.seat,
                                   dry_run=args.dry_run, replace=args.replace, **options)
            print(json.dumps(result,sort_keys=True))
            return 0
        except seat_grounding.Refused as exc:
            print(str(exc), file=sys.stderr)
            return 1
        except store.SeatActWithoutReceipt:
            print('seat install incomplete or unreceipted; inspect files and receipts before retrying', file=sys.stderr)
            return 74
        except stage1_features.NotOffered:
            raise
        except (OSError,ValueError,TypeError,store.RegistryMutationRefused) as exc:
            reason = ('CLI kit state or authorization invalid' if args.kind in {'claude-cli','codex-cli','gemini-cli'} else seat_install.refusal_reason(exc))
            print('seat install refused: ' + reason
                  + '; inspect the managed state before retrying',file=sys.stderr)
            return 1
    if args.seat_cmd in {"home", "set-model"}:
        from provision import machine
        try:
            if args.seat_cmd == "home":
                result = machine.seat_homes(args.seats)
                result = result[0] if len(result) == 1 else result
            else:
                result = machine.record_model(args.seat, args.model, token=args.presented_token)
        except store.RegistryMutationRefused as exc:
            return _refuse_identity("seat", exc.reason, str(exc))
        except (OSError, ValueError, TypeError) as exc:
            print(f"seat {args.seat_cmd} refused: {exc}", file=sys.stderr)
            return 1
        print(json.dumps(result, sort_keys=True))
        return 0
    if args.seat_cmd == "help-clear":
        from provision import seat_help
        try:
            result = seat_help.clear(args.seat, token=args.presented_token)
        except store.RegistryMutationRefused as exc:
            return _refuse_identity("seat", exc.reason, str(exc))
        except (OSError, ValueError, TypeError):
            print("help-clear failed; inspect the help receipt before retry", file=sys.stderr)
            return 1
        print(json.dumps(result))
        return 0
    if args.seat_cmd == "wake-revive":
        from desktop_support import require
        codex_dispatch = require('codex_dispatch')
        try:
            result = codex_dispatch.revive(
                args.seat, presented_token=args.presented_token, expected_actor=args.identity,
                reason=args.reason, expected_generation=args.generation)
        except store.RegistryMutationRefused as exc:
            return _refuse_identity("seat", exc.reason, str(exc))
        except (OSError, ValueError) as exc:
            print(f"wake revive refused or receipt uncertain: {exc}", file=sys.stderr)
            return 1
        print(json.dumps(result))
        return 0
    if args.seat_cmd in {'wake-hookset-record', 'wake-hookset-show', 'wake-hook-interface-policy', 'wake-hook-interface-show'}:
        from desktop_support import require
        inapp_hookset = require('inapp_hookset')
        import claude_hook_interface
        try:
            if args.seat_cmd == 'wake-hook-interface-show':
                result = claude_hook_interface.inspect(presented_token=args.presented_token)
            elif args.seat_cmd == 'wake-hook-interface-policy':
                result = claude_hook_interface.set_policy(presented_token=args.presented_token,
                    previous=args.previous, expires_at=args.expires_at,
                    expected_generation=args.expected_generation, reason=args.reason)
            elif args.seat_cmd == 'wake-hookset-show':
                result = inapp_hookset.inspect_own(args.seat, presented_token=args.presented_token)
            else:
                spec = json.loads(inapp_hookset.read_file(args.record_file, inapp_hookset.MAX_SPEC_BYTES))
                result = inapp_hookset.provision(args.seat, spec, presented_token=args.presented_token,
                                                 expected_generation=args.expected_generation)
        except store.RegistryMutationRefused as exc:
            return _refuse_identity('seat', exc.reason, str(exc))
        except store.SeatActWithoutReceipt as exc:
            print(str(exc), file=sys.stderr)
            return 74
        except claude_hook_interface.Refused as exc:
            print(f'hook interface refused: {exc}', file=sys.stderr)
            return 1
        except (OSError, ValueError, TypeError, KeyError):
            print('hook-set act refused or incomplete; inspect registry and receipts before retry', file=sys.stderr)
            return 1
        print(json.dumps(result))
        return 0
    if args.seat_cmd in {"wake-declare", "wake-clear"}:
        from desktop_support import require
        inapp_wake_route = None
        try:
            if args.seat != args.identity:
                return _refuse_identity("seat", "wake_route_wrong_actor", "a seat declares only its own route")
            if (args.seat_cmd == 'wake-declare' and args.kind != 'inapp-socket'
                    and any(getattr(args,key,None) is not None for key in ('hook_set_digest',
                        'hook_set_generation','session_start_source','hook_home','previous_generation',
                        'hook_interface_version','hook_interface_digest','grounding_generation'))):
                raise ValueError('hook-set qualification is only for inapp-socket')
            if args.seat_cmd == "wake-clear":
                route = (store.load_participants().get(args.seat) or {}).get('wake_route')
                if isinstance(route, dict) and route.get('kind') == 'inapp-socket':
                    from desktop_support import require
                    inapp_wake_route = require('inapp_wake_route')
                    result = inapp_wake_route.change(args.seat, presented_token=args.presented_token)
                elif isinstance(route, dict) and route.get('kind') == 'agy-desktop':
                    from desktop_support import require
                    agy_wake_route = require('agy_wake_route')
                    result = agy_wake_route.clear(args.seat, presented_token=args.presented_token)
                else:
                    result = require('codex_wake_route').clear(args.seat, presented_token=args.presented_token)
            elif args.kind == 'inapp-socket':
                if not args.ref:
                    print(f"{product_identity.command()} seat wake-declare: error: argument --ref is required for inapp-socket", file=sys.stderr)
                    return 2
                from desktop_support import require
                inapp_wake_route = require('inapp_wake_route')
                result = inapp_wake_route.change(
                    args.seat, ref=args.ref, session_ref=args.session_ref,
                    presented_token=args.presented_token,
                    **{key:getattr(args,key,None) for key in ('hook_set_digest','hook_set_generation',
                       'session_start_source','hook_home','previous_generation',
                       'hook_interface_version','hook_interface_digest','grounding_generation')})
                # Bind a later completion failure to this authenticated receipt,
                # never to a subsequent registry read or a caller-supplied route.
                args._inapp_declaration_receipt = result['receipt']
            elif args.kind == 'agy-desktop':
                from desktop_support import require
                agy_wake_route = require('agy_wake_route')
                result = agy_wake_route.declare(
                    args.seat, conversation_id=args.conversation_id, presented_token=args.presented_token)
            else:
                if not args.ref:
                    print(f"{product_identity.command()} seat wake-declare: error: argument --ref is required for codex-ipc", file=sys.stderr)
                    return 2
                result = require('codex_wake_route').declare(
                    args.seat, ref=args.ref, host_id=args.host_id,
                    conversation_id=args.conversation_id, presented_token=args.presented_token)
        except store.RegistryMutationRefused as exc:
            return _refuse_identity("seat", exc.reason, str(exc))
        except store.SeatActWithoutReceipt as exc:
            print(str(exc), file=sys.stderr)
            return 74
        except RuntimeError as exc:
            if inapp_wake_route is None or not isinstance(exc, inapp_wake_route.DeclarationIndeterminate):
                raise
            print(f'wake route state indeterminate: {exc}', file=sys.stderr)
            return 74
        except (OSError, ValueError) as exc:
            print(f"wake route refused: {exc}", file=sys.stderr)
            return 1
        print(json.dumps(result))
        return 0
    if args.seat_cmd == "declare":
        try:
            result = store.provision_seat_declaration(
                args.identity, args.seat, hosting_kind=args.hosting_kind,
                tmux_socket=args.tmux_socket, workspace_dir=args.workspace_dir,
                config_dir=args.config_dir, session_ref=args.session_ref,
                history_limit=args.history_limit, presented_token=args.presented_token)
        except store.RegistryMutationRefused as exc:
            return _refuse_identity(args.command, exc.reason, str(exc))
        except store.SeatActWithoutReceipt as exc:
            print(f"{YELLOW}{exc} — the declaration stands; the ledger row is missing{RESET}",
                  file=sys.stderr)
            return 74
        except (OSError, RuntimeError, ValueError) as exc:
            print(f"error: seat declaration refused for {args.seat}: {exc}", file=sys.stderr)
            return 1
        print(f"declared {args.seat} ({'changed' if result['changed'] else 'unchanged'}); "
              f"receipt {result['receipt']['id']}")
        return 0
    if args.seat_cmd != "launch":
        raise ValueError(f"unknown seat operation: {args.seat_cmd!r}")
    try:
        result = seat_launcher.launch(args.seat, presented_token=args.presented_token,
                                      interactive=getattr(args, "interactive", False),
                                      claude_permission_mode=getattr(args, "claude_permission_mode", None))
    except store.RegistryMutationRefused as exc:
        return _refuse_identity(args.command, exc.reason, str(exc))
    except stage1_features.NotOffered:
        raise
    except (OSError, RuntimeError, ValueError) as exc:
        print(f"error: seat launch refused for {args.seat}: {exc}", file=sys.stderr)
        return 1
    print(f"launched {result.seat} on private socket {result.socket}")
    print(f"history-limit {result.history_limit}")
    print(f"pane.log {result.pane_log} — {result.pane_log_evidence}")
    if getattr(args, "interactive", False):
        print("Native trust/readiness and answered mail are unverified; complete the onboarding checks.")
    return 0


def cmd_panel(args) -> int:
    """Render the one read-only A.7 panel producer as JSON or a compact table."""
    snapshot = seat_panel.build()
    if args.json:
        print(json.dumps(snapshot, indent=2))
        return 0
    columns = seat_panel.PANEL_SEAT_FIELDS
    if any("focus" in row for row in snapshot["seats"]):
        columns = (*columns, "focus")  # D-GOV-2 (f): only once the feature was switched on
    print("\t".join(columns))
    for row in snapshot["seats"]:
        print("\t".join(f"{row[name]['value']} [{row[name]['source']}]"
                        + (f" {row[name].get('detail', '')}" if name in {"token_status", "pane_state"} else "")
                        for name in columns))
    print(f"measured_at\t{snapshot['measured_at']} [RUNTIME-VERIFIED]")
    print(f"retired: {snapshot['retired_count']}")
    return 0


def cmd_provision(args) -> int:
    """Run the provisioning manifest (the installer's governed-setup step). Thin
    passthrough to provision/run.py so `orch provision` works from a packaged
    install (reviewer PR#42 HIGH: the installer must have a real entry point, not
    fall through to a false-green success). Exit code IS the runner's — 0 ok,
    1 failed, 3 required-pending-without --spine-only."""
    from provision import run as _prov
    argv = []
    if getattr(args, "spine_only", False):
        argv.append("--allow-pending")
    if getattr(args, "only", None):
        argv += ["--only", args.only]
    if getattr(args, "dry_run", False):
        argv.append("--dry-run")
    for name in ("seat", "seat_home", "commission_file", "lifecycle_authority", "cycle", "seat_home_map", "recorded_model"):
        value = getattr(args, name, None)
        if value:
            argv += ["--" + name.replace("_", "-"), str(value)]
    token = getattr(args, "presented_token", None)
    return _prov.main(argv, presented_token=token) if token else _prov.main(argv)


# --- interactive menu ---

MENU = f"""
{BOLD}1{RESET} read my inbox     {BOLD}2{RESET} dialogue feed
{BOLD}4{RESET} message someone   {BOLD}5{RESET} assign task       {BOLD}6{RESET} task board
{BOLD}7{RESET} raise/lower hand  {BOLD}8{RESET} stack up/down     {BOLD}9{RESET} doctor   {BOLD}q{RESET} quit
"""


def interactive(identity: str, token_bound: bool = False,
                presented_token: str | None = None) -> int:
    try:
        import readline  # noqa: F401  (line editing in input())
    except ImportError:
        pass
    ns = argparse.Namespace(identity=identity, presented_token=presented_token,
                            peek=False, json=False, tail=20,
                            follow=False, among=None, subset=False, since=None, until=None,
                            done=None, reopen=None, participant=None)
    how = ("seat token" if token_bound
           else "asserted — read-only views; hub-acting menu items need a seat token")
    print(f"{DIM}you are {identity} ({how}){RESET}")

    def needs_token() -> bool:
        """Hub-acting menu items follow the same rule as the subcommands (A.4)."""
        if token_bound:
            return False
        instruction = product_identity.diagnostic(
            f"run {product_identity.command()} from your seat workspace, or set $ORCH_TOKEN_FILE",
            'use the registered agent workspace')
        print(f"{RED}refusing: this menu item acts on the hub and needs a seat token "
              f"(reason=no_seat_token) — {instruction}{RESET}")
        return True
    last_send_status = 0
    while True:
        cmd_status(ns)
        print(MENU)
        try:
            choice = input(f"{BOLD}{product_identity.command()}>{RESET} ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            return last_send_status
        try:
            if choice in ("q", "quit", "exit"):
                return last_send_status
            elif choice == "1":
                if not needs_token():
                    _print_messages(store.drain_inbox(identity), False)
            elif choice == "2":
                cmd_log(ns)
            elif choice == "4" and not needs_token():
                parts = store.load_participants()
                names = [p for p in parts if p != identity]
                print("  " + " · ".join(names))
                to = input("to (comma-separated)> ").strip()
                text = input("message> ").strip()
                if to and text:
                    last_send_status = cmd_send(argparse.Namespace(
                        identity=identity, to=to, to_option=None, text=[text],
                        envelope=None, presented_token=presented_token))
            elif choice == "5" and not needs_token():
                assignee = input("assignee> ").strip()
                title = input("task> ").strip()
                if assignee and title:
                    a = argparse.Namespace(identity=identity, presented_token=presented_token,
                                           assignee=assignee, title=[title])
                    cmd_assign(a)
            elif choice == "6":
                cmd_tasks(ns)
                sub = input("done <id> / reopen <id> / enter to continue> ").strip()
                if sub and needs_token():
                    sub = ""
                if sub.startswith("done "):
                    store.task_event("done", task_id=sub[5:].strip(), actor=identity)
                elif sub.startswith("reopen "):
                    store.task_event("reopened", task_id=sub[7:].strip(), actor=identity)
            elif choice == "7" and not needs_token():
                me = store.load_participants().get(identity, {})
                if me.get("hand_raised"):
                    cmd_lower(ns)
                else:
                    msg = input("why?> ").strip()
                    a = argparse.Namespace(identity=identity, presented_token=presented_token,
                                           message=[msg or "attention please"])
                    cmd_raise(a)
            elif choice == "8":
                if daemon_pid():
                    if input("stack is UP — take it down? [y/N]> ").strip().lower() == "y":
                        cmd_down(ns)
                else:
                    a = argparse.Namespace(store=None, port=8020)
                    cmd_up(a)
            elif choice == "9":
                cmd_doctor(ns)
            if choice:
                input(f"{DIM}(enter to continue){RESET} ")
        except (EOFError, KeyboardInterrupt):
            print()
            continue
        except Exception as exc:
            print(f"{RED}error: {exc}{RESET}")
            input(f"{DIM}(enter to continue){RESET} ")


def _journal_inapp_completion_failure(args, exc) -> None:
    """Record a caught post-declaration failure without retrying either act."""
    row = getattr(args, '_inapp_declaration_receipt', None)
    route = row.get('route') if isinstance(row, dict) else None
    if (not isinstance(route, dict) or row.get('kind') != 'wake-route'
            or row.get('event') != 'declared' or row.get('seat') != args.identity
            or row.get('requester') != args.identity or route.get('kind') != 'inapp-socket'):
        return
    try:
        import hashlib
        import receipts
        auth_reasons = {'registry_auth_'+reason for reason in (
            'no_token', 'unknown_token', 'revoked', 'pending', 'expired', 'missing_surface',
            'unregistered_seat', 'retired_seat', 'parked_seat', 'wrong_actor')}
        details = {}
        if isinstance(exc, store.RegistryMutationRefused):
            reason = (exc.reason if isinstance(exc.reason, str) and exc.reason in auth_reasons
                      else 'completion_registry_refused')
            error_type = 'RegistryMutationRefused'
        elif isinstance(exc, OSError):
            reason, error_type = 'completion_io_error', 'OSError'
            if type(exc.errno) is int:
                details['errno'] = exc.errno
        else:
            reason = 'completion_error'
            error_type = (type(exc).__name__ if type(exc) in
                          (ValueError, TypeError, RuntimeError, NameError, AttributeError,
                           json.JSONDecodeError) else 'Exception')
        with receipts._nudge_lock():
            receipts._append({'kind': 'seat-act-completion-failed', 'seat': row['seat'],
                'command': 'seat', 'subcommand': 'wake-declare', 'reason': reason,
                'error_type': error_type, 'outcome': 'unconfirmed', **details,
                'declaration_generation': row['generation'], 'declaration_ts': row['ts'],
                'declaration_receipt_sha256': hashlib.sha256(json.dumps(
                    row, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
                'ts': store.now_iso()})
    except Exception:
        print('declaration completed; activity failure journal unavailable', file=sys.stderr)


class _VersionAction(argparse.Action):
    """`--version`: the package metadata is read only when the flag is given, so no other
    invocation reads anything it did not read before (the digest's effect audit holds)."""
    def __init__(self, option_strings, dest=argparse.SUPPRESS, default=argparse.SUPPRESS, help=None):
        super().__init__(option_strings=option_strings, dest=dest, default=default, nargs=0, help=help)

    def __call__(self, parser, namespace, values, option_string=None):
        import product
        print(product.version_line())
        parser.exit()


def main() -> int:
    product_profile = product_identity.load()
    description = (product_profile.display_name+' — local mail and a read-only console for coding agents.\n'
                   'Use setup for first run, doctor for prerequisites, and --help on a command for its options.'
                   if product_profile.is_public else __doc__)
    parser = _CommandParser(prog=product_profile.command(), description=description,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--version", action=_VersionAction,
                        help="print the installed version (from the package metadata) and exit")
    parser.add_argument("--as", dest="identity", default=None,
                        help=("asserted identity for read-only/local views; authenticated acts use the seat identity"
                             if product_profile.is_public else "asserted identity for read-only/local views (else $ORCH_AGENT); "
                             "INERT for hub-acting commands, whose identity is derived from "
                             "the seat token"))
    parser.add_argument("--token-file", default=None, metavar="PATH",
                        help=(argparse.SUPPRESS if product_profile.is_public else
                             "seat token file (else $ORCH_TOKEN_FILE, $ORCH_TOKEN, or the "
                             "nearest .orch/token at or above the cwd — the seat's workspace)"))
    sub = parser.add_subparsers(dest="command")
    from desktop_support import available
    private_routes = [kind for kind, module in (
        ('codex-ipc', 'codex_wake_route'), ('inapp-socket', 'inapp_wake_route'),
        ('agy-desktop', 'agy_wake_route')) if available(module)]
    private_installs = (['claude', 'codex'] if available('inapp_install') else [])
    install_kinds = ['claude-cli', 'codex-cli', 'gemini-cli']
    if available('agy_install'):
        private_installs.append('agy-desktop')

    sub.add_parser("message-file", help="stage bounded literal text from stdin in your own immutable private outbox; does not send")
    sub.add_parser("status", help="who's here, unread counts, stack health")
    p = sub.add_parser("panel", help="fresh labeled seat panel")
    p.add_argument("--json", action="store_true")

    if private_routes:
        sub.add_parser("seat-event", help="post one authenticated pointer hook event from JSON stdin")
    sub.add_parser("hook-fetch", help="durably save and authenticate a full-body hook inbox from JSON stdin")
    if available('agy_sidecar') and 'agy-desktop' in private_routes:
        sub.add_parser('agy-hook-fetch',help='one authenticated transcript-free AGY invocation fetch')
        sub.add_parser('agy-hook-emitted',help='record emission without retiring recovery')
        for command in ('agy-read','agy-ack'):
            p=sub.add_parser(command,help='explicitly read or acknowledge durable AGY recovery mail')
            p.add_argument('msg_ids',nargs='+')
            p.add_argument('--seat',help='operator disposition of another seat, current provisioner only')
        p=sub.add_parser('agy-sidecar',help='app-supervised scoped intent bridge; never a seat token')
        p.add_argument('--bridge-token-file',required=True)
        p.add_argument('--store-dir',required=True)
        p.add_argument('--agentapi',help='absolute agentapi executable; otherwise resolve the app-supplied PATH')
        p.add_argument('--once',action='store_true',help='one bounded pass, for qualification')
    p = sub.add_parser("inbox", help="read + consume my new messages")
    p.add_argument("participant", nargs="?", help="defaults to your identity")
    p.add_argument("--peek", action="store_true", help="read without consuming")
    p.add_argument("--save-home", nargs="?", const="", metavar="PATH",
                   help="durably file before consumption; omit PATH to use the bearer's registered home")
    p.add_argument("--harness-json", help="optional last-reported harness facts for this authenticated fetch")
    p.add_argument("--json", action="store_true")

    p = sub.add_parser("wait", help="observe own unread mail without fetching; exits 0 mail, 3 timeout, other error")
    p.add_argument("--seat", required=True)
    p.add_argument("--timeout", required=True, help="seconds, 0 through 7200; polls no faster than every 5 seconds")
    p.error = lambda message, wait_parser=p: wait_parser.exit(2, "wait: error invalid_arguments\n")

    p = sub.add_parser("mail", help="fetch one stage-1 envelope and my pending set")
    p.add_argument("msg_id")

    p = sub.add_parser('recall', help='recall unread mail or withdraw it with notices to readers')
    p.add_argument('msg_id')
    p.add_argument('--reason', default='')
    p.add_argument('--unread-only', action='store_true')
    p.add_argument('--authorization-file', help='scoped principal-signed recall record for cross-author recall')

    p = sub.add_parser('focus', help="a focus period: defer this seat's wakes, never its mail (D-GOV-2 (f))")
    fs = p.add_subparsers(dest='focus_cmd', required=True)
    q = fs.add_parser('start', help='declare a focus period for your seat (the principal: for any seat)')
    q.add_argument('--for', dest='minutes', type=int, required=True, metavar='MINUTES')
    q.add_argument('--reason', default=None, help='one line, at most 256 bytes')
    q.add_argument('--seat', default=None, help='principal only: declare for this seat')
    fs.add_parser('release', help='end your own focus period')
    q = fs.add_parser('break', help="end another seat's period (the principal or a Chief of Staff)")
    q.add_argument('seat')
    q.add_argument('--reason', required=True, help='one line, at most 256 bytes')
    q = fs.add_parser('show', help='the policy and the active periods, with pending counts')
    q.add_argument('seat', nargs='?')
    q = fs.add_parser('policy', help="the principal's activation record and maximum")
    ps = q.add_subparsers(dest='policy_cmd', required=True)
    ps.add_parser('show', help='the current policy row')
    r = ps.add_parser('set', help='activate with a maximum, change it, or set the feature inactive')
    mode = r.add_mutually_exclusive_group(required=True)
    mode.add_argument('--maximum', type=int, metavar='MINUTES')
    mode.add_argument('--inactive', action='store_true')
    r.add_argument('--expected-generation', required=True, help="'none' for the first row")
    r.add_argument('--reason', required=True, help='one line, at most 256 bytes')

    p = sub.add_parser("await", help="block until a message arrives (watcher primitive)")
    p.add_argument("participant", nargs="?")
    p.add_argument("--timeout", type=float, default=None)
    p.add_argument("--json", action="store_true")
    p.add_argument("--filtered", action="store_true",
                   help="wake only on addressed/mentioned messages (read-only log "
                        "tail, inbox untouched); exit 2 = heartbeat batch sweep")
    p.add_argument("--heartbeat-hours", type=float, default=8.0,
                   help="filtered mode: max hours before a batch-sweep wake (exit 2)")

    p = sub.add_parser("send", help="send direct messages to explicit participants")
    p.epilog = ("Before recipients: --re TEXT --authority VALUE --confirm --bluf TEXT "
                "--triage VALUE --ack MSG_ID --claims-recipients A,B. "
                "Use --body-file PATH before or after recipients for a UTF-8 file "
                "(exclusive with positional body and stdin data). "
                "Use -- before literal option text; omit both body and file to read stdin.")
    p.raw_send = True
    p.add_argument("send_tokens", nargs=argparse.REMAINDER,
                   help="[RECIPIENTS] [--to RECIPIENTS] [message | --body-file PATH] (else stdin)")

    p = sub.add_parser("broadcast", help=f"retired; points to explicit {product_profile.command()} send")
    p.add_argument("text", nargs="*")

    p = sub.add_parser("interrupt",
                       help="operator: break an agent's runaway loop / get its attention")
    p.add_argument("agent")
    p.add_argument("reason", nargs="*")

    p = sub.add_parser("log", help="dialogue feed")
    p.add_argument("--tail", type=int, default=30)
    p.add_argument("--follow", "-f", action="store_true")
    log_filter = p.add_mutually_exclusive_group()
    log_filter.add_argument("--participant", metavar="SEAT",
                   help="sender or recorded recipient; mentions alone do not match")
    log_filter.add_argument("--among", metavar="A,B,C",
                   help="exact participant set: sender plus recorded recipients; legacy "
                        "broadcast/room rows use their recorded recipients")
    p.add_argument("--subset", action="store_true",
                   help="with --among, match participant sets contained in the named set")
    p.add_argument("--since", help="inclusive YYYY-MM-DD or ISO instant")
    p.add_argument("--until", help="inclusive whole day for YYYY-MM-DD, or ISO instant")

    p = sub.add_parser("assign", help="create + assign a task")
    p.add_argument("assignee")
    p.add_argument("title", nargs="+")

    p = sub.add_parser("tasks", help="task board")
    p.add_argument("--done", help="mark task id done")
    p.add_argument("--reopen", help="reopen task id")

    p = sub.add_parser("reviews", help="convergence reviews (view / evaluate / clear)")
    p.add_argument("--show", help="show one review's verdicts + state")
    p.add_argument("--evaluate", help="run the consensus oracle on a review id")
    p.add_argument("--clear", help="clear a review id (the human Z)")
    p.add_argument("--override", help="override reason (required to clear a contested review)")

    p = sub.add_parser("raise", help="raise your hand")
    p.add_argument("message", nargs="+")
    sub.add_parser("lower", help="lower your hand")

    p = sub.add_parser("join", help="register a participant")
    p.add_argument("name")
    p.add_argument("--kind", choices=["human", "agent", "system"])
    p.add_argument("--channel", choices=sorted(store.VALID_CHANNELS))
    p.add_argument("--family")
    p.add_argument("--tmux-session")

    p = sub.add_parser("up", help="create a fresh store if unbound; start daemon and local web only")
    p.add_argument("--store", metavar="ABSOLUTE_PATH", help=f"new store path (default: ~/{product_profile.home_directory}/store); never switch an existing binding")
    p.add_argument("--port", type=int, default=8020, help="loopback web port (default: 8020)")
    p = sub.add_parser("setup", help="first run on this Mac: check the prerequisites, start the store and services, make the Chief of Staff's seat, open the console")
    p.add_argument("--store", metavar="ABSOLUTE_PATH", help=f"new store path (default: ~/{product_profile.home_directory}/store); never switch an existing binding")
    p.add_argument("--port", type=int, default=8020, help="loopback web port (default: 8020)")
    p.add_argument("--chief", default="Chief", metavar="NAME", help="the Chief of Staff seat's name (default: Chief)")
    p.add_argument("--no-open", action="store_true", help="do not open the console in the browser")
    sub.add_parser("down", help="stop daemon and web only after verified death and lease release; preserve seats/history (use shutdown to request checkpoints first)")
    p = sub.add_parser("shutdown", help="request checkpoints, then stop verified infrastructure; preserve seats/history")
    p.add_argument("--grace", type=int, default=120, help="seconds for agents to checkpoint (default 120)")
    p = sub.add_parser("doctor", help="diagnose the stack")
    p.add_argument("--port", type=int, default=None,
                   help=product_identity.diagnostic(
                       "expected web port; default: verified running service, then PSQR_PORT/8020",
                       "expected web port; default: verified running service, then 8020"))
    migrate = sub.add_parser("migrate", help="import legacy orchestration.json history")
    migrate.add_argument('--legacy-owner', help='explicit historical author of legacy channel messages')

    p = sub.add_parser("rooms", help=f"retired; points to {product_profile.command()} log --among")
    p.add_argument("retired_args", nargs="*")
    p = sub.add_parser("room", help=f"retired; points to {product_profile.command()} log --among")
    p.add_argument("retired_args", nargs="*")
    p = sub.add_parser("quarantine", help="CoS review queue")
    p.add_argument("quarantine_cmd", choices=["list", "release", "discard"])
    p.add_argument("msg_id", nargs="?")
    credentials = p.add_mutually_exclusive_group()
    credentials.add_argument("--governance-key", help="registered CoS Ed25519 private PEM file (0600); never a seat token")
    credentials.add_argument("--authorization-file", help="signed, scoped quarantine authorization JSON")
    p.add_argument("--json", action="store_true")

    p = sub.add_parser("serve", help="run the web server in the foreground")
    p.add_argument("--port", type=int, default=SERVER_PORT)
    p.add_argument("--host", default="127.0.0.1")

    p = sub.add_parser("attach", help="attach to a participant's tmux session")
    p.add_argument("name")
    p = sub.add_parser("seat", help="private per-seat tmux hosting")
    ps = p.add_subparsers(dest="seat_cmd", required=True)
    if install_kinds:
        pi=ps.add_parser('install',help='provisioner: install a workspace CLI kit or an available desktop kit')
        pi.add_argument('seat', nargs='?', help='required for Claude/AGY; Codex always renders the whole registered roster')
        pi.add_argument('--kind',required=True,choices=install_kinds+private_installs)
        pi.add_argument('--project-id')
        pi.add_argument('--app-config-dir')
        pi.add_argument('--app-data-dir')
        pi.add_argument('--allow-sidecar-install',metavar='PRINCIPAL_WORD')
        pi.add_argument('--replace',metavar='EXPECTED_GENERATION')
        pi.add_argument('--claude-startup-recovery', choices=['legacy','held-v1'],
                        help='Claude desktop only: explicitly provision read-retry/held startup; omitted preserves prior policy')
        pi.add_argument('--dry-run',action='store_true')
        pi.add_argument('--remove',action='store_true')
        profile=pi.add_mutually_exclusive_group()
        profile.add_argument('--vendor-profile-dir',metavar='ABSOLUTE_DIRECTORY',
                             help='Claude CLI only: use this existing native profile; HOME is unchanged')
        profile.add_argument('--clear-vendor-profile',action='store_true',
                             help='Claude CLI only: remove an explicit native profile using --replace')
    if 'claude' in private_installs:
        pn = ps.add_parser('new', help='provisioner: one receipted act creates a Claude desktop seat '
                                       '(participant, home, credential, kit); --remove undoes it')
        pn.add_argument('seat')
        pn.add_argument('--kind', required=True, metavar='KIND', help='claude')
        pn.add_argument('--home', metavar='PATH', help='canonical absolute home (default ~/agents/<seat>)')
        pn.add_argument('--dry-run', action='store_true', help='print the plan; write nothing')
        pn.add_argument('--remove', action='store_true', help='undo exactly what the recorded acts made')
        pn.add_argument('--role', metavar='ROLE', help='explicit role; privileged roles need an approval record')
        pn.add_argument('--approval-record-id', metavar='ID')
        pn.add_argument('--approval-record-sha256', metavar='HEX')
        pn.add_argument('--commission-file', metavar='PATH', help='commission text for the seat grounding')
    pg = ps.add_parser('grounding-record', help='provisioner: receipt already-adopted seat expectations; no adoption or grant')
    pg.add_argument('seat')
    pg.add_argument('--norms-sha256', required=True)
    pg.add_argument('--standard-revision', required=True, type=int)
    pg.add_argument('--addenda', required=True, type=int)
    pg.add_argument('--expected-generation', required=True)
    pg.add_argument('--basis', required=True, help='reference to the adopting record; opaque to this product')
    pg = ps.add_parser('grounding-show', help='authenticated own-seat grounding, deployed catalog and declared model')
    pg.add_argument('seat')
    ph = ps.add_parser("home", help="read registered homes and recorded models; no token required")
    ph.add_argument("seats", nargs="+", help="registered agent(s); one object or a list in JSON")
    pm = ps.add_parser("set-model", help="CoS/human: record a seat's model; does not switch its harness")
    pm.add_argument("seat")
    pm.add_argument("model")
    pl = ps.add_parser("launch", help="launch a registered seat on its private socket")
    pl.add_argument("--interactive", action="store_true", help="start the installed CLI kit directly; preserves the registered role")
    pl.add_argument("--claude-permission-mode", choices=["manual", "bypassPermissions"],
                    help="Claude interactive launch only; defaults to bypassPermissions, with manual for an explicit charter")
    pl.add_argument("seat")
    pd = ps.add_parser("declare", help="declare governance-owned private-seat hosting fields")
    pd.add_argument("seat")
    pd.add_argument("--hosting-kind", required=True, choices=["tmux-hosted"])
    pd.add_argument("--tmux-socket", required=True)
    pd.add_argument("--workspace-dir", required=True)
    pd.add_argument("--config-dir", required=True)
    pd.add_argument("--session-ref", required=True)
    pd.add_argument("--history-limit", required=True, type=int)
    if private_routes:
        pw = ps.add_parser("wake-declare", help="declare your own inert host/task wake route")
        pw.add_argument("seat")
        pw.add_argument("--ref", help="absolute canonical desktop IPC socket path")
        pw.add_argument("--host-id", default="local", choices=["local"])
        pw.add_argument("--conversation-id")
        pw.add_argument("--kind", choices=private_routes, default=private_routes[0])
        pw.add_argument("--session-ref", help="Claude local app session id for inapp-socket")
        pw.add_argument('--hook-set-digest', help='opt-in provisioned Claude hook-set SHA-256')
        pw.add_argument('--hook-set-generation', help='generation from wake-hookset-show')
        pw.add_argument('--hook-interface-version', type=int, help='v2 hook-set client interface version')
        pw.add_argument('--hook-interface-digest', help='v2 client interface descriptor digest')
        pw.add_argument('--grounding-generation', help='store grounding generation observed by the product SessionStart hook')
        pw.add_argument('--session-start-source', choices=['startup','resume'])
        pw.add_argument('--hook-home', help='canonical registered home; qualified Claude declarations only')
        pw.add_argument('--previous-generation', help='current route generation, or none for a first declaration')
    if available('inapp_hookset'):
        ph = ps.add_parser('wake-hookset-record', help='current provisioner: record a pinned Claude hook set')
        ph.add_argument('seat')
        ph.add_argument('--record-file', required=True, help='absolute path to bounded JSON qualification specification')
        ph.add_argument('--expected-generation', required=True, help='current provisioning generation, or none')
        ph = ps.add_parser('wake-hookset-show', help='read your own qualification record and current route generation')
        ph.add_argument('seat')
        ph = ps.add_parser('wake-hook-interface-policy', help='current provisioner: receipt the previous-version migration window')
        ph.add_argument('--previous', choices=['until-cleared', 'disabled'], required=True)
        ph.add_argument('--expires-at', help='optional timezone-qualified expiry for previous-version acceptance')
        ph.add_argument('--expected-generation', required=True, help='current policy generation from wake-hook-interface-show, or none')
        ph.add_argument('--reason', required=True)
        ps.add_parser('wake-hook-interface-show', help='authenticated read of deployed client interface and migration policy')
    if private_routes:
        pc = ps.add_parser("wake-clear", help="clear your own wake route")
        pc.add_argument("seat")
    pc = ps.add_parser("help-clear", help="CoS/human: clear a seat help signal without removing its file")
    pc.add_argument("seat")
    if 'codex-ipc' in private_routes:
        pr = ps.add_parser("wake-revive", help="CoS/human: clear a legacy Codex route death by receipt; proven refusals require own-seat re-declaration")
        pr.add_argument("seat")
        pr.add_argument("--reason", required=True, help="recorded operational reason, one line (maximum 500 characters)")
        pr.add_argument("--generation", help="refuse if the current route generation differs")
    p = sub.add_parser("store", help="active-store binding: candidates (measure) / register (bind)")
    ps = p.add_subparsers(dest="store_cmd", required=True)
    pc = ps.add_parser("candidates",
                       help="measure every known candidate store side by side; chooses none")
    pc.add_argument("paths", nargs="*", help="extra store directories to measure")
    pc.add_argument("--scan", action="append", default=[], metavar="DIR",
                    help="also measure every directory under DIR that holds a log.jsonl")
    pc.add_argument("--json", action="store_true")
    pr = ps.add_parser("register",
                       help=f"bind ONE store: write ~/{product_profile.home_directory}/active_store + a ledger receipt")
    pr.add_argument("path", help="absolute path of an existing store directory (has log.jsonl)")
    pr.add_argument("--json", action="store_true")
    p = sub.add_parser("registry", help="explicit registry maintenance")
    registry = p.add_subparsers(dest="registry_cmd", required=True)
    registry.add_parser("roles", help="read stored role, role_source and state for every participant")
    setting_role = registry.add_parser("set-role", help="assign an explicit role; never revokes tokens")
    setting_role.add_argument("seat")
    setting_role.add_argument("role", choices=sorted(store.PARTICIPANT_ROLES))
    setting_role.add_argument("--approved-by-principal", metavar="RECORD_ID",
                             help="CoS-landed principal approval; required for old or new privileged roles")
    setting_role.add_argument("--approved-by-principal-sha256", metavar="SHA256",
                             help="verified content hash of that approval record (required with its id)")
    retiring = registry.add_parser("retire", help="retire a seat without deleting its identity (revoke tokens first)")
    retiring.add_argument("seat")
    parking = registry.add_parser("park", help="pause a seat after revoking its tokens")
    parking.add_argument("seat")
    unparking = registry.add_parser("unpark", help="resume a parked identity; fresh invite is separate")
    unparking.add_argument("seat")
    unparking.add_argument("--channel", choices=["pull", "tmux"])
    registry.add_parser("parked", help="list parked identities and attribution")
    registry.add_parser("retired", help="list permanently retired identities and attribution")
    normalise = registry.add_parser("normalise-roles", help="plan legacy roles; apply only a reviewed digest")
    normalise.add_argument("--apply", action="store_true")
    normalise.add_argument("--plan-sha256", help="digest returned by the current plan")
    normalise.add_argument("--approved-by-principal", metavar="RECORD_ID",
                           help="CoS-landed register record of the principal's approval for human rows")
    normalise.add_argument("--approved-by-principal-sha256", metavar="SHA256",
                           help="verified content hash of that approval record (required with its id)")
    p = sub.add_parser("invite", help=product_identity.diagnostic(
        "CoS: issue a seat token invite → <seat home>/.orch/invite (0600)",
        "CoS: issue a seat credential invite"))
    p.add_argument("seat", help="registered participant id the token will identify")
    p.add_argument("--kind", choices=["seat"], default="seat")
    p.add_argument("--role", default=None,
                   help="token role; must equal the seat's registry role (`daemon` for the system row)")
    p.add_argument("--seat-home", default=None, metavar="DIR",
                   help="the seat's workspace (default ~/agents/<seat>)")
    p.add_argument("--ttl", type=int, default=store.INVITE_TTL_SEC, help="invite lifetime, seconds")
    p.add_argument("--bootstrap", action="store_true",
                   help="issue the FIRST token of a store on an asserted --as identity "
                        "(refused once any seat token exists)")
    p = sub.add_parser("token", help="seat token: claim / status / revoke (the value is never printed)")
    pt = p.add_subparsers(dest="token_cmd", required=True)
    migration = pt.add_parser("migrate-surfaces", help="local legacy-session migration: dry run first; never automatic")
    migration.add_argument("--apply", action="store_true")
    migration.add_argument("--plan-sha256", help="digest returned by the current dry run")
    pc = pt.add_parser("claim", help="seat: redeem <seat home>/.orch/invite → <seat home>/.orch/token (0600)")
    pc.add_argument("seat")
    pc.add_argument("--seat-home", default=None, metavar="DIR")
    pc.add_argument("--invite-file", default=None, metavar="PATH", help="read the invite from this file")
    pc.add_argument("--invite-stdin", action="store_true",
                    help="read the invite from stdin (never argv: argv lands in pane.log)")
    ppl = pt.add_parser("place", help="seat: locked repair after a claim that committed but was not placed — "
                                        "places the staged file only if its session is still the seat's live one")
    ppl.add_argument("seat")
    ppl.add_argument("--seat-home", default=None, metavar="DIR")
    pst = pt.add_parser("status", help="validity of the token in hand, or a seat's token records (ids/states only)")
    pst.add_argument("seat", nargs="?")
    pst.add_argument("--json", action="store_true")
    prv = pt.add_parser("revoke", help="CoS: revoke every live token of a seat (retirement)")
    prv.add_argument("seat")
    p = sub.add_parser("login", help="principal: sign in with your password at this terminal (no echo)")
    p.add_argument("principal", nargs="?", help="the identity to sign in (default: the one principal)")
    p.add_argument("--seat-home", default=None, metavar="DIR")
    # Channels the product refuses by name (D-CRED-3): accepted only to be refused.
    p.add_argument("--password", default=None, help=argparse.SUPPRESS)
    p.add_argument("--password-file", default=None, help=argparse.SUPPRESS)
    p.add_argument("--password-stdin", action="store_true", help=argparse.SUPPRESS)
    p = sub.add_parser("principal", help="principal: credential acts (password measure, password set, recover)")
    pp = p.add_subparsers(dest="principal_cmd", required=True)
    ppw = pp.add_parser("password", help="the principal password")
    ppws = ppw.add_subparsers(dest="password_cmd", required=True)
    ppws.add_parser("measure", help="deployment frame: measure the pw1 profile on this host; refused under 250 ms")
    for parent, name, text in (
            (ppws, "set", "set or change the password, with this identity's live session (no echo)"),
            (pp, "recover", "the store's filesystem owner sets a new password for the principal (no echo)")):
        q = parent.add_parser(name, help=text)
        q.add_argument("principal", nargs="?", help="the identity (default: the one principal)")
        q.add_argument("--resume", default=None, metavar="OPERATION_ID",
                       help="finish an incomplete operation; needs no session and no password")
        # Channels the product refuses by name (D-CRED-3): accepted only to be refused.
        q.add_argument("--password", default=None, help=argparse.SUPPRESS)
        q.add_argument("--password-file", default=None, help=argparse.SUPPRESS)
        q.add_argument("--password-stdin", action="store_true", help=argparse.SUPPRESS)
    sub.add_parser("install", help=f"symlink {product_profile.command()} into ~/.local/bin")
    p = sub.add_parser("provision", help="run the provisioning manifest (installer setup step)")
    p.add_argument("--spine-only", action="store_true",
                   help="accept not-yet-wired (PENDING) steps as OK (alpha spine install)")
    p.add_argument("--only", help="run just this manifest step id")
    p.add_argument("--dry-run", action="store_true", help="print what each step would do")

    from provision.run import add_machine_arguments
    add_machine_arguments(p)

    p = sub.add_parser("obligations", help=product_identity.diagnostic(
                      "the obligations journal (inert unless ORCH_OBLIGATIONS_ENABLED=1); ",
                      "the obligations journal (when enabled by the installation); ") +
                                           "the credential by its path only")
    obligations_cmds = p.add_subparsers(dest="obligations_cmd", required=True)
    pa = obligations_cmds.add_parser("append", help="Chief of Staff: admit one event from a file; prints the "
                                                    "stored event or the refusal")
    pa.add_argument("file", metavar="PATH", help="one JSON object: the event, without ts and actor")
    obligations_cmds.add_parser("show", help="Chief of Staff or principal: the replay, with edges and derived states")
    obligations_cmds.add_parser("repair-tail", help="Chief of Staff or principal: remove a torn tail (the bytes "
                                                    "after the last newline) with a receipt; never a complete line")
    p = sub.add_parser("digest", help="read-only usage and delivery digest")
    p.add_argument("--out", help="new output file (0600); default: store/run/digest-<time>.json")

    p = sub.add_parser("usage", help="submit an account usage report; never query an account")
    usage = p.add_subparsers(dest="usage_cmd", required=True)
    report = usage.add_parser("report", help="qualified operator: submit one whole report file")
    report.add_argument("--file", required=True, metavar="PATH")
    report.add_argument("--submission-key", help="reuse exactly this key when retrying this report")
    if available('account_usage_codex'):
        codex = usage.add_parser("codex", help="reduce and submit an operator-saved desktop usage JSON result")
        codex.add_argument("--file", required=True, metavar="PATH")
        codex.add_argument("--submission-key", required=True)
    binding = usage.add_parser("binding", help="Chief of Staff: designate, authorize, bind or revoke a reporter")
    actions = binding.add_subparsers(dest="binding_cmd", required=True)
    operator = actions.add_parser("operator")
    operator.add_argument("--reporter", required=True)
    operator.add_argument("--account-ref", required=True)
    operator.add_argument("--authority-ref", required=True)
    authorize = actions.add_parser("authorize-seat")
    authorize.add_argument("--reporter", required=True)
    authorize.add_argument("--authority-ref", required=True)
    seat = actions.add_parser("seat")
    seat.add_argument("--reporter", required=True)
    seat.add_argument("--authorization-id", required=True)
    revoke = actions.add_parser("revoke")
    revoke.add_argument("--reporter", required=True)
    retention = usage.add_parser("retention", help="operator: plan or explicitly archive and compact history")
    retain = retention.add_subparsers(dest="retention_cmd", required=True)
    retain.add_parser("plan")
    apply = retain.add_parser("apply")
    apply.add_argument("--plan", required=True, metavar="PATH")
    apply.add_argument("--archive", required=True, metavar="PATH")

    args, extra = parser.parse_known_args()
    if args.command == "wait":
        # This path owns authentication: the generic binder creates lock files
        # and a successful generic dispatch appends activity. Neither is a wait.
        if extra:
            print("wait: error invalid_arguments")
            return 2
        from orch_wait import run
        return run(args)
    if extra:
        parser.error("unrecognized arguments: " + " ".join(extra))
    if args.command in {"login", "principal"}:
        try:
            stage1_features.require_private("principal_credentials")
        except stage1_features.NotOffered as exc:
            print(str(exc), file=sys.stderr)
            return 2
    if args.command == "digest":
        from usage_digest import run
        return run(args.out)
    if args.command == "send":
        try:
            send_tokens, args.body_file = _extract_send_body_file(args.send_tokens)
            args.to, args.to_option, args.text, args.envelope = _parse_send_envelope(send_tokens)
            if args.body_file is not None and args.text:
                raise ValueError("cannot combine --body-file with a positional body")
        except ValueError as exc:
            parser.error(str(exc))
    # Identity. Read-only/local views take --as, else $ORCH_AGENT, else the operator. Hub-acting
    # commands DERIVE identity from the seat token (Phase A A.4; ORCH_SPEC_01 D-IDT-1) in
    # _bind_hub_identity, and --as / $ORCH_AGENT are inert for them. NEVER default to the operator
    # for a hub-acting command — the gap that let an agent's send execute AS the operator
    # (reviewer/reviewer HIGH) is closed at its root: no assertion identifies a sender.
    args.asserted = args.identity or os.environ.get("ORCH_AGENT")
    args.identity = args.asserted
    args.token_bound = False
    args.auth = "asserted"
    if args.command == "store" and args.store_cmd == "register" and not args.identity:
        instruction = product_identity.diagnostic('pass --as NAME or set ORCH_AGENT', 'pass --as NAME')
        print(f"{RED}refusing to register a store without an identity — {instruction}. "
              f"(The receipt names the registrant.){RESET}", file=sys.stderr)
        return 2
    # Phase 0 W0.1 (ORCH_SPEC_01 D-STO-1): every store-touching command fails fast when no
    # store is bound — ONE diagnostic on stderr, exit STORE_UNBOUND_EXIT, nothing written.
    # Only the binding act itself, the installer, and provisioning legitimately run
    # unbound. The sentinel STORE_DIR makes any path that slips past this refuse at its
    # first store touch, caught below by the same handler. The store check comes FIRST:
    # a token lives in the store, so an unbound process has no token to present.
    STORE_FREE = {"store", "install", "provision", "up", "setup"}
    try:
        if args.command == "doctor":
            try:
                store.require_bound_store()
            except store.StoreUnbound:
                # Before any store exists, the version and the prerequisites are still worth
                # showing (B1); the unbound diagnostic and its exit code follow unchanged.
                import product
                print(product.version_line())
                _doctor_prerequisites()
                raise
        if args.command not in STORE_FREE:
            store.require_bound_store()
        if _is_hub_acting(args):
            rc = _bind_hub_identity(args)
            if rc:
                return rc
        elif not args.command:
            found = store.find_presented_token(args.token_file)
            rec = store.token_verdict(found["token"])[0] if found["token"] else None
            if rec is not None:
                args.identity, args.token_bound = rec["participant_id"], True
            return interactive(args.identity or store.operator_identity(), args.token_bound,
                               found["token"] if rec is not None else None)
        elif not args.identity:
            args.identity = store.OWNER  # local commands do not need a registered inbox
        result = _dispatch(args)
        # Lifecycle acts own their singular receipts, including recovery retries.
        if (result == 0 and args.token_bound and args.command not in {'recall', 'focus', 'usage', 'seat-event', 'hook-fetch', 'agy-hook-fetch', 'agy-hook-emitted', 'agy-read', 'agy-ack', 'await'}
                and not (args.command == 'seat' and args.seat_cmd in {'wake-hookset-show', 'wake-hook-interface-policy', 'wake-hook-interface-show'})
                and not (args.command == 'registry' and args.registry_cmd in {'retire', 'park', 'unpark', 'set-role'})):
            import receipts
            def record_act(actor):
                if getattr(args, 'harness', None) is not None:
                    import harness_facts
                    harness_facts.append_act(actor, args.command, args.harness)
                    return
                with receipts._nudge_lock():
                    receipts._append({'kind': 'seat-act', 'seat': actor, 'command': args.command,
                                      'ts': store.now_iso()})
            try:
                store.authenticated_registry_act(args.presented_token, record_act, expected_actor=args.identity)
            except Exception as exc:
                _journal_inapp_completion_failure(args, exc)
                print('command completed; seat activity receipt unavailable', file=sys.stderr)
        return result
    except (store.StoreUnbound, store.LegacyRoleNormalisationIncomplete, store.OperatorIdentityError) as exc:
        print(str(exc), file=sys.stderr)
        return exc.exit_code


def _dispatch(args) -> int:
    handlers = {
        "message-file": cmd_message_file,
        "usage": cmd_usage, "status": cmd_status, "panel": cmd_panel, "inbox": cmd_inbox,
        "seat-event": cmd_seat_event, "hook-fetch": cmd_hook_fetch,
        'agy-hook-fetch':cmd_agy_hook_fetch,'agy-hook-emitted':cmd_agy_hook_emitted,
        'agy-read':cmd_agy_read,'agy-ack':cmd_agy_read,'agy-sidecar':cmd_agy_sidecar,
        "recall": cmd_recall, "focus": cmd_focus, "mail": cmd_mail, "await": cmd_await,
        "login": cmd_login, "principal": cmd_principal,
        "send": cmd_send, "broadcast": cmd_broadcast, "interrupt": cmd_interrupt,
        "log": cmd_log,
        "assign": cmd_assign, "tasks": cmd_tasks, "reviews": cmd_reviews, "raise": cmd_raise,
        "lower": cmd_lower, "join": cmd_join, "up": cmd_up, "setup": cmd_setup, "down": cmd_down,
        "shutdown": cmd_shutdown,
        "doctor": cmd_doctor, "migrate": cmd_migrate,
        "rooms": cmd_rooms,
        "quarantine": cmd_quarantine,
        "room": cmd_room, "serve": cmd_serve,
        "attach": cmd_attach, "seat": cmd_seat,
        "install": cmd_install, "provision": cmd_provision,
        "store": cmd_store, "registry": cmd_registry, "invite": cmd_invite, "token": cmd_token,
        "obligations": cmd_obligations,
    }
    try:
        return handlers[args.command](args)
    except stage1_features.NotOffered as exc:
        print(str(exc), file=sys.stderr)
        return 2
    except (store.UnreadMailRefused, store.UnreadStateBusy) as exc:
        print("error: " + json.dumps(exc.detail, sort_keys=True), file=sys.stderr)
        return 1
    except store.RegistryMutationRefused as exc:
        return _refuse_identity(args.command, exc.reason, str(exc))


if __name__ == "__main__":
    raise SystemExit(main())
