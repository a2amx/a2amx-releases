"""Vendor-neutral durable receipt helpers shared by native dispatchers.

Callers retain their existing authenticated act and journal-lock boundaries.
No vendor transport or adapter is imported or activated by these functions.
"""
from __future__ import annotations

import receipts


def _rows():
    """Compatibility seam for the shared strict receipt reader."""
    return receipts.strict_rows()



def _append(row):
    """Compatibility seam for append plus directory durability."""
    return receipts.append_durable(row)



def _delivery(rows, seat):
    committed = {r.get("txn-id") for r in rows if r.get("kind") == "delivery-transaction"
                 and r.get("phase") == "commit"}
    committed -= {r.get("txn-id") for r in rows if r.get("kind") == "delivery-transaction"
                  and r.get("phase") == "abort"}
    import recall
    recalled = recall.graph(rows)
    states = {}
    for r in rows:
        # A committed fetch is durable before materialization. Reconstruct it
        # directly after a crash; dispatch must not resurrect the fetched set.
        if (r.get("kind") == "delivery-transaction" and r.get("phase") == "prepare"
                and r.get("event") == "FETCHED" and r.get("seat") == seat
                and r.get("txn-id") in committed):
            for mid in r.get("msg-ids", []):
                states[mid] = "FETCHED"
        if r.get("kind") != "delivery" or r.get("seat") != seat:
            continue
        if r.get("txn-id") is not None and r.get("txn-id") not in committed:
            continue
        if isinstance(r.get("msg-id"), str):
            if (r.get("adapter") in {"inapp-socket", "codex-ipc", "agy-desktop"} and r.get("event") == "POKED"
                    and states.get(r["msg-id"]) == "FETCHED"):
                continue
            states[r["msg-id"]] = r.get("event")
    return [mid for mid, event in states.items() if event in {"QUEUED", "POKED"} and mid not in recalled], \
        {mid for mid, event in states.items() if event == "FETCHED"}
