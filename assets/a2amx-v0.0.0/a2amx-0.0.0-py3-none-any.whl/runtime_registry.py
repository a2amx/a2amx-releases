"""G1.1 runtime-ownership core — Layer 1 of the ADOPTED converged design
(docs/G1_RUNTIME_OWNERSHIP_DESIGN.md, the operator Z 2026-07-13). PR-1 of three:
ownership schema + store + CAS/recovery, provable with a FAKE adapter — no
vendor commands live here, ever (that is Layer 2, PR-2).

Launch protocol (design §3, r13): the launcher (1) emits a DURABLE prelaunch
intent (:func:`emit_claim_intent` → IntentContext) BEFORE any process; (2)
spawns the supervisor, which mints READY and BLOCKS for GO with its OWN pre-CAS
deadline (a launcher that dies after READY must never leave a wedged supervisor
holding the flock); (3) :func:`attach_supervisor` reads READY over the private
pipe; (4) :func:`claim` CASes STARTING and CONSUMES the intent exactly once;
(5) :func:`send_go` — bound to this capability + a live STARTING row, one-shot —
releases the supervisor to spawn the vendor child. A refusal at any step +
:func:`abort_supervisor`/:func:`abort_intent` leaves zero vendor process.

Authority model (r9/r10/r13, reviewer):
- **OwnerContext** — human lifecycle operations. Minted ONLY by
  :func:`verify_owner` (a module-private sentinel makes direct construction
  raise); today verify_owner enforces the operator/UI label rule, and PR-2's
  authenticated UI-server route (adopted Q4) becomes its only caller.
- **IntentContext** — the nonforgeable prelaunch intent (minted by
  :func:`emit_claim_intent`, backed by a durable OPEN intent row); claim
  consumes it exactly once so a claim cannot skip, forge, or reuse an intent.
- **SupervisorHandle** — the LAUNCHER-BOUND supervisor identity (r10,
  reviewer CRIT#2): the launcher spawns the supervisor itself and calls
  :func:`attach_supervisor` on its OWN Popen; the handle carries the READY
  the child wrote to its private stdout pipe, and attach refuses if the
  READY's pid is not the launcher's actual child. A lock-holder X can copy a
  victim's pid/birth into the lock file, but it cannot speak on the private
  pipe of a child it didn't spawn — claim requires pipe-READY == lock
  attestation, exactly.
- **SupervisorContext** — the attempt-scoped capability returned by claim();
  its secret token (hashed into the lease) gates every attempt advance.

Liveness is IDENTITY, not pid: every supervisor/child check compares the
OS-reported process birth (ps lstart) and the REAL host boot id (sysctl
kern.boottime) against the recorded ones. Clearing ownership (finalize,
finish_stop, sweep) additionally requires the recorded VENDOR CHILD dead and
its predeclared RESOURCE torn down (r10, reviewer CRIT#1) — a supervisor
crash that frees the flock while its child survives never yields the seat.
Failure is TWO-PHASE: FAILED retains the teardown identity until a finalize
proves child-dead + resource-gone + holder-gone.
"""
from __future__ import annotations

import fcntl
import hashlib
import hmac
import json
import math
import os
import re
import secrets
import subprocess
import sys
import time
import types
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import ledger
import runtime_host_control as rhc
import store
import tmux_bridge
from harness.sdk_versions import (CLAUDE_AGENT_SDK_VERSION,
                                  GOOGLE_ANTIGRAVITY_SDK_VERSION,
                                  OPENAI_CODEX_SDK_VERSION)

RUNTIME_FILE = store.STORE_DIR / "roster_runtime.json"
RUNTIME_LOCK = store.STORE_DIR / ".roster_runtime.lock"      # registry-WRITE lock
SEAT_LOCK_DIR = store.STORE_DIR / "runtime_locks"            # per-seat LIFETIME locks
LEGACY_SEED = store.STORE_DIR / "roster_runtime.seed.json"   # Operator's capture, preserved
CREDENTIAL_CATALOG_FILE = store.STORE_DIR / "runtime_credentials.json"
ARMING_GRANT_FILE = store.STORE_DIR / "runtime_arming_grants.json"

SYNTHETIC_GRANT_SCHEMA = 1
SYNTHETIC_GRANT_KIND = "synthetic_phase3_fixture"
SYNTHETIC_GRANT_AUTHORITY = "synthetic-fixture-no-authority"
SYNTHETIC_GRANT_SCOPE = "deny-only"
SYNTHETIC_GRANT_MAX_TTL_SEC = 60.0
ARMING_GRANT_MAX_BYTES = 8 * 1024 * 1024
_SYNTHETIC_GRANT_FIELDS = frozenset({
    "schema_version", "kind", "authority", "scope", "grant_id", "seat",
    "attempt_id", "launch_mode", "head", "manifest_sha256",
    "policy_sha256", "executable_sha256", "attempt_sha256", "boot_id",
    "issued_at_monotonic", "expires_at_monotonic",
})
_GRANT_BINDING_FIELDS = frozenset({
    "head", "manifest_sha256", "policy_sha256", "executable_sha256",
})
_GRANT_ID_RE = re.compile(r"^grt_[A-Za-z0-9_-]{16,96}$")
_CONSUMED_GRANT_FIELDS = frozenset({
    "grant_id", "seat", "attempt_id", "runtime_id", "generation", "boot_id",
    "operator", "consumed_at_monotonic", "grant_sha256", "bindings",
})

STATES = ("STARTING", "ACTIVE", "STOPPING", "STOPPED", "FAILED")
MANAGEMENTS = ("sdk", "tmux", "in_app")
EFFORTS = ("low", "medium", "high", "xhigh")
HANDLE_KINDS = ("session_uuid", "session_file", "rebirth_doc", "app_marker")
RESOURCE_KINDS = ("tmux_pane", "process_group", "session_dir")

#: PR-2b native-adapter architecture.  These are deliberately closed and live
#: in the registry authority: supervisor and launcher import ONE validator and
#: canonicalizer, so READY cannot attest one interpretation while claim stores
#: another.  The adapter-host path is dormant until its reviewed implementation
#: slice lands; the contracts are persisted now so that slice cannot invent an
#: unbound role, permission profile, resume handle, or transport after claim.
ATTEMPT_CONFIG_SCHEMA = 1
ATTEMPT_TRANSPORT = "adapter_host"
ADAPTER_FAMILIES = ("claude", "codex", "gemini")
LAUNCH_MODES = ("NEW", "RESUME")
PERMISSION_PROFILES = ("read_only", "workspace_write")
VENDOR_TRANSPORTS = ("claude_sdk", "codex_sdk", "gemini_antigravity")
ADAPTER_HOST_ARGV = (
    sys.executable,
    str(Path(__file__).resolve().parent / "scripts" / "run_sdk_agent.py"),
)
ADAPTER_PROTOCOLS = {
    "claude": {"transport": "claude_sdk",
               "version": f"claude-agent-sdk/{CLAUDE_AGENT_SDK_VERSION}",
               "argv": ADAPTER_HOST_ARGV},
    "codex": {"transport": "codex_sdk",
              "version": f"openai-codex/{OPENAI_CODEX_SDK_VERSION}",
              "argv": ADAPTER_HOST_ARGV},
    "gemini": {"transport": "gemini_antigravity",
               "version": f"google-antigravity/{GOOGLE_ANTIGRAVITY_SDK_VERSION}",
               "argv": ADAPTER_HOST_ARGV},
}
VENDOR_OBSERVED_SCHEMA = 1
VENDOR_OBSERVED_MAX_BYTES = 4096
HANDLE_ATTESTATION_SCHEMA = 2
HANDLE_ATTESTATION_MAX_BYTES = 4096
HANDLE_PROOF_KINDS = ("claude_sdk_session", "codex_sdk_thread",
                      "antigravity_session")
PARTICIPANT_LAUNCH_IDENTITY_SCHEMA = 1
CREDENTIAL_CATALOG_SCHEMA = 1
CREDENTIAL_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$")
CREDENTIAL_CATALOG_MAX_BYTES = 65536

_ATTEMPT_CONFIG_KEYS = frozenset({
    "schema_version", "seat", "management", "transport", "family",
    "vendor_transport", "protocol_version", "adapter_argv", "launch_mode",
    "participant_role", "permission_profile", "model", "effort", "work_dir",
    "store_dir", "participant_revision", "credential_id", "credential_ref",
    "resume_handle",
})
_VENDOR_OBSERVED_KEYS = frozenset({
    "schema_version", "type", "seat", "attempt_id", "runtime_id",
    "generation", "attempt_sha256", "vendor_pid", "proc_birth", "pgid",
    "resource", "transport_kind", "protocol_version", "auth_tag",
})
_HANDLE_ATTESTATION_KEYS_V1 = frozenset({
    "schema_version", "type", "seat", "attempt_id", "runtime_id",
    "generation", "attempt_sha256", "handle", "exclusive", "proof_kind",
    "proof_ref", "auth_tag",
})
_HANDLE_ATTESTATION_KEYS = _HANDLE_ATTESTATION_KEYS_V1 | {"assurance"}
_HANDLE_ASSURANCE_KEYS = frozenset({
    "source", "session_id_assurance", "independently_verified",
    "residual_gate", "residual",
})
_HANDLE_ASSURANCE_SOURCES = frozenset({
    "claude_sdk_host_observation", "codex_sdk_host_observation",
    "gemini_sdk_host_observation",
})
_HANDLE_INDEPENDENT_BASE = frozenset({
    "artifact_integrity", "attempt_binding", "process_topology",
})

#: Closed vocabularies for the broad ledger — never free-form text (r9 MED#8,
#: r10 MED#7): a reason for terminal receipts, a code for refusals.
FAIL_REASONS = ("verify_failed", "spawn_failed", "capture_ambiguous",
                "timeout", "operator_abort", "claim_refused", "stale_swept",
                "go_failed", "adapter_failed")
REFUSAL_CODES = ("bad_state", "unfinalized_failed", "no_desired_config",
                 "externally_managed", "lock_free", "attestation_mismatch",
                 "supervisor_identity", "boot_mismatch", "malformed_record",
                 "intent_missing", "go_state", "go_spent", "go_delivery",
                 "lock_held", "launch_config_mismatch", "handle_reserved",
                 "handle_family", "grant_absent", "grant_shape", "grant_kind",
                 "grant_scope", "grant_id", "grant_identity", "grant_binding",
                 "grant_expiry", "grant_replay", "sealed_env_unmet")

# reviewer A1-A12: the frozen architecture contract is data, not review prose.
# Live-vendor proofs named below remain OPEN until adapters arm; their schema,
# call-site wiring and fake/property checks are architecture-now.
RUNTIME_STRUCTURAL_CONTRACT = {
    "A1": "shared named soundness core and declarative state/action policy",
    "A2": "closed schema, state coherence, monotonic exact CAS lineage",
    "A3": "ownership capability, GO, boot, supervisor, heartbeat, lock/resource",
    "A4": "participant revision, privilege and workspace/store binding",
    "A5": "attempt transport/config digest and live credential catalog binding",
    "A6": "canonical all-field handle provenance and continuity family",
    "A7": "persisted session-file canonical target; no compare-time resolution",
    "A8": "observed child/resource and terminal escapee evidence",
    "A9": "promotion consumes the full live proof set under one fence",
    "A10": "all accepted-GO failures retain FAILED then tear down",
    "A11": "cross-process launch fence, fixed order, cleanup outside fence",
    "A12": "state-policy resume, exact readiness and continuity compatibility",
}

# Deferred runtime evidence is explicit rather than silently waived.  None of
# these names arms a vendor path; each remains a separately reviewable gate.
RUNTIME_OPEN_PROOFS = {
    "native_handle_attestation": "real vendor session/exclusivity semantics",
    "live_catalog_rotation": "credential rotation against a running vendor",
    "secure_open_session_file": "secure-open/revalidate persisted canonical target",
    "PR2B-ORPHAN-REAP": "real descendant discovery and escapee reaping",
    "runtime_e2e_matrix": "reboot/stop/resume/readiness/cost against real vendors",
}

RUNTIME_SOUNDNESS_FACTS = frozenset({
    "schema_state", "terminal_finalized", "terminal_escapees_clear",
    "live_open_intent", "management_authority", "claim_intent_binding",
    "participant_presence", "live_attempt_binding", "live_ownership",
    "active_handle", "observed_resource", "workspace_store",
    "vendor_identity", "handle_provenance", "resume_continuity",
})

# State policy controls doctor/resume projection. Action policy records which
# shared facts each mutation consumes; meta-tests require two-way registration.
# management_authority and claim_intent_binding are intentionally action-only:
# an in_app seat is healthy-but-external, and caller capability cannot be
# evaluated without a claim request.
RUNTIME_STATE_POLICIES = {
    "CLAIMABLE": frozenset({
        "schema_state", "terminal_finalized", "terminal_escapees_clear",
        "live_open_intent", "participant_presence", "handle_provenance",
        "resume_continuity",
    }),
    "STARTING": frozenset({
        "schema_state", "participant_presence", "live_attempt_binding",
        "live_ownership", "handle_provenance",
    }),
    "ACTIVE": frozenset({
        "schema_state", "participant_presence", "live_attempt_binding",
        "live_ownership", "active_handle", "observed_resource",
        "workspace_store", "vendor_identity", "handle_provenance",
    }),
    "STOPPING": frozenset({
        # STOPPING is intentionally not required to keep the child/vendor
        # live: normal teardown makes those facts false before finish_stop's
        # terminal proof can commit.  Ownership + provenance are the only
        # continuing liveness obligations in this state.
        "schema_state", "participant_presence", "live_ownership",
        "handle_provenance",
    }),
    "FAILED_DIRTY": frozenset({
        "schema_state", "terminal_finalized", "terminal_escapees_clear",
        "participant_presence", "handle_provenance",
    }),
}

RUNTIME_ACTION_POLICIES = {
    "emit_claim_intent": frozenset({
        "schema_state", "terminal_finalized", "terminal_escapees_clear",
        "live_open_intent",
    }),
    "claim": frozenset({
        "schema_state", "terminal_finalized", "terminal_escapees_clear",
        "management_authority", "claim_intent_binding", "participant_presence",
        "live_attempt_binding", "handle_provenance", "resume_continuity",
        "live_ownership",
    }),
    "verify_capability": frozenset({
        "schema_state", "participant_presence", "live_attempt_binding",
        "live_ownership",
    }),
    "promote": frozenset({
        "schema_state", "participant_presence", "live_attempt_binding",
        "live_ownership", "active_handle", "observed_resource",
        "workspace_store", "vendor_identity", "handle_provenance",
    }),
    "finish_stop": frozenset({
        "schema_state", "live_ownership", "observed_resource",
        "terminal_escapees_clear",
    }),
    "finalize_failed": frozenset({
        "schema_state", "live_ownership", "observed_resource",
        "terminal_escapees_clear",
    }),
}

# Inputs whose absence would make a registered action fact vacuously pass.
# The core fails closed on these omissions, so a caller cannot silently turn a
# policy requirement off by conditionally passing None (Bugbot 3609489573).
RUNTIME_ACTION_FACT_INPUTS = {
    "participant_presence": "participants",
    "handle_provenance": "seats",
}


def _soundness_action(name: str):
    """Attach one action to its declarative soundness policy.

    This deliberately does not wrap the mutation (and therefore cannot alter
    capability/CAS behavior).  The two-way meta-test fails if an action is
    missing, misspelled, or registered against facts outside the shared core.
    """
    if name not in RUNTIME_ACTION_POLICIES:
        raise AssertionError(f"unknown runtime soundness action {name!r}")

    def decorate(fn):
        if fn.__name__ != name:
            raise AssertionError(
                f"runtime soundness action {name!r} decorates {fn.__name__!r}")
        fn.runtime_soundness_policy = RUNTIME_ACTION_POLICIES[name]
        return fn

    return decorate


_SOUNDNESS_ORDER = (
    "schema_state", "terminal_finalized", "terminal_escapees_clear",
    "live_open_intent", "management_authority", "claim_intent_binding",
    "participant_presence", "live_attempt_binding", "live_ownership",
    "active_handle", "observed_resource", "workspace_store",
    "vendor_identity", "handle_provenance", "resume_continuity",
)


def _require_action_soundness(
        action: str, facts: Dict[str, List[str]]) -> None:
    """Consume the same named fact result used by doctor/resume.

    Exact capability checks validate the caller before this call; commit-time
    CAS selectors may repeat the admitted row shape afterward. Final liveness
    observations are passed back through the core to close a race. The decision
    vocabulary itself lives only in ``runtime_soundness_core``.
    """
    policy = RUNTIME_ACTION_POLICIES[action]
    for name in _SOUNDNESS_ORDER:
        messages = facts[name] if name in policy else []
        if not messages:
            continue
        message = messages[0]
        if name == "live_attempt_binding" and "READY launch digest" in message:
            raise OwnershipConflict(message, code="launch_config_mismatch")
        if name in ("participant_presence", "live_attempt_binding",
                    "workspace_store", "vendor_identity"):
            raise ValidationError(message)
        code = {
            "schema_state": "bad_state",
            "terminal_finalized": "unfinalized_failed",
            "terminal_escapees_clear": "unfinalized_failed",
            "management_authority": "externally_managed",
            "claim_intent_binding": "intent_missing",
            "active_handle": "attestation_mismatch",
            "observed_resource": "supervisor_identity",
            "handle_provenance": "handle_reserved",
            "resume_continuity": "handle_family",
        }.get(name, "bad_state")
        if name == "live_ownership":
            if "accepted durable GO" in message or "capability does not match" in message:
                code = "go_state"
            elif "another boot" in message or "boot identity is unprobeable" in message:
                code = "boot_mismatch"
            elif "has not acquired the lifetime lock" in message:
                code = "lock_held"
            elif "lifetime lock not held" in message:
                code = "lock_free"
            elif "attestation drifts" in message:
                code = "attestation_mismatch"
            else:
                code = "supervisor_identity"
        raise OwnershipConflict(message, code=code)

#: durable prelaunch-intent lifecycle (r13 CRIT#1): OPEN → CONSUMED (by a
#: STARTING claim, exactly once) | ABORTED (launcher chose not to spawn) |
#: TIMED_OUT (swept — the launcher abandoned it before claim).
INTENT_STATES = ("OPEN", "CONSUMED", "ABORTED", "TIMED_OUT")
INTENT_CLOSED_STATES = ("ABORTED", "TIMED_OUT")

STALE_ATTEMPT_SEC = 300.0

#: a heartbeat may sit at most this far in the future before it reads as stale
#: (r30 Bugbot) — small enough to reject a corrupt/foreign future clock, large
#: enough to tolerate ordinary NTP jitter between set and compare on one host.
CLOCK_SKEW_GRACE_SEC = 5.0

#: the supervisor's declared pre-CAS go_deadline must be a FINITE positive number
#: below the stale-attempt horizon (r20 reviewer HIGH#1) — NaN/±Inf/zero/negative/
#: over-max are all rejected in both mint_ready and _validate_ready_shape so a
#: supervisor cannot declare an effectively nonexistent deadline (json.loads
#: parses NaN/Infinity by default, so this is reachable through the READY frame).
GO_DEADLINE_MAX_SEC = 120.0


def _valid_go_deadline(value: Any) -> bool:
    """A finite, positive, bounded go_deadline (0 < d <= GO_DEADLINE_MAX_SEC).
    Total: a huge JSON int (~10**309 is legal + frame-sized) raises OverflowError
    on float() — that must be a clean False, not an exception that escapes
    _validate_ready_shape past attach's kill+reap (r21 reviewer HIGH#1)."""
    import math
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    try:
        v = float(value)
    except (OverflowError, ValueError, TypeError):
        return False
    return math.isfinite(v) and 0.0 < v <= GO_DEADLINE_MAX_SEC

#: module-private mint sentinel: direct construction of the authority types
#: raises (r10, reviewer HIGH#4 — a publicly constructible dataclass is a type
#: check, not authorization). Python cannot make this airtight against a
#: caller reaching into module internals; the honest contract is explicit:
#: only verify_owner()/attach_supervisor()/claim() mint these, and PR-2's
#: authenticated route becomes the only legitimate front door.
_MINT = object()


class OwnershipConflict(RuntimeError):
    """A CAS precondition failed. `code` is from REFUSAL_CODES — the only part
    that ever reaches the broad ledger."""
    def __init__(self, msg: str, code: str = "bad_state"):
        super().__init__(msg)
        self.code = code if code in REFUSAL_CODES else "bad_state"


class ValidationError(ValueError):
    """A typed record failed schema validation — fail closed, write nothing."""


@dataclass(frozen=True)
class OwnerContext:
    operator: str
    _mark: Any = field(default=None, repr=False, compare=False)

    def __post_init__(self):
        if self._mark is not _MINT:
            raise PermissionError(
                "OwnerContext is minted only by verify_owner() — direct "
                "construction is not authorization")


class SupervisorHandle:
    """Launcher-bound supervisor identity: wraps the launcher's OWN Popen and
    the READY read from its private stdout pipe. Minted only by
    attach_supervisor().

    The attach-time endpoint (Popen) and READY are FROZEN into read-only
    properties (r14 CRIT: a mutable popen/ready could be swapped or transplanted
    after attach to deliver a bound GO to a DIFFERENT process). `ready` is a
    read-only mapping; `popen` has no setter. As with the _MINT sentinel this is
    an honest contract, not airtight against a caller reaching into slots."""
    __slots__ = ("_popen", "_ready", "_go_sent")

    def __init__(self, popen, ready: Dict[str, Any], mark: Any = None):
        if mark is not _MINT:
            raise PermissionError("SupervisorHandle is minted only by attach_supervisor()")
        self._popen = popen
        self._ready = types.MappingProxyType(dict(ready))   # frozen attach-time snapshot
        self._go_sent = False                 # r13 CRIT#2: GO is one-shot per handle

    @property
    def popen(self):
        return self._popen

    @property
    def ready(self) -> Dict[str, Any]:
        return self._ready


@dataclass(frozen=True)
class IntentContext:
    """The prelaunch intent capability (r13 CRIT#1). Minted only by
    emit_claim_intent(), backed by a DURABLE OPEN intent row on the seat.
    claim() consumes it exactly once, atomically with the STARTING commit —
    a bare attempt_id string proved nothing (a caller could skip intent,
    forge an id, or reuse a refused one)."""
    seat: str
    attempt_id: str
    operator: str
    intent_id: str
    _mark: Any = field(default=None, repr=False, compare=False)

    def __post_init__(self):
        if self._mark is not _MINT \
                or not isinstance(self.intent_id, str) \
                or re.fullmatch(r"int-[0-9a-f]{32}", self.intent_id) is None:
            raise PermissionError(
                "IntentContext is minted with a valid incarnation only by "
                "emit_claim_intent() — direct construction is not authorization")


@dataclass(frozen=True)
class SupervisorContext:
    seat: str
    attempt_id: str
    runtime_id: str
    generation: int
    token: str
    _mark: Any = field(default=None, repr=False, compare=False)

    def __post_init__(self):
        if self._mark is not _MINT:
            raise PermissionError(
                "SupervisorContext is minted only by claim() — direct "
                "construction is not authorization")


def verify_owner(auth_source: str, operator: str) -> OwnerContext:
    """The ONE place operator authority is established. Today: the operator/UI
    label rule (as approvals.decide); PR-2's authenticated UI-server route
    becomes the sole caller so the label is server-derived, never asserted."""
    if auth_source not in {"operator_token", "ui_token"}:
        raise PermissionError(
            f"runtime ownership mutations require an operator/UI terminal, not {auth_source!r}")
    if not isinstance(operator, str) or not operator:
        raise ValidationError("operator identity required")
    return OwnerContext(operator=operator, _mark=_MINT)


# --------------------------------------------------------------------------
# process/host identity — identity, never bare pid liveness
# --------------------------------------------------------------------------

#: pinned probe environment (r20 reviewer MED#3): `ps -o lstart=` renders the
#: birth string under the PROBING process's TZ/LC_TIME, while the recorded
#: string was rendered under the supervisor's env at READY/record time. A drift
#: (login shell vs launchd/cron, changed system TZ, LANG=de_DE vs C) would make
#: the SAME live pid render differently and read as "provably dead". Pinning
#: TZ=UTC + LC_ALL=C makes writer and prober deterministic by construction.
_PROBE_ENV = {**os.environ, "TZ": "UTC", "LC_ALL": "C", "LANG": "C"}


def _valid_pid(value: Any) -> Optional[int]:
    """A REAL pid or None. bool is rejected explicitly — isinstance(True, int)
    is True in Python; a boolean would validate as PID 1 (init)."""
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        return None
    return value


def os_proc_birth(pid: int) -> Optional[str]:
    """OS-reported process start time (anti PID-reuse). None if not running.
    Rendered under the pinned probe env so writer and prober agree (r20 MED#3)."""
    try:
        out = subprocess.run(["ps", "-o", "lstart=", "-p", str(pid)],
                             capture_output=True, text=True, timeout=5, env=_PROBE_ENV)
        birth = out.stdout.strip()
        return " ".join(birth.split()) if birth else None
    except Exception:
        return None


def host_boot_id() -> Optional[str]:
    """A REAL, STABLE host boot identity (r10 MED#6; r12 MED#5 fail-closed; r20
    reviewer MED#4.1) — macOS ``kern.bootsessionuuid`` (a random UUID minted once
    per boot), Linux ``/proc/sys/kernel/random/boot_id``. Deliberately NOT
    ``kern.boottime``: that is clock-derived (≈ now − uptime) and can shift on
    clock adjustments / sleep-wake, spuriously tripping the boot gates. Returns
    None if NEITHER platform probe succeeds (no constant fallback — a constant
    would match across reboots); callers fail CLOSED on None. Each probe must
    exit 0 AND its output must UUID-parse (r20 reviewer MED#2 — a diagnostic or
    garbage constant must never be accepted as a per-boot identity nor suppress
    the fallback)."""
    import uuid

    def _as_uuid(s: Any) -> Optional[str]:
        if not isinstance(s, str) or not s.strip():
            return None
        try:
            u = uuid.UUID(s.strip())
        except ValueError:
            return None
        if u.int == 0:
            return None                       # r21 reviewer MED#2: the nil UUID is
            #                                   syntactically valid but cannot be a
            #                                   per-boot identity (matches across boots)
        return s.strip()

    try:
        out = subprocess.run(["sysctl", "-n", "kern.bootsessionuuid"],
                             capture_output=True, text=True, timeout=5, env=_PROBE_ENV)
        if out.returncode == 0:
            u = _as_uuid(out.stdout)
            if u is not None:
                return u
    except Exception:
        pass
    try:
        return _as_uuid(Path("/proc/sys/kernel/random/boot_id").read_text())
    except OSError:
        return None


def _proc_identity_ok(pid: Optional[int], birth: Any) -> bool:
    """Alive AND the same incarnation (pid + OS birth match). A ZOMBIE is
    dead: an unreaped child still shows its lstart in ps, so the state must
    be checked too or a killed vendor child would pass the identity probe."""
    if pid is None or not isinstance(birth, str) or not birth:
        return False
    try:
        out = subprocess.run(["ps", "-o", "stat=,lstart=", "-p", str(pid)],
                             capture_output=True, text=True, timeout=5, env=_PROBE_ENV)
        line = out.stdout.strip()
        if not line:
            return False
        stat, _, seen_birth = line.partition(" ")
        if stat.startswith("Z"):
            return False
        return " ".join(seen_birth.split()) == " ".join(birth.split())
    except Exception:
        return False


def proc_identity_ok(pid: Optional[int], birth: Any) -> bool:
    """Public face of :func:`_proc_identity_ok` for the daemon-lock health predicate
    (ORCH_SPEC_01 D-STO-1, Phase 0 W0.3): the SAME incarnation test the runtime
    registry applies to supervisors, so ``orch status``/``doctor`` cannot drift to a
    weaker liveness notion than the registry's."""
    return _proc_identity_ok(pid, birth)


def _resource_gone(resource: Any) -> bool:
    """Resource-specific TEARDOWN proof (r10, reviewer CRIT#1). Fail closed:
    an unprovable resource is NOT gone."""
    if not isinstance(resource, dict):
        return False
    kind, value = resource.get("kind"), resource.get("value")
    if kind == "process_group":
        try:
            os.killpg(int(value), 0)
            return False                      # signalable ⇒ still alive
        except ProcessLookupError:
            return True
        except (ValueError, TypeError, PermissionError):
            return False                      # unprovable ⇒ not gone
    if kind == "tmux_pane":
        # r20 reviewer HIGH#2: Layer 1 CANNOT soundly probe a bare pane id. The
        # tag carries only `%N`, but `display-message` probes the DEFAULT server
        # — a pane on a non-default socket (`tmux -L …`, `TMUX_TMPDIR`) reads
        # "gone while alive" (unsafe clear), and pane ids reset per server
        # lifetime so a recycled `%5` reads "alive forever" (permanent wedge).
        # So tmux_pane is treated EXACTLY like session_dir here — never provable,
        # doctor-red — until a Layer-2 adapter supplies a server-scoped proof
        # (socket_path + server/pane-created identity + pane_id).
        return False
    if kind == "session_dir":
        # a session_dir carries NO process-teardown signal of its own — the
        # child's pid is the only liveness evidence, handled in _child_gone
        # (Bugbot r10 HIGH: returning True here let a birth-mismatched but
        # LIVE pid read as gone). Never assert gone from a passive directory.
        return False
    return False


def _kill0_state(pid: int) -> str:
    """A second, independent liveness primitive (r13 HIGH#3): signal-0 probe.
    ESRCH ⇒ 'dead' (no such process); EPERM ⇒ 'alive' (exists, not ours);
    any other error ⇒ 'unknown' (fail closed)."""
    try:
        os.kill(pid, 0)
        return "alive"
    except ProcessLookupError:
        return "dead"
    except PermissionError:
        return "alive"
    except Exception:
        return "unknown"


def _proc_state(pid: Optional[int], birth: Any) -> str:
    """TRI-STATE incarnation probe (r13 HIGH#4): 'alive' (this exact
    incarnation is running), 'dead' (the recorded incarnation is provably
    gone — pid unmapped, zombie, or the pid is now a DIFFERENT incarnation),
    or 'unknown' (the probe itself failed and we may not conclude anything).
    Callers of teardown must fail CLOSED on 'unknown' — never treat a probe
    error as death."""
    if pid is None:
        return "unknown"
    try:
        out = subprocess.run(["ps", "-o", "stat=,lstart=", "-p", str(pid)],
                             capture_output=True, text=True, timeout=5, env=_PROBE_ENV)
    except Exception:
        return "unknown"
    if out.returncode != 0 or not out.stdout.strip():
        # ps nonzero/empty is AMBIGUOUS — "pid not found" OR a ps/tool error
        # (r13 HIGH#3: never treat a probe failure as death). Cross-check with a
        # signal-0: ESRCH ⇒ provably dead; EPERM ⇒ alive (a live foreign proc);
        # anything else ⇒ unknown, fail closed.
        return _kill0_state(pid)
    line = out.stdout.strip()
    if not line:
        return "dead"
    stat, _, seen_birth = line.partition(" ")
    if stat.startswith("Z"):
        return "dead"                         # zombie: the process has exited
    if not isinstance(birth, str) or not birth:
        return "unknown"                      # can't compare incarnation
    if " ".join(seen_birth.split()) == " ".join(birth.split()):
        return "alive"                        # same incarnation, running
    return "dead"                             # pid reused: recorded incarnation gone


def _incarnation_gone(pid: Any, birth: Any) -> bool:
    """A PROVABLY-DEAD teardown gate for the supervisor incarnation (r15 Bugbot):
    True ONLY when the tri-state probe says 'dead'; 'alive' AND 'unknown' fail
    closed. `not _proc_identity_ok(...)` conflated a probe error with death and
    would let finalize/finish/sweep clear ownership on an UNPROVEN supervisor
    death — teardown must require proof, never absence of a positive probe."""
    return _proc_state(_valid_pid(pid), birth) == "dead"


def _child_gone(observed: Any, predeclared_resource: Any = None) -> bool:
    """The recorded vendor child AND its resource are gone. Two cases:

    (a) observation NEVER landed (crash between spawn and record_observed —
        r12 CRIT#2). observed is None, but a PREDECLARED resource was attested
        into the lease at claim, so we prove THAT resource gone. A
        process_group/tmux resource has a real teardown probe; a session_dir
        does not, so it stays unprovable → NOT gone → doctor-red.
    (b) observation landed. Gone requires BOTH the recorded child incarnation
        provably DEAD (tri-state; 'unknown' fails closed) AND the resource
        torn down (r13 HIGH#4: a group LEADER can die while descendants keep
        running in its group, so child death alone must not clear ownership).
        A session_dir has NO typed teardown proof in Layer 1 and no exception
        was adopted (r13 HIGH#5), so it stays unprovable → doctor-red until
        Layer 2 supplies one; every probeable kind requires child-dead + resource-gone.

    SCOPE (r20 reviewer HIGH#1): the process_group proof is sound only for
    processes that stay IN the recorded group. A descendant that ESCAPES the
    group — setsid()/start_new_session (daemonized helpers, MCP servers, job-
    controlling wrapper shells) — is invisible to killpg, so "child dead + group
    empty" can be true while escaped vendor work survives. r13 HIGH#4 closed the
    inverse (leader dies, group lives); group ESCAPE is unprovable from the pgid
    alone and is NOT covered here. The "never yields the seat while its child
    survives" guarantee is therefore honestly scoped to IN-GROUP processes; the
    PR-2 adapter contract owns escape detection (a descendant walk at stop time)
    before it may clear ownership. See docs/G1_RUNTIME_OWNERSHIP_DESIGN.md."""
    if observed is None:
        # crash-before-record: the predeclared resource is the only teardown
        # identity we have — require IT proven gone (session_dir ⇒ never)
        return _resource_gone(predeclared_resource)
    if not isinstance(observed, dict):
        return False                          # malformed ⇒ unprovable ⇒ not gone
    pid = _valid_pid(observed.get("child_pid"))
    if pid is None:
        return False                          # no probeable identity ⇒ fail closed
    if _proc_state(pid, observed.get("child_birth")) != "dead":
        return False                          # alive or unknown ⇒ not gone
    return _resource_gone(observed.get("resource"))   # AND resource torn down (session_dir ⇒ never)


def _resource_membership_ok(child_pid: int, resource: Dict[str, Any], *,
                            seat: str | None = None,
                            participants: Dict[str, Dict[str, Any]] | None = None) -> bool:
    """Prove the child PID is genuinely a MEMBER of its claimed resource (r13
    HIGH#5), not just that the caller echoed the predeclared tag. Layer 1 can
    verify process_group membership from the kernel (os.getpgid). A tmux pane
    is verified through process ancestry on the seat's exact registered private
    socket. A session_dir has no process-membership proof and remains refused."""
    if not isinstance(resource, dict):
        return False
    kind, value = resource.get("kind"), resource.get("value")
    if kind == "process_group":
        try:
            return os.getpgid(child_pid) == int(value)
        except (ProcessLookupError, ValueError, TypeError, OSError):
            return False
    if kind == "tmux_pane" and seat is not None and participants is not None:
        participant = participants.get(seat) or {}
        if resource.get("socket_path") != participant.get("tmux_socket"):
            return False
        expected_session = participant.get("tmux_session")
        if not isinstance(expected_session, str) or not expected_session:
            return False
        resolved = tmux_bridge.pane_identity_for_process(
            child_pid, seat=seat, participants=participants)
        if not resolved.ok:
            return False
        pane_id, session = resolved.stdout.split(":", 1)
        return pane_id == value and session == expected_session
    return False                              # session_dir (or incomplete tmux evidence)


def _validate_seat(seat: Any) -> str:
    # aligned with the participant registry's id rule (reviewer r9 MED#8)
    if not isinstance(seat, str) or not store.PARTICIPANT_ID_RE.match(seat or ""):
        raise ValidationError(f"invalid seat name {seat!r}")
    return seat


# --------------------------------------------------------------------------
# per-seat lifetime lock + launcher-bound supervisor handshake
# --------------------------------------------------------------------------

def seat_lock_path(seat: str) -> Path:
    _validate_seat(seat)
    SEAT_LOCK_DIR.mkdir(parents=True, exist_ok=True)
    return SEAT_LOCK_DIR / f"{seat}.lock"


def mint_ready(pid: int, proc_birth: str, resource: Dict[str, Any],
               *, go_deadline: float,
               attempt_sha256: Optional[str] = None) -> Dict[str, Any]:
    """The supervisor's nonce-bound READY (design §3 step 1) — minted BY the
    supervisor process about ITSELF while holding the flock, BEFORE it spawns
    any vendor child. It attests the PREDECLARED resource it will spawn into
    (r12 CRIT#1) so a crash/refusal between READY and the CAS-GO still has a
    bound teardown identity, and DECLARES the pre-CAS `go_deadline` it will
    honor (r20 reviewer MED#7a) so attach can refuse a supervisor that ships none
    — turning the launcher-death recovery convention into a checked invariant.
    boot_id from the host, fail-closed on None."""
    boot = host_boot_id()
    if boot is None:
        raise OwnershipConflict("host boot id unavailable — cannot mint READY",
                                code="boot_mismatch")
    if not _valid_go_deadline(go_deadline):
        raise ValidationError(
            f"mint_ready requires a finite go_deadline in (0, {GO_DEADLINE_MAX_SEC}] seconds")
    if attempt_sha256 is not None and not _valid_sha256(attempt_sha256):
        raise ValidationError("mint_ready attempt_sha256 must be null or SHA-256 hex")
    return {"pid": pid, "proc_birth": proc_birth, "boot_id": boot,
            "nonce": secrets.token_hex(16),
            "runtime_id": store.new_id("rt"), "lease_id": store.new_id("lse"),
            "resource": validate_resource(resource), "go_deadline": float(go_deadline),
            # Explicit null preserves the legacy fake-adapter drill while making
            # a native adapter's READY configuration binding unambiguous.
            "attempt_sha256": attempt_sha256}


def acquire_seat_lock(seat: str, *, ready: Optional[Dict[str, Any]] = None) -> Optional[int]:
    """Non-blocking acquire of the per-seat LIFETIME lock; the caller (the
    supervisor) keeps the fd open for the runtime's whole life and, when
    `ready` is given, ATTESTS it into the file it now holds."""
    fd = os.open(seat_lock_path(seat), os.O_RDWR | os.O_CREAT, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        os.close(fd)
        return None
    if ready is not None:
        blob = json.dumps(ready).encode()
        os.ftruncate(fd, 0)
        os.lseek(fd, 0, os.SEEK_SET)
        os.write(fd, blob)
        os.fsync(fd)
    return fd


def release_seat_lock(fd: int) -> None:
    try:
        fcntl.flock(fd, fcntl.LOCK_UN)
    finally:
        os.close(fd)


def probe_seat_lock_free(seat: str) -> bool:
    """Heldness derived by attempting the lock — never a stored field."""
    fd = acquire_seat_lock(seat)
    if fd is None:
        return False
    release_seat_lock(fd)
    return True


def read_lock_attestation(seat: str) -> Optional[Dict[str, Any]]:
    try:
        att = json.loads(seat_lock_path(seat).read_text(encoding="utf-8"))
        if not isinstance(att, dict) or _valid_pid(att.get("pid")) is None:
            return None
        for k in ("proc_birth", "boot_id", "nonce", "runtime_id", "lease_id"):
            if not isinstance(att.get(k), str) or not att[k]:
                return None
        try:
            validate_resource(att.get("resource"))   # the predeclared resource
        except ValidationError:
            return None
        if att.get("attempt_sha256") is not None \
                and not _valid_sha256(att.get("attempt_sha256")):
            return None
        return att
    except (OSError, ValueError):
        return None


ATTACH_TIMEOUT_SEC = 10.0


def _kill_reap(popen) -> None:
    """Deterministic teardown of a supervisor we will not use: terminate,
    then kill, then reap. The supervisor has NOT spawned a vendor child yet
    (it blocks for GO), so tearing it down here leaves zero vendor process."""
    try:
        popen.terminate()
    except Exception:
        pass
    try:
        popen.wait(timeout=3)
    except Exception:
        try:
            popen.kill()
            popen.wait(timeout=3)
        except Exception:
            pass


READY_MAX_BYTES = 65536


def _read_framed_line(fd: int, *, deadline_sec: float, max_bytes: int) -> Optional[bytes]:
    """Deadline-aware, size-bounded read of ONE '\\n'-terminated frame from a
    raw fd (r13 HIGH#6). select() only proves a byte is readable; a bare
    readline() can then block forever on a partial line with no newline, so we
    loop with a SHRINKING deadline and cap the buffer. Returns the frame
    without its newline, or None on timeout / EOF-before-newline / oversize.

    The supervisor protocol writes exactly READY '\\n' and then BLOCKS for GO
    (design §3 step 1), so at attach time the pipe holds only the READY frame —
    a frame carrying bytes past its newline is itself malformed and rejected."""
    import select
    import time
    end = time.monotonic() + deadline_sec
    buf = bytearray()
    while True:
        remaining = end - time.monotonic()
        if remaining <= 0:
            return None
        r, _, _ = select.select([fd], [], [], remaining)
        if not r:
            return None
        try:
            chunk = os.read(fd, 4096)
        except OSError:
            return None
        if not chunk:
            return None                       # EOF before a full frame
        buf.extend(chunk)
        nl = buf.find(b"\n")
        if nl != -1:
            if nl != len(buf) - 1:
                return None                   # over-read: bytes past the frame ⇒ malformed
            return bytes(buf[:nl])
        if len(buf) > max_bytes:
            return None                       # oversized, still no newline ⇒ refuse


def _validate_ready_shape(ready: Any) -> None:
    """The COMPLETE READY contract (r13 HIGH#6): every identity field the lease
    is built from must be present and typed in attach, not discovered missing
    at a later claim refusal."""
    if not isinstance(ready, dict):
        raise ValidationError("READY must be a JSON object")
    if _valid_pid(ready.get("pid")) is None:
        raise ValidationError("READY.pid must be a positive int")
    for k in ("proc_birth", "boot_id", "nonce", "runtime_id", "lease_id"):
        if not isinstance(ready.get(k), str) or not ready[k]:
            raise ValidationError(f"READY.{k} must be a non-empty string")
    # r20 reviewer MED#7a: a supervisor MUST declare the pre-CAS go_deadline it
    # honors — a Layer-2 adapter that forgets it would leave a live flock-holder
    # + STARTING row forever if the launcher dies between claim and GO. Making
    # it a required, positive READY field turns that convention into an invariant
    # attach can (and does) enforce.
    if not _valid_go_deadline(ready.get("go_deadline")):
        raise ValidationError(
            f"READY.go_deadline must be a finite number in (0, {GO_DEADLINE_MAX_SEC}] seconds "
            f"(NaN/±Inf/zero/negative/over-max rejected)")
    if ready.get("attempt_sha256") is not None \
            and not _valid_sha256(ready.get("attempt_sha256")):
        raise ValidationError("READY.attempt_sha256 must be null or SHA-256 hex")
    validate_resource(ready.get("resource"))  # raises ValidationError if bad


def attach_supervisor(popen, *, timeout: float = ATTACH_TIMEOUT_SEC) -> SupervisorHandle:
    """Bind the launcher's OWN spawned supervisor (r10 CRIT#2): read the READY
    frame from the child's private stdout pipe with a DEADLINE-BOUNDED,
    size-capped read (r13 HIGH#6 — select-then-readline could block forever on
    a partial line). READY must name the supervisor's own pid, carry the full
    identity shape, and attest a valid predeclared resource; a timeout,
    oversize, malformed line, wrong pid, or bad shape ⇒ kill+reap the
    supervisor and raise (it has not spawned a vendor child yet, so nothing
    leaks)."""
    raw = _read_framed_line(popen.stdout.fileno(),
                            deadline_sec=timeout, max_bytes=READY_MAX_BYTES)
    if raw is None:
        _kill_reap(popen)
        raise OwnershipConflict(
            "supervisor did not emit a complete READY frame within the bound",
            code="supervisor_identity")
    try:
        ready = json.loads(raw)
    except (TypeError, ValueError):
        _kill_reap(popen)
        raise ValidationError(f"supervisor did not speak a valid READY line: {raw!r}")
    try:
        _validate_ready_shape(ready)
    except ValidationError:
        _kill_reap(popen)
        raise ValidationError("READY is missing or malforms a required identity field")
    if _valid_pid(ready.get("pid")) != popen.pid:
        _kill_reap(popen)
        raise OwnershipConflict(
            f"READY names pid {ready.get('pid')!r} but the launcher's child is "
            f"{popen.pid} — a supervisor may only attest ITSELF",
            code="supervisor_identity")
    return SupervisorHandle(popen, ready, mark=_MINT)


def _claimable_terminal_soundness_issues(rec: Dict[str, Any]) -> Dict[str, str]:
    """Shared state-aware facts for any path that can select a new launch."""
    issues: Dict[str, str] = {}
    if rec.get("launch_state") == "FAILED" and rec.get("lease") is not None:
        issues["terminal_finalized"] = (
            "unfinalized FAILED (retained teardown identity — finalize)")
    if rec.get("escapees") is not None:
        issues["terminal_escapees_clear"] = (
            "claimable terminal row retains unfinalized escaped descendants")
    return issues


def _validated_attempt_id(value: Optional[str]) -> str:
    if value is None:
        return store.new_id("att")
    if not isinstance(value, str) \
            or re.fullmatch(r"att-[0-9a-f]{10}", value) is None:
        raise ValidationError("caller-bound attempt_id must match att-<10 lowercase hex>")
    return value


def _new_intent_id() -> str:
    """A durable 128-bit incarnation for one OPEN intent lifecycle."""
    return f"int-{secrets.token_hex(16)}"


@_soundness_action("emit_claim_intent")
def emit_claim_intent(seat: str, *, owner: OwnerContext,
                      attempt_id: Optional[str] = None) -> IntentContext:
    """§3 step 0 — the DURABLE prelaunch intent, persisted BEFORE the launcher
    spawns the supervisor (r13 CRIT#1: intent must precede any process AND be
    an enforced precondition, not a bare string). Writes an OPEN intent row on
    the seat and returns the nonforgeable IntentContext claim() consumes
    exactly once. Refuses if the seat is mid-lifecycle or already carries a
    live OPEN intent; a STALE OPEN intent (abandoned launcher) is timed out
    and superseded here so the seat is never wedged."""
    _require_owner(owner, "emit_claim_intent")
    _validate_seat(seat)
    attempt_id = _validated_attempt_id(attempt_id)
    intent_id = _new_intent_id()
    superseded: List[Dict[str, Any]] = []

    def _emit_intent():
        seats = _read_unlocked()
        # attempt_id is composite-scoped by seat in every authoritative
        # consumer. Per-seat state soundness below owns lifecycle exclusion;
        # durable grant replay/uniqueness is keyed independently by grant_id.
        # Do not reintroduce an all-seat bare-attempt collision scan here.
        rec = seats.setdefault(seat, _empty_record())
        state = rec.get("launch_state")
        # Same named fact result as claim and doctor/resume.
        _require_action_soundness(
            "emit_claim_intent",
            runtime_soundness_core(
                dict(rec, seat=seat), action="emit_claim_intent"))
        # Exact commit-time CAS selector.  The core owns the decision
        # vocabulary; this selector proves the row still has the shape that
        # action policy admitted under this same registry lock.
        if state not in (None, "STOPPED", "FAILED"):
            raise OwnershipConflict(
                f"seat {seat!r} is {state!r}; an intent needs none/STOPPED/FAILED",
                code="bad_state")
        prior = rec.get("intent")
        if isinstance(prior, dict) and prior.get("state") == "OPEN":
            # A live row was refused by the registered live_open_intent fact;
            # the only OPEN row reaching this point is stale and reclaimable.
            prior["state"] = "TIMED_OUT"      # abandoned launcher — reclaim it
            prior["updated"] = store.now_iso()
            if prior.get("attempt_id"):
                superseded.append({
                    "attempt_id": prior["attempt_id"],
                    "intent_id": prior.get("intent_id"),
                })
        rec["intent"] = {"attempt_id": attempt_id, "operator": owner.operator,
                         "intent_id": intent_id, "state": "OPEN",
                         "created": store.now_iso(),
                         "heartbeat": store.now_iso()}
        rec["updated"] = store.now_iso()
        _write_unlocked(seats)

    _locked(_emit_intent)
    # closure receipts of superseded rows are a best-effort mirror (the row is
    # already durably TIMED_OUT) — but the prelaunch intent receipt is the
    # adopted FAIL-CLOSED authorization/audit gate (design §3 + table): it is
    # written BEFORE any claim/spawn and a receipt failure ABORTS with no
    # capability. r15 reviewer HIGH#1: do NOT downgrade it to best-effort. To
    # avoid the wedge, on receipt failure atomically ABORT the exact OPEN row we
    # just wrote, return no capability, and re-raise.
    for old in superseded:
        _emit("runtime_intent_closed", owner.operator,
              {"seat": seat, "attempt_id": old["attempt_id"],
               **({"intent_id": old["intent_id"]}
                  if old.get("intent_id") else {}),
               "state": "TIMED_OUT"})
    try:
        ledger.emit("runtime_claim_intent", actor_id=owner.operator,
                    payload={"seat": seat, "attempt_id": attempt_id,
                             "intent_id": intent_id})
    except Exception:
        _locked(lambda: _abort_open_intent_row(
            seat, attempt_id, intent_id))          # un-wedge, fail closed
        # r28 Bugbot: ledger the ABORTED closure so the audit trail matches the
        # registry's terminal intent state (as operator abort_intent does). Best
        # effort — the durable ABORTED row is the source of truth; if the ledger
        # is down this mirror is simply absent, same as the failed open receipt.
        _emit("runtime_intent_closed", owner.operator,
              {"seat": seat, "attempt_id": attempt_id,
               "intent_id": intent_id, "state": "ABORTED"})
        raise
    return IntentContext(seat=seat, attempt_id=attempt_id,
                         operator=owner.operator, intent_id=intent_id,
                         _mark=_MINT)


def _abort_open_intent_row(
        seat: str, attempt_id: str, intent_id: str) -> None:
    """Roll back a just-written OPEN intent row when its fail-closed prelaunch
    receipt could not be persisted (r15 reviewer HIGH#1) — so the seat is not
    wedged, yet no capability is returned. Runs under the registry lock."""
    seats = _read_unlocked()
    rec = seats.get(seat)
    cur = (rec or {}).get("intent")
    if isinstance(cur, dict) and cur.get("attempt_id") == attempt_id \
            and cur.get("intent_id") == intent_id \
            and cur.get("state") == "OPEN":
        cur["state"] = "ABORTED"
        cur["updated"] = store.now_iso()
        rec["updated"] = store.now_iso()
        _write_unlocked(seats)


def abort_intent(seat: str, *, owner: OwnerContext, intent: IntentContext) -> None:
    """The launcher decided not to spawn (or aborted the supervisor): close the
    OPEN intent as ABORTED so it can never be consumed and the seat is free for
    a new intent. Idempotent on an already-closed intent."""
    _require_owner(owner, "abort_intent")
    # r21 Bugbot: bind the operator exactly as claim() does — a verified
    # OwnerContext must not ABORT (and mis-attribute the closure of) ANOTHER
    # launcher's OPEN intent it happens to hold the IntentContext for.
    if not isinstance(intent, IntentContext) or intent.seat != seat \
            or intent.operator != owner.operator:
        raise PermissionError(
            "abort_intent requires this seat's IntentContext minted by the SAME owner")

    def _abort():
        seats = _read_unlocked()
        rec = seats.get(seat)
        cur = (rec or {}).get("intent")
        if not isinstance(cur, dict) or cur.get("attempt_id") != intent.attempt_id \
                or cur.get("intent_id") != intent.intent_id \
                or cur.get("operator") != owner.operator:
            return False
        if cur.get("state") != "OPEN":
            return False                      # already CONSUMED/ABORTED/TIMED_OUT — no-op
        cur["state"] = "ABORTED"
        cur["updated"] = store.now_iso()
        rec["updated"] = store.now_iso()
        _write_unlocked(seats)
        return True

    # receipt EXACTLY once, only after a committed OPEN→ABORTED transition
    # (r13 Bugbot / reviewer r13 HIGH#4 — no spurious/duplicate close receipts)
    if _locked(_abort):
        _emit("runtime_intent_closed", owner.operator,
              {"seat": seat, "attempt_id": intent.attempt_id,
               "intent_id": intent.intent_id, "state": "ABORTED"})


def _ready_binds_lease(ready: Dict[str, Any], lease: Dict[str, Any]) -> bool:
    """The COMPLETE READY identity matches the lease this attempt was claimed
    under (r13 CRIT#2): a visible runtime_id is not enough — a second attached
    supervisor could copy it while carrying its OWN nonce. Every secret/identity
    field the lease was built from must match, so GO reaches only the exact
    supervisor that won the CAS."""
    return (_valid_pid(ready.get("pid")) == _valid_pid(lease.get("supervisor_pid"))
            and ready.get("proc_birth") == lease.get("proc_birth")
            and ready.get("boot_id") == lease.get("boot_id")
            and ready.get("nonce") == lease.get("nonce")
            and ready.get("lease_id") == lease.get("lease_id")
            and ready.get("runtime_id") == lease.get("runtime_id")
            and ready.get("attempt_sha256") == lease.get("attempt_sha256"))


def send_go(supervisor: SupervisorHandle, ctx: SupervisorContext) -> None:
    """After the STARTING CAS commits, tell the blocked supervisor to spawn its
    vendor child — nonce-bound so only OUR supervisor acts (r13 CRIT#2). GO is
    BOUND and one-shot: the FULL handle READY identity (pid/birth/boot/nonce/
    lease_id/runtime_id) must match the lease this attempt was claimed under,
    the seat must still be exactly STARTING under THIS capability (so a
    fail_attempt(ctx) before GO refuses), and a durable go_sent flag on the
    pending attempt makes GO fire at most once. Before this, no vendor child
    exists."""
    if not isinstance(supervisor, SupervisorHandle) or not isinstance(ctx, SupervisorContext):
        raise PermissionError("send_go needs the launcher's handle + the claim capability")
    if supervisor.ready.get("runtime_id") != ctx.runtime_id \
            or not supervisor.ready.get("nonce"):
        raise PermissionError(
            "send_go handle does not belong to this claim capability (runtime_id mismatch)")
    if supervisor._go_sent:
        raise OwnershipConflict("GO already sent on this supervisor handle", code="go_spent")

    def _mark_go():
        seats = _read_unlocked()
        rec = seats.get(ctx.seat)
        if not rec or rec.get("launch_state") != "STARTING" or not _sup_matches(ctx, rec):
            raise OwnershipConflict(
                f"seat {ctx.seat!r} is not STARTING under this capability — no GO",
                code="go_state")
        # the supplied handle must be the EXACT one the lease was minted from —
        # not merely one sharing the visible runtime_id (r13 CRIT#2)
        if not _ready_binds_lease(supervisor.ready, rec["lease"]) \
                or validate_resource(supervisor.ready.get("resource")) != rec["pending_attempt"].get("resource"):
            raise OwnershipConflict(
                f"seat {ctx.seat!r} GO handle does not bind the claimed lease identity",
                code="attestation_mismatch")
        # r14 CRIT: recheck the LIVE frozen endpoint immediately before the mark —
        # the attach-time Popen must still be running and still BE the pid its
        # READY attests (the endpoint is frozen, so it cannot have been swapped;
        # this also refuses a GO to an endpoint that has since exited)
        if supervisor.popen.poll() is not None \
                or _valid_pid(supervisor.popen.pid) != _valid_pid(supervisor.ready.get("pid")):
            raise OwnershipConflict(
                f"seat {ctx.seat!r} GO endpoint is not the live attested supervisor",
                code="supervisor_identity")
        pend = rec["pending_attempt"]
        if pend.get("go_sent"):
            raise OwnershipConflict(f"seat {ctx.seat!r} attempt already GO'd", code="go_spent")
        # r18: persist go_sent FIRST (durable authorization BEFORE any child can
        # exist), so any spawned child is trackable by record_observed.
        pend["go_sent"] = True
        rec["lease"]["heartbeat"] = store.now_iso()
        rec["updated"] = store.now_iso()
        _write_unlocked(seats)                # COMMIT go_sent (write 1)
        # r22 reviewer HIGH: deliver GO UNDER this SAME lock, atomically with the
        # STARTING guarantee — a concurrent fail_attempt cannot terminalize the
        # attempt between the mark and delivery and let a child spawn under a
        # FAILED row. The write is NON-BLOCKING (r21 Bugbot) so a pathologically
        # full pipe cannot pin the global registry flock (the supervisor is
        # select()ing on stdin, so a one-line GO is consumed immediately in
        # practice). A delivery failure moves the attempt to retained-identity
        # FAILED in this same section; if THAT write also fails, a typed compound
        # outcome preserves both errors and sweep_stale reclaims the row (reviewer
        # r21 MED#4). The caller never gets a raw I/O escape.
        # PR-2 S-A: the GO frame carries the CAPABILITY (the SupervisorContext
        # material claim() minted for this exact attempt) so the REAL supervisor
        # can persist observed/handle/promote itself (design §3 step 3 — the
        # PR-1 fake relayed via the launcher; production must not). It rides the
        # SAME committed sequence: bind-READY-to-lease, live-endpoint re-probe,
        # durable go_sent, then ONE non-blocking write under this lock — no
        # separate token channel to desync. lease_id is echoed so the supervisor
        # can cross-check the frame against its OWN minted READY before minting
        # (reconstitute_supervisor_context). Compact separators keep the frame
        # well under PIPE_BUF (512) so the single os.write stays atomic — the
        # non-blocking delivery below relies on all-or-nothing, and a partial
        # write is already a typed go_delivery failure, never a half-armed
        # supervisor.
        line = (json.dumps(
            {"go": supervisor.ready["nonce"],
             "lease_id": supervisor.ready["lease_id"],
             "ctx": {"seat": ctx.seat, "attempt_id": ctx.attempt_id,
                     "runtime_id": ctx.runtime_id, "generation": ctx.generation,
                     "token": ctx.token}},
            separators=(",", ":")) + "\n").encode()
        delivery_exc = None
        try:
            fd = supervisor.popen.stdin.fileno()
            fcntl.fcntl(fd, fcntl.F_SETFL, fcntl.fcntl(fd, fcntl.F_GETFL) | os.O_NONBLOCK)
            if os.write(fd, line) != len(line):
                delivery_exc = OSError("partial GO write")
        except Exception as e:
            delivery_exc = e
        if delivery_exc is None:
            return                            # delivered; STARTING + go_sent committed
        rec["launch_state"] = "FAILED"        # lease + pending RETAINED = teardown identity
        rec["updated"] = store.now_iso()
        op = (rec.get("lease") or {}).get("operator") or RECOVERY_ACTOR
        recovery_exc = None
        try:
            _write_unlocked(seats)            # write 2 (retained FAILED)
        except Exception as e2:
            recovery_exc = e2                 # store unwritable ⇒ sweep reclaims the go_sent row
        if recovery_exc is not None:
            # r28 Bugbot: DON'T receipt go_failed here — on disk the seat is still
            # STARTING+go_sent (the FAILED write did not land), so a terminal
            # receipt would contradict the registry. sweep_stale reclaims the row
            # and emits its own stale_swept receipt.
            raise OwnershipConflict(
                f"seat {ctx.seat!r} GO delivery failed ({delivery_exc!r}) AND the "
                f"retained-FAILED recovery write failed ({recovery_exc!r}); the "
                f"STARTING+go_sent row will be reclaimed by sweep", code="go_delivery")
        _emit("runtime_failed", op, {         # only after the FAILED transition durably committed
            "seat": ctx.seat, "attempt_id": ctx.attempt_id,
            "runtime_id": ctx.runtime_id, "generation": ctx.generation,
            "reason": "go_failed"})
        raise OwnershipConflict(
            f"seat {ctx.seat!r} GO delivery failed ({delivery_exc!r}); attempt moved to "
            f"FAILED (retained teardown identity)", code="go_delivery")

    _locked(_mark_go)                         # bind + recheck + go_sent + atomic non-blocking deliver
    supervisor._go_sent = True                # only after a committed, delivered GO


def abort_supervisor(supervisor: SupervisorHandle) -> None:
    """CAS failed / refusal — tear the blocked supervisor down before it can
    spawn a vendor child (r12 CRIT#1). Idempotent."""
    if isinstance(supervisor, SupervisorHandle):
        _kill_reap(supervisor.popen)


#: a GO frame (nonce + lease echo + capability ctx) is a few hundred bytes;
#: anything near this bound is not a GO (PR-2 S-A)
GO_MAX_BYTES = 4096


def read_go_frame(fd: int, *, deadline_sec: float,
                  max_bytes: int = GO_MAX_BYTES) -> Optional[bytes]:
    """SUPERVISOR-side bounded GO read (PR-2 S-A): one '\\n'-terminated frame
    from the private stdin pipe with a shrinking deadline and a size cap — the
    same framer discipline attach_supervisor applies to READY (r13 HIGH#6),
    exported so the real supervisor never hand-rolls a blocking readline.
    Returns the frame without its newline, or None on timeout / EOF / oversize
    / bytes-past-frame — every None is 'no GO': the caller exits WITHOUT
    spawning (§7a.5)."""
    return _read_framed_line(fd, deadline_sec=deadline_sec, max_bytes=max_bytes)


@_soundness_action("verify_capability")
def verify_capability(ctx: SupervisorContext) -> None:
    """Non-mutating capability PREFLIGHT (PR-2 r2, reviewer CRIT#1): prove the
    reconstituted capability matches the LIVE registry row BEFORE any vendor
    process exists. Frame-shape validation alone cannot catch a cross-bound
    ctx whose token never matched this seat's lease — without this check the
    supervisor would spawn a real vendor child (network/credential/cost side
    effects) only for record_observed to refuse it afterwards, violating the
    zero-child contract for unauthorized GOs. Verifies under the registry
    lock: STARTING under exactly this capability (_sup_matches token hash),
    a durable go_sent, a live same-boot supervisor incarnation, and the
    lifetime lock actually held. Raises; mutates nothing."""
    seat = _require_sup(ctx, ctx.seat).seat
    this_boot = host_boot_id()                # probe boot OUTSIDE the lock
    _locked(lambda: _verify_capability_unlocked(ctx, seat, this_boot))


def _verify_capability_unlocked(ctx: SupervisorContext, seat: str,
                                this_boot: Optional[str]) -> Dict[str, Any]:
    """Registry-lock-held half shared by preflight and grant consumption."""
    seats = _read_unlocked()
    rec = seats.get(seat)
    # participant_presence is an action-policy fact for every capability
    # verification, including legacy rows without a native attempt plan.
    participants = store.load_participants()
    facts = runtime_soundness_core(
        dict(rec or _empty_record(), seat=seat), participants=participants,
        seats=seats, this_boot=this_boot, action="verify_capability",
        action_context={"supervisor_ctx": ctx})
    _require_action_soundness("verify_capability", facts)
    if not rec or rec.get("launch_state") != "STARTING":
        raise OwnershipConflict(
            f"seat {seat!r} has no STARTING attempt for capability verification "
            f"— refusing to spawn", code="go_state")
    return rec


def capability_names_accepted_go(ctx: SupervisorContext) -> bool:
    """Whether this exact capability owns a durably accepted GO transition.

    This is deliberately narrower than :func:`verify_capability`: participant,
    catalog, liveness, and lock drift may revoke spawning *after* GO, but only
    a token-bound STARTING row with ``go_sent`` authorizes the supervisor to
    write retained FAILED.  A shape-valid forged/pre-GO frame remains the
    benign childless refusal path and cannot mutate somebody else's attempt.
    """
    seat = _require_sup(ctx, ctx.seat).seat

    def _accepted() -> bool:
        rec = _read_unlocked().get(seat)
        return bool(
            rec and rec.get("launch_state") == "STARTING"
            and _sup_matches(ctx, rec)
            and (rec.get("pending_attempt") or {}).get("go_sent") is True)

    return _locked(_accepted)


def reconstitute_supervisor_context(frame: Any, *, ready: Dict[str, Any]) -> SupervisorContext:
    """SUPERVISOR-side narrow minting entry (PR-2 S-A). The launcher's send_go
    delivered a capability-carrying GO frame; this is the ONLY path by which a
    supervisor process turns that frame into a typed SupervisorContext — there
    is no caller-forgeable constructor (direct construction raises), and NOTHING
    in the frame is trusted before it is checked against the supervisor's OWN
    minted READY (`ready` must be the exact dict this process minted via
    mint_ready and attested into its lock):

      - the frame must be a closed shape: exactly {go, lease_id, ctx}, with ctx
        exactly {seat, attempt_id, runtime_id, generation, token} — unknown or
        missing keys refuse (a frame is a protocol message, not a config);
      - frame.go must equal OUR nonce and frame.lease_id OUR lease_id — a GO
        bound to any other attempt/supervisor refuses before any field is used;
      - ctx.runtime_id must equal OUR runtime_id (the capability names the same
        attempt the nonce proved);
      - every ctx field is shape-checked (seat id rule, non-empty ids, a real
        positive int generation, non-empty token).

    Possession of the minted context still proves nothing by itself: every
    attempt-advancing call re-verifies it against the LIVE registry row
    (_sup_matches token hash + _require_live_supervisor) at use. A refusal here
    means 'no GO' — the supervisor exits without spawning a vendor child."""
    if not isinstance(ready, dict) or not ready.get("nonce") \
            or not ready.get("lease_id") or not ready.get("runtime_id"):
        raise ValidationError("reconstitute requires the supervisor's own minted READY")
    if not isinstance(frame, dict) or set(frame.keys()) != {"go", "lease_id", "ctx"}:
        raise ValidationError("GO frame must be exactly {go, lease_id, ctx}")
    if frame["go"] != ready["nonce"]:
        raise ValidationError("GO frame nonce does not match this supervisor's READY")
    if frame["lease_id"] != ready["lease_id"]:
        raise ValidationError("GO frame lease_id does not match this supervisor's READY")
    ctx = frame["ctx"]
    if not isinstance(ctx, dict) or set(ctx.keys()) != \
            {"seat", "attempt_id", "runtime_id", "generation", "token"}:
        raise ValidationError(
            "GO ctx must be exactly {seat, attempt_id, runtime_id, generation, token}")
    if ctx["runtime_id"] != ready["runtime_id"]:
        raise ValidationError("GO ctx runtime_id does not match this supervisor's READY")
    seat = _validate_seat(ctx["seat"])
    for k in ("attempt_id", "token"):
        if not isinstance(ctx[k], str) or not ctx[k]:
            raise ValidationError(f"GO ctx.{k} must be a non-empty string")
    gen = ctx["generation"]
    if not isinstance(gen, int) or isinstance(gen, bool) or gen <= 0:
        raise ValidationError("GO ctx.generation must be a positive int")
    return SupervisorContext(seat=seat, attempt_id=ctx["attempt_id"],
                             runtime_id=ctx["runtime_id"], generation=gen,
                             token=ctx["token"], _mark=_MINT)


# --------------------------------------------------------------------------
# store plumbing — flock/atomic-replace/0600 + FULL state-table read checks
# --------------------------------------------------------------------------

def _locked(fn):
    store.ensure_store()
    with RUNTIME_LOCK.open("a") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        try:
            return fn()
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def _corrupt(msg: str) -> RuntimeError:
    return RuntimeError(f"runtime registry {RUNTIME_FILE} is corrupt ({msg}); refusing to read")


def _check_snapshot(seat: str, name: str, snap: Any, *, want_handle: bool) -> None:
    if not isinstance(snap, dict):
        raise _corrupt(f"seat {seat!r} {name} is {type(snap).__name__}")
    try:
        validate_spec(snap.get("spec"))
    except ValidationError as e:
        raise _corrupt(f"seat {seat!r} {name}.spec invalid: {e}")
    if not isinstance(snap.get("runtime_id"), str) or not snap["runtime_id"]:
        raise _corrupt(f"seat {seat!r} {name}.runtime_id")
    gen = snap.get("generation")
    if isinstance(gen, bool) or not isinstance(gen, int) or gen <= 0:
        raise _corrupt(f"seat {seat!r} {name}.generation {gen!r}")
    attempt_cfg = snap.get("attempt_config")
    attempt_digest = None
    if attempt_cfg is not None:
        try:
            clean_attempt = validate_attempt_config(
                attempt_cfg, seat=seat, spec=snap.get("spec"))
            attempt_digest = attempt_config_sha256(clean_attempt)
        except ValidationError as e:
            raise _corrupt(f"seat {seat!r} {name}.attempt_config invalid: {e}")
    if want_handle:
        try:
            validate_handle(snap.get("handle"))
        except ValidationError as e:
            raise _corrupt(f"seat {seat!r} {name}.handle invalid: {e}")
    elif snap.get("handle") is not None:
        try:
            validate_handle(snap["handle"])
        except ValidationError as e:
            raise _corrupt(f"seat {seat!r} {name}.handle invalid: {e}")
    if want_handle and attempt_cfg is not None \
            and clean_attempt.get("launch_mode") == "RESUME" \
            and validate_handle(snap.get("handle")) != clean_attempt.get("resume_handle"):
        raise _corrupt(
            f"seat {seat!r} {name}.handle differs from its RESUME handle")
    res = snap.get("resource")
    if res is not None:
        try:
            validate_resource(res)
        except ValidationError as e:
            raise _corrupt(f"seat {seat!r} {name}.resource invalid: {e}")
    # r13 MED#8: a pending_attempt must carry a nonempty attempt_id AND the
    # predeclared resource — a malformed pending that passed the validator
    # failed later in inconsistent ways (finalize/sweep read its resource)
    if name == "pending_attempt":
        if not isinstance(snap.get("attempt_id"), str) or not snap["attempt_id"]:
            raise _corrupt(f"seat {seat!r} pending_attempt missing attempt_id")
        if res is None:
            raise _corrupt(f"seat {seat!r} pending_attempt missing predeclared resource")
    vendor_obs = snap.get("vendor_observed")
    handle_att = snap.get("handle_attestation")
    if vendor_obs is not None:
        if attempt_cfg is None:
            raise _corrupt(f"seat {seat!r} {name}.vendor_observed without attempt_config")
        try:
            validate_vendor_observed(
                vendor_obs, seat=seat, attempt_id=snap.get("attempt_id"),
                runtime_id=snap.get("runtime_id"), generation=gen,
                attempt_sha256=attempt_digest, resource=res)
        except ValidationError as e:
            raise _corrupt(f"seat {seat!r} {name}.vendor_observed invalid: {e}")
    if handle_att is not None:
        if vendor_obs is None:
            raise _corrupt(
                f"seat {seat!r} {name}.handle_attestation precedes vendor_observed")
        try:
            clean_att = validate_handle_attestation(
                handle_att, seat=seat, attempt_id=snap.get("attempt_id"),
                runtime_id=snap.get("runtime_id"), generation=gen,
                attempt_sha256=attempt_digest)
        except ValidationError as e:
            raise _corrupt(f"seat {seat!r} {name}.handle_attestation invalid: {e}")
        if snap.get("handle") is not None \
                and clean_att["handle"] != validate_handle(snap["handle"]):
            raise _corrupt(
                f"seat {seat!r} {name}.handle differs from handle_attestation")
    if attempt_cfg is not None and want_handle \
            and (vendor_obs is None or handle_att is None):
        raise _corrupt(
            f"seat {seat!r} {name} native adapter lacks vendor/handle proof")
    # observed_runtime shape + resource-drift (r12 HIGH#4): if present it must
    # be a well-formed child identity whose resource matches the snapshot's
    obs = snap.get("observed_runtime")
    if obs is not None:
        if not isinstance(obs, dict) or _valid_pid(obs.get("child_pid")) is None \
                or not isinstance(obs.get("child_birth"), str) or not obs["child_birth"]:
            raise _corrupt(f"seat {seat!r} {name}.observed_runtime malformed")
        try:
            obs_res = validate_resource(obs.get("resource"))
        except ValidationError as e:
            raise _corrupt(f"seat {seat!r} {name}.observed_runtime.resource invalid: {e}")
        if res is not None and obs_res != res:
            raise _corrupt(f"seat {seat!r} {name}.observed_runtime.resource drifts from {name}.resource")
        for key in ("work_dir", "store_dir"):
            value = obs.get(key)
            if value is not None and (
                    not isinstance(value, str) or not os.path.isabs(value)
                    or any(c in value for c in "\n\0")):
                raise _corrupt(
                    f"seat {seat!r} {name}.observed_runtime.{key} malformed")
        if attempt_cfg is not None \
                and (obs.get("work_dir") != clean_attempt["work_dir"]
                     or obs.get("store_dir") != clean_attempt["store_dir"]):
            raise _corrupt(
                f"seat {seat!r} {name}.observed_runtime workspace/store drift")
    elif want_handle:
        # an ACTIVE/prior snapshot (want_handle) must carry its observed child
        raise _corrupt(f"seat {seat!r} {name} missing observed_runtime")


def _check_record(seat: str, rec: Any) -> None:
    """FULL state-table invariants on every read (r10, reviewer HIGH#5): a
    malformed row blocks all reads/mutation; doctor goes red on this."""
    try:
        _validate_seat(seat)
    except ValidationError:
        raise _corrupt(f"invalid seat key {seat!r}")
    if not isinstance(rec, dict):
        raise _corrupt(f"seat {seat!r} record is {type(rec).__name__}")
    state = rec.get("launch_state")
    if state is not None and state not in STATES:
        raise _corrupt(f"seat {seat!r} launch_state {state!r}")
    gen = rec.get("gen_counter", 0)
    if isinstance(gen, bool) or not isinstance(gen, int) or gen < 0:
        raise _corrupt(f"seat {seat!r} gen_counter {gen!r}")
    if rec.get("desired_config") is not None:
        try:
            validate_spec(rec["desired_config"])
        except ValidationError as e:
            raise _corrupt(f"seat {seat!r} desired_config invalid: {e}")
    esc = rec.get("escapees")
    if esc is not None:
        if not isinstance(esc, dict) \
                or not isinstance(esc.get("runtime_id"), str) or not esc["runtime_id"] \
                or isinstance(esc.get("generation"), bool) \
                or not isinstance(esc.get("generation"), int) \
                or not isinstance(esc.get("entries"), list):
            raise _corrupt(f"seat {seat!r} escapees malformed")
        for row in esc["entries"]:
            if not isinstance(row, dict) or _valid_pid(row.get("pid")) is None \
                    or not isinstance(row.get("birth"), str) or not row["birth"]:
                raise _corrupt(f"seat {seat!r} escapees entry malformed")
        # r3 non-blocking precision (reviewer): the runtime-bound schema must
        # FAIL LOUD if the persisted pair does not equal the live lease it was
        # bound to (a terminal dirty row has its lease cleared atomically with
        # the set, so escapees-without-lease is not reachable via a clean path)
        lease_here = rec.get("lease")
        if isinstance(lease_here, dict) and (
                esc["runtime_id"] != lease_here.get("runtime_id")
                or esc["generation"] != lease_here.get("generation")):
            raise _corrupt(
                f"seat {seat!r} escapees runtime_id/generation does not match the lease")
    # The durable exit fact is state-bound. Operator stop uses
    # STOPPING/{status}; an unexpected adapter-host death uses retained
    # FAILED/{status, reason=adapter_failed}. No other shape/state may carry it.
    ex = rec.get("exit")
    if ex is not None:
        state = rec.get("launch_state")
        wanted = {"status"} if state == "STOPPING" else {"status", "reason"}
        if not isinstance(ex, dict) or set(ex.keys()) != wanted:
            raise _corrupt(f"seat {seat!r} exit fact has an invalid shape for {state!r}")
        st = ex.get("status")
        if st is not None and (isinstance(st, bool) or not isinstance(st, int)):
            raise _corrupt(f"seat {seat!r} exit status must be an int or None")
        stopping = state == "STOPPING" and rec.get("active") is not None \
            and rec.get("lease") is not None
        failed = state == "FAILED" and ex.get("reason") == "adapter_failed" \
            and rec.get("active") is not None \
            and rec.get("lease") is not None and rec.get("pending_attempt") is None
        if not (stopping or failed):
            raise _corrupt(
                f"seat {seat!r} exit fact is inconsistent with {state!r}")
    pend, active, prior, lease = (rec.get("pending_attempt"), rec.get("active"),
                                  rec.get("prior_active"), rec.get("lease"))
    if pend is not None:
        _check_snapshot(seat, "pending_attempt", pend, want_handle=False)
    if active is not None:
        _check_snapshot(seat, "active", active, want_handle=True)
    if prior is not None:
        _check_snapshot(seat, "prior_active", prior, want_handle=True)
    if lease is not None:
        if not isinstance(lease, dict) or _valid_pid(lease.get("supervisor_pid")) is None \
                or isinstance(lease.get("generation"), bool) \
                or not isinstance(lease.get("generation"), int):
            raise _corrupt(f"seat {seat!r} lease malformed")
        # every identity field written at claim time must be present + non-empty
        # (Bugbot r10 MED: a lease missing proc_birth made _proc_identity_ok
        # read a LIVE supervisor as dead, letting finish_stop reach STOPPED)
        for f in ("runtime_id", "lease_id", "nonce", "token_sha256",
                  "proc_birth", "boot_id", "heartbeat", "operator"):
            if not isinstance(lease.get(f), str) or not lease[f]:
                raise _corrupt(f"seat {seat!r} lease missing identity field {f!r}")
        # r13 MED#8: heartbeat must be a PARSEABLE timestamp, not any nonempty
        # string — an unparseable clock silently reads as 'stale' downstream
        if _parse_iso(lease.get("heartbeat")) is None:
            raise _corrupt(f"seat {seat!r} lease heartbeat is not an ISO timestamp")
        # r21 reviewer MED#5: the persisted go_deadline is bounded like the READY it
        # came from (a corrupt one would mis-set the recovery horizon)
        if not _valid_go_deadline(lease.get("go_deadline")):
            raise _corrupt(f"seat {seat!r} lease go_deadline out of bounds")
        lease_digest = lease.get("attempt_sha256")
        if lease_digest is not None and not _valid_sha256(lease_digest):
            raise _corrupt(f"seat {seat!r} lease attempt_sha256 malformed")

    def _pair_equal(snap):
        return (lease is not None and snap is not None
                and lease.get("runtime_id") == snap.get("runtime_id")
                and lease.get("generation") == snap.get("generation"))

    if state == "STARTING":
        if pend is None or lease is None or not _pair_equal(pend):
            raise _corrupt(f"seat {seat!r} STARTING needs pending+lease, pair-equal")
        # r13 MED#6: go_sent, when present, is strictly boolean — a truthy
        # non-bool would read as permanent GO-spent
        if "go_sent" in pend and not isinstance(pend["go_sent"], bool):
            raise _corrupt(f"seat {seat!r} pending_attempt.go_sent must be a boolean")
        # r30 Bugbot: observation can only have been recorded AFTER a durable GO
        # (record_observed gates on go_sent), so an observed pending WITHOUT
        # go_sent is a corrupt/inconsistent row — reject it so no advance path
        # (record_handle) can progress it on stale evidence
        if pend.get("observed_runtime") is not None and not pend.get("go_sent"):
            raise _corrupt(f"seat {seat!r} STARTING pending has observed_runtime but no go_sent")
        # r31 reviewer LOW residual: a proven handle can only exist AFTER GO +
        # observation (record_handle enforces the order at write time) — a row
        # with a handle but missing go_sent/observed is an impossible proof order
        if pend.get("handle") is not None \
                and (pend.get("go_sent") is not True or pend.get("observed_runtime") is None):
            raise _corrupt(f"seat {seat!r} STARTING pending has a handle out of proof order "
                           f"(requires go_sent + observed_runtime)")
        if pend.get("attempt_config") is not None:
            if lease.get("attempt_sha256") != attempt_config_sha256(pend["attempt_config"]):
                raise _corrupt(
                    f"seat {seat!r} STARTING attempt_config digest differs from lease")
            if pend.get("vendor_observed") is not None \
                    and pend.get("observed_runtime") is None:
                raise _corrupt(
                    f"seat {seat!r} VENDOR_OBSERVED precedes adapter-host observation")
            if pend.get("handle") is not None \
                    and pend.get("handle_attestation") is None:
                raise _corrupt(
                    f"seat {seat!r} native adapter handle lacks external attestation")
    elif state in ("ACTIVE", "STOPPING"):
        if active is None or lease is None or not _pair_equal(active):
            raise _corrupt(f"seat {seat!r} {state} needs active+lease, pair-equal")
        if pend is not None:
            raise _corrupt(f"seat {seat!r} {state} must not carry a pending attempt")
        if active.get("attempt_config") is not None \
                and lease.get("attempt_sha256") != attempt_config_sha256(
                    active["attempt_config"]):
            raise _corrupt(
                f"seat {seat!r} {state} attempt_config digest differs from lease")
    elif state == "STOPPED":
        if lease is not None or pend is not None:
            raise _corrupt(f"seat {seat!r} STOPPED must carry no lease/pending")
    elif state == "FAILED":
        retained_pending = pend is not None and lease is not None \
            and _pair_equal(pend)
        retained_active = active is not None and pend is None \
            and lease is not None and _pair_equal(active)
        finalized = pend is None and lease is None
        if not (retained_pending or retained_active or finalized):
            raise _corrupt(
                f"seat {seat!r} FAILED must retain one teardown pair or be finalized")
    elif state is None:
        # r12 HIGH#4: a None-state row is an EMPTY ownership row (only desired
        # config/intent may be present) — a stale lease/active/pending under None
        # would be overwritten by the next claim, silently losing a live owner
        if lease is not None or pend is not None or active is not None or prior is not None:
            raise _corrupt(f"seat {seat!r} None-state must carry no ownership fields")

    # r13 CRIT#1: the durable intent row is a typed, closed-vocabulary field
    intent = rec.get("intent")
    if intent is not None:
        if not isinstance(intent, dict) \
                or not isinstance(intent.get("attempt_id"), str) or not intent["attempt_id"] \
                or not isinstance(intent.get("operator"), str) or not intent["operator"] \
                or intent.get("state") not in INTENT_STATES \
                or _parse_iso(intent.get("heartbeat")) is None \
                or (intent.get("intent_id") is not None
                    and (not isinstance(intent["intent_id"], str)
                         or re.fullmatch(
                             r"int-[0-9a-f]{32}", intent["intent_id"]) is None)):
            raise _corrupt(f"seat {seat!r} intent malformed")
        # Pre-incarnation rows remain readable for a fail-closed migration:
        # no new IntentContext can match their absent intent_id, while a stale
        # OPEN can still be atomically superseded into the new schema.
    # r13 MED#6: a STARTING pending attempt must pair EXACTLY with a CONSUMED
    # intent for the SAME attempt_id — not merely "when the ids happen to match".
    # A drifted/absent intent under STARTING is a corrupt row, not a silent pass.
    if state == "STARTING" and pend is not None:
        if not isinstance(intent, dict) \
                or intent.get("attempt_id") != pend.get("attempt_id") \
                or intent.get("state") != "CONSUMED":
            raise _corrupt(
                f"seat {seat!r} STARTING pending must pair with the same CONSUMED intent")


def _read_unlocked() -> Dict[str, Dict[str, Any]]:
    try:
        with RUNTIME_FILE.open("r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        return {}
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        raise _corrupt(str(e))
    if isinstance(data, dict) and "_schema" in data:
        if data.get("_schema") != 1:
            raise _corrupt(f"unsupported _schema={data.get('_schema')!r} (this code understands 1)")
        seats = data.get("seats")
        if not isinstance(seats, dict):
            raise _corrupt(f"schema 1 with {type(seats).__name__} seats")
        for name, rec in seats.items():
            _check_record(name, rec)
        return seats
    if isinstance(data, dict):
        if LEGACY_SEED.exists():
            raise _corrupt(f"schema-less object but legacy seed already at {LEGACY_SEED}")
        os.replace(RUNTIME_FILE, LEGACY_SEED)
        return {}
    raise _corrupt(f"top-level {type(data).__name__}, expected object")


def _write_unlocked(seats: Dict[str, Dict[str, Any]]) -> None:
    store.ensure_store()
    tmp = RUNTIME_FILE.with_suffix(".json.tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump({"_schema": 1, "seats": seats}, f, indent=2, ensure_ascii=False)
        f.flush()
        os.fsync(f.fileno())
    os.chmod(tmp, 0o600)
    os.replace(tmp, RUNTIME_FILE)


def _read_arming_grants_unlocked() -> Dict[str, Dict[str, Any]]:
    import stat
    try:
        fd = os.open(ARMING_GRANT_FILE,
                     os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
    except FileNotFoundError:
        return {}
    except OSError as error:
        raise _corrupt(f"arming grant ledger open: {error}")
    try:
        metadata = os.fstat(fd)
        if not stat.S_ISREG(metadata.st_mode) or metadata.st_uid != os.geteuid() \
                or stat.S_IMODE(metadata.st_mode) != 0o600 \
                or metadata.st_size > ARMING_GRANT_MAX_BYTES:
            raise _corrupt("arming grant ledger is not a bounded private regular file")
        raw = os.read(fd, ARMING_GRANT_MAX_BYTES + 1)
        after = os.fstat(fd)
        before_identity = (metadata.st_dev, metadata.st_ino, metadata.st_mode,
                           metadata.st_size, metadata.st_mtime_ns)
        after_identity = (after.st_dev, after.st_ino, after.st_mode,
                          after.st_size, after.st_mtime_ns)
        if before_identity != after_identity or len(raw) != metadata.st_size:
            raise _corrupt("arming grant ledger changed while being read")
    finally:
        os.close(fd)
    if len(raw) > ARMING_GRANT_MAX_BYTES:
        raise _corrupt("arming grant ledger exceeds the size bound")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as error:
        raise _corrupt(f"arming grant ledger: {error}")
    if not isinstance(payload, dict) or set(payload) != {"_schema", "consumed"} \
            or payload.get("_schema") != 1 \
            or not isinstance(payload.get("consumed"), dict):
        raise _corrupt("arming grant ledger has an invalid shape")
    consumed = payload["consumed"]
    for grant_id, record in consumed.items():
        if not isinstance(grant_id, str) or _GRANT_ID_RE.fullmatch(grant_id) is None \
                or not isinstance(record, dict) \
                or set(record) != _CONSUMED_GRANT_FIELDS \
                or record.get("grant_id") != grant_id \
                or not _valid_sha256(record.get("grant_sha256")) \
                or not isinstance(record.get("seat"), str) or not record["seat"] \
                or not isinstance(record.get("attempt_id"), str) \
                or re.fullmatch(r"att-[0-9a-f]{10}", record["attempt_id"]) is None \
                or not isinstance(record.get("runtime_id"), str) \
                or not record["runtime_id"] \
                or isinstance(record.get("generation"), bool) \
                or not isinstance(record.get("generation"), int) \
                or record["generation"] <= 0 \
                or not isinstance(record.get("boot_id"), str) or not record["boot_id"] \
                or not isinstance(record.get("operator"), str) or not record["operator"] \
                or not isinstance(record.get("consumed_at_monotonic"), float) \
                or not math.isfinite(record["consumed_at_monotonic"]) \
                or not isinstance(record.get("bindings"), dict) \
                or set(record["bindings"]) != _GRANT_BINDING_FIELDS \
                or re.fullmatch(r"[0-9a-f]{40}",
                                record["bindings"].get("head", "")) is None \
                or any(not _valid_sha256(record["bindings"].get(key))
                       for key in _GRANT_BINDING_FIELDS if key != "head"):
            raise _corrupt(f"arming grant ledger record {grant_id!r} is invalid")
    return dict(consumed)


def _write_arming_grants_unlocked(consumed: Dict[str, Dict[str, Any]]) -> None:
    """Atomic, durable consumed-set commit under ``RUNTIME_LOCK``."""
    store.ensure_store()
    serialized = json.dumps(
        {"_schema": 1, "consumed": consumed}, indent=2,
        ensure_ascii=False, sort_keys=True)
    if len(serialized.encode("utf-8")) > ARMING_GRANT_MAX_BYTES:
        # Never commit a file our own fail-closed reader will reject. Retaining
        # the prior consumed set is safer than replacing it with a self-created
        # oversized ledger that wedges every later replay check.
        raise RuntimeError("arming grant ledger capacity exhausted")
    tmp = ARMING_GRANT_FILE.with_name(
        f".{ARMING_GRANT_FILE.name}.{secrets.token_hex(8)}.tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL
                 | os.O_CLOEXEC | os.O_NOFOLLOW, 0o600)
    try:
        stream = os.fdopen(fd, "w", encoding="utf-8")
    except Exception:
        os.close(fd)
        raise
    try:
        stream.write(serialized)
        stream.flush()
        os.fsync(stream.fileno())
    except Exception:
        stream.close()
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass
        raise
    else:
        stream.close()
    try:
        os.replace(tmp, ARMING_GRANT_FILE)
    except Exception:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass
        raise
    directory_fd = os.open(ARMING_GRANT_FILE.parent, os.O_RDONLY)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)


# --------------------------------------------------------------------------
# typed-record validation
# --------------------------------------------------------------------------

def validate_spec(spec: Any) -> Dict[str, Any]:
    if not isinstance(spec, dict):
        raise ValidationError("LaunchSpec must be an object")
    management = spec.get("management")
    if management not in MANAGEMENTS:
        raise ValidationError(f"management must be one of {MANAGEMENTS}, got {management!r}")
    model = spec.get("model")
    if not isinstance(model, str) or not model.strip() or model.strip().lower() == "default":
        raise ValidationError(f"model must be an exact resolved model id, got {model!r}")
    effort = spec.get("effort")
    if effort is not None and effort not in EFFORTS:
        raise ValidationError(f"effort must be null or one of {EFFORTS}, got {effort!r}")
    work_dir = spec.get("work_dir")
    if not isinstance(work_dir, str) or not os.path.isabs(work_dir):
        raise ValidationError(f"work_dir must be an absolute path, got {work_dir!r}")
    return {"management": management, "model": model.strip(),
            "effort": effort, "work_dir": work_dir}


def canonical_session_id(value: Any) -> str:
    """Collapse every parser-equivalent UUID spelling to one session identity."""
    import uuid

    if not isinstance(value, str) or not value:
        raise ValidationError("session id must be a non-empty UUID string")
    try:
        return str(uuid.UUID(value))
    except ValueError as exc:
        raise ValidationError(
            f"session id must UUID-parse, got {value!r}") from exc


def validate_handle(handle: Any) -> Dict[str, Any]:
    if not isinstance(handle, dict):
        raise ValidationError("Handle must be an object")
    kind, ref = handle.get("kind"), handle.get("ref")
    if kind not in HANDLE_KINDS:
        raise ValidationError(f"handle.kind must be one of {HANDLE_KINDS}, got {kind!r}")
    if not isinstance(ref, str) or not ref:
        raise ValidationError("handle.ref must be a non-empty string")
    expected_keys = ({"kind", "ref", "canonical_target"}
                     if kind == "session_file" else {"kind", "ref"})
    if set(handle) != expected_keys:
        raise ValidationError(
            f"{kind} handle must contain exactly {sorted(expected_keys)}")
    if kind == "session_uuid":
        # UUID spelling is not identity.  Use the same canonicalizer as SDK
        # result entry and authoritative turn accounting.
        ref = canonical_session_id(ref)
    if kind == "session_file":
        if not os.path.isabs(ref):
            raise ValidationError("session_file handle must be an absolute path")
        canonical = handle.get("canonical_target")
        if not isinstance(canonical, str) or not os.path.isabs(canonical) \
                or any(c in canonical for c in "\n\0"):
            raise ValidationError(
                "session_file.canonical_target must be a clean absolute path")
        # A7: comparison never resolves the filesystem. Trusted adapter
        # observation must securely walk an existing symlink-free path and
        # persist that target in BOTH fields; late normpath/realpath would be a
        # retargetable TOCTOU. Secure open/revalidation is armed-adapter work.
        if os.path.normpath(ref) != ref or os.path.normpath(canonical) != canonical \
                or ref != canonical:
            raise ValidationError(
                "session_file must persist one lexical canonical target; aliases refused")
        return {"kind": kind, "ref": ref, "canonical_target": canonical}
    return {"kind": kind, "ref": ref}


def _handles_equal(left: Any, right: Any) -> bool:
    """Compare the closed, canonical Handle identity rather than input JSON."""
    return validate_handle(left) == validate_handle(right)


def model_family(model: Any) -> str:
    """Derive the closed continuity domain from one resolved model id."""
    value = model.lower() if isinstance(model, str) else ""
    if value.startswith("claude") or value.startswith("fable"):
        return "claude"
    if "gpt" in value or value.startswith("codex") or value.startswith("o"):
        return "codex"
    if "gemini" in value or "antigravity" in value:
        return "gemini"
    raise ValidationError(f"cannot derive a vendor family from model {model!r}")


def permission_profile_for_role(role: Any) -> str:
    """The closed role -> OS/vendor permission boundary for an SDK seat.

    Only the explicit ``coder`` role receives a writable sandbox.  Every other
    registered non-human harness role is read-only; a human/unknown role is not
    a launchable agent identity and fails closed.  The action seam still
    resolves the role live on every tool call, so a later role change cannot
    turn this launch-time containment decision into an allow.
    """
    if role == "coder":
        return "workspace_write"
    if role in ("reviewer", "chief_of_staff", "system_governor"):
        return "read_only"
    raise ValidationError(f"role {role!r} is not a launchable agent role")


def _normalized_family(value: Any) -> Optional[str]:
    """Delegates to store.normalize_family — one definition, not two.

    This was a byte-identical second copy. Two normalizations of the same field
    is how the vendor set drifts apart: adding a family here and not there
    yields a seat that launches but never receives, or receives but never
    launches, with both halves looking correct in isolation.
    """
    return store.normalize_family(value)


def participant_launch_identity(seat: str, participant: Any) -> Dict[str, Any]:
    """Return the closed participant fields that authorize one native launch.

    Presence/hand/label timestamps are deliberately excluded: they do not
    authorize a process.  Seat, agent kind, family, role, and channel do.  The
    resulting revision is stable across unrelated registry chatter but changes
    whenever the launch identity or its privilege boundary changes.
    """
    _validate_seat(seat)
    if not isinstance(participant, dict) or participant.get("kind") != "agent":
        raise ValidationError(f"seat {seat!r} is not a registered agent")
    participant_id = participant.get("id")
    if participant_id is not None and participant_id != seat:
        raise ValidationError(
            f"participant id {participant_id!r} does not match seat {seat!r}")
    family = _normalized_family(participant.get("family"))
    if family is None:
        raise ValidationError(f"seat {seat!r} has no launchable vendor family")
    role = participant.get("role")
    if role is None:
        role = store._default_role(participant.get("kind") or "agent",
                                   participant.get("family"))
    permission_profile_for_role(role)  # closed role vocabulary
    channel = participant.get("channel")
    if not isinstance(channel, str) or not channel.strip() \
            or any(c in channel for c in "\n\0"):
        raise ValidationError(f"seat {seat!r} has no valid participant channel")
    return {
        "schema_version": PARTICIPANT_LAUNCH_IDENTITY_SCHEMA,
        "seat": seat,
        "kind": "agent",
        "family": family,
        "role": role,
        "channel": channel,
    }


def canonical_participant_launch_identity(seat: str, participant: Any) -> bytes:
    return json.dumps(
        participant_launch_identity(seat, participant), sort_keys=True,
        separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def participant_launch_revision(seat: str, participant: Any) -> str:
    return hashlib.sha256(
        canonical_participant_launch_identity(seat, participant)).hexdigest()


def adapter_host_argv(family: str, seat: str, work_dir: str) -> List[str]:
    """Derive the exact per-seat SDK adapter-host invocation.

    The vendor SDK owns its private subprocess/connection.  The supervisor
    launches only this long-lived host, never a raw app-server or ACP grammar.
    Seat and workspace are included in the digest-bound argv so a claim cannot
    be replayed onto another participant or sandbox boundary.
    """
    normalized = _normalized_family(family)
    if normalized is None:
        raise ValidationError(f"adapter host family must be one of {ADAPTER_FAMILIES}")
    _validate_seat(seat)
    if not isinstance(work_dir, str) or not os.path.isabs(work_dir) \
            or any(c in work_dir for c in "\n\0"):
        raise ValidationError("adapter host work_dir must be a clean absolute path")
    return [*ADAPTER_PROTOCOLS[normalized]["argv"],
            "--as", seat, "--worktree", work_dir]


def validate_attempt_config(config: Any, *, seat: Optional[str] = None,
                            spec: Optional[Dict[str, Any]] = None,
                            participant: Optional[Dict[str, Any]] = None
                            ) -> Dict[str, Any]:
    """Validate/canonicalize one *effective* native-adapter launch plan.

    This object is the security boundary between the operator-side launcher and
    the blocked supervisor.  It is a CLOSED shape on purpose: every field that
    can alter identity, privilege, cost, workspace, credential selection, or
    session continuity is covered by :func:`attempt_config_sha256`.
    """
    if not isinstance(config, dict) or set(config) != _ATTEMPT_CONFIG_KEYS:
        got = sorted(config) if isinstance(config, dict) else type(config).__name__
        raise ValidationError(
            f"attempt_config must contain exactly {sorted(_ATTEMPT_CONFIG_KEYS)}, got {got}")
    if config.get("schema_version") != ATTEMPT_CONFIG_SCHEMA:
        raise ValidationError(
            f"attempt_config.schema_version must be {ATTEMPT_CONFIG_SCHEMA}")
    cfg_seat = config.get("seat")
    _validate_seat(cfg_seat)
    if seat is not None and cfg_seat != seat:
        raise ValidationError(
            f"attempt_config seat {cfg_seat!r} does not match claim seat {seat!r}")
    if config.get("management") != "sdk" or config.get("transport") != ATTEMPT_TRANSPORT:
        raise ValidationError("attempt_config must select sdk/adapter_host")
    family = _normalized_family(config.get("family"))
    if family is None:
        raise ValidationError(f"attempt_config.family must be one of {ADAPTER_FAMILIES}")
    protocol = ADAPTER_PROTOCOLS[family]
    if config.get("vendor_transport") != protocol["transport"] \
            or config.get("protocol_version") != protocol["version"]:
        raise ValidationError(
            f"attempt_config must select the closed {family} transport/protocol")
    mode = config.get("launch_mode")
    if mode not in LAUNCH_MODES:
        raise ValidationError(f"launch_mode must be one of {LAUNCH_MODES}")
    role = config.get("participant_role")
    profile = config.get("permission_profile")
    expected_profile = permission_profile_for_role(role)
    if profile != expected_profile:
        raise ValidationError(
            f"permission_profile {profile!r} does not match role {role!r} "
            f"({expected_profile!r})")
    model = config.get("model")
    if not isinstance(model, str) or not model.strip() or model.strip().lower() == "default":
        raise ValidationError("attempt_config.model must be an exact resolved model id")
    effort = config.get("effort")
    if effort is not None and effort not in EFFORTS:
        raise ValidationError(f"attempt_config.effort must be null or one of {EFFORTS}")
    work_dir, store_dir = config.get("work_dir"), config.get("store_dir")
    for name, value in (("work_dir", work_dir), ("store_dir", store_dir)):
        if not isinstance(value, str) or not os.path.isabs(value) \
                or any(c in value for c in "\n\0"):
            raise ValidationError(f"attempt_config.{name} must be a clean absolute path")
    expected_argv = adapter_host_argv(family, cfg_seat, work_dir)
    if config.get("adapter_argv") != expected_argv:
        raise ValidationError(
            f"attempt_config.adapter_argv must equal the per-seat {family} adapter host")
    participant_revision = config.get("participant_revision")
    if not _valid_sha256(participant_revision):
        raise ValidationError(
            "attempt_config.participant_revision must be a lowercase SHA-256 hex digest")
    if participant_revision != participant_revision.lower():
        raise ValidationError(
            "attempt_config.participant_revision must be lowercase SHA-256 hex")
    credential_id = config.get("credential_id")
    if credential_id is not None and (
            not isinstance(credential_id, str)
            or CREDENTIAL_ID_RE.fullmatch(credential_id) is None):
        raise ValidationError(
            "attempt_config.credential_id must be null or a closed catalog identifier")
    credential_ref = config.get("credential_ref")
    if credential_ref is not None and (
            not isinstance(credential_ref, str) or not os.path.isabs(credential_ref)
            or any(c in credential_ref for c in "\n\0")):
        raise ValidationError(
            "attempt_config.credential_ref must be null or a clean absolute path reference")
    if (credential_id is None) != (credential_ref is None):
        raise ValidationError(
            "attempt_config credential_id and credential_ref must both be null or both be set")
    if family == "gemini" and credential_id is None:
        raise ValidationError(
            "gemini adapter attempts require a server-resolved credential catalog id")
    resume = config.get("resume_handle")
    if mode == "NEW":
        if resume is not None:
            raise ValidationError("NEW attempt_config requires explicit resume_handle null")
        clean_resume = None
    else:
        clean_resume = validate_handle(resume)
        allowed = {"claude": {"session_uuid"},
                   "codex": {"session_uuid"},
                   "gemini": {"session_uuid", "session_file"}}[family]
        if clean_resume["kind"] not in allowed:
            raise ValidationError(
                f"{family} RESUME cannot consume handle kind {clean_resume['kind']!r}")

    clean = {
        "schema_version": ATTEMPT_CONFIG_SCHEMA,
        "seat": cfg_seat,
        "management": "sdk",
        "transport": ATTEMPT_TRANSPORT,
        "family": family,
        "vendor_transport": protocol["transport"],
        "protocol_version": protocol["version"],
        "adapter_argv": expected_argv,
        "launch_mode": mode,
        "participant_role": role,
        "permission_profile": profile,
        "model": model.strip(),
        "effort": effort,
        "work_dir": work_dir,
        "store_dir": store_dir,
        "participant_revision": participant_revision,
        # A stable REFERENCE only.  Secret values never enter this object,
        # READY, argv digests, the registry, logs, or receipts.
        "credential_id": credential_id,
        "credential_ref": credential_ref,
        # Always present, including explicit null, so NEW and RESUME digests
        # can never collapse onto one another.
        "resume_handle": clean_resume,
    }
    if spec is not None:
        clean_spec = validate_spec(spec)
        for key in ("management", "model", "effort", "work_dir"):
            if clean[key] != clean_spec[key]:
                raise ValidationError(
                    f"attempt_config.{key} does not match desired_config.{key}")
    if participant is not None:
        identity = participant_launch_identity(cfg_seat, participant)
        if identity["family"] != family:
            raise ValidationError(
                f"attempt family {family!r} does not match participant family "
                f"{identity['family']!r}")
        if identity["role"] != role:
            raise ValidationError(
                f"attempt role {role!r} does not match participant role "
                f"{identity['role']!r}")
        live_revision = participant_launch_revision(cfg_seat, participant)
        if participant_revision != live_revision:
            raise ValidationError(
                f"attempt participant revision does not match live seat {cfg_seat!r}")
    return clean


def validate_synthetic_grant(grant: Any, *, expected_seat: str,
                             expected_attempt_id: str,
                             attempt_sha256: str, launch_mode: str,
                             expected_bindings: Dict[str, str],
                             boot_id: str, now_monotonic: float) -> Dict[str, Any]:
    """Validate the closed, explicitly non-authoritative Phase-3 fixture.

    The monotonic clock is evaluated at consumption time.  It is system-boot
    scoped (the boot id is bound too), survives supervisor restart, and cannot
    be advanced by the same-UID subject without kernel/root authority.
    """
    if not isinstance(grant, dict) or set(grant) != _SYNTHETIC_GRANT_FIELDS:
        raise OwnershipConflict("synthetic grant has an open or incomplete shape",
                                code="grant_shape")
    if grant.get("schema_version") != SYNTHETIC_GRANT_SCHEMA \
            or grant.get("kind") != SYNTHETIC_GRANT_KIND:
        raise OwnershipConflict("synthetic grant schema/kind mismatch", code="grant_kind")
    if grant.get("authority") != SYNTHETIC_GRANT_AUTHORITY \
            or grant.get("scope") != SYNTHETIC_GRANT_SCOPE:
        raise OwnershipConflict("synthetic grant carries authority or non-deny scope",
                                code="grant_scope")
    if not isinstance(grant.get("grant_id"), str) \
            or _GRANT_ID_RE.fullmatch(grant["grant_id"]) is None:
        raise OwnershipConflict("synthetic grant id is invalid", code="grant_id")
    if not isinstance(grant.get("attempt_id"), str) \
            or re.fullmatch(r"att-[0-9a-f]{10}", grant["attempt_id"]) is None:
        raise OwnershipConflict("synthetic grant attempt id is invalid",
                                code="grant_identity")
    expected_identity = {
        "seat": expected_seat, "attempt_id": expected_attempt_id,
        "attempt_sha256": attempt_sha256, "launch_mode": launch_mode,
        "boot_id": boot_id,
    }
    if any(grant.get(key) != value for key, value in expected_identity.items()):
        raise OwnershipConflict("synthetic grant attempt identity mismatch",
                                code="grant_identity")
    if not isinstance(expected_bindings, dict) \
            or set(expected_bindings) != _GRANT_BINDING_FIELDS:
        raise OwnershipConflict("expected grant bindings have an invalid shape",
                                code="grant_binding")
    if re.fullmatch(r"[0-9a-f]{40}", expected_bindings["head"]) is None \
            or any(not _valid_sha256(expected_bindings[key])
                   for key in _GRANT_BINDING_FIELDS if key != "head"):
        raise OwnershipConflict("expected grant bindings are invalid", code="grant_binding")
    if any(grant.get(key) != value for key, value in expected_bindings.items()):
        raise OwnershipConflict("synthetic grant digest binding mismatch",
                                code="grant_binding")
    issued, expiry = grant.get("issued_at_monotonic"), grant.get("expires_at_monotonic")
    if any(isinstance(value, bool) or not isinstance(value, (int, float))
           or not math.isfinite(value) for value in (issued, expiry, now_monotonic)):
        raise OwnershipConflict("synthetic grant monotonic time is invalid",
                                code="grant_expiry")
    if issued > now_monotonic or expiry <= now_monotonic or expiry <= issued \
            or expiry - issued > SYNTHETIC_GRANT_MAX_TTL_SEC:
        raise OwnershipConflict("synthetic grant is not live at consume time",
                                code="grant_expiry")
    return dict(grant)


def preflight_synthetic_grant(grant: Any, *, seat: str,
                              attempt_config: Dict[str, Any],
                              now_monotonic: Optional[float] = None) -> Dict[str, Any]:
    """Static pre-intent fixture check; grants no launch authority.

    This catches malformed/expired/wrong-seat/wrong-attempt fixtures before an
    intent or process exists. Artifact equality is deliberately deferred to
    externally verified bindings; copying hashes from the fixture is only a
    syntax check, never self-attestation.
    """
    if not isinstance(grant, dict):
        raise OwnershipConflict("synthetic grant is absent", code="grant_absent")
    attempt = validate_attempt_config(attempt_config, seat=seat)
    attempt_id = grant.get("attempt_id")
    bindings = {key: grant.get(key) for key in _GRANT_BINDING_FIELDS}
    boot = host_boot_id()
    if boot is None:
        raise OwnershipConflict("host boot id unavailable for grant preflight",
                                code="boot_mismatch")
    return validate_synthetic_grant(
        grant, expected_seat=seat, expected_attempt_id=attempt_id,
        attempt_sha256=attempt_config_sha256(attempt),
        launch_mode=attempt["launch_mode"], expected_bindings=bindings,
        boot_id=boot,
        now_monotonic=(time.monotonic() if now_monotonic is None
                       else now_monotonic))


def verify_and_consume_synthetic_grant(
        ctx: SupervisorContext, grant: Any, *, expected_bindings: Dict[str, str],
        now_monotonic: Optional[Any] = None) -> Dict[str, Any]:
    """Atomically revalidate capability + consume one fixture before spawn.

    The consumed record is authoritative and durable.  A crash after this
    commit but before Popen burns the grant; restart/replay refuses.  This
    function does not assert external immutability and grants no real the operator
    authority; the supervisor must independently require the sealed gate.
    """
    seat = _require_sup(ctx, ctx.seat).seat
    boot = host_boot_id()
    if boot is None:
        raise OwnershipConflict("host boot id unavailable for grant consumption",
                                code="boot_mismatch")
    def _consume() -> Dict[str, Any]:
        rec = _verify_capability_unlocked(ctx, seat, boot)
        pending = rec.get("pending_attempt") or {}
        attempt = pending.get("attempt_config")
        if attempt is None:
            raise OwnershipConflict("synthetic grant requires a native attempt",
                                    code="grant_identity")
        attempt_digest = attempt_config_sha256(attempt)
        consumed = _read_arming_grants_unlocked()
        # The production clock is sampled only after the caller has acquired
        # RUNTIME_LOCK and immediately before validation/commit. A waiter may
        # not carry a pre-lock timestamp past expiry. Tests may inject either
        # a fixed numeric sample or a callable sampled at this same boundary.
        if now_monotonic is None:
            now_value = time.monotonic()
        elif callable(now_monotonic):
            now_value = now_monotonic()
        else:
            now_value = now_monotonic
        clean = validate_synthetic_grant(
            grant, expected_seat=ctx.seat,
            expected_attempt_id=ctx.attempt_id,
            attempt_sha256=attempt_digest,
            launch_mode=attempt["launch_mode"],
            expected_bindings=expected_bindings, boot_id=boot,
            now_monotonic=now_value)
        grant_id = clean["grant_id"]
        if grant_id in consumed:
            raise OwnershipConflict("synthetic grant was already consumed",
                                    code="grant_replay")
        if any(record.get("seat") == ctx.seat
               and record.get("attempt_id") == ctx.attempt_id
               and record.get("runtime_id") == ctx.runtime_id
               and record.get("generation") == ctx.generation
               for record in consumed.values()):
            raise OwnershipConflict("attempt already consumed a synthetic grant",
                                    code="grant_replay")
        record = {
            "grant_id": grant_id, "seat": ctx.seat,
            "attempt_id": ctx.attempt_id, "runtime_id": ctx.runtime_id,
            "generation": ctx.generation, "boot_id": boot,
            "operator": (rec.get("lease") or {}).get("operator") or RECOVERY_ACTOR,
            "consumed_at_monotonic": float(now_value),
            "grant_sha256": hashlib.sha256(json.dumps(
                clean, sort_keys=True, separators=(",", ":"),
                ensure_ascii=False).encode("utf-8")).hexdigest(),
            "bindings": dict(expected_bindings),
        }
        consumed[grant_id] = record
        _write_arming_grants_unlocked(consumed)
        return record

    out = _locked(_consume)
    _emit("synthetic_arming_grant_consumed", out["operator"], dict(out))
    return out


def canonical_attempt_config(config: Any, **validate_kwargs: Any) -> bytes:
    """The ONE deterministic serializer used independently by both processes."""
    clean = validate_attempt_config(config, **validate_kwargs)
    return json.dumps(clean, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False).encode("utf-8")


def attempt_config_sha256(config: Any, **validate_kwargs: Any) -> str:
    return hashlib.sha256(canonical_attempt_config(config, **validate_kwargs)).hexdigest()


def _verify_private_file(path: os.PathLike[str] | str, *, label: str) -> None:
    import stat
    try:
        st = os.lstat(path)
    except OSError as e:
        raise ValidationError(f"{label} is unavailable: {e}")
    if not stat.S_ISREG(st.st_mode) or stat.S_ISLNK(st.st_mode) \
            or st.st_uid != os.geteuid() or stat.S_IMODE(st.st_mode) != 0o600:
        raise ValidationError(
            f"{label} must be a non-symlink regular 0600 file owned by this uid")


def verify_credential_reference(path: Optional[str]) -> None:
    """Validate a server-resolved credential file without reading its secret."""
    if path is None:
        return
    _verify_private_file(path, label="credential reference")


def _load_credential_catalog() -> Dict[str, Dict[str, str]]:
    """Read the closed, private server catalog that maps ids to file refs."""
    import stat
    try:
        fd = os.open(
            CREDENTIAL_CATALOG_FILE,
            os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    except OSError as e:
        raise ValidationError(f"credential catalog is unavailable: {e}")
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_uid != os.geteuid() \
                or stat.S_IMODE(st.st_mode) != 0o600:
            raise ValidationError(
                "credential catalog must be a non-symlink regular 0600 file "
                "owned by this uid")
        if st.st_size > CREDENTIAL_CATALOG_MAX_BYTES:
            raise ValidationError("credential catalog exceeds its size bound")
        os.set_blocking(fd, True)
        chunks: List[bytes] = []
        total = 0
        while True:
            chunk = os.read(fd, min(65536, CREDENTIAL_CATALOG_MAX_BYTES + 1 - total))
            if not chunk:
                break
            chunks.append(chunk)
            total += len(chunk)
            if total > CREDENTIAL_CATALOG_MAX_BYTES:
                raise ValidationError("credential catalog exceeds its size bound")
        raw_bytes = b"".join(chunks)
    finally:
        os.close(fd)
    try:
        raw = json.loads(raw_bytes.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise ValidationError(f"credential catalog is unreadable: {e}")
    return _validate_credential_catalog_data(raw)


def _validate_credential_catalog_data(raw: Any) -> Dict[str, Dict[str, str]]:
    if not isinstance(raw, dict) or set(raw) != {"schema_version", "entries"} \
            or raw.get("schema_version") != CREDENTIAL_CATALOG_SCHEMA \
            or not isinstance(raw.get("entries"), dict):
        raise ValidationError("credential catalog must be the closed v1 envelope")
    clean: Dict[str, Dict[str, str]] = {}
    for credential_id, entry in raw["entries"].items():
        if not isinstance(credential_id, str) \
                or CREDENTIAL_ID_RE.fullmatch(credential_id) is None \
                or not isinstance(entry, dict) \
                or set(entry) != {"seat", "family", "credential_ref"}:
            raise ValidationError("credential catalog contains a malformed entry")
        catalog_seat = entry.get("seat")
        _validate_seat(catalog_seat)
        family = _normalized_family(entry.get("family"))
        if family is None or entry.get("family") != family:
            raise ValidationError(
                f"credential catalog entry {credential_id!r} has a non-canonical family")
        credential_ref = entry.get("credential_ref")
        if not isinstance(credential_ref, str) or not os.path.isabs(credential_ref) \
                or any(c in credential_ref for c in "\n\0"):
            raise ValidationError(
                f"credential catalog entry {credential_id!r} has an invalid reference")
        clean[credential_id] = {
            "seat": catalog_seat,
            "family": family,
            "credential_ref": credential_ref,
        }
    return clean


def provision_credential_catalog(entries: Dict[str, Dict[str, str]], *,
                                 owner: OwnerContext) -> Dict[str, Dict[str, str]]:
    """Operator-only catalog replace under the shared launch-identity fence.

    This is the sole supported writer.  The same fence is held continuously
    around the last live binding check and credential-consuming Popen, so a
    rotation is either wholly before that check or wholly after child spawn.
    """
    _require_owner(owner, "provision_credential_catalog")
    clean = _validate_credential_catalog_data({
        "schema_version": CREDENTIAL_CATALOG_SCHEMA,
        "entries": entries,
    })
    envelope = {
        "schema_version": CREDENTIAL_CATALOG_SCHEMA,
        "entries": clean,
    }
    with store.runtime_launch_fence():
        for entry in clean.values():
            verify_credential_reference(entry["credential_ref"])
        store.ensure_store()
        tmp = CREDENTIAL_CATALOG_FILE.with_name(
            f".{CREDENTIAL_CATALOG_FILE.name}.{secrets.token_hex(8)}.tmp")
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                     0o600)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", closefd=False) as out:
                json.dump(envelope, out, indent=2, ensure_ascii=False)
                out.flush()
                os.fsync(out.fileno())
            os.replace(tmp, CREDENTIAL_CATALOG_FILE)
        finally:
            os.close(fd)
            try:
                tmp.unlink()
            except FileNotFoundError:
                pass
    return clean


def resolve_credential_catalog_entry(
        seat: str, family: str, credential_id: Optional[str]
        ) -> tuple[Optional[str], Optional[str]]:
    """Resolve a public id (or unique Gemini default) to the private file ref."""
    _validate_seat(seat)
    clean_family = _normalized_family(family)
    if clean_family is None:
        raise ValidationError(f"unknown credential family {family!r}")
    if credential_id is None:
        if clean_family != "gemini":
            return None, None
        # Roster restore has no operator text field from which to recover an id
        # on a first/legacy Gemini launch.  The server may select only a UNIQUE
        # seat+family entry; ambiguity fails closed and requires an explicit id.
        matches = [
            (candidate_id, entry)
            for candidate_id, entry in _load_credential_catalog().items()
            if entry["seat"] == seat and entry["family"] == clean_family
        ]
        if len(matches) != 1:
            raise ValidationError(
                f"gemini seat {seat!r} needs exactly one catalog entry when no "
                f"credential id is supplied (found {len(matches)})")
        credential_id, entry = matches[0]
        verify_credential_reference(entry["credential_ref"])
        return credential_id, entry["credential_ref"]
    if not isinstance(credential_id, str) \
            or CREDENTIAL_ID_RE.fullmatch(credential_id) is None:
        raise ValidationError("credential id is not a closed catalog identifier")
    entry = _load_credential_catalog().get(credential_id)
    if entry is None:
        raise ValidationError(f"credential id {credential_id!r} is not provisioned")
    if entry["seat"] != seat or entry["family"] != clean_family:
        raise ValidationError(
            f"credential id {credential_id!r} is not provisioned for "
            f"{seat!r}/{clean_family}")
    verify_credential_reference(entry["credential_ref"])
    return credential_id, entry["credential_ref"]


def resolve_credential_catalog(seat: str, family: str,
                               credential_id: Optional[str]) -> Optional[str]:
    """Compatibility helper returning only the server-resolved file reference."""
    return resolve_credential_catalog_entry(seat, family, credential_id)[1]


def verify_credential_catalog_binding(config: Dict[str, Any]) -> None:
    """Re-resolve the live server catalog and compare it to the bound plan."""
    resolved_id, resolved = resolve_credential_catalog_entry(
        config["seat"], config["family"], config.get("credential_id"))
    if resolved_id != config.get("credential_id"):
        raise ValidationError(
            "attempt credential id differs from the live server catalog")
    if resolved != config.get("credential_ref"):
        raise ValidationError(
            "attempt credential reference differs from the live server catalog")


def validate_live_attempt_binding(
        config: Any, *, seat: str, spec: Dict[str, Any],
        participant: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """The one live native-attempt soundness primitive.

    Claim, post-GO/pre-spawn verification, promotion, and the read-only health
    projection all call this exact function. Participant revision and private
    credential-catalog binding therefore cannot be added to a mutation gate
    without also becoming doctor/resume-visible, or vice versa.
    """
    clean = validate_attempt_config(
        config, seat=seat, spec=spec, participant=participant)
    verify_credential_catalog_binding(clean)
    return clean


def launch_identity_fence():
    """Public context manager for check-through-spawn/commit fencing."""
    return store.runtime_launch_fence()


def _snapshot_family(snapshot: Any) -> Optional[str]:
    if not isinstance(snapshot, dict):
        return None
    cfg = snapshot.get("attempt_config")
    if isinstance(cfg, dict):
        family = _normalized_family(cfg.get("family"))
        if family is not None:
            return family
    spec = snapshot.get("spec")
    try:
        return model_family((spec or {}).get("model"))
    except ValidationError:
        return None


def resume_continuity_issue(rec: Dict[str, Any]) -> Optional[str]:
    """State-aware retained-handle continuity check for a claimable row."""
    active = rec.get("active")
    handle = active.get("handle") if isinstance(active, dict) else None
    if handle is None:
        return None
    retained_family = _snapshot_family(active)
    try:
        desired_family = model_family((rec.get("desired_config") or {}).get("model"))
    except ValidationError as e:
        return str(e)
    if retained_family is None:
        return "retained handle continuity family is unproven"
    if retained_family != desired_family:
        return (f"retained {retained_family} handle cannot resume as "
                f"{desired_family} without explicit transfer/NEW")
    return None


def _handle_identity(handle: Any) -> tuple[str, str]:
    clean = validate_handle(handle)
    return (clean["kind"], clean.get("canonical_target", clean["ref"]))


def _resume_handle_reservation_index(
        seats: Dict[str, Dict[str, Any]]) -> Dict[tuple[str, str], List[Dict[str, Any]]]:
    """Canonical index of every durable field that can retain handle ownership."""
    index: Dict[tuple[str, str], List[Dict[str, Any]]] = {}

    def add(seat: str, source: str, handle: Any, family: Optional[str]) -> None:
        if handle is None:
            return
        index.setdefault(_handle_identity(handle), []).append({
            "seat": seat, "source": source, "family": family,
        })

    for seat, rec in seats.items():
        if not isinstance(rec, dict):
            continue
        pending = rec.get("pending_attempt")
        if isinstance(pending, dict):
            family = _snapshot_family(pending)
            cfg = pending.get("attempt_config")
            add(seat, "pending_attempt.resume_handle",
                cfg.get("resume_handle") if isinstance(cfg, dict) else None, family)
            # A proven handle can land before promote and must reserve identity
            # just as strongly as the requested RESUME handle.
            add(seat, "pending_attempt.handle", pending.get("handle"), family)
        for source in ("active", "prior_active"):
            snapshot = rec.get(source)
            add(seat, f"{source}.handle",
                snapshot.get("handle") if isinstance(snapshot, dict) else None,
                _snapshot_family(snapshot))
    return index


def _reserved_resume_handle_owner(seats: Dict[str, Dict[str, Any]],
                                  requester: str,
                                  handle: Dict[str, str]) -> Optional[str]:
    """Return another seat retaining provenance for a canonical RESUME handle."""
    for entry in _resume_handle_reservation_index(seats).get(
            _handle_identity(handle), []):
        if entry["seat"] != requester:
            return entry["seat"]
    return None


def _same_seat_resume_family_conflict(
        seats: Dict[str, Dict[str, Any]], requester: str,
        handle: Dict[str, str], family: str) -> Optional[str]:
    """Return the retained incompatible continuity domain, if one exists."""
    retained = {
        entry.get("family")
        for entry in _resume_handle_reservation_index(seats).get(
            _handle_identity(handle), [])
        if entry["seat"] == requester and entry.get("family") is not None
    }
    if retained and family not in retained:
        return sorted(retained)[0]
    return None


def handle_provenance_issues(
        seat: str, seats: Dict[str, Dict[str, Any]]) -> List[str]:
    """Read-only projection of canonical cross-seat/family reservation drift."""
    issues: List[str] = []
    for entries in _resume_handle_reservation_index(seats).values():
        owned = [entry for entry in entries if entry["seat"] == seat]
        if not owned:
            continue
        others = sorted({entry["seat"] for entry in entries if entry["seat"] != seat})
        if others:
            issues.append(
                f"handle provenance overlaps seat(s) {', '.join(others)}")
        families = {entry.get("family") for entry in owned
                    if entry.get("family") is not None}
        if len(families) > 1:
            issues.append(
                f"same-seat handle provenance spans continuity families {sorted(families)}")
    return issues


def _valid_sha256(value: Any) -> bool:
    if not isinstance(value, str) or len(value) != 64:
        return False
    try:
        int(value, 16)
    except ValueError:
        return False
    return True


def _vendor_frame_payload(frame: Dict[str, Any]) -> bytes:
    payload = {k: frame[k] for k in sorted(_VENDOR_OBSERVED_KEYS - {"auth_tag"})}
    return json.dumps(payload, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False).encode("utf-8")


def derive_vendor_observed_key(attempt_token: str, attempt_sha256: str) -> bytes:
    """Derive a frame-only key; the host never receives the registry capability."""
    if not isinstance(attempt_token, str) or not attempt_token or not _valid_sha256(attempt_sha256):
        raise ValidationError("cannot derive vendor-observed key from malformed attempt identity")
    return hmac.new(attempt_token.encode("utf-8"),
                    ("vendor-observed-v1:" + attempt_sha256).encode("ascii"),
                    hashlib.sha256).digest()


def sign_vendor_observed(frame: Dict[str, Any], frame_key: bytes) -> str:
    if not isinstance(frame_key, bytes) or len(frame_key) != hashlib.sha256().digest_size:
        raise ValidationError("vendor-observed frame key must be a SHA-256-sized byte string")
    return hmac.new(frame_key, _vendor_frame_payload(frame), hashlib.sha256).hexdigest()


def validate_vendor_observed(frame: Any, *, seat: Optional[str] = None,
                             attempt_id: Optional[str] = None,
                             runtime_id: Optional[str] = None,
                             generation: Optional[int] = None,
                             attempt_sha256: Optional[str] = None,
                             resource: Optional[Dict[str, Any]] = None,
                             frame_key: Optional[bytes] = None) -> Dict[str, Any]:
    """Validate the bounded, one-frame pre-ACTIVE vendor identity contract.

    Persistence and process-tree/escapee proof are deliberately performed by
    the later adapter-host implementation slice.  This architecture contract
    makes their ordering unambiguous: host observation first; this authenticated
    vendor frame second; handle proof third; promotion last.
    """
    if not isinstance(frame, dict) or set(frame) != _VENDOR_OBSERVED_KEYS:
        raise ValidationError("VENDOR_OBSERVED frame has a non-closed shape")
    try:
        raw = json.dumps(frame, sort_keys=True, separators=(",", ":"),
                         ensure_ascii=False).encode("utf-8")
    except (TypeError, ValueError) as e:
        raise ValidationError(f"VENDOR_OBSERVED is not JSON-serializable: {e}")
    if len(raw) > VENDOR_OBSERVED_MAX_BYTES:
        raise ValidationError("VENDOR_OBSERVED frame exceeds the bounded size")
    if frame.get("schema_version") != VENDOR_OBSERVED_SCHEMA \
            or frame.get("type") != "VENDOR_OBSERVED":
        raise ValidationError("VENDOR_OBSERVED schema/type mismatch")
    _validate_seat(frame.get("seat"))
    for key in ("attempt_id", "runtime_id", "proc_birth", "protocol_version"):
        if not isinstance(frame.get(key), str) or not frame[key] \
                or any(c in frame[key] for c in "\n\0"):
            raise ValidationError(f"VENDOR_OBSERVED.{key} must be a clean non-empty string")
    gen, vendor_pid, pgid = frame.get("generation"), frame.get("vendor_pid"), frame.get("pgid")
    if isinstance(gen, bool) or not isinstance(gen, int) or gen <= 0:
        raise ValidationError("VENDOR_OBSERVED.generation must be a positive int")
    if _valid_pid(vendor_pid) is None or _valid_pid(pgid) is None:
        raise ValidationError("VENDOR_OBSERVED vendor_pid/pgid must be positive ints")
    if not _valid_sha256(frame.get("attempt_sha256")):
        raise ValidationError("VENDOR_OBSERVED.attempt_sha256 must be a SHA-256 hex digest")
    if not isinstance(frame.get("resource"), dict) \
            or set(frame["resource"]) != {"kind", "value"}:
        raise ValidationError("VENDOR_OBSERVED.resource must be a closed ResourceTag")
    clean_resource = validate_resource(frame.get("resource"))
    if frame.get("transport_kind") not in VENDOR_TRANSPORTS:
        raise ValidationError(f"VENDOR_OBSERVED transport must be one of {VENDOR_TRANSPORTS}")
    if not _valid_sha256(frame.get("auth_tag")):
        raise ValidationError("VENDOR_OBSERVED.auth_tag must be a SHA-256 HMAC")
    expected = (("seat", seat), ("attempt_id", attempt_id), ("runtime_id", runtime_id),
                ("generation", generation), ("attempt_sha256", attempt_sha256))
    for key, value in expected:
        if value is not None and frame.get(key) != value:
            raise ValidationError(f"VENDOR_OBSERVED.{key} is not this attempt")
    if resource is not None and clean_resource != validate_resource(resource):
        raise ValidationError("VENDOR_OBSERVED.resource is not the predeclared resource")
    # pgid is the ACTUAL post-Popen membership.  It may differ from the
    # predeclared process-group resource when the vendor immediately setsid;
    # record_vendor_observed then persists pid+birth as an escapee before any
    # handle or promotion is legal.
    if frame_key is not None:
        want = sign_vendor_observed(frame, frame_key)
        if not hmac.compare_digest(frame["auth_tag"], want):
            raise ValidationError("VENDOR_OBSERVED authentication failed")
    return {**frame, "resource": clean_resource}


def _handle_frame_payload(frame: Dict[str, Any]) -> bytes:
    keys = _HANDLE_ATTESTATION_KEYS if frame.get("schema_version") == 2 \
        else _HANDLE_ATTESTATION_KEYS_V1
    payload = {k: frame[k] for k in sorted(keys - {"auth_tag"})}
    return json.dumps(payload, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode("utf-8")


def sign_handle_attestation(frame: Dict[str, Any], frame_key: bytes) -> str:
    if not isinstance(frame_key, bytes) or len(frame_key) != hashlib.sha256().digest_size:
        raise ValidationError("handle-attestation key must be a SHA-256-sized byte string")
    return hmac.new(frame_key, _handle_frame_payload(frame), hashlib.sha256).hexdigest()


def validate_handle_assurance(value: Any, *, launch_mode: Optional[str] = None,
                              family: Optional[str] = None) -> Dict[str, Any]:
    """Validate the typed, deliberately limited SDK-host proof taxonomy.

    This value says which facts the supervisor independently checked and names
    the 0.2.123 encapsulation residual.  It must never be interpreted as a
    vendor signature over the NEW session id or as satisfying B10.
    """
    if not isinstance(value, dict) or set(value) != _HANDLE_ASSURANCE_KEYS:
        raise ValidationError("handle assurance has a non-closed shape")
    source = value.get("source")
    if source not in _HANDLE_ASSURANCE_SOURCES:
        raise ValidationError("handle assurance source is not a closed SDK-host source")
    if family is not None and source != f"{family}_sdk_host_observation":
        raise ValidationError("handle assurance source crossed adapter families")
    if value.get("session_id_assurance") != rhc.SESSION_ID_ASSURANCE:
        raise ValidationError("handle assurance overclaims session-id provenance")
    if value.get("residual_gate") != "B10" \
            or value.get("residual") != rhc.SESSION_ID_RESIDUAL:
        raise ValidationError("handle assurance omits the named B10 residual")
    facts = value.get("independently_verified")
    if not isinstance(facts, list) or not all(isinstance(v, str) for v in facts) \
            or facts != sorted(set(facts)):
        raise ValidationError(
            "handle assurance independently_verified must be a sorted unique list")
    fact_set = frozenset(facts)
    allowed = _HANDLE_INDEPENDENT_BASE | {"resume_requested_equality"}
    if not _HANDLE_INDEPENDENT_BASE <= fact_set or not fact_set <= allowed:
        raise ValidationError("handle assurance independently_verified set is invalid")
    if launch_mode == "NEW" and "resume_requested_equality" in fact_set:
        raise ValidationError("NEW handle assurance cannot claim RESUME equality")
    if launch_mode == "RESUME" and "resume_requested_equality" not in fact_set:
        raise ValidationError("RESUME handle assurance must record requested equality")
    return {
        "source": source,
        "session_id_assurance": rhc.SESSION_ID_ASSURANCE,
        "independently_verified": facts,
        "residual_gate": "B10",
        "residual": rhc.SESSION_ID_RESIDUAL,
    }


def validate_handle_attestation(frame: Any, *, seat: Optional[str] = None,
                                attempt_id: Optional[str] = None,
                                runtime_id: Optional[str] = None,
                                generation: Optional[int] = None,
                                attempt_sha256: Optional[str] = None,
                                frame_key: Optional[bytes] = None) -> Dict[str, Any]:
    """Validate the vendor-specific external/exclusive handle proof.

    Registry reservation prevents two local claims from racing, but it cannot
    prove the vendor accepted RESUME for that exact session or that another
    adapter host does not own it.  The later implementation must persist this
    authenticated proof after VENDOR_OBSERVED and before record_handle.
    """
    schema = frame.get("schema_version") if isinstance(frame, dict) else None
    keys = _HANDLE_ATTESTATION_KEYS if schema == HANDLE_ATTESTATION_SCHEMA \
        else _HANDLE_ATTESTATION_KEYS_V1 if schema == 1 else None
    if keys is None or not isinstance(frame, dict) or set(frame) != keys:
        raise ValidationError("HANDLE_ATTESTATION frame has a non-closed shape")
    try:
        raw = json.dumps(frame, sort_keys=True, separators=(",", ":"),
                         ensure_ascii=False).encode("utf-8")
    except (TypeError, ValueError) as e:
        raise ValidationError(f"HANDLE_ATTESTATION is not JSON-serializable: {e}")
    if len(raw) > HANDLE_ATTESTATION_MAX_BYTES:
        raise ValidationError("HANDLE_ATTESTATION frame exceeds the bounded size")
    if frame.get("schema_version") not in (1, HANDLE_ATTESTATION_SCHEMA) \
            or frame.get("type") != "HANDLE_ATTESTATION":
        raise ValidationError("HANDLE_ATTESTATION schema/type mismatch")
    _validate_seat(frame.get("seat"))
    for key in ("attempt_id", "runtime_id", "proof_ref"):
        if not isinstance(frame.get(key), str) or not frame[key] \
                or any(c in frame[key] for c in "\n\0"):
            raise ValidationError(f"HANDLE_ATTESTATION.{key} must be a clean string")
    gen = frame.get("generation")
    if isinstance(gen, bool) or not isinstance(gen, int) or gen <= 0:
        raise ValidationError("HANDLE_ATTESTATION.generation must be a positive int")
    if not _valid_sha256(frame.get("attempt_sha256")):
        raise ValidationError("HANDLE_ATTESTATION.attempt_sha256 must be SHA-256 hex")
    if not isinstance(frame.get("handle"), dict):
        raise ValidationError("HANDLE_ATTESTATION.handle must be an object")
    # validate_handle owns the kind-dependent closed shape: UUID handles carry
    # {kind,ref}; session_file additionally carries its persisted
    # canonical_target.  A second fixed-key gate here would make the two
    # validators structurally inconsistent.
    clean_handle = validate_handle(frame.get("handle"))
    if frame.get("exclusive") is not True:
        raise ValidationError("HANDLE_ATTESTATION must prove exclusive ownership")
    if frame.get("proof_kind") not in HANDLE_PROOF_KINDS:
        raise ValidationError(f"HANDLE_ATTESTATION proof_kind must be one of {HANDLE_PROOF_KINDS}")
    assurance = None
    if schema == HANDLE_ATTESTATION_SCHEMA:
        assurance = validate_handle_assurance(frame.get("assurance"))
    if not _valid_sha256(frame.get("auth_tag")):
        raise ValidationError("HANDLE_ATTESTATION.auth_tag must be a SHA-256 HMAC")
    expected = (("seat", seat), ("attempt_id", attempt_id),
                ("runtime_id", runtime_id), ("generation", generation),
                ("attempt_sha256", attempt_sha256))
    for key, value in expected:
        if value is not None and frame.get(key) != value:
            raise ValidationError(f"HANDLE_ATTESTATION.{key} is not this attempt")
    if frame_key is not None:
        want = sign_handle_attestation(frame, frame_key)
        if not hmac.compare_digest(frame["auth_tag"], want):
            raise ValidationError("HANDLE_ATTESTATION authentication failed")
    return {**frame, "handle": clean_handle,
            **({"assurance": assurance} if assurance is not None else {})}


def _int_or_none(v: Any) -> Optional[int]:
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def validate_resource(resource: Any) -> Dict[str, Any]:
    if not isinstance(resource, dict):
        raise ValidationError("ResourceTag must be an object")
    kind, value = resource.get("kind"), resource.get("value")
    if kind not in RESOURCE_KINDS:
        raise ValidationError(f"resource.kind must be one of {RESOURCE_KINDS}, got {kind!r}")
    if not isinstance(value, str) or not value or any(c in value for c in "\n\0"):
        raise ValidationError("resource.value must be a clean non-empty string")
    if kind == "session_dir" and not os.path.isabs(value):
        raise ValidationError("session_dir resource must be an absolute path")
    if kind == "process_group" and _valid_pid(_int_or_none(value)) is None:
        raise ValidationError("process_group resource must be a positive integer pgid")
    clean = {"kind": kind, "value": value}
    if kind == "tmux_pane":
        socket_path = resource.get("socket_path")
        if not isinstance(socket_path, str) or not os.path.isabs(socket_path) \
                or any(c in socket_path for c in "\n\0") \
                or os.path.normpath(socket_path) != socket_path:
            raise ValidationError(
                "tmux_pane resource requires a normalized absolute socket_path")
        clean["socket_path"] = socket_path
    return clean


def _emit(kind: str, actor: str, payload: Dict[str, Any]) -> None:
    try:
        ledger.emit(kind, actor_id=actor, payload=payload)
    except Exception:
        pass  # receipts mirror, never decide


def _require_owner(ctx: Any, what: str) -> OwnerContext:
    if not isinstance(ctx, OwnerContext):
        raise PermissionError(f"{what} requires a verified OwnerContext")
    return ctx


def _require_sup(ctx: Any, seat: str) -> SupervisorContext:
    if not isinstance(ctx, SupervisorContext) or ctx.seat != seat:
        raise PermissionError("attempt-advancing calls require the claim-minted "
                              "SupervisorContext for this seat")
    return ctx


def _sup_matches(ctx: SupervisorContext, rec: Dict[str, Any]) -> bool:
    pend, lease = rec.get("pending_attempt"), rec.get("lease")
    if not pend or not lease:
        return False
    return (pend.get("attempt_id") == ctx.attempt_id
            and pend.get("runtime_id") == ctx.runtime_id
            and pend.get("generation") == ctx.generation
            and lease.get("token_sha256") == hashlib.sha256(ctx.token.encode()).hexdigest())


def _require_live_supervisor(rec: Dict[str, Any], seat: str, this_boot: Optional[str]) -> None:
    """A STARTING attempt may only be ADVANCED / its heartbeat REFRESHED by a
    supervisor whose recorded incarnation is still alive (r27 Bugbot). Otherwise
    a launcher retry loop calling record_observed/record_handle after the
    supervisor+child are gone would keep the lease heartbeat fresh and starve
    sweep_stale, leaving a dead STARTING row until manual intervention. A dead
    incarnation ⇒ refuse; the row then goes stale and recovery reclaims it.

    `this_boot` is the current host boot id, computed by the CALLER BEFORE taking
    the registry lock (r29 reviewer MED#2) — the reboot epoch cannot change within
    a call, so the sysctl/boot probe must not run under the global flock. None
    (probe unavailable) ⇒ fail closed."""
    lease = rec.get("lease") or {}
    # BOOT EPOCH (r28 reviewer MED#2): pid+birth alone let a recycled PID with a
    # matching rendered birth string after a reboot/clock reset refresh a
    # prior-boot STARTING row. A lease from another boot cannot be the current
    # holder (flocks/pids/pgids don't survive a reboot).
    if this_boot is None or lease.get("boot_id") != this_boot:
        raise OwnershipConflict(
            f"seat {seat!r} lease is from another boot — refusing to advance/refresh a "
            f"prior-boot attempt", code="boot_mismatch")
    if not _proc_identity_ok(_valid_pid(lease.get("supervisor_pid")), lease.get("proc_birth")):
        raise OwnershipConflict(
            f"seat {seat!r} supervisor incarnation is gone — refusing to advance a "
            f"dead attempt (heartbeat not refreshed; recovery may reclaim)",
            code="supervisor_identity")


def _parse_iso(value: Any):
    """A bounded, parseable, TIMEZONE-AWARE ISO timestamp or None (r13 MED#8;
    r20 reviewer MED#5). A tz-NAIVE string parses fine but is uncomparable to the
    always-aware store.now_iso() — subtracting them raises TypeError, which one
    foreign-written naive heartbeat would turn into a wholesale sweep_stale
    crash inside _locked (every OTHER seat's recovery aborts). Rejecting naive
    here makes _check_record fail loud on it (an uncomparable clock is as bad as
    an unparseable one) and keeps _stale_iso total."""
    from datetime import datetime
    try:
        ts = datetime.fromisoformat(str(value))
    except (ValueError, TypeError):
        return None
    if ts.tzinfo is None or ts.tzinfo.utcoffset(ts) is None:
        return None                           # tz-naive ⇒ uncomparable ⇒ reject
    return ts


def _stale_iso(value: Any, within: float) -> bool:
    """True if the timestamp is stale — unparseable/naive, older than `within`,
    OR set in the FUTURE beyond a small clock-skew grace (r30 Bugbot). A
    heartbeat can only legitimately be in the PAST (store.now_iso() is the same
    host clock); one set far ahead (hand edit, migration, clock reset) is
    corrupt and must NOT read as 'fresh' forever — that would wedge sweep_stale /
    intent supersede on a dead row. An unreadable/future clock is as bad as an
    old one; both are stale, never fresh."""
    from datetime import datetime
    ts = _parse_iso(value)
    if ts is None:
        return True
    age = (datetime.now().astimezone() - ts).total_seconds()
    return age > within or age < -CLOCK_SKEW_GRACE_SEC


def _heartbeat_fresh(lease: Dict[str, Any], within: float = STALE_ATTEMPT_SEC) -> bool:
    return not _stale_iso(lease.get("heartbeat"), within)


# --------------------------------------------------------------------------
# reads + desired config
# --------------------------------------------------------------------------

def get_seat(seat: str) -> Optional[Dict[str, Any]]:
    return _locked(_read_unlocked).get(seat)


def list_seats() -> List[Dict[str, Any]]:
    seats = _locked(_read_unlocked)
    return [dict(rec, seat=name) for name, rec in sorted(seats.items())]


def runtime_soundness_core(rec: Dict[str, Any], *,
                           participants: Optional[Dict[str, Dict[str, Any]]] = None,
                           seats: Optional[Dict[str, Dict[str, Any]]] = None,
                           this_boot: Optional[str] = None,
                           store_dir: Optional[str] = None,
                           action: Optional[str] = None,
                           action_context: Optional[Dict[str, Any]] = None
                           ) -> Dict[str, List[str]]:
    """Return every registered normalized fact; policy decides applicability."""
    if action is not None and action not in RUNTIME_ACTION_POLICIES:
        raise AssertionError(f"unknown runtime soundness action {action!r}")
    action_context = action_context or {}
    facts: Dict[str, List[str]] = {name: [] for name in RUNTIME_SOUNDNESS_FACTS}

    def add(name: str, message: str) -> None:
        if name not in facts:
            raise AssertionError(f"unregistered runtime soundness fact {name!r}")
        facts[name].append(message)

    if action is not None:
        supplied_inputs = {"participants": participants, "seats": seats}
        for fact, input_name in RUNTIME_ACTION_FACT_INPUTS.items():
            if fact in RUNTIME_ACTION_POLICIES[action] \
                    and supplied_inputs[input_name] is None:
                add(fact,
                    f"{action} cannot evaluate {fact}: required {input_name} input missing")

    seat = rec.get("seat")
    state = rec.get("launch_state")
    lease = rec.get("lease")
    active = rec.get("active")
    desired = rec.get("desired_config") or {}
    boot = host_boot_id() if this_boot is None else this_boot
    durable_dir = str(store.STORE_DIR) if store_dir is None else store_dir
    participant = participants.get(seat) if participants is not None else None
    try:
        _validate_seat(seat)
        seat_valid = True
    except ValidationError:
        seat_valid = False
        add("schema_state", "record has no valid seat identity")
    if state not in (None, "STARTING", "ACTIVE", "STOPPING", "STOPPED", "FAILED"):
        add("schema_state", f"unknown launch_state {state!r}")
    expected_states = {
        "emit_claim_intent": (None, "STOPPED", "FAILED"),
        "claim": (None, "STOPPED", "FAILED"),
        "verify_capability": ("STARTING",),
        "promote": ("STARTING",),
        "finish_stop": ("STOPPING",),
        "finalize_failed": ("FAILED",),
    }
    if action in expected_states and state not in expected_states[action]:
        add("schema_state",
            f"{action} requires launch_state in {expected_states[action]!r}, got {state!r}")
    if desired.get("management") == "in_app":
        add("management_authority",
            "seat is in_app/EXTERNALLY_MANAGED and cannot be server-claimed")
    if participants is not None and seat not in participants:
        add("participant_presence", "no participants.json entry (roster↔participants drift)")
    if seats is not None and isinstance(seat, str):
        for issue in handle_provenance_issues(seat, seats):
            add("handle_provenance", issue)
    if state in (None, "STOPPED", "FAILED") \
            and action not in ("finish_stop", "finalize_failed"):
        for name, issue in _claimable_terminal_soundness_issues(rec).items():
            add(name, issue)
        intent = rec.get("intent")
        if isinstance(intent, dict) and intent.get("state") == "OPEN" \
                and not _stale_iso(intent.get("heartbeat"), STALE_ATTEMPT_SEC):
            add("live_open_intent",
                f"live OPEN intent {intent.get('attempt_id')!r} already owns prelaunch")
        explicit_new = (action == "claim"
                        and isinstance(action_context.get("attempt_config"), dict)
                        and action_context["attempt_config"].get("launch_mode") == "NEW")
        if (state != "FAILED" or lease is None) and not explicit_new:
            continuity = resume_continuity_issue(rec)
            if continuity is not None:
                add("resume_continuity", f"resume continuity mismatch: {continuity}")
    if action == "claim":
        candidate = action_context.get("attempt_config")
        claim_ready = action_context.get("ready")
        claim_intent = action_context.get("intent_context")
        claim_owner = action_context.get("owner_context")
        row_intent = rec.get("intent")
        if not isinstance(claim_intent, IntentContext) \
                or not isinstance(claim_owner, OwnerContext) \
                or claim_intent.seat != seat \
                or claim_intent.operator != claim_owner.operator \
                or not isinstance(row_intent, dict) \
                or row_intent.get("state") != "OPEN" \
                or row_intent.get("attempt_id") != getattr(claim_intent, "attempt_id", None) \
                or row_intent.get("intent_id") != getattr(claim_intent, "intent_id", None) \
                or row_intent.get("operator") != claim_intent.operator:
            add("claim_intent_binding",
                "claim capability does not own this exact OPEN intent")
        if rec.get("desired_config") is None:
            add("schema_state", "claim requires a desired_config")
        if boot is None:
            add("live_ownership", "claim host boot identity is unprobeable")
        if candidate is not None:
            try:
                bound = validate_live_attempt_binding(
                    candidate, seat=seat, spec=rec.get("desired_config"),
                    participant=participant if participants is not None else None)
            except ValidationError as e:
                add("live_attempt_binding", f"claim attempt configuration drift: {e}")
            else:
                if hasattr(claim_ready, "get") and claim_ready.get("attempt_sha256") \
                        != attempt_config_sha256(bound):
                    add("live_attempt_binding",
                        "claim READY launch digest does not match the canonical plan")
                resume_handle = bound.get("resume_handle")
                if bound.get("launch_mode") == "RESUME" and resume_handle is not None \
                        and seats is not None:
                    owner = _reserved_resume_handle_owner(seats, seat, resume_handle)
                    if owner is not None:
                        add("handle_provenance",
                            f"resume handle is reserved by seat {owner!r}")
                    retained_family = _same_seat_resume_family_conflict(
                        seats, seat, resume_handle, bound["family"])
                    if retained_family is not None:
                        add("resume_continuity",
                            f"resume handle belongs to retained {retained_family!r} "
                            f"continuity, not requested {bound['family']!r}")
        elif hasattr(claim_ready, "get") and claim_ready.get("attempt_sha256") is not None:
            add("live_attempt_binding",
                "claim READY launch digest names an unclaimed native plan")
        supervisor = action_context.get("supervisor_handle")
        ready = claim_ready
        if supervisor is not None:
            if not isinstance(supervisor, SupervisorHandle) \
                    or supervisor.popen.poll() is not None:
                add("live_ownership", "claim supervisor process has exited")
            if not hasattr(ready, "get"):
                add("live_ownership", "claim has no bound READY identity")
            else:
                if probe_seat_lock_free(seat):
                    add("live_ownership", "claim lifetime lock not held")
                attestation = read_lock_attestation(seat)
                resource = action_context.get("resource")
                if attestation is None or any(
                        attestation.get(key) != ready.get(key) for key in
                        ("pid", "proc_birth", "boot_id", "nonce", "runtime_id",
                         "lease_id", "attempt_sha256")) \
                        or attestation.get("resource") != resource:
                    add("live_ownership", "claim lock attestation drifts from READY")
                if not _proc_identity_ok(
                        _valid_pid(ready.get("pid")), ready.get("proc_birth")):
                    add("live_ownership", "claim supervisor incarnation is not provably live")
                if boot is None or ready.get("boot_id") != boot:
                    add("live_ownership", "claim READY is from another boot")
    if action in ("verify_capability", "promote"):
        ctx = action_context.get("supervisor_ctx")
        if not isinstance(ctx, SupervisorContext) or not _sup_matches(ctx, rec):
            add("live_ownership", f"{action} capability does not match the live attempt")
        if not isinstance(rec.get("pending_attempt"), dict) \
                or not rec["pending_attempt"].get("go_sent"):
            add("live_ownership", f"{action} requires an accepted durable GO")
    if state in ("STARTING", "ACTIVE", "STOPPING") \
            and action not in ("finish_stop", "finalize_failed"):
        if not isinstance(lease, dict):
            add("live_ownership", f"{state} with no lease (lost ownership record)")
        else:
            if boot is None:
                add("live_ownership", f"{state} host boot identity is unprobeable")
            elif lease.get("boot_id") != boot:
                add("live_ownership", f"{state} lease from another boot — reboot recovery needed")
            final_supervisor_live = action_context.get("final_supervisor_live")
            supervisor_live = (final_supervisor_live
                               if action == "promote"
                               and isinstance(final_supervisor_live, bool)
                               else _proc_identity_ok(
                                   _valid_pid(lease.get("supervisor_pid")),
                                   lease.get("proc_birth")))
            if not supervisor_live:
                add("live_ownership",
                    f"{state} supervisor incarnation is not provably live")
            if seat_valid:
                final_lock_held = action_context.get("final_lock_held")
                lock_free = (not final_lock_held
                             if action == "promote" and isinstance(final_lock_held, bool)
                             else probe_seat_lock_free(seat))
                if lock_free:
                    add("live_ownership",
                        f"{state} lifetime lock not held (unprovable lease)")
                else:
                    att = read_lock_attestation(seat)
                    snap = rec.get("pending_attempt") if state == "STARTING" else active
                    expected_resource = snap.get("resource") if isinstance(snap, dict) else None
                    expected = {
                        "pid": lease.get("supervisor_pid"),
                        "proc_birth": lease.get("proc_birth"),
                        "boot_id": lease.get("boot_id"), "nonce": lease.get("nonce"),
                        "runtime_id": lease.get("runtime_id"),
                        "lease_id": lease.get("lease_id"),
                        "attempt_sha256": lease.get("attempt_sha256"),
                    }
                    if att is None or any(att.get(k) != v for k, v in expected.items()) \
                            or (expected_resource is not None
                                and att.get("resource") != expected_resource):
                        add("live_ownership",
                            f"{state} lock holder attestation drifts from lease")
            if not _heartbeat_fresh(lease):
                suffix = " — stuck STOPPING" if state == "STOPPING" else ""
                add("live_ownership", f"{state} lease heartbeat stale{suffix}")
    if state == "STARTING":
        pending = rec.get("pending_attempt")
        attempt_cfg = pending.get("attempt_config") if isinstance(pending, dict) else None
        if attempt_cfg is not None:
            try:
                validate_live_attempt_binding(
                    attempt_cfg, seat=seat, spec=pending.get("spec"),
                    participant=participant if participants is not None else None)
            except ValidationError as e:
                add("live_attempt_binding", f"STARTING attempt configuration drift: {e}")
    live_snapshot = (active if state == "ACTIVE" else
                     rec.get("pending_attempt") if action == "promote" else None)
    live_label = "ACTIVE" if state == "ACTIVE" else "promotion candidate"
    if live_snapshot is not None:
        if not isinstance(live_snapshot, dict):
            add("schema_state", f"{live_label} snapshot is not an object")
        else:
            handle = live_snapshot.get("handle")
            if handle is None:
                add("active_handle", f"{live_label} without a proven handle")
            obs = live_snapshot.get("observed_runtime") or {}
            host_pid = _valid_pid(obs.get("child_pid"))
            if not _proc_identity_ok(host_pid, obs.get("child_birth")):
                add("observed_resource",
                    f"{live_label} observed adapter/child incarnation is not provably live")
            else:
                try:
                    host_resource = validate_resource(obs.get("resource"))
                except ValidationError:
                    host_resource = None
                if host_resource is None \
                        or not _resource_membership_ok(
                            host_pid, host_resource, seat=seat,
                            participants=participants):
                    add("observed_resource",
                        f"{live_label} observed adapter/child resource membership is unproven")
            attempt_cfg = live_snapshot.get("attempt_config")
            cfg = None
            if attempt_cfg is not None:
                try:
                    cfg = validate_live_attempt_binding(
                        attempt_cfg, seat=seat, spec=live_snapshot.get("spec"),
                        participant=participant if participants is not None else None)
                except ValidationError as e:
                    add("live_attempt_binding",
                        f"{live_label} attempt configuration drift: {e}")
                if cfg is not None:
                    if obs.get("work_dir") != cfg["work_dir"]:
                        add("workspace_store",
                            f"{live_label} observed workspace differs from claimed work_dir")
                    if obs.get("store_dir") != cfg["store_dir"]:
                        add("workspace_store",
                            f"{live_label} observed store differs from claimed store_dir")
                    if cfg["store_dir"] != durable_dir:
                        add("workspace_store",
                            f"{live_label} store_dir {cfg['store_dir']!r} "
                            f"!= current store {durable_dir!r}")
                vendor = live_snapshot.get("vendor_observed") or {}
                vendor_pid = _valid_pid(vendor.get("vendor_pid"))
                if not _proc_identity_ok(vendor_pid, vendor.get("proc_birth")):
                    add("vendor_identity",
                        f"{live_label} vendor incarnation is not provably live")
                declared = live_snapshot.get("resource") or obs.get("resource")
                try:
                    declared = validate_resource(declared)
                except ValidationError:
                    declared = None
                if declared is not None and declared["kind"] == "process_group":
                    in_group = (vendor_pid is not None
                                and _resource_membership_ok(vendor_pid, declared))
                    escape_pair = {"pid": vendor_pid, "birth": vendor.get("proc_birth")}
                    escape_rows = ((rec.get("escapees") or {}).get("entries")
                                   if isinstance(rec.get("escapees"), dict) else [])
                    if not in_group and escape_pair not in escape_rows:
                        add("vendor_identity",
                            f"{live_label} vendor is outside its group without durable "
                            f"escapee identity")
                if action == "promote":
                    attestation = live_snapshot.get("handle_attestation")
                    try:
                        attested = validate_handle_attestation(attestation)["handle"]
                    except (ValidationError, TypeError):
                        add("active_handle",
                            "promotion candidate lacks a valid exclusive handle attestation")
                    else:
                        if handle is None or not _handles_equal(attested, handle):
                            add("active_handle",
                                "promotion candidate handle attestation does not match handle")
            else:
                # Legacy S-A rows may carry observations from before the native
                # schema.  Validate either dimension when present, without
                # conflating desired workspace with the store directory.
                if obs.get("work_dir") is not None \
                        and obs.get("work_dir") != desired.get("work_dir"):
                    add("workspace_store",
                        "ACTIVE observed workspace differs from desired work_dir")
                if obs.get("store_dir") is not None and obs.get("store_dir") != durable_dir:
                    add("workspace_store", "ACTIVE observed store differs from current store")
    if action in ("finish_stop", "finalize_failed"):
        terminal_lock_held = action_context.get("terminal_lock_held") is True
        terminal_snapshot = active if action == "finish_stop" else (
            rec.get("pending_attempt") or rec.get("active"))
        if isinstance(lease, dict):
            if not terminal_lock_held:
                add("live_ownership", f"{action} has not acquired the lifetime lock")
            if not _incarnation_gone(lease.get("supervisor_pid"),
                                     lease.get("proc_birth")):
                add("live_ownership", f"{action} supervisor is not provably gone")
            resource = ((terminal_snapshot or {}).get("observed_runtime") or {}).get("resource")
            if action == "finalize_failed":
                resource = (terminal_snapshot or {}).get("resource") or resource
            if not _child_gone(
                    (terminal_snapshot or {}).get("observed_runtime"), resource):
                add("observed_resource",
                    f"{action} child/resource teardown is not proven")
            if not _escapees_gone(rec):
                add("terminal_escapees_clear",
                    f"{action} escaped-descendant teardown is not proven")
        elif action == "finish_stop":
            add("live_ownership", "finish_stop has no usable lease identity")
        elif rec.get("escapees") is not None:
            add("terminal_escapees_clear",
                "finalize_failed must not clear a lease-less retained escapee set")
    return facts


def _runtime_state_policy(rec: Dict[str, Any]) -> frozenset[str]:
    state = rec.get("launch_state")
    if state == "FAILED" and rec.get("lease") is not None:
        return RUNTIME_STATE_POLICIES["FAILED_DIRTY"]
    if state in (None, "STOPPED", "FAILED"):
        return RUNTIME_STATE_POLICIES["CLAIMABLE"]
    return RUNTIME_STATE_POLICIES.get(state, frozenset({"schema_state"}))


def runtime_health_issues(rec: Dict[str, Any], **kwargs: Any) -> List[str]:
    """State-aware read-only projection of the single named soundness core."""
    facts = runtime_soundness_core(rec, **kwargs)
    return [message for name in _runtime_state_policy(rec)
            for message in facts[name]]


def _empty_record() -> Dict[str, Any]:
    return {"desired_config": None, "active": None, "pending_attempt": None,
            "prior_active": None, "lease": None, "launch_state": None,
            "intent": None, "gen_counter": 0, "exit": None,
            "created": store.now_iso(), "updated": store.now_iso()}


def set_desired_config(seat: str, spec: Dict[str, Any], *, owner: OwnerContext) -> Dict[str, Any]:
    """The operator-owned source of truth claim() reads. Never touches ownership."""
    _require_owner(owner, "set_desired_config")
    _validate_seat(seat)
    clean = validate_spec(spec)

    def _set():
        seats = _read_unlocked()
        rec = seats.setdefault(seat, _empty_record())
        rec["desired_config"] = clean
        rec["updated"] = store.now_iso()
        _write_unlocked(seats)
        return dict(rec, seat=seat)

    return _locked(_set)


def rollback_spec(seat: str, source: str, *, owner: OwnerContext) -> Dict[str, Any]:
    """The rollback rule's code path (design §6b): copy the chosen snapshot's
    FULL spec back into desired_config — pre-promote failure rolls back from
    `active`, post-promote regression from `prior_active`. Always followed by
    an ordinary claim through the same state machine."""
    _require_owner(owner, "rollback_spec")
    if source not in ("active", "prior_active"):
        raise ValidationError("rollback source must be 'active' or 'prior_active'")

    def _rb():
        seats = _read_unlocked()
        rec = seats.get(seat)
        snap = (rec or {}).get(source)
        if snap is None:
            raise OwnershipConflict(f"seat {seat!r} has no {source} snapshot to roll back to")
        rec["desired_config"] = snap["spec"]
        rec["updated"] = store.now_iso()
        _write_unlocked(seats)
        return dict(rec, seat=seat)

    return _locked(_rb)


# --------------------------------------------------------------------------
# the launch state machine (§3)
# --------------------------------------------------------------------------

@_soundness_action("claim")
def claim(seat: str, *, owner: OwnerContext, supervisor: SupervisorHandle,
          intent: IntentContext,
          attempt_config: Optional[Dict[str, Any]] = None) -> SupervisorContext:
    """§3 step 2 (CAS). The launcher has already: emitted the DURABLE intent
    (emit_claim_intent → IntentContext), spawned the BLOCKED supervisor, and
    attached it (READY carries the predeclared resource). claim CONSUMES the
    OPEN intent exactly once — atomically with the STARTING commit (r13 CRIT#1:
    a bare attempt_id proved nothing) — and returns the capability; the
    launcher then send_go()s. The supervisor spawns NO vendor child until GO,
    so a refusal here + the caller's abort_supervisor()/abort_intent() leaves
    zero vendor process (r12 CRIT#1).

    The resource comes from the attested READY, never a separate arg. Boot id
    fails CLOSED. gen_counter is consumed once the seat is CLAIMABLE (state +
    config + OPEN-intent preconditions pass), even if identity checks then
    refuse — 'consumed regardless of outcome' (r11 Bugbot MED). The intent, by
    contrast, is consumed ONLY on the STARTING commit, so a refused claim
    leaves the OPEN intent legitimately retryable."""
    _require_owner(owner, "claim")
    _validate_seat(seat)
    if not isinstance(supervisor, SupervisorHandle):
        raise PermissionError("claim requires the launcher-bound SupervisorHandle")
    if not isinstance(intent, IntentContext) or intent.seat != seat \
            or intent.operator != owner.operator:
        raise PermissionError(
            "claim requires this seat's IntentContext from emit_claim_intent, "
            "minted by the SAME owner")
    attempt_id = intent.attempt_id
    ready = supervisor.ready
    sup_pid = _valid_pid(ready.get("pid"))
    clean_resource = validate_resource(ready.get("resource"))
    # This validation is intentionally independent from the supervisor process's
    # fork-time parse.  It checks the launcher-owned object but does not trust or
    # reuse the digest READY carried.
    clean_attempt = (validate_attempt_config(attempt_config, seat=seat)
                     if attempt_config is not None else None)
    token = secrets.token_hex(24)
    this_boot = host_boot_id()
    burned = {"gen": None}                     # the generation once it is consumed

    def _claim():
        seats = _read_unlocked()
        rec = seats.setdefault(seat, _empty_record())
        state = rec.get("launch_state")
        # A legacy/no-plan claim still consumes participant_presence.  Load the
        # registry unconditionally so None never disables a registered fact.
        participants = store.load_participants()
        participant = participants.get(seat)
        facts = runtime_soundness_core(
            dict(rec, seat=seat), participants=participants, seats=seats,
            this_boot=this_boot, action="claim",
            action_context={
                "attempt_config": clean_attempt, "ready": ready,
                "intent_context": intent, "owner_context": owner,
            })
        _require_action_soundness("claim", facts)
        # Exact commit-time CAS selectors repeat no decision vocabulary: the
        # action policy above decided; these bind the row written under the
        # same lock to the state and capability it admitted.
        if state not in (None, "STOPPED", "FAILED"):
            raise OwnershipConflict(
                f"seat {seat!r} is {state!r}; a claim needs none/STOPPED/FAILED",
                code="bad_state")
        cur_intent = rec.get("intent")
        if not isinstance(cur_intent, dict) or cur_intent.get("state") != "OPEN" \
                or cur_intent.get("attempt_id") != attempt_id \
                or cur_intent.get("intent_id") != intent.intent_id \
                or cur_intent.get("operator") != owner.operator:
            raise OwnershipConflict(
                f"seat {seat!r} has no OPEN intent for attempt {attempt_id!r} — refused",
                code="intent_missing")
        spec = rec["desired_config"]
        clean_spec = validate_spec(spec)
        attempt_digest = None
        if clean_attempt is not None:
            bound_attempt = validate_live_attempt_binding(
                clean_attempt, seat=seat, spec=clean_spec, participant=participant)
            attempt_digest = attempt_config_sha256(bound_attempt)
            clean_attempt_for_row = bound_attempt
        else:
            clean_attempt_for_row = None
        # the seat IS claimable — consume the generation now and persist it, so
        # a subsequent identity refusal still burns it (monotonic; r11 Bugbot MED)
        gen = int(rec.get("gen_counter", 0)) + 1
        rec["gen_counter"] = gen
        burned["gen"] = gen                    # r21 reviewer MED#6: expose the burned gen
        _write_unlocked(seats)
        # identity gate — refusals past here leave gen consumed
        identity_facts = runtime_soundness_core(
            dict(rec, seat=seat), participants=participants, seats=seats,
            this_boot=this_boot, action="claim",
            action_context={
                "attempt_config": clean_attempt,
                "supervisor_handle": supervisor,
                "ready": ready,
                "resource": clean_resource,
                "intent_context": intent,
                "owner_context": owner,
            })
        _require_action_soundness("claim", identity_facts)
        rec["pending_attempt"] = {
            "spec": clean_spec, "attempt_id": attempt_id,
            "runtime_id": ready["runtime_id"], "generation": gen,
            "resource": clean_resource, "observed_runtime": None, "handle": None,
            "attempt_config": clean_attempt_for_row, "vendor_observed": None,
            "handle_attestation": None,
        }
        rec["lease"] = {
            "runtime_id": ready["runtime_id"], "generation": gen,
            "lease_id": ready["lease_id"], "supervisor_pid": sup_pid,
            "proc_birth": ready["proc_birth"], "boot_id": ready["boot_id"],
            "nonce": ready["nonce"],
            "attempt_sha256": attempt_digest,
            "token_sha256": hashlib.sha256(token.encode()).hexdigest(),
            "heartbeat": store.now_iso(),
            # r13 MED#7: persist the INITIATING verified operator so
            # supervisor-driven transitions (promote/fail) receipt the human who
            # started the attempt, never the seat id
            "operator": owner.operator,
            # r21 reviewer MED#5: persist the declared go_deadline so recovery can
            # reclaim a dead post-claim supervisor after ITS deadline (≤120s)
            # rather than waiting out the full 300s heartbeat horizon
            "go_deadline": float(ready["go_deadline"]),
        }
        # consume the intent EXACTLY ONCE, atomically with the STARTING commit
        cur_intent["state"] = "CONSUMED"
        cur_intent["updated"] = store.now_iso()
        rec["launch_state"] = "STARTING"
        rec["exit"] = None                    # fresh attempt — no prior exit fact
        rec["updated"] = store.now_iso()
        _write_unlocked(seats)
        return gen

    try:
        # Lock order: launch-identity fence -> runtime registry.  Participant
        # and catalog writers take the same outer fence, so the live binding
        # check and STARTING commit are one atomic authorization boundary.
        with store.runtime_launch_fence():
            gen = _locked(_claim)
    except OwnershipConflict as e:
        # r21 reviewer MED#6: a refusal PAST the gen-consume gate burned a
        # generation — the receipt must carry it (None for a pre-consume refusal)
        # so audit/recovery can tie the burned counter to the refusal event
        _emit("runtime_failed", owner.operator, {
            "seat": seat, "attempt_id": attempt_id,
            "runtime_id": ready.get("runtime_id"), "generation": burned["gen"],
            "reason": "claim_refused", "code": e.code})
        raise
    return SupervisorContext(seat=seat, attempt_id=attempt_id,
                             runtime_id=ready["runtime_id"], generation=gen,
                             token=token, _mark=_MINT)


def record_observed(ctx: SupervisorContext, observed: Dict[str, Any]) -> None:
    """§3 step 3: the vendor CHILD identity, persisted the instant it exists,
    IN the predeclared resource. Touches the lease heartbeat."""
    seat = _require_sup(ctx, ctx.seat).seat
    child_pid = _valid_pid(observed.get("child_pid"))
    child_birth = observed.get("child_birth")
    if child_pid is None or not isinstance(child_birth, str) or not child_birth:
        raise ValidationError("observed_runtime needs child_pid (positive int, "
                              "not bool) + child_birth")
    clean_resource = validate_resource(observed.get("resource"))
    observed_paths: Dict[str, str] = {}
    for key in ("work_dir", "store_dir"):
        value = observed.get(key)
        if value is not None:
            if not isinstance(value, str) or not os.path.isabs(value) \
                    or any(c in value for c in "\n\0"):
                raise ValidationError(f"observed_runtime.{key} must be a clean absolute path")
            observed_paths[key] = value
    this_boot = host_boot_id()                # r29 reviewer MED#2: probe boot OUTSIDE the lock
    # r12 HIGH#3: the recorded incarnation must be ALIVE at record time — a
    # stale/wrong birth accepted here would let stop/finalize/sweep clear while
    # the real child still runs. Prove pid+birth now.
    if not _proc_identity_ok(child_pid, child_birth):
        raise OwnershipConflict(
            f"observed child {child_pid} is not alive as the recorded incarnation — refused")
    # r13 HIGH#5: prove the child actually BELONGS to the claimed resource, not
    # merely that the caller repeated the predeclared tag — a buggy/hostile
    # adapter could otherwise bind an unrelated live pid to our process group
    # and defeat later stop/recovery. Layer 1 can verify process_group
    # membership directly; a tmux pane is accepted only through the seat's
    # registry-declared private socket. session_dir remains unprovable here.
    participants = store.load_participants()
    if not _resource_membership_ok(
            child_pid, clean_resource, seat=seat, participants=participants):
        raise OwnershipConflict(
            f"observed child {child_pid} is not a member of its claimed "
            f"{clean_resource.get('kind')} resource — refused (Layer 1 cannot "
            f"verify this kind without a Layer-2 adapter proof)")

    def _rec():
        seats = _read_unlocked()
        rec = seats.get(seat)
        if not rec or rec.get("launch_state") != "STARTING" or not _sup_matches(ctx, rec):
            raise OwnershipConflict(f"no live STARTING attempt for this capability on {seat!r}")
        pend = rec["pending_attempt"]
        # r13 CRIT#1: observation is only legal AFTER a durable GO — otherwise a
        # caller could skip send_go and record the still-blocked supervisor as
        # the child, promoting a false ACTIVE before any vendor spawn
        if not pend.get("go_sent"):
            raise OwnershipConflict(
                f"seat {seat!r} attempt has not been GO'd — no vendor child can exist yet",
                code="go_state")
        # r13 CRIT#1: the vendor child is NEVER the supervisor itself (the
        # supervisor leads the predeclared process group, so it would pass the
        # membership probe) — reject child_pid == the lease's supervisor pid
        if child_pid == _valid_pid(rec["lease"].get("supervisor_pid")):
            raise OwnershipConflict(
                f"seat {seat!r} observed child is the supervisor itself — refused")
        if clean_resource != pend.get("resource"):
            raise OwnershipConflict(
                "observed resource does not match the predeclared one — refused")
        if pend.get("attempt_config") is not None:
            cfg = validate_attempt_config(pend["attempt_config"])
            if observed_paths != {"work_dir": cfg["work_dir"],
                                  "store_dir": cfg["store_dir"]}:
                raise OwnershipConflict(
                    "native adapter host must observe exact work_dir and store_dir")
        _require_live_supervisor(rec, seat, this_boot)   # r27/r29: live + same-boot supervisor
        pend["observed_runtime"] = {"child_pid": child_pid,
                                    "child_birth": child_birth,
                                    "resource": clean_resource,
                                    **observed_paths}
        rec["lease"]["heartbeat"] = store.now_iso()
        rec["updated"] = store.now_iso()
        _write_unlocked(seats)

    _locked(_rec)


def _observed_process_tree(root_pid: int) -> Optional[Dict[int, Dict[str, Any]]]:
    """One bounded process snapshot for the nested host->vendor identity hop."""
    try:
        out = subprocess.run(
            ["ps", "-axo", "pid=,pgid=,ppid=,lstart="], capture_output=True,
            text=True, timeout=10, env=_PROBE_ENV, check=False)
    except Exception:
        return None
    if out.returncode != 0:
        return None
    rows: Dict[int, Dict[str, Any]] = {}
    for line in out.stdout.splitlines():
        parts = line.split()
        if len(parts) < 4:
            continue
        try:
            pid = int(parts[0])
            rows[pid] = {"pid": pid, "pgid": int(parts[1]),
                         "ppid": int(parts[2]), "birth": " ".join(parts[3:])}
        except ValueError:
            continue
    if root_pid not in rows:
        return {}
    descendants = {root_pid}
    changed = True
    while changed:
        changed = False
        for pid, row in rows.items():
            if pid not in descendants and row["ppid"] in descendants:
                descendants.add(pid)
                changed = True
    return {pid: rows[pid] for pid in descendants}


def record_vendor_observed(ctx: SupervisorContext, frame: Dict[str, Any]) -> None:
    """Persist the nested adapter-host -> vendor identity before handle proof.

    The supervisor has already persisted the adapter HOST through
    record_observed.  This method verifies one authenticated, size-bounded frame
    against that still-live host's current descendant tree.  An already-escaped
    vendor is durably added to the grow-only escapee set in the SAME write.

    OPEN(PR2B-ORPHAN-REAP): if the host dies and an already-setsid vendor is
    reparented before topology validation, refuse the frame (never promote) but
    do NOT put its unvalidated pid into the killable escapee set.  The real-
    vendor matrix plus GC/reaper design must add topology-validated reap-
    identity capture.  Trading that bounded orphan leak for a mis-aimed kill is
    not acceptable containment.
    """
    seat = _require_sup(ctx, ctx.seat).seat
    current = get_seat(seat) or {}
    pend0 = current.get("pending_attempt") or {}
    digest = attempt_config_sha256(pend0.get("attempt_config"))
    key = derive_vendor_observed_key(ctx.token, digest)
    clean = validate_vendor_observed(
        frame, seat=seat, attempt_id=ctx.attempt_id,
        runtime_id=ctx.runtime_id, generation=ctx.generation,
        attempt_sha256=digest, resource=pend0.get("resource"), frame_key=key)
    cfg0 = validate_attempt_config(pend0.get("attempt_config"))
    if clean["transport_kind"] != cfg0["vendor_transport"] \
            or clean["protocol_version"] != cfg0["protocol_version"]:
        raise OwnershipConflict(
            "VENDOR_OBSERVED transport/protocol differs from the digest-bound plan")
    host = pend0.get("observed_runtime") or {}
    host_pid = _valid_pid(host.get("child_pid"))
    if host_pid is None or clean["vendor_pid"] == host_pid:
        raise OwnershipConflict("VENDOR_OBSERVED must name a distinct vendor descendant")
    tree = _observed_process_tree(host_pid) if host_pid is not None else None
    row = tree.get(clean["vendor_pid"]) if tree is not None else None
    if row is None or row.get("birth") != clean["proc_birth"] \
            or row.get("pgid") != clean["pgid"]:
        raise OwnershipConflict(
            "VENDOR_OBSERVED identity is not in the already-observed live host tree")
    this_boot = host_boot_id()

    def _rec():
        seats = _read_unlocked()
        rec = seats.get(seat)
        if not rec or rec.get("launch_state") != "STARTING" or not _sup_matches(ctx, rec):
            raise OwnershipConflict(f"no live STARTING attempt for {seat!r}")
        pend = rec["pending_attempt"]
        if not pend.get("go_sent") or pend.get("observed_runtime") is None:
            raise OwnershipConflict("VENDOR_OBSERVED requires GO and observed adapter host",
                                    code="go_state")
        if pend.get("vendor_observed") is not None:
            raise OwnershipConflict("this attempt already consumed its VENDOR_OBSERVED frame")
        if attempt_config_sha256(pend.get("attempt_config")) != digest:
            raise OwnershipConflict("attempt configuration changed before vendor observation")
        _require_live_supervisor(rec, seat, this_boot)
        host_now = pend["observed_runtime"]
        if not _proc_identity_ok(_valid_pid(host_now.get("child_pid")),
                                 host_now.get("child_birth")) \
                or not _proc_identity_ok(clean["vendor_pid"], clean["proc_birth"]):
            raise OwnershipConflict("adapter host or vendor died before observation persisted")
        try:
            current_pgid = os.getpgid(clean["vendor_pid"])
        except OSError:
            current_pgid = None
        if current_pgid != clean["pgid"]:
            raise OwnershipConflict(
                "vendor process-group identity changed before observation persisted")
        declared = validate_resource(pend["resource"])
        if declared["kind"] == "process_group" \
                and str(clean["pgid"]) != declared["value"]:
            esc = rec.get("escapees")
            entries = list(esc.get("entries", [])) if isinstance(esc, dict) else []
            pair = {"pid": clean["vendor_pid"], "birth": clean["proc_birth"]}
            if pair not in entries:
                entries.append(pair)
            rec["escapees"] = {"runtime_id": ctx.runtime_id,
                                "generation": ctx.generation,
                                "entries": entries}
        pend["vendor_observed"] = clean
        rec["lease"]["heartbeat"] = store.now_iso()
        rec["updated"] = store.now_iso()
        _write_unlocked(seats)

    _locked(_rec)


def record_handle_attestation(ctx: SupervisorContext, frame: Dict[str, Any]) -> None:
    """Persist the vendor's external/exclusive handle proof, after identity."""
    seat = _require_sup(ctx, ctx.seat).seat
    current = get_seat(seat) or {}
    pend0 = current.get("pending_attempt") or {}
    digest = attempt_config_sha256(pend0.get("attempt_config"))
    key = derive_vendor_observed_key(ctx.token, digest)
    clean = validate_handle_attestation(
        frame, seat=seat, attempt_id=ctx.attempt_id,
        runtime_id=ctx.runtime_id, generation=ctx.generation,
        attempt_sha256=digest, frame_key=key)
    this_boot = host_boot_id()

    def _rec():
        seats = _read_unlocked()
        rec = seats.get(seat)
        if not rec or rec.get("launch_state") != "STARTING" or not _sup_matches(ctx, rec):
            raise OwnershipConflict(f"no live STARTING attempt for {seat!r}")
        pend = rec["pending_attempt"]
        if pend.get("vendor_observed") is None:
            raise OwnershipConflict("handle attestation requires VENDOR_OBSERVED first")
        if pend.get("handle_attestation") is not None:
            raise OwnershipConflict("this attempt already has a handle attestation")
        cfg = validate_attempt_config(pend.get("attempt_config"))
        family_proof = {"claude": "claude_sdk_session",
                        "codex": "codex_sdk_thread",
                        "gemini": "antigravity_session"}[cfg["family"]]
        if clean["proof_kind"] != family_proof:
            raise OwnershipConflict("handle proof kind does not match adapter family")
        if clean.get("schema_version") != HANDLE_ATTESTATION_SCHEMA \
                or clean.get("assurance") is None:
            raise OwnershipConflict(
                "native handle proof requires the typed observed-not-independent assurance")
        validate_handle_assurance(
            clean["assurance"], launch_mode=cfg["launch_mode"], family=cfg["family"])
        if cfg["launch_mode"] == "RESUME" \
                and clean["handle"] != cfg["resume_handle"]:
            raise OwnershipConflict("vendor did not exclusively adopt the requested resume handle")
        _require_live_supervisor(rec, seat, this_boot)
        pend["handle_attestation"] = clean
        rec["lease"]["heartbeat"] = store.now_iso()
        rec["updated"] = store.now_iso()
        _write_unlocked(seats)

    _locked(_rec)


def record_handle(ctx: SupervisorContext, handle: Dict[str, Any]) -> None:
    """§3 step 4: VERIFY writes the PROVEN handle. Proof order enforced."""
    seat = _require_sup(ctx, ctx.seat).seat
    clean = validate_handle(handle)
    this_boot = host_boot_id()                # r29 reviewer MED#2: probe boot OUTSIDE the lock

    def _rec():
        seats = _read_unlocked()
        rec = seats.get(seat)
        if not rec or rec.get("launch_state") != "STARTING" or not _sup_matches(ctx, rec):
            raise OwnershipConflict(f"no live STARTING attempt for this capability on {seat!r}")
        pend = rec["pending_attempt"]
        if not pend.get("go_sent"):           # r30 Bugbot: require the durable GO, as
            raise OwnershipConflict(          # record_observed/promote do (a corrupt observed-
                f"seat {seat!r} attempt has not been GO'd — no handle advance",  # but-not-GO'd row
                code="go_state")              # must not progress the handle or refresh heartbeat)
        if pend.get("observed_runtime") is None:
            raise OwnershipConflict(
                f"attempt {ctx.attempt_id!r} has no observed_runtime — record the child first")
        if pend.get("attempt_config") is not None:
            if pend.get("vendor_observed") is None:
                raise OwnershipConflict(
                    f"attempt {ctx.attempt_id!r} has no VENDOR_OBSERVED proof")
            att = pend.get("handle_attestation")
            if att is None or validate_handle_attestation(att)["handle"] != clean:
                raise OwnershipConflict(
                    f"attempt {ctx.attempt_id!r} lacks the matching exclusive handle proof")
            cfg = validate_attempt_config(pend["attempt_config"])
            if cfg["launch_mode"] == "RESUME" and clean != cfg["resume_handle"]:
                raise OwnershipConflict("recorded handle does not match the requested RESUME handle")
        # A NEW attempt can discover a handle already retained by another
        # local seat.  Refuse before persisting a duplicate provenance claim;
        # the same canonical all-field index also gates claim/promotion/health.
        other_seat = _reserved_resume_handle_owner(seats, seat, clean)
        if other_seat is not None:
            raise OwnershipConflict(
                f"handle is already reserved by seat {other_seat!r}",
                code="handle_reserved")
        _require_live_supervisor(rec, seat, this_boot)   # r27/r29: live + same-boot supervisor
        pend["handle"] = clean
        rec["lease"]["heartbeat"] = store.now_iso()
        rec["updated"] = store.now_iso()
        _write_unlocked(seats)

    _locked(_rec)


@_soundness_action("promote")
def promote(ctx: SupervisorContext) -> Dict[str, Any]:
    """§3 step 5: CAS STARTING→ACTIVE — revalidating the WHOLE ownership story
    immediately before the CAS (reviewer r9 CRIT#4 + r10 HIGH#3): capability ↔
    exact lease/pending pair; SUPERVISOR alive as the recorded incarnation on
    this boot; the recorded VENDOR CHILD alive as ITS recorded incarnation;
    lock held with OUR attestation; heartbeat fresh; full proof chain."""
    seat = _require_sup(ctx, ctx.seat).seat
    this_boot = host_boot_id()                # r31 reviewer MED#5: probe boot OUTSIDE the lock

    def _prom():
        seats = _read_unlocked()
        rec = seats.get(seat)
        # promote also declares participant_presence for legacy rows; keep the
        # policy input complete instead of keying it to native-plan presence.
        participants = store.load_participants()
        facts = runtime_soundness_core(
            dict(rec or _empty_record(), seat=seat), participants=participants, seats=seats,
            this_boot=this_boot, action="promote",
            action_context={"supervisor_ctx": ctx})
        _require_action_soundness("promote", facts)
        if not rec or rec.get("launch_state") != "STARTING":
            raise OwnershipConflict(f"promote lost the race on seat {seat!r}")
        pend, lease = rec["pending_attempt"], rec["lease"]
        obs = pend.get("observed_runtime")
        assert isinstance(obs, dict)          # enforced by shared action facts
        # Final TOCTOU observations are data passed back through the same
        # registered policy.  The mutation does not reimplement the decision
        # vocabulary after the shared core has run.
        final_facts = runtime_soundness_core(
            dict(rec, seat=seat), participants=participants, seats=seats,
            this_boot=this_boot, action="promote",
            action_context={
                "supervisor_ctx": ctx,
                "final_supervisor_live": _proc_identity_ok(
                    _valid_pid(lease.get("supervisor_pid")), lease.get("proc_birth")),
                "final_lock_held": not probe_seat_lock_free(seat),
            })
        _require_action_soundness("promote", final_facts)
        if rec.get("active") is not None:
            rec["prior_active"] = rec["active"]
        rec["active"] = {
            "spec": pend["spec"], "handle": pend["handle"],
            "runtime_id": pend["runtime_id"], "generation": pend["generation"],
            "observed_runtime": obs,
        }
        if pend.get("attempt_config") is not None:
            rec["active"].update({
                "attempt_id": pend["attempt_id"],
                "resource": pend["resource"],
                "attempt_config": pend["attempt_config"],
                "vendor_observed": pend["vendor_observed"],
                "handle_attestation": pend["handle_attestation"],
            })
        rec["pending_attempt"] = None
        rec["lease"]["heartbeat"] = store.now_iso()
        rec["launch_state"] = "ACTIVE"
        rec["updated"] = store.now_iso()
        _write_unlocked(seats)
        return dict(rec, seat=seat)

    # Hold the participant/catalog writer fence continuously from the live
    # revision check through the ACTIVE write.  An update is therefore wholly
    # before (and refused) or wholly after the committed generation.
    with store.runtime_launch_fence():
        out = _locked(_prom)
    # r13 MED#7: actor = the INITIATING operator persisted in the lease, never
    # the seat id (which mis-attributes the action to the seat itself)
    actor = (out.get("lease") or {}).get("operator") or RECOVERY_ACTOR
    _emit("runtime_promoted", actor, {
        "seat": seat, "attempt_id": ctx.attempt_id, "runtime_id": ctx.runtime_id,
        "generation": ctx.generation,
        "management": out["active"]["spec"]["management"],
        "model": out["active"]["spec"]["model"]})
    return out


def fail_attempt(ctx: SupervisorContext, *, reason: str) -> Dict[str, Any]:
    """TWO-PHASE failure, phase 1: mark FAILED, RETAIN lease + pending
    (the teardown identity). finalize_failed() is the only clearer."""
    seat = _require_sup(ctx, ctx.seat).seat
    if reason not in FAIL_REASONS:
        raise ValidationError(f"reason must be one of {FAIL_REASONS}, got {reason!r}")

    def _fail():
        seats = _read_unlocked()
        rec = seats.get(seat)
        if not rec or rec.get("launch_state") != "STARTING" or not _sup_matches(ctx, rec):
            raise OwnershipConflict(f"no live STARTING attempt for this capability on {seat!r}")
        rec["launch_state"] = "FAILED"      # lease + pending_attempt RETAINED
        rec["updated"] = store.now_iso()
        _write_unlocked(seats)
        return dict(rec, seat=seat)

    out = _locked(_fail)
    actor = (out.get("lease") or {}).get("operator") or RECOVERY_ACTOR   # r13 MED#7
    _emit("runtime_failed", actor, {
        "seat": seat, "attempt_id": ctx.attempt_id, "runtime_id": ctx.runtime_id,
        "generation": ctx.generation, "reason": reason})
    return out


def fail_runtime_exit(ctx: SupervisorContext, *, exit_status: Any) -> Dict[str, Any]:
    """Typed unexpected adapter-host exit: ACTIVE -> retained FAILED.

    The active snapshot and lifetime lease remain as teardown identity until
    :func:`finalize_failed` proves the supervisor, child, process group, and
    escapees gone. An operator-requested STOPPING exit is intentionally not
    accepted here; that follows the ordinary stop path.
    """
    seat = _require_sup(ctx, ctx.seat).seat
    if exit_status is not None and (isinstance(exit_status, bool)
                                    or not isinstance(exit_status, int)):
        raise ValidationError("exit_status must be an int or None")

    def _fail() -> tuple[str, Dict[str, Any]]:
        seats = _read_unlocked()
        rec = seats.get(seat)
        if not rec or not _lease_matches(ctx, rec):
            raise OwnershipConflict(
                f"seat {seat!r} has no live runtime under this capability")
        state = rec.get("launch_state")
        if state == "FAILED":
            prior = rec.get("exit")
            if prior == {"status": exit_status, "reason": "adapter_failed"}:
                return ("dup", dict(rec, seat=seat))
            raise OwnershipConflict(
                f"seat {seat!r} already has a different FAILED exit",
                code="bad_state")
        if state != "ACTIVE" or rec.get("active") is None:
            raise OwnershipConflict(
                f"seat {seat!r} is {state!r}, not ACTIVE for unexpected exit",
                code="bad_state")
        rec["launch_state"] = "FAILED"
        rec["exit"] = {"status": exit_status, "reason": "adapter_failed"}
        rec["lease"]["heartbeat"] = store.now_iso()
        rec["updated"] = store.now_iso()
        _write_unlocked(seats)
        return ("new", dict(rec, seat=seat))

    outcome, out = _locked(_fail)
    if outcome == "new":
        actor = (out.get("lease") or {}).get("operator") or RECOVERY_ACTOR
        _emit("runtime_failed", actor, {
            "seat": seat, "attempt_id": ctx.attempt_id,
            "runtime_id": ctx.runtime_id, "generation": ctx.generation,
            "reason": "adapter_failed", "exit_status": exit_status})
    return out


def _lease_matches(ctx: SupervisorContext, rec: Dict[str, Any]) -> bool:
    """POST-PROMOTE capability match (PR-2 r2): after promote,
    `pending_attempt` is None so _sup_matches cannot apply — the lease token
    hash plus the active runtime identity still bind the capability to
    exactly this runtime incarnation."""
    lease, active = rec.get("lease"), rec.get("active")
    if not lease or not active:
        return False
    return (lease.get("runtime_id") == ctx.runtime_id
            and active.get("runtime_id") == ctx.runtime_id
            and active.get("generation") == ctx.generation
            and lease.get("token_sha256") == hashlib.sha256(ctx.token.encode()).hexdigest())


def record_runtime_exit(ctx: SupervisorContext, *, exit_status: Any) -> Dict[str, Any]:
    """PR-2 r2 (reviewer HIGH#3): the supervisor DURABLY records an unexpected
    vendor-child exit BEFORE it tears down and releases the flock. Without
    this the row stays ACTIVE with a dead runtime forever — claim refuses
    ACTIVE and the sweep ignores ACTIVE: false status plus a permanent
    manual-recovery wedge. CAS ACTIVE→STOPPING under the post-promote
    capability; the exit status rides a `runtime_exited` receipt. The row is
    then closable by the ordinary proven paths (finish_stop, or the
    stale-STOPPING sweep once the supervisor is gone)."""
    seat = _require_sup(ctx, ctx.seat).seat
    if exit_status is not None and (isinstance(exit_status, bool)
                                    or not isinstance(exit_status, int)):
        raise ValidationError("exit_status must be an int or None")

    def _rec():
        seats = _read_unlocked()
        rec = seats.get(seat)
        if not rec or not _lease_matches(ctx, rec):
            raise OwnershipConflict(
                f"seat {seat!r} has no live runtime under this capability")
        state = rec.get("launch_state")
        if state == "ACTIVE":
            # ACTIVE never carries an exit fact (r13 state-binding invariant) —
            # always perform the CAS to STOPPING and commit the fact. Never a
            # dup here (a dup on ACTIVE would tear down a still-false-ACTIVE row).
            rec["launch_state"] = "STOPPING"  # lease + lock retained; death provable later
        elif state == "STOPPING":
            # operator began the stop, child now exits: idempotent ONLY here.
            prior = rec.get("exit")
            if prior is not None:
                if prior.get("status") == exit_status:
                    return ("dup", dict(rec, seat=seat))   # already committed
                raise OwnershipConflict(
                    f"seat {seat!r} already recorded a different exit_status "
                    f"({prior.get('status')!r} != {exit_status!r})", code="bad_state")
        else:
            raise OwnershipConflict(
                f"seat {seat!r} is {state!r}, not ACTIVE/STOPPING under this capability")
        # r12/r13 reviewer MED: the exit fact is DURABLE (committed under the CAS)
        # for CONTROL-PLANE SAFETY — it prevents a false-ACTIVE row and drives
        # the STOPPING transition. It is runtime-scoped (cleared at the terminal
        # commit). The runtime_exited RECEIPT is a separate AT-MOST-ONCE
        # BEST-EFFORT mirror (adopted mirror policy: receipts mirror, never
        # decide) — a ledger failure or a commit→emit crash may drop it; the
        # durable fact, not the receipt, is the safety mechanism.
        rec["exit"] = {"status": exit_status}
        rec["lease"]["heartbeat"] = store.now_iso()
        rec["updated"] = store.now_iso()
        _write_unlocked(seats)
        return ("new", dict(rec, seat=seat))

    outcome, out = _locked(_rec)
    if outcome == "new":
        # at-most-once best-effort mirror of the committed fact
        actor = (out.get("lease") or {}).get("operator") or RECOVERY_ACTOR
        _emit("runtime_exited", actor, {
            "seat": seat, "runtime_id": ctx.runtime_id, "generation": ctx.generation,
            "exit_status": exit_status})
    return out


def record_escapees(ctx: SupervisorContext, escapees: Any) -> None:
    """PR-2 r2 (reviewer HIGH#4 / reviewer bar): persist the
    incarnation-pinned GROUP-ESCAPED descendant set DURABLY, typed and
    CAS-bound to this capability's runtime_id+generation, the moment the
    supervisor observes it change. The in-memory set dies with the
    supervisor; Layer 1's group-scoped proofs are blind to escapees — only a
    registry-persisted identity lets finalize_failed/finish_stop REFUSE to
    clear ownership while an escapee provably lives. Valid from STARTING
    (attempt capability) or ACTIVE (post-promote lease capability). The set
    survives promotion (top-level field, untouched by promote) and is cleared
    only by the terminal transitions after ITS OWN death proof passes.

    SCOPE (§7a.1, declared residual): only OBSERVED escapees can be
    persisted. A descendant that daemonizes AND whose whole parent chain
    exits within one sampling interval — before any process-table snapshot
    captured the lineage edge — is unobservable to userspace polling and is
    OUT OF SCOPE; adapters that spawn such helpers are unsupported."""
    seat = _require_sup(ctx, ctx.seat).seat
    if not isinstance(escapees, list):
        raise ValidationError("escapees must be a list of {pid, birth} rows")
    clean = []
    for row in escapees:
        if not isinstance(row, dict):
            raise ValidationError("escapee row must be an object")
        pid = _valid_pid(row.get("pid"))
        birth = row.get("birth")
        if pid is None or not isinstance(birth, str) or not birth:
            raise ValidationError("escapee row needs pid (positive int) + birth")
        clean.append({"pid": pid, "birth": birth})

    def _rec():
        seats = _read_unlocked()
        rec = seats.get(seat)
        state = (rec or {}).get("launch_state")
        if not rec or state not in ("STARTING", "ACTIVE", "STOPPING") \
                or not (_sup_matches(ctx, rec) or _lease_matches(ctx, rec)):
            raise OwnershipConflict(
                f"seat {seat!r} has no live attempt/runtime under this capability")
        # r10 Bugbot MED: the persisted escapee set is MONOTONIC — it may only
        # GROW here (union new entries into the existing set, keeping each
        # recorded incarnation), never shrink. A live descendant that stops
        # being counted as out-of-group (re-enters the group, or a walk
        # transiently misses it) must NOT be dropped without a death proof, or
        # finish_stop/finalize_failed could clear the seat while a §7a.1
        # descendant runs. Entries leave ONLY via a terminal clear that first
        # proves EVERY incarnation dead (finalize_escapees/finish_stop/
        # finalize_failed/sweep). A superseding runtime_id/generation replaces.
        prior = rec.get("escapees") or {}
        keep = prior.get("entries") or [] if (
            prior.get("runtime_id") == ctx.runtime_id
            and prior.get("generation") == ctx.generation) else []
        # r11 reviewer: the grow-only identity key is the full (pid, birth)
        # PAIR, not the pid alone — on PID reuse the SAME pid may hold two
        # distinct incarnations (a dead old birth + a live new birth), and BOTH
        # must persist until each is separately proven dead. Keying by pid would
        # keep only the old birth; _escapees_gone would then see the current
        # live birth mismatch, declare the recorded (dead) incarnation gone, and
        # let a terminal clear proceed while the new same-pid incarnation runs.
        seen = {(e["pid"], e["birth"]) for e in keep}
        merged = list(keep)
        for e in clean:
            k = (e["pid"], e["birth"])
            if k not in seen:
                seen.add(k)
                merged.append(e)
        merged.sort(key=lambda e: (e["pid"], e["birth"]))
        rec["escapees"] = {"runtime_id": ctx.runtime_id,
                           "generation": ctx.generation, "entries": merged} \
            if merged else None
        rec["lease"]["heartbeat"] = store.now_iso()
        rec["updated"] = store.now_iso()
        _write_unlocked(seats)

    _locked(_rec)


def _escapees_gone(rec: Dict[str, Any]) -> bool:
    """Every persisted escapee incarnation is PROVABLY dead (tri-state via
    _incarnation_gone; unknown fails closed). An empty/absent set is gone."""
    esc = rec.get("escapees")
    if not esc:
        return True
    return all(_incarnation_gone(e.get("pid"), e.get("birth"))
               for e in (esc.get("entries") or []))


def finalize_escapees(seat: str, *, owner: OwnerContext) -> Dict[str, Any]:
    """r3 reviewer #7: owner-authorized recovery for a TERMINAL row
    (FAILED/STOPPED) that still carries a persisted escapee set — e.g. a
    legacy/repaired row, or one written before a crash. `claim` fail-closes on
    any non-null escapee set (no slow probes under its lock), so without this
    path such a seat is permanently unclaimable. This proves the runtime-bound
    set gone under the SAME lock+CAS discipline as the terminal proofs
    (acquire-and-hold the lifetime lock; prove every incarnation dead; CAS the
    set unchanged), then clears it — after which claim proceeds normally. It
    NEVER runs on a live/STARTING/ACTIVE/STOPPING row (those advance their own
    escapee set) and never clears a set with a still-live incarnation."""
    _require_owner(owner, "finalize_escapees")
    _validate_seat(seat)
    fd = acquire_seat_lock(seat)              # HOLD across all three phases
    cleared = None
    try:
        # PHASE 1 (registry lock, cheap): snapshot terminal state + the exact
        # escapee set. NO slow probes here (r4 reviewer F-1: proving under the
        # global lock would block every seat read/write — same three-phase
        # discipline sweep_stale uses).
        def _snap():
            seats = _read_unlocked()
            rec = seats.get(seat)
            if not rec or rec.get("launch_state") not in ("FAILED", "STOPPED"):
                raise OwnershipConflict(
                    f"seat {seat!r} is not a terminal row — no escapee cleanup")
            if rec.get("lease") is not None:
                raise OwnershipConflict(
                    f"seat {seat!r} is not finalized (lease present) — finalize first",
                    code="unfinalized_failed")
            return rec.get("escapees")
        esc = _locked(_snap)
        if esc is None:
            return get_seat(seat)             # idempotent no-op — emit NOTHING (F-2)
        if fd is None:
            raise OwnershipConflict(
                f"seat {seat!r} lifetime lock still HELD — cleanup unproven",
                code="lock_held")
        # PHASE 2 (NO registry lock): the slow per-incarnation death proof runs
        # while we hold only the per-seat lifetime fd (no live holder can enter)
        if not _escapees_gone({"escapees": esc}):
            raise OwnershipConflict(
                f"seat {seat!r} escaped descendant still alive — cleanup unproven")

        # PHASE 3 (registry lock, cheap): CAS the EXACT unchanged set, clear it
        def _commit():
            seats = _read_unlocked()
            rec = seats.get(seat)
            if not rec or rec.get("launch_state") not in ("FAILED", "STOPPED") \
                    or rec.get("lease") is not None or rec.get("escapees") != esc:
                raise OwnershipConflict(
                    f"seat {seat!r} changed under escapee cleanup — retry",
                    code="bad_state")
            rec["escapees"] = None
            rec["exit"] = None            # exit fact cleared with the terminal commit
            rec["updated"] = store.now_iso()
            _write_unlocked(seats)
            return dict(rec, seat=seat)
        out = _locked(_commit)
        cleared = esc
    finally:
        if fd is not None:
            release_seat_lock(fd)
    # F-2 (audit truth): emit a dedicated receipt ONLY when a set was actually
    # cleared, carrying that set's runtime_id+generation — never a misattributed
    # runtime_stopped, and never on the idempotent no-op path.
    _emit("runtime_escapees_cleared", owner.operator, {
        "seat": seat, "runtime_id": cleared.get("runtime_id"),
        "generation": cleared.get("generation"),
        "count": len(cleared.get("entries") or [])})
    return out


def recover_reboot(*, owner: OwnerContext) -> List[Dict[str, Any]]:
    """§7a.2 boot-mismatch reboot recovery (operator-authorized). A lease whose
    `boot_id` != the current host boot PROVES its supervisor + vendor child +
    process group + flock cannot be running — flocks, pids and pgids do not
    survive a reboot. So a prior-boot lease is cleared to a CLAIMABLE terminal
    WITHOUT any process probe (the boot mismatch IS the death proof), unwedging
    a roster stranded by a machine restart. This NEVER touches a same-boot lease
    (which still needs the ordinary live proofs) — boot-mismatch is a strictly
    additional, strictly safe gone-proof. host_boot_id() unavailable ⇒ fail
    closed (recover nothing). Each seat is cleared under its own held lifetime
    lock (free post-reboot); a same-boot holder ⇒ skip (defensive)."""
    _require_owner(owner, "recover_reboot")
    this_boot = host_boot_id()
    if this_boot is None:
        raise OwnershipConflict("host boot id unavailable — reboot recovery fails closed",
                                code="boot_mismatch")
    # snapshot lease-bearing seats whose lease is from another boot
    candidates: List[Dict[str, Any]] = []
    seats = _locked(_read_unlocked)
    for name, rec in sorted(seats.items()):
        lease = rec.get("lease")
        state = rec.get("launch_state")
        if isinstance(lease, dict) and state in ("STARTING", "ACTIVE", "STOPPING", "FAILED") \
                and lease.get("boot_id") != this_boot:
            candidates.append({"seat": name, "state": state,
                               "runtime_id": lease.get("runtime_id"),
                               "generation": lease.get("generation")})

    recovered: List[Dict[str, Any]] = []
    for c in candidates:
        seat = c["seat"]
        fd = acquire_seat_lock(seat)        # free post-reboot; a live same-boot holder ⇒ None ⇒ skip
        if fd is None:
            continue
        try:
            def _clear():
                s = _read_unlocked()
                rec = s.get(seat)
                lease = (rec or {}).get("lease")
                if not rec or not isinstance(lease, dict) \
                        or lease.get("boot_id") == this_boot:
                    return None             # changed under us / now same-boot — leave it
                prev = rec.get("launch_state")
                active = rec.get("active")
                failed_runtime_active = prev == "FAILED" \
                    and rec.get("pending_attempt") is None \
                    and isinstance(active, dict) \
                    and active.get("runtime_id") == lease.get("runtime_id") \
                    and active.get("generation") == lease.get("generation")
                rec["lease"] = None
                rec["pending_attempt"] = None
                if failed_runtime_active:
                    # Unexpected ACTIVE exit retained the current failed
                    # runtime as teardown identity. A prior-boot proof clears
                    # that dead current snapshot just like finalize_failed;
                    # FAILED-from-STARTING keeps its unrelated rollback active.
                    rec["active"] = None
                rec["escapees"] = None
                rec["exit"] = None
                # ACTIVE/STOPPING → STOPPED (a completed stop); STARTING/FAILED →
                # FAILED-finalized (lease cleared ⇒ claimable)
                rec["launch_state"] = "STOPPED" if prev in ("ACTIVE", "STOPPING") else "FAILED"
                rec["updated"] = store.now_iso()
                _write_unlocked(s)
                return prev
            prev = _locked(_clear)
            if prev is not None:
                recovered.append({**c, "recovered_from": prev})
        finally:
            release_seat_lock(fd)

    for r in recovered:
        _emit("runtime_stopped" if r["recovered_from"] in ("ACTIVE", "STOPPING")
              else "runtime_failed", owner.operator,
              {"seat": r["seat"], "runtime_id": r["runtime_id"],
               "generation": r["generation"], "reason": "reboot_recovery"}
              if r["recovered_from"] not in ("ACTIVE", "STOPPING")
              else {"seat": r["seat"], "runtime_id": r["runtime_id"],
                    "generation": r["generation"]})
    return recovered


@_soundness_action("finalize_failed")
def finalize_failed(seat: str, *, owner: OwnerContext) -> Dict[str, Any]:
    """TWO-PHASE failure, phase 2: clear the teardown identity ONLY once the
    supervisor incarnation is gone, the recorded VENDOR CHILD is dead and its
    resource torn down (r10 CRIT#1), and this finalizer ACQUIRES-AND-HOLDS the
    lifetime lock across the CAS + commit (r18 reviewer HIGH: a probe-then-release
    leaves a check-to-commit gap a contender can enter, finalizing while another
    holder owns the lock). The held fd both proves no live holder AND blocks any
    contender until the transition commits. Seat-lock acquire is non-blocking, so
    ordering (seat→registry) can never deadlock with claim (registry→non-blocking
    seat probe)."""
    _require_owner(owner, "finalize_failed")
    _validate_seat(seat)
    fd = acquire_seat_lock(seat)              # HOLD across CAS+commit; None ⇒ a live holder
    try:
        def _fin():
            seats = _read_unlocked()
            rec = seats.get(seat)
            facts = runtime_soundness_core(
                dict(rec or _empty_record(), seat=seat), seats=seats,
                action="finalize_failed",
                action_context={"terminal_lock_held": fd is not None})
            _require_action_soundness("finalize_failed", facts)
            if not rec or rec.get("launch_state") != "FAILED":
                raise OwnershipConflict(f"seat {seat!r} is not FAILED")
            active = rec.get("active")
            lease = rec.get("lease")
            failed_runtime_active = rec.get("pending_attempt") is None \
                and isinstance(active, dict) and isinstance(lease, dict) \
                and active.get("runtime_id") == lease.get("runtime_id") \
                and active.get("generation") == lease.get("generation")
            rec["lease"] = None
            rec["pending_attempt"] = None
            if failed_runtime_active:
                rec["active"] = None
            rec["escapees"] = None
            rec["exit"] = None            # exit fact cleared with the terminal commit
            rec["updated"] = store.now_iso()
            _write_unlocked(seats)
            return dict(rec, seat=seat)

        return _locked(_fin)
    finally:
        if fd is not None:
            release_seat_lock(fd)


def begin_stop(seat: str, *, owner: OwnerContext) -> Dict[str, Any]:
    """§5 stop, first half: ACTIVE→STOPPING; lease + lock RETAINED."""
    _require_owner(owner, "begin_stop")

    def _stop():
        seats = _read_unlocked()
        rec = seats.get(seat)
        if not rec or rec.get("launch_state") != "ACTIVE":
            raise OwnershipConflict(
                f"seat {seat!r} is {(rec or {}).get('launch_state')!r}, not ACTIVE")
        rec["launch_state"] = "STOPPING"
        # r20 reviewer MED#6: refresh the heartbeat at the stop transition. The
        # lease heartbeat is last touched at promote, so a runtime ACTIVE longer
        # than STALE_ATTEMPT_SEC (i.e. every real one) would enter STOPPING
        # ALREADY stale, making the sweep's staleness gate vacuous for STOPPING.
        # Touching it here makes "stale" actually encode abandonment for both
        # states the sweep gates (PR-2 supervisors additionally heartbeat during
        # long graceful stops).
        if isinstance(rec.get("lease"), dict):
            rec["lease"]["heartbeat"] = store.now_iso()
        rec["updated"] = store.now_iso()
        _write_unlocked(seats)
        return dict(rec, seat=seat)

    return _locked(_stop)


@_soundness_action("finish_stop")
def finish_stop(seat: str, *, owner: OwnerContext) -> Dict[str, Any]:
    """§5 stop, second half: STOPPING→STOPPED only once the supervisor
    incarnation is gone, the ACTIVE runtime's recorded CHILD is dead and its
    resource torn down (r10 CRIT#1), and the lock probes free. `active` is
    retained as the rollback source."""
    _require_owner(owner, "finish_stop")
    _validate_seat(seat)
    fd = acquire_seat_lock(seat)              # HOLD across CAS+commit (r18 reviewer HIGH)
    try:
        def _fin():
            seats = _read_unlocked()
            rec = seats.get(seat)
            facts = runtime_soundness_core(
                dict(rec or _empty_record(), seat=seat), seats=seats,
                action="finish_stop",
                action_context={"terminal_lock_held": fd is not None})
            _require_action_soundness("finish_stop", facts)
            if not rec or rec.get("launch_state") != "STOPPING":
                raise OwnershipConflict(
                    f"seat {seat!r} is {(rec or {}).get('launch_state')!r}, not STOPPING")
            rec["lease"] = None
            rec["escapees"] = None
            rec["exit"] = None            # exit fact cleared with the terminal commit
            rec["launch_state"] = "STOPPED"
            rec["updated"] = store.now_iso()
            _write_unlocked(seats)
            return dict(rec, seat=seat)

        out = _locked(_fin)
    finally:
        if fd is not None:
            release_seat_lock(fd)
    _emit("runtime_stopped", owner.operator, {
        "seat": seat,
        "runtime_id": (out.get("active") or {}).get("runtime_id"),
        "generation": (out.get("active") or {}).get("generation")})
    return out


#: recovery runs as the harness, never as a person — the actor is fixed,
#: not caller-supplied, so a swept receipt can never be attributed to "the operator"
#: without an operator capability (r12 MED#7).
RECOVERY_ACTOR = "System"


def _sweep_horizon(state: str, lease: Dict[str, Any], stale_sec: float) -> float:
    """The abandonment horizon a sweep uses for this state (r21 reviewer MED#5).
    A STARTING attempt's is the SHORTER of stale_sec and the supervisor's
    declared go_deadline (+ clock-skew grace) — it self-exits at its deadline, so
    it is reclaimable sooner. STOPPING keeps the full window. Phase 1 (candidate
    selection) and phase 3 (commit) MUST use the SAME horizon (r22 Bugbot) — else
    a candidate picked with the short horizon is re-rejected at commit with the
    long one, delaying recovery."""
    if state == "STARTING":
        gd = lease.get("go_deadline")
        if isinstance(gd, (int, float)) and not isinstance(gd, bool):
            return min(stale_sec, float(gd) + 30.0)
    return stale_sec


def sweep_stale(*, stale_sec: float = STALE_ATTEMPT_SEC) -> List[Dict[str, Any]]:
    """Recovery: STARTING/STOPPING with a stale heartbeat, supervisor
    incarnation gone, the recorded child dead + (predeclared) resource torn
    down, and a free lock ⇒ swept (STOPPING→STOPPED as a completed stop;
    STARTING→FAILED finalized — dead+free+gone IS the finalize proof).
    Anything unprovable is left for doctor-red — never guessed. Abandoned OPEN
    intents (launcher crashed before claim) are timed out so the seat is never
    wedged. The actor is the fixed RECOVERY_ACTOR (r12 MED#7).

    The expensive ps/tmux/killpg probes run OUTSIDE the registry write lock
    (r13 MED#10): phase 1 snapshots candidates + times out intents under the
    lock, phase 2 probes lock-free, phase 3 CASes each still-unchanged
    candidate (same state + lease runtime_id/generation + still-stale). N stale
    seats no longer serialize every reader behind N×(probe timeout)."""
    operator = RECOVERY_ACTOR
    swept: List[Dict[str, Any]] = []
    intent_timeouts: List[Dict[str, Any]] = []
    candidates: List[Dict[str, Any]] = []

    def _snapshot():
        seats = _read_unlocked()
        changed = False
        for name, rec in seats.items():
            intent = rec.get("intent")
            if isinstance(intent, dict) and intent.get("state") == "OPEN" \
                    and _stale_iso(intent.get("heartbeat"), stale_sec):
                intent["state"] = "TIMED_OUT"      # abandoned before claim
                intent["updated"] = store.now_iso()
                rec["updated"] = store.now_iso()
                intent_timeouts.append({
                    "seat": name,
                    "attempt_id": intent.get("attempt_id"),
                    "intent_id": intent.get("intent_id"),
                })
                changed = True
            state = rec.get("launch_state")
            if state not in ("STARTING", "STOPPING"):
                continue
            lease = rec.get("lease")
            if not isinstance(lease, dict):
                continue
            # r21 reviewer MED#5: a STARTING attempt's abandonment horizon is the
            # SHORTER of the stale-heartbeat window and the supervisor's declared
            # go_deadline (a dead post-claim supervisor self-exits at its deadline,
            # so it is reclaimable before the 300s horizon). The death proof below
            # is still the sole safety gate; this only sets WHEN we bother to probe.
            if not _stale_iso(lease.get("heartbeat"), _sweep_horizon(state, lease, stale_sec)):
                continue
            if _valid_pid(lease.get("supervisor_pid")) is None:
                continue                        # unprovable — doctor-red
            if state == "STARTING":
                src = rec.get("pending_attempt") or {}
                obs, predecl = src.get("observed_runtime"), src.get("resource")
            else:
                src = rec.get("active") or {}
                obs = src.get("observed_runtime")
                predecl = (obs or {}).get("resource")
            candidates.append({
                "seat": name, "state": state,
                "sup_pid": _valid_pid(lease.get("supervisor_pid")),
                "proc_birth": lease.get("proc_birth"),
                "runtime_id": lease.get("runtime_id"),
                "generation": lease.get("generation"),
                "attempt_id": (rec.get("pending_attempt") or {}).get("attempt_id"),
                # r3 CRIT#1: the runtime-bound escapee set rides the candidate —
                # phase 2 must prove EVERY persisted escaped descendant dead
                # (group-scoped child/resource proofs are blind to them) and
                # phase 3 CASes the set unchanged before the terminal commit
                "escapees": rec.get("escapees"),
                "obs": obs, "predecl": predecl})
        if changed:
            _write_unlocked(seats)

    _locked(_snapshot)

    # phase 2 — lock-free probes (the slow part)
    # For each proven-dead candidate, ACQUIRE and HOLD the per-seat lifetime
    # lock (r16 reviewer MED#2): this both proves the lock is free AND blocks any
    # new legitimate holder from entering, so the phase-2 teardown proof stays
    # valid through the commit WITHOUT re-running ps/tmux probes under the global
    # registry lock (which reintroduced the MED#10 slow-probe-under-lock problem).
    provable: List[Dict[str, Any]] = []
    held_fds: Dict[str, int] = {}
    try:
        for c in candidates:
            if not _incarnation_gone(c["sup_pid"], c["proc_birth"]):
                continue                        # supervisor not PROVABLY dead (alive/unknown)
            if not _child_gone(c["obs"], c["predecl"]):
                continue                        # child/resource survives — refuse
            # r3 CRIT#1: every persisted escaped descendant must be PROVABLY
            # dead too — swept-terminal must not clear a seat whose escapee
            # (invisible to the group probes above) still runs
            if not _escapees_gone({"escapees": c["escapees"]}):
                continue
            fd = acquire_seat_lock(c["seat"])   # acquire + HOLD (free ⇒ no live holder, and none may enter)
            if fd is None:
                continue                        # lock still held by a live holder — refuse
            held_fds[c["seat"]] = fd
            provable.append(c)

        def _commit():
            seats = _read_unlocked()
            changed = False
            for c in provable:
                rec = seats.get(c["seat"])
                if not rec or rec.get("launch_state") != c["state"]:
                    continue                    # state moved under us
                lease = rec.get("lease")
                if not isinstance(lease, dict) \
                        or lease.get("runtime_id") != c["runtime_id"] \
                        or lease.get("generation") != c["generation"] \
                        or not _stale_iso(lease.get("heartbeat"),
                                          _sweep_horizon(c["state"], lease, stale_sec)):
                    continue                    # a fresh incarnation/refresh — leave for next sweep
                    #                             (SAME horizon as phase 1 — r22 Bugbot)
                # r3 CRIT#1: the escapee set must be EXACTLY the one phase 2
                # proved dead — a supervisor that persisted a new escapee after
                # our snapshot invalidates the proof; leave for the next sweep
                if rec.get("escapees") != c["escapees"]:
                    continue
                # no OS probe here: we HOLD the per-seat lifetime lock, so the
                # phase-2 dead+gone proof cannot have been invalidated by a new
                # holder/child; only cheap in-memory CAS runs under the lock
                rec["pending_attempt"] = None
                rec["lease"] = None
                rec["escapees"] = None          # proven dead above — cleared with the terminal commit
                rec["exit"] = None            # exit fact cleared with the terminal commit
                rec["launch_state"] = "STOPPED" if c["state"] == "STOPPING" else "FAILED"
                rec["updated"] = store.now_iso()
                swept.append({"seat": c["seat"], "runtime_id": c["runtime_id"],
                              "generation": c["generation"], "attempt_id": c["attempt_id"],
                              "swept_from": c["state"], "swept_to": rec["launch_state"]})
                changed = True
            if changed:
                _write_unlocked(seats)

        if provable:
            _locked(_commit)
    finally:
        for fd in held_fds.values():
            try:
                release_seat_lock(fd)
            except Exception:
                pass

    for s in swept:
        kind = "runtime_stopped" if s["swept_to"] == "STOPPED" else "runtime_failed"
        payload = {"seat": s["seat"], "runtime_id": s["runtime_id"],
                   "generation": s["generation"], "attempt_id": s["attempt_id"],
                   "swept_from": s["swept_from"]}
        if kind == "runtime_failed":
            payload["reason"] = "stale_swept"
        _emit(kind, operator, payload)
    for it in intent_timeouts:
        _emit("runtime_intent_closed", operator,
              {"seat": it["seat"], "attempt_id": it["attempt_id"],
               **({"intent_id": it["intent_id"]}
                  if it.get("intent_id") else {}),
               "state": "TIMED_OUT"})
    return swept
