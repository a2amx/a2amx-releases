"""Credential isolation at child-process boundaries; never changes the parent."""
import os
import re
import shlex

_VALUES = {'ORCH_TOKEN', 'PSQR_AUTH_TOKEN', 'PSQR_UI_TOKEN', 'PSQR_GUEST_TOKEN',
           'SSH_AUTH_SOCK', 'SSH_AGENT_PID'}
_PATH = re.compile(r'(?:TOKEN_(?:FILE|PATH)|CREDENTIALS?(?:_(?:FILE|PATH))?)$')
CLAUDE_BILLING_VARIABLES = ('ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN',
                            'CLAUDE_CODE_OAUTH_TOKEN')
CLI_PLATFORM_VARIABLES = ('HOME', 'USER', 'LOGNAME', 'PATH', 'TMPDIR', 'LANG', 'TERM')


def interactive_claude_env(*, store_dir, vendor_profile_dir=None, environment=None):
    """Construct a private server environment, never inherit app/session state.

    Check forbidden credential *presence* before selection; never read its value.
    HOME is retained unchanged. ORCH's store and the optional native profile are
    explicit launch bindings, not values borrowed from the provisioning agent.
    """
    source = os.environ if environment is None else environment
    if any(name in source for name in CLAUDE_BILLING_VARIABLES):
        raise ValueError('doctor: cli_vendor_credential_environment_present; '
                         'remove ANTHROPIC_API_KEY, ANTHROPIC_AUTH_TOKEN and '
                         'CLAUDE_CODE_OAUTH_TOKEN from the launch environment; no process started')
    if any(not isinstance(source.get(name), str) or not source[name]
           for name in ('HOME', 'PATH')):
        raise ValueError('doctor: cli_platform_environment_missing; HOME and PATH are required')
    result = {name: source[name] for name in CLI_PLATFORM_VARIABLES if name in source}
    result['PSQR_STORE_DIR'] = str(store_dir)
    if vendor_profile_dir is not None:
        result['CLAUDE_CONFIG_DIR'] = str(vendor_profile_dir)
    return result


def credential_names(environment):
    return sorted(name for name in environment if name in _VALUES or _PATH.search(name))


def sanitized_env(environment=None, *, server=False):
    source = os.environ if environment is None else environment
    removed = set(credential_names(source))
    # This web credential protects observation only; it cannot author.
    if server:
        removed.discard('PSQR_AUTH_TOKEN')
    return {key: value for key, value in source.items() if key not in removed}


def seat_command(command: str, home, environment=None):
    source = os.environ if environment is None else environment
    names = sorted(set(credential_names(source)) | _VALUES | {'ORCH_TOKEN_FILE', 'PSQR_DAEMON_TOKEN_FILE'})
    prefix = 'env ' + ' '.join('-u ' + shlex.quote(name) for name in names)
    script = f'cd {shlex.quote(str(home))} && {command}'
    return prefix + ' /bin/sh -c ' + shlex.quote(script)
