"""Claude event/identity shim over the harness-neutral core. Plain added context."""
from __future__ import annotations

import argparse
import json
import os
import sys

from wake_hook_client import CliEndpoint
from wake_hook_core import CLAUDE_OUTPUT_BYTES, run_prompt


def handle(payload, *, home, environ, endpoint_factory=CliEndpoint, profile="desktop"):
    if not isinstance(payload, dict) or payload.get('hook_event_name') != 'UserPromptSubmit':
        return ''
    prompt = payload.get('prompt')
    if not isinstance(prompt, str):
        return ''
    endpoint = endpoint_factory(home)
    endpoint.session_id = payload.get('session_id')
    from harness_facts import collect
    endpoint.harness = collect(environ, payload.get('harness'))
    # Host session is distinct from transcript session, as the native kits measured.
    if profile not in {'cli', 'desktop'}:
        return ''
    session_ref = environ.get('CLAUDE_CODE_HOST_SESSION_ID') if profile == 'desktop' else None
    return run_prompt(prompt, session_ref, endpoint, budget=CLAUDE_OUTPUT_BYTES,
                      post_pointer=profile == 'desktop')


def main():
    class QuietParser(argparse.ArgumentParser):
        def error(self, message):
            raise ValueError('invalid hook arguments')
    try:
        parser = QuietParser(add_help=False)
        parser.add_argument('--home', required=True)
        parser.add_argument('--profile', choices=['cli', 'desktop'], default='desktop')
        args = parser.parse_args()
        payload = json.load(sys.stdin)
        output = handle(payload, home=args.home, environ=os.environ, profile=args.profile)
    except Exception:
        output = ''  # Malformed native input cannot become a refusal/control object.
    sys.stdout.write(output)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
