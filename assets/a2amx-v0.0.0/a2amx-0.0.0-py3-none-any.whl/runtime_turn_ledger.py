"""Authoritative, restart-durable SDK turn and cost receipts.

This ledger is deliberately separate from the broad best-effort audit ledger.
Each START or RESULT is an idempotent transaction under the runtime registry's
existing process-wide lock: a complete, validated scan is the index; an exact
retry returns the original receipt; and a same-key/different-digest retry fails
closed.  There is no append-plus-cache crash window.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import re
import secrets
import stat
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Dict, Optional

import runtime_registry as rr
import store


SCHEMA_VERSION = 1
CANONICALIZATION_VERSION = 1
LEDGER_NAME = "runtime_turn_ledger.jsonl"
MAX_LEDGER_BYTES = 16 * 1024 * 1024
MAX_LEDGER_ROWS = 100_000
MAX_RECORD_BYTES = 32 * 1024
MAX_JSON_VALUE_BYTES = 16 * 1024
MAX_COST_INTEGER_DIGITS = 9
MAX_COST_FRACTION_DIGITS = 12

_PHASES = frozenset({"START", "RESULT"})
_RECORD_KEYS = frozenset({
    "schema_version", "canonicalization_version", "phase", "seat",
    "runtime_id", "generation", "turn_id", "request_digest", "receipt_id",
    "payload",
})
_START_PAYLOAD_KEYS = frozenset({"prompt_sha256"})
_RESULT_PAYLOAD_KEYS = frozenset({
    "session_id", "result_uuid", "subtype", "is_error", "duration_ms",
    "duration_api_ms", "cost_usd", "usage", "model_usage",
})
_CLEAN_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,255}$")
_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_RECEIPT_ID = re.compile(r"^trn-[0-9a-f]{32}$")


class TurnLedgerError(RuntimeError):
    """The authoritative turn ledger could not prove an idempotent commit."""


def canonical_json(value: Any) -> bytes:
    try:
        return json.dumps(value, sort_keys=True, separators=(",", ":"),
                          ensure_ascii=False, allow_nan=False).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise TurnLedgerError(f"turn value is not strict JSON: {exc}") from exc


def _strict_object(raw: bytes, *, label: str) -> Dict[str, Any]:
    def pairs(items):
        value = {}
        for key, item in items:
            if key in value:
                raise TurnLedgerError(f"{label} contains duplicate key {key!r}")
            value[key] = item
        return value

    try:
        value = json.loads(
            raw.decode("utf-8"), object_pairs_hook=pairs,
            parse_constant=lambda token: (_ for _ in ()).throw(
                TurnLedgerError(f"{label} contains non-finite number {token}")))
    except TurnLedgerError:
        raise
    except Exception as exc:
        raise TurnLedgerError(f"{label} is not strict UTF-8 JSON: {exc}") from exc
    if not isinstance(value, dict):
        raise TurnLedgerError(f"{label} must be a JSON object")
    return value


def _clean_id(value: Any, label: str) -> str:
    if not isinstance(value, str) or _CLEAN_ID.fullmatch(value) is None:
        raise TurnLedgerError(f"{label} must be a bounded clean identifier")
    return value


def _sha256(value: Any, label: str) -> str:
    if not isinstance(value, str) or _SHA256.fullmatch(value) is None:
        raise TurnLedgerError(f"{label} must be a lowercase SHA-256 digest")
    return value


def canonical_cost_usd(value: Any) -> Optional[str]:
    """Return an explicit unavailable state or one canonical decimal cost."""
    if value is None:
        # JSON null means the vendor did not supply a measurement.  It must
        # remain distinct from "0", which is a real and meaningful cost.
        return None
    if isinstance(value, bool) or not isinstance(value, (str, int, float, Decimal)):
        raise TurnLedgerError("cost_usd must be a decimal-compatible scalar")
    if isinstance(value, float) and not math.isfinite(value):
        raise TurnLedgerError("cost_usd must be finite")
    try:
        dec = Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise TurnLedgerError("cost_usd is not a decimal") from exc
    if not dec.is_finite() or dec < 0:
        raise TurnLedgerError("cost_usd must be finite and non-negative")
    normalized = format(dec, "f")
    integer, dot, fraction = normalized.partition(".")
    integer_digits = len(integer.lstrip("0")) or 1
    fraction = fraction.rstrip("0")
    if integer_digits > MAX_COST_INTEGER_DIGITS \
            or len(fraction) > MAX_COST_FRACTION_DIGITS:
        raise TurnLedgerError("cost_usd exceeds the bounded decimal precision")
    integer = integer.lstrip("0") or "0"
    return integer + (("." + fraction) if fraction else "")


def _bounded_json_value(value: Any, label: str) -> Any:
    raw = canonical_json(value)
    if len(raw) > MAX_JSON_VALUE_BYTES:
        raise TurnLedgerError(f"{label} exceeds the bounded JSON size")
    # Round-trip through the strict decoder so tuples and exotic mapping
    # implementations cannot hash differently from what is persisted.
    try:
        return json.loads(raw.decode("utf-8"))
    except json.JSONDecodeError as exc:  # canonical_json already made JSON
        raise TurnLedgerError(f"{label} cannot be canonicalized") from exc


def start_payload(prompt_sha256: Any) -> Dict[str, Any]:
    return {"prompt_sha256": _sha256(prompt_sha256, "prompt_sha256")}


def result_payload(*, session_id: Any, result_uuid: Any, subtype: Any,
                   is_error: Any, duration_ms: Any, duration_api_ms: Any,
                   cost_usd: Any, usage: Any, model_usage: Any) -> Dict[str, Any]:
    if not isinstance(is_error, bool):
        raise TurnLedgerError("result is_error must be boolean")
    for label, value in (("duration_ms", duration_ms),
                         ("duration_api_ms", duration_api_ms)):
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise TurnLedgerError(f"{label} must be a non-negative integer")
    try:
        canonical_session_id = rr.canonical_session_id(session_id)
    except rr.ValidationError as exc:
        raise TurnLedgerError("result session_id must be a UUID") from exc
    return {
        "session_id": canonical_session_id,
        "result_uuid": _clean_id(result_uuid, "result UUID"),
        "subtype": _clean_id(subtype, "result subtype"),
        "is_error": is_error,
        "duration_ms": duration_ms,
        "duration_api_ms": duration_api_ms,
        "cost_usd": canonical_cost_usd(cost_usd),
        "usage": _bounded_json_value(usage, "result usage"),
        "model_usage": _bounded_json_value(model_usage, "result model_usage"),
    }


def _validate_payload(phase: str, value: Any) -> Dict[str, Any]:
    keys = _START_PAYLOAD_KEYS if phase == "START" else _RESULT_PAYLOAD_KEYS
    if not isinstance(value, dict) or set(value) != keys:
        raise TurnLedgerError(f"{phase} payload has a non-closed shape")
    if phase == "START":
        return start_payload(value.get("prompt_sha256"))
    return result_payload(**value)


def request_digest(*, phase: str, identity: Dict[str, Any],
                   payload: Dict[str, Any]) -> str:
    body = {
        "canonicalization_version": CANONICALIZATION_VERSION,
        "phase": phase,
        "seat": identity["seat"], "runtime_id": identity["runtime_id"],
        "generation": identity["generation"], "turn_id": identity["turn_id"],
        "payload": payload,
    }
    return hashlib.sha256(canonical_json(body)).hexdigest()


def _validate_identity(identity: Any) -> Dict[str, Any]:
    if not isinstance(identity, dict) \
            or set(identity) != {"seat", "runtime_id", "generation", "turn_id"}:
        raise TurnLedgerError("turn identity has a non-closed shape")
    generation = identity.get("generation")
    if isinstance(generation, bool) or not isinstance(generation, int) or generation <= 0:
        raise TurnLedgerError("turn generation must be a positive integer")
    return {
        "seat": _clean_id(identity.get("seat"), "turn seat"),
        "runtime_id": _clean_id(identity.get("runtime_id"), "turn runtime_id"),
        "generation": generation,
        "turn_id": _clean_id(identity.get("turn_id"), "turn id"),
    }


def _validate_record(value: Any) -> Dict[str, Any]:
    if not isinstance(value, dict) or set(value) != _RECORD_KEYS:
        raise TurnLedgerError("turn-ledger record has a non-closed shape")
    if value.get("schema_version") != SCHEMA_VERSION \
            or value.get("canonicalization_version") != CANONICALIZATION_VERSION:
        raise TurnLedgerError("turn-ledger schema/canonicalization mismatch")
    phase = value.get("phase")
    if phase not in _PHASES:
        raise TurnLedgerError("turn-ledger phase is invalid")
    identity = _validate_identity({key: value.get(key) for key in
                                   ("seat", "runtime_id", "generation", "turn_id")})
    payload = _validate_payload(phase, value.get("payload"))
    digest = request_digest(phase=phase, identity=identity, payload=payload)
    if value.get("request_digest") != digest:
        raise TurnLedgerError("turn-ledger request digest is invalid")
    if not isinstance(value.get("receipt_id"), str) \
            or _RECEIPT_ID.fullmatch(value["receipt_id"]) is None:
        raise TurnLedgerError("turn-ledger receipt id is invalid")
    clean = {
        "schema_version": SCHEMA_VERSION,
        "canonicalization_version": CANONICALIZATION_VERSION,
        "phase": phase, **identity, "request_digest": digest,
        "receipt_id": value["receipt_id"], "payload": payload,
    }
    if len(canonical_json(clean)) + 1 > MAX_RECORD_BYTES:
        raise TurnLedgerError("turn-ledger record exceeds the bounded size")
    return clean


def _ledger_path() -> Path:
    store.ensure_store()
    return Path(store.STORE_DIR) / LEDGER_NAME


def _open_ledger() -> int:
    fd = os.open(_ledger_path(), os.O_RDWR | os.O_CREAT | os.O_APPEND
                 | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK, 0o600)
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_uid != os.geteuid() \
                or stat.S_IMODE(st.st_mode) != 0o600:
            raise TurnLedgerError(
                "runtime turn ledger must be an owned regular mode-0600 file")
        if st.st_size > MAX_LEDGER_BYTES:
            raise TurnLedgerError("runtime turn ledger exceeds its full-scan bound")
        os.set_blocking(fd, True)
        return fd
    except Exception:
        os.close(fd)
        raise


def _scan(fd: int) -> Dict[tuple[str, str, int, str, str], Dict[str, Any]]:
    before = os.fstat(fd)
    os.lseek(fd, 0, os.SEEK_SET)
    chunks = []
    total = 0
    while True:
        chunk = os.read(fd, min(65536, MAX_LEDGER_BYTES + 1 - total))
        if not chunk:
            break
        chunks.append(chunk)
        total += len(chunk)
        if total > MAX_LEDGER_BYTES:
            raise TurnLedgerError("runtime turn ledger exceeds its full-scan bound")
    after = os.fstat(fd)
    before_id = (before.st_dev, before.st_ino, before.st_size,
                 before.st_mtime_ns, before.st_ctime_ns)
    after_id = (after.st_dev, after.st_ino, after.st_size,
                after.st_mtime_ns, after.st_ctime_ns)
    if before_id != after_id or total != before.st_size:
        raise TurnLedgerError("runtime turn ledger changed during its locked scan")
    raw = b"".join(chunks)
    if raw and not raw.endswith(b"\n"):
        raise TurnLedgerError("runtime turn ledger has a torn final record")
    lines = raw.splitlines()
    if len(lines) > MAX_LEDGER_ROWS:
        raise TurnLedgerError("runtime turn ledger exceeds its row bound")
    index: Dict[tuple[str, str, int, str, str], Dict[str, Any]] = {}
    for row, line in enumerate(lines, 1):
        if not line or len(line) + 1 > MAX_RECORD_BYTES:
            raise TurnLedgerError(f"runtime turn ledger row {row} is invalid")
        record = _validate_record(_strict_object(line, label=f"turn-ledger row {row}"))
        if canonical_json(record) != line:
            raise TurnLedgerError(
                f"turn-ledger row {row} is not canonical version "
                f"{CANONICALIZATION_VERSION}")
        key = (record["seat"], record["runtime_id"], record["generation"],
               record["turn_id"], record["phase"])
        if key in index:
            raise TurnLedgerError("runtime turn ledger contains a duplicate key")
        index[key] = record
    return index


def _active_snapshot_unlocked(identity: Dict[str, Any]) -> Dict[str, Any]:
    record = rr._read_unlocked().get(identity["seat"])
    active = record.get("active") if isinstance(record, dict) else None
    if not isinstance(active, dict) or record.get("launch_state") != "ACTIVE" \
            or active.get("runtime_id") != identity["runtime_id"] \
            or active.get("generation") != identity["generation"]:
        raise TurnLedgerError("turn identity is not the current ACTIVE generation")
    return active


def record_turn(*, phase: str, identity: Dict[str, Any],
                payload: Dict[str, Any]) -> Dict[str, Any]:
    """Commit or recover one START/RESULT receipt under ``RUNTIME_LOCK``.

    This public function acquires the registry lock itself.  Callers must not
    invoke it from inside ``runtime_registry._locked``; the production control
    path calls it only between registry mutations and tests enforce that shape.
    """
    if phase not in _PHASES:
        raise TurnLedgerError("turn phase must be START or RESULT")
    clean_identity = _validate_identity(identity)
    clean_payload = _validate_payload(phase, payload)
    digest = request_digest(
        phase=phase, identity=clean_identity, payload=clean_payload)

    def mutate() -> Dict[str, Any]:
        active = _active_snapshot_unlocked(clean_identity)
        if phase == "RESULT":
            handle = rr.validate_handle(active.get("handle"))
            if handle.get("kind") != "session_uuid" \
                    or clean_payload["session_id"] != handle.get("ref"):
                raise TurnLedgerError(
                    "RESULT session id differs from the ACTIVE attested handle")
        fd = _open_ledger()
        try:
            index = _scan(fd)
            key = (clean_identity["seat"], clean_identity["runtime_id"],
                   clean_identity["generation"], clean_identity["turn_id"], phase)
            previous = index.get(key)
            if previous is not None:
                if previous["request_digest"] != digest:
                    raise TurnLedgerError(
                        "turn key was already committed with a conflicting digest")
                return previous
            identity_prefix = (clean_identity["seat"],
                               clean_identity["runtime_id"],
                               clean_identity["generation"])
            if phase == "START":
                for existing_key in index:
                    if existing_key[:3] != identity_prefix \
                            or existing_key[4] != "START":
                        continue
                    result_key = (*existing_key[:4], "RESULT")
                    if result_key not in index:
                        raise TurnLedgerError(
                            "another turn is already open for this runtime generation")
            if phase == "RESULT":
                start_key = (clean_identity["seat"], clean_identity["runtime_id"],
                             clean_identity["generation"],
                             clean_identity["turn_id"], "START")
                if start_key not in index:
                    raise TurnLedgerError(
                        "RESULT has no durable START receipt for this turn")
            record = {
                "schema_version": SCHEMA_VERSION,
                "canonicalization_version": CANONICALIZATION_VERSION,
                "phase": phase, **clean_identity,
                "request_digest": digest,
                "receipt_id": "trn-" + secrets.token_hex(16),
                "payload": clean_payload,
            }
            record = _validate_record(record)
            raw = canonical_json(record) + b"\n"
            if os.fstat(fd).st_size + len(raw) > MAX_LEDGER_BYTES \
                    or len(index) + 1 > MAX_LEDGER_ROWS:
                raise TurnLedgerError(
                    "runtime turn ledger has no full-scan capacity for this receipt")
            view = memoryview(raw)
            while view:
                written = os.write(fd, view)
                if written <= 0:
                    raise TurnLedgerError("short append to runtime turn ledger")
                view = view[written:]
            os.fsync(fd)
            final = os.fstat(fd)
            if not stat.S_ISREG(final.st_mode) \
                    or final.st_size > MAX_LEDGER_BYTES:
                raise TurnLedgerError("runtime turn ledger changed after append")
            return record
        finally:
            os.close(fd)

    return rr._locked(mutate)


def record_start(identity: Dict[str, Any], *, prompt_sha256: str) -> Dict[str, Any]:
    return record_turn(
        phase="START", identity=identity, payload=start_payload(prompt_sha256))


def record_result(identity: Dict[str, Any], **result: Any) -> Dict[str, Any]:
    return record_turn(
        phase="RESULT", identity=identity, payload=result_payload(**result))
