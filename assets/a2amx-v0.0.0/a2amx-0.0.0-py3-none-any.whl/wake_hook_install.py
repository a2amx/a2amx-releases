"""CoS provisioning instrument; invocation never grants authority to install.

Run only under the named seat pilot's Z, from the provisioner's workspace.
Adds/removes exactly its generated hook; other settings values are preserved.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shlex
import sys
import tempfile


def definition(home, *, python=sys.executable, module='wake_hook_claude'):
    return {'hooks':[{'type':'command','command':shlex.join([python,'-I','-m',module,'--home',str(home)]),
                      'timeout':20}]}


def update(home, *, remove=False, python=sys.executable):
    home=Path(home)
    if not home.is_absolute() or home.resolve()!=home or not home.is_dir():
        raise ValueError('seat home must be an existing canonical directory')
    if Path.cwd().resolve().is_relative_to(home):
        raise ValueError('run provisioning from the provisioner workspace, never the target seat')
    target=home/'.claude/settings.json'
    if target.is_symlink() or target.parent.is_symlink(): raise ValueError('settings symlink refused')
    old=target.read_bytes() if target.exists() else None
    settings=json.loads(old) if old else {}
    if not isinstance(settings,dict): raise ValueError('settings must be a JSON object')
    hooks=settings.setdefault('hooks',{})
    if not isinstance(hooks,dict): raise ValueError('hooks must be a JSON object')
    entries=hooks.get('UserPromptSubmit',[])
    if not isinstance(entries,list): raise ValueError('UserPromptSubmit must be a list')
    own=definition(home,python=python)
    if remove:
        revised=[entry for entry in entries if entry!=own]
        if revised==entries:return {'changed':False,'action':'already_absent'}
    else:
        if own in entries:return {'changed':False,'action':'already_installed'}
        revised=[*entries,own]
    if revised:hooks['UserPromptSubmit']=revised
    else:hooks.pop('UserPromptSubmit',None)
    target.parent.mkdir(mode=0o700,exist_ok=True)
    fd,temp=tempfile.mkstemp(prefix='.orch-hook-',dir=target.parent)
    try:
        with os.fdopen(fd,'w') as f:
            json.dump(settings,f,indent=2,ensure_ascii=False);f.write('\n');f.flush();os.fsync(f.fileno())
        if old is not None:os.chmod(temp,target.stat().st_mode & 0o777)
        os.replace(temp,target)
        fd=os.open(target.parent,os.O_RDONLY)
        try:os.fsync(fd)
        finally:os.close(fd)
    finally:Path(temp).unlink(missing_ok=True)
    return {'changed':True,'action':'removed' if remove else 'installed','path':str(target),
            'effective':'installation picked up immediately in measured Claude sessions; removal pickup unmeasured; pilot Z required',
            'preservation':'JSON values; formatting may change and an empty hooks object may remain'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--home',required=True)
    parser.add_argument('--remove',action='store_true')
    args=parser.parse_args()
    try: print(json.dumps(update(args.home,remove=args.remove)))
    except (OSError,ValueError):
        print('hook provisioning refused; settings unchanged or completion uncertain',file=sys.stderr)
        return 1
    return 0


if __name__=='__main__':raise SystemExit(main())
