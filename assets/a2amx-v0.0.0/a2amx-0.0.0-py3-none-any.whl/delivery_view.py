"""The delivery view: what a read puts into a seat's context of a stored message.

The seat's inbox file keeps every record whole. A delivery (a hook's or a read's) prints each record with three parts removed,
and nothing else changed:

1. from ``envelope``: ``bluf`` (the text's opening, repeated), ``v``, ``triage``, and ``confirm`` when
   it is false; ``re``, ``authority``, a true ``confirm`` and any other envelope field stay;
2. ``vet``, when its verdict and disposition are PASS and every row is PASS; otherwise only its PASS
   rows, so a message that is not PASS keeps its verdict, disposition, reason and every other row;
3. the displayed ``to``, when the typed ``recipients`` are present.

A field this list does not name is printed as stored (``meta``, ``supersedes``, ``cites``, a recall's
projection). Every value printed is the stored value at the same path, except the report's
``checks``: the rows kept are an order-preserving subsequence of the stored rows, so their indices
may compact. A seat can compare a read with its inbox file by removing the
same parts. A record, envelope or report of an unexpected shape is printed as stored: the view
removes only what it can show is PASS or repeated.

The definition lives in wake_hook_core.py, the hooks' pinned client module, so that the three
vendors' hooks and the two reads print one definition without adding a file to the hooks'
qualified client sources. This module is its name for the reads.
"""
from wake_hook_core import ENVELOPE_REMOVED, PASS  # noqa: F401
from wake_hook_core import delivery_view as view
from wake_hook_core import dump_delivery_views as dumps

__all__ = ['view', 'dumps', 'ENVELOPE_REMOVED', 'PASS']
