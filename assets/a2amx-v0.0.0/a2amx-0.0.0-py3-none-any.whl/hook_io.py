"""Bounded native-hook JSON input, independent of any desktop transport."""
import json
import os
import selectors
import stat
import time


def read_bytes(fd, *, limit=16384, timeout=2.0):
    info=os.fstat(fd)
    if stat.S_ISREG(info.st_mode):
        if info.st_size>limit:raise ValueError('hook input too large')
        data=os.read(fd,limit+1)
        if len(data)!=info.st_size:raise ValueError('incomplete hook input')
    else:
        data=bytearray();deadline=time.monotonic()+timeout
        with selectors.DefaultSelector() as ready:
            ready.register(fd,selectors.EVENT_READ)
            while True:
                left=deadline-time.monotonic()
                if left<=0 or not ready.select(left):raise TimeoutError('hook input deadline')
                chunk=os.read(fd,min(4096,limit+1-len(data)))
                if not chunk:break
                data.extend(chunk)
                if len(data)>limit:raise ValueError('hook input too large')
    return bytes(data)


def read_json(fd, *, limit=16384, timeout=2.0):
    data=read_bytes(fd,limit=limit,timeout=timeout)
    value=json.loads(data)
    if not isinstance(value,dict):raise ValueError('hook input must be an object')
    return value
