"""The focus period: D-GOV-2 (f) of ORCH_SPEC_01_ADDENDUM_FOCUS_04, adopted 2026-10-05.

A seat may tell the store "do not wake me for the next N minutes". Its mail is
admitted, QUEUED, counted and fetchable exactly as without a period; only the
emission of a *new* wake attempt (D-POKE-3's poke, a new D-POKE-2b ``pre``) is
deferred. Every open attempt keeps its own retries, further attempts, holds and
reconciliations. The contract, with the builder's readings the author settled,
is docs/FOCUS_PERIOD.md.

Records are rows of the shared receipt journal (store/receipts.jsonl), appended
under the nudge lock, so a declaration, a message commit and a ``pre`` are
ordered by one exclusion boundary:

* ``focus-policy``: a hash-chained compare-and-set series written only under a
  ``human_authority`` token. Its first row is the activation and carries the
  maximum; a later row changes the maximum or sets the feature inactive.
* ``focus-period``: one ``start`` row per period and exactly one ``end`` row.
* ``delivery-disposition``: one ``DEFERRED`` row per message QUEUED for a seat
  while its period is active, with ``detail`` ``focus: <period id>``.

Inert until activated: with no policy row ``focus start`` refuses
``focus_inactive`` and nothing reads a period. The sentinel ``store/focus-enabled``,
written with the first policy row, is the send path's and the daemon's only
read while the feature has never been switched on.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import time
from datetime import datetime, timezone
from typing import Any, Dict, Iterable

import receipts
import store

POLICY_KIND = 'focus-policy'
PERIOD_KIND = 'focus-period'
DISPOSITION_KIND = 'delivery-disposition'
KINDS = frozenset({POLICY_KIND, PERIOD_KIND, DISPOSITION_KIND})
SENTINEL = 'focus-enabled'
REASON_BYTES = 256
MAXIMUM_BOUND = 10080  # a week, in minutes: a sanity bound on the principal's number, not a default
CAUSES = ('expired', 'released', 'broken', 'pass-through')
ROUTE_KINDS = frozenset({'codex-ipc', 'inapp-socket', 'agy-desktop', 'launched'})
POLICY_FIELDS = frozenset({'kind', 'event', 'state', 'maximum_minutes', 'previous_generation',
                           'generation', 'requester', 'reason', 'log_offset', 'ts'})
START_FIELDS = frozenset({'kind', 'phase', 'period-id', 'seat', 'actor', 'minutes', 'start_epoch',
                          'end_epoch', 'reason', 'policy_generation', 'listed_pre', 'log_offset', 'ts'})
END_FIELDS = frozenset({'kind', 'phase', 'period-id', 'seat', 'cause', 'actor', 'reason', 'epoch', 'ts'})
DISPOSITION_FIELDS = frozenset({'kind', 'event', 'msg-id', 'seat', 'detail', 'period-id', 'ts'})


class Refused(ValueError):
    """A stable, typed refusal: ``str(exc)`` is the reason the CLI prints."""


def digest(value) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     ensure_ascii=True, allow_nan=False).encode()).hexdigest()


def _is_digest(value) -> bool:
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def sentinel_path():
    return store.STORE_DIR / SENTINEL


def switched_on_once() -> bool:
    """True once any policy row was written. The sole read while never activated."""
    return sentinel_path().exists()


def _write_sentinel() -> None:
    path = sentinel_path()
    if not path.exists():
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_NOFOLLOW, 0o600)
        os.close(fd)


def _iso(epoch: float) -> str:
    return datetime.fromtimestamp(epoch, timezone.utc).astimezone().isoformat(timespec='seconds')


def valid_reason(reason, *, required: bool) -> str | None:
    """One line of at most 256 bytes of UTF-8 (§3.9), or None where optional."""
    if reason is None or reason == '':
        if required:
            raise Refused('reason_required')
        return None
    if (not isinstance(reason, str) or len(reason.encode('utf-8')) > REASON_BYTES
            or any(ord(c) < 32 or c in '\x7f\x85  ' for c in reason)):
        raise Refused('reason_must_be_one_line_at_most_256_bytes')
    return reason


# --- reading the records ---------------------------------------------------------------

def policy(rows: Iterable[Dict[str, Any]]) -> Dict[str, Any] | None:
    """The current row of the complete CAS series; a malformed series never rolls back."""
    current = None
    for row in rows:
        if row.get('kind') != POLICY_KIND:
            continue
        expected = current['generation'] if current else 'none'
        state, maximum = row.get('state'), row.get('maximum_minutes')
        if (set(row) != POLICY_FIELDS or row.get('event') != 'recorded'
                or state not in {'active', 'inactive'}
                or (state == 'active' and (type(maximum) is not int or not 1 <= maximum <= MAXIMUM_BOUND))
                or (state == 'inactive' and maximum is not None)
                or row.get('previous_generation') != expected
                or row.get('generation') != digest({k: v for k, v in row.items() if k != 'generation'})
                or not isinstance(row.get('requester'), str) or not row['requester']
                or not isinstance(row.get('reason'), str) or not row['reason']
                or type(row.get('log_offset')) is not int or row['log_offset'] < 0
                or not isinstance(row.get('ts'), str)):
            raise Refused('focus_policy_unavailable')
        current = row
    return current


def periods(rows: Iterable[Dict[str, Any]]):
    """(starts, ends) by period id. Any focus-period row failing its schema raises."""
    starts: Dict[str, Dict[str, Any]] = {}
    ends: Dict[str, Dict[str, Any]] = {}
    for row in rows:
        if row.get('kind') != PERIOD_KIND:
            continue
        pid, phase = row.get('period-id'), row.get('phase')
        if not isinstance(pid, str) or not pid.startswith('focus-'):
            raise Refused('focus_policy_degraded')
        if phase == 'start':
            listed = row.get('listed_pre')
            if (set(row) != START_FIELDS or pid in starts
                    or not isinstance(row.get('seat'), str) or not row['seat']
                    or not isinstance(row.get('actor'), str) or not row['actor']
                    or type(row.get('minutes')) is not int or row['minutes'] < 1
                    or not all(isinstance(row.get(k), (int, float)) and not isinstance(row.get(k), bool)
                               for k in ('start_epoch', 'end_epoch'))
                    or row['end_epoch'] != row['start_epoch'] + 60 * row['minutes']
                    or (row.get('reason') is not None and not isinstance(row['reason'], str))
                    or not _is_digest(row.get('policy_generation'))
                    or type(row.get('log_offset')) is not int or row['log_offset'] < 0
                    or not isinstance(listed, list) or not all(isinstance(e, str) for e in listed)):
                raise Refused('focus_policy_degraded')
            starts[pid] = row
        elif phase == 'end':
            if (set(row) != END_FIELDS or pid not in starts or pid in ends
                    or row.get('seat') != starts[pid]['seat']
                    or row.get('cause') not in CAUSES
                    or not isinstance(row.get('actor'), str) or not row['actor']
                    or (row.get('reason') is not None and not isinstance(row['reason'], str))
                    or not isinstance(row.get('epoch'), (int, float))):
                raise Refused('focus_policy_degraded')
            ends[pid] = row
        else:
            raise Refused('focus_policy_degraded')
    return starts, ends


def _epoch_of(ts) -> float | None:
    try:
        return datetime.fromisoformat(ts).timestamp() if isinstance(ts, str) else None
    except ValueError:
        return None


def projection(rows, now: float) -> Dict[str, Any]:
    """The one validated reading every veto, end and act shares.

    Raises ``Refused('focus_policy_unavailable')`` for a malformed policy series
    and ``Refused('focus_policy_degraded')`` for a malformed period row; every
    veto then fails open (§3.10). Otherwise returns:

    * ``recorded``: whether any policy row exists;
    * ``policy``: the current policy row, or None;
    * ``active``: seat -> start row of each period that defers;
    * ``owed``: period id -> the end the journal already makes due, earliest
      first: ``expired`` at its end time, ``broken`` by a later inactive policy
      row, or ``pass-through`` by a later withdrawal notice to that seat as a
      reader (§3.3, §3.4, msg-efb024be3a point 8). An owed period defers nothing
      even before its end record is written; ``settle_unlocked`` writes it.
    """
    rows = list(rows)
    current = policy(rows)
    starts, ends = periods(rows)
    position = {id(r): i for i, r in enumerate(rows)}
    inactive = [(i, r) for i, r in enumerate(rows)
                if r.get('kind') == POLICY_KIND and r.get('state') == 'inactive']
    withdrawals = [(i, r) for i, r in enumerate(rows)
                   if r.get('kind') == 'withdraw' and isinstance(r.get('epoch'), (int, float))
                   and isinstance(r.get('readers'), (dict, list))]
    found: Dict[str, Dict[str, Any]] = {}
    owed: Dict[str, Dict[str, Any]] = {}
    for pid, start in starts.items():
        if pid in ends:
            continue
        here = position[id(start)]
        due = []
        if now >= start['end_epoch']:
            due.append((start['end_epoch'], 'expired', store.DAEMON_SEAT, None))
        killer = next((r for i, r in inactive if i > here), None)
        if killer is not None:
            when = _epoch_of(killer.get('ts'))
            due.append((start['start_epoch'] if when is None else when, 'broken',
                        killer['requester'], 'focus policy set inactive'))
        notice = next((r for i, r in withdrawals if i > here and start['seat'] in r['readers']
                       and r['epoch'] < start['end_epoch']), None)
        if notice is not None:
            due.append((notice['epoch'], 'pass-through', str(notice.get('from')),
                        f"withdrawal notice for {notice.get('supersedes')}"))
        if due:
            epoch, cause, actor, reason = min(due, key=lambda d: d[0])
            owed[pid] = {'start': start, 'cause': cause, 'actor': actor, 'reason': reason,
                         'epoch': epoch}
        else:
            found[start['seat']] = start
    recorded = any(r.get('kind') == POLICY_KIND for r in rows)
    return {'recorded': recorded, 'policy': current, 'active': found, 'owed': owed}


def active(rows, now: float) -> Dict[str, Dict[str, Any]]:
    """Seat -> its deferring period's start row, from the validated projection."""
    return projection(rows, now)['active']


def _blocking(view: Dict[str, Any], seat: str) -> Dict[str, Any] | None:
    """The period that holds a new wake for *seat*: an active one, or one whose end
    the journal makes due but does not yet hold (its end record is not written)."""
    start = view['active'].get(seat)
    if start is not None:
        return start
    return next((o['start'] for o in view['owed'].values() if o['start']['seat'] == seat), None)


def deferring_unlocked(seat: str, rows=None, now: float | None = None) -> Dict[str, Any] | None:
    """The period that defers a new wake attempt for *seat*, or None. Fails open (§3.10).

    The caller holds the nudge lock (the chokepoints do); a declaration therefore
    either precedes this read or follows it, never interleaves. Before it answers,
    every end the record owes this seat is written: a period that has ended (its
    end time passed, an inactive policy row, a withdrawal to the seat as a reader)
    has its end record before any new ``pre``, and a principal's message whose end
    record failed at its admission is never deferred against. If that end cannot be
    written now, the period still holds the wake (``focus_deferred``) until a later
    call writes it: a failed write is not a failed read, and only an unreadable or
    malformed record fails open.
    """
    if not switched_on_once():
        return None
    now = time.time() if now is None else now
    try:
        rows = receipts.strict_rows() if rows is None else rows
        if _blocking(projection(rows, now), seat) is None:
            return None
        if settle_unlocked(now, rows=rows):
            rows = receipts.strict_rows()
        return _blocking(projection(rows, now), seat)
    except (Refused, ValueError, OSError):
        return None


def focusing_seats(now: float | None = None) -> Dict[str, Dict[str, Any]]:
    """One read for the daemon's pass, after its settle: seat -> the period holding its wake.

    An active period, or one whose end the settle could not write. Fails open.
    """
    if not switched_on_once():
        return {}
    try:
        view = projection(receipts.strict_rows(), time.time() if now is None else now)
    except (Refused, ValueError, OSError):
        return {}
    held = {o['start']['seat']: o['start'] for o in view['owed'].values()}
    return {**held, **view['active']}


# --- the outstanding-attempt predicate of §2 --------------------------------------------

def _attempts(rows, seat: str):
    pres = [r for r in rows if r.get('kind') == 'nudge' and r.get('phase') == 'pre'
            and r.get('target seat') == seat and r.get('route_kind') in ROUTE_KINDS]
    posts: Dict[str, Dict[str, Any]] = {}
    for r in rows:
        if r.get('kind') == 'nudge' and r.get('phase') == 'post':
            posts[r.get('event-id')] = r
    return pres, posts


def _resolution_index(rows, seat: str):
    """Everything §2 counts as resolving an attempt, keyed for lookup."""
    import recall
    reconciled = {r.get('event-id', r.get('nudge-event-id')) for r in rows
                  if r.get('kind') in {'recall-reconciliation', 'wake-reconciled', 'claude-reconciliation'}}
    dead_events = {r.get('event-id') for r in rows if r.get('kind') == 'wake_route_dead'}
    dead_terminal = [(i, r) for i, r in enumerate(rows) if r.get('kind') == 'wake_route_dead'
                     and r.get('seat') == seat and r.get('terminal')]
    held = {r.get('nudge-event-id', r.get('event-id')) for r in rows
            if r.get('kind') in {'claude-route-hold', 'wake_route_hold'}}
    fetched = {}
    for position, row in store.valid_fetched_deliveries(rows):
        if row.get('seat') == seat and isinstance(row.get('msg-id'), str):
            fetched.setdefault(row['msg-id'], []).append(position)
    for position, row in enumerate(rows):
        if (row.get('kind') == 'delivery' and row.get('event') == 'FETCHED' and row.get('txn-id') is None
                and row.get('seat') == seat and isinstance(row.get('msg-id'), str)):
            fetched.setdefault(row['msg-id'], []).append(position)
    return {'reconciled': reconciled, 'dead_events': dead_events, 'dead_terminal': dead_terminal,
            'held': held, 'fetched': fetched, 'recalled': set(recall.graph(rows))}


def outstanding_attempts(rows, seat: str) -> list[str]:
    """Event ids of *seat*'s attempts that §2 counts outstanding.

    Outstanding: the attempt's current state is ``uncertain`` (its post) or held
    (a hold row for it), and the record holds none of: a reconciliation row for it
    (the seat's fetch, ``recalled``, hook observation); the seat's valid FETCHED of
    its message after its ``pre`` (§2 (i), read without the T bound: the builder's
    reading, docs/FOCUS_PERIOD.md); a recall of its message; a further attempt that
    supersedes it and is itself resolved; a ``wake_route_dead`` written for it or a
    terminal one for the seat after it. tmux attempts post only success/failure and
    are never outstanding. A ``pre`` with no post is UNKNOWN, never outstanding.
    """
    pres, posts = _attempts(rows, seat)
    index = _resolution_index(rows, seat)
    position = {id(r): i for i, r in enumerate(rows)}
    by_supersedes: Dict[str, list] = {}
    for pre in pres:
        if isinstance(pre.get('supersedes'), str):
            by_supersedes.setdefault(pre['supersedes'], []).append(pre)
    memo: Dict[str, bool] = {}

    def resolved(pre) -> bool:
        eid = pre.get('event-id')
        if eid in memo:
            return memo[eid]
        memo[eid] = False  # a cycle can resolve nothing
        here = position[id(pre)]
        post = posts.get(eid)
        done = (eid in index['reconciled'] or eid in index['dead_events']
                or pre.get('msg-id') in index['recalled']
                or any(p > here for p in index['fetched'].get(pre.get('msg-id'), []))
                or any(i > here for i, _ in index['dead_terminal'])
                or (post is not None and post.get('result') in {'accepted', 'refused', 'recalled'}
                    and eid not in index['held'])
                or any(settled(later) for later in by_supersedes.get(eid, [])))
        memo[eid] = done
        return done

    def settled(pre) -> bool:
        """A further attempt counts once it is itself resolved (§2 (iii))."""
        return resolved(pre)

    result = []
    for pre in pres:
        eid = pre.get('event-id')
        post = posts.get(eid)
        open_state = ((post is not None and post.get('result') in {'uncertain', 'held'})
                      or eid in index['held'])
        if open_state and not resolved(pre):
            result.append(eid)
    return result


def unknown_attempts(rows, seat: str) -> list[str]:
    """``pre`` rows with no post, no reconciliation and no recall: listed by a declaration."""
    import recall
    recalled = set(recall.graph(rows))
    posts = {r.get('event-id') for r in rows if r.get('kind') == 'nudge' and r.get('phase') == 'post'}
    reconciled = {r.get('event-id', r.get('nudge-event-id')) for r in rows
                  if r.get('kind') in {'recall-reconciliation', 'wake-reconciled', 'claude-reconciliation'}}
    return [r['event-id'] for r in rows if r.get('kind') == 'nudge' and r.get('phase') == 'pre'
            and r.get('target seat') == seat and isinstance(r.get('event-id'), str)
            and r['event-id'] not in posts and r['event-id'] not in reconciled
            and r.get('msg-id') not in recalled]


# --- writing the records (caller holds the nudge lock) --------------------------------------

def _append(row: Dict[str, Any]) -> Dict[str, Any]:
    return receipts.append_durable(row)


def _end_unlocked(start: Dict[str, Any], cause: str, actor: str, reason: str | None,
                  now: float) -> Dict[str, Any] | None:
    """Exactly one end record per period: the first cause to commit is the end."""
    _, ends = periods(receipts.strict_rows())
    if start['period-id'] in ends:
        return None
    return _append({'kind': PERIOD_KIND, 'phase': 'end', 'period-id': start['period-id'],
                    'seat': start['seat'], 'cause': cause, 'actor': actor, 'reason': reason,
                    'epoch': now, 'ts': store.now_iso()})


# --- the admission's focus evidence, and its repair --------------------------------------
#
# Once a policy row exists, every admitted message's canonical record carries
# ``focus_commit``, decided under the commit's nudge lock and written in the same
# append as the admission itself: the recipients journaled QUEUED at the commit,
# the recipients whose wake the admission defers (period id each), and the
# recipients whose period it ends as a pass-through. The receipt rows that follow
# (QUEUED, DEFERRED, the pass-through end) are written under the same lock; any
# that fails is owed, and ``settle_unlocked`` writes it from the canonical record,
# once, before any wake is selected and before any declaration decides.

def _log_size() -> int:
    """The message log's size: the byte position the next admission is appended at."""
    return store.LOG_FILE.stat().st_size if store.LOG_FILE.exists() else 0


def _admissions_from(offset: int) -> tuple[list[Dict[str, Any]], int]:
    """Canonical records carrying ``focus_commit`` at or after byte *offset*, and the end read.

    Positions, not timestamps, order the log: a record appended later with an
    older ``ts`` (a recall's recovery) is read where it stands.
    """
    if offset > _log_size():
        offset = 0  # the log was replaced
    found: list[Dict[str, Any]] = []
    while True:
        records, after = store.read_jsonl(store.LOG_FILE, offset)
        found.extend(r for r in records if isinstance(r, dict) and isinstance(r.get('focus_commit'), dict))
        if after == offset:
            return found, offset
        offset = after


def _owed_by_admissions(rows, admissions) -> list[Dict[str, Any]]:
    """The receipt rows the canonical admissions owe and the journal lacks, in order."""
    import recall
    recalled = set(recall.graph(rows))  # a recalled message owes no QUEUED; its other rows stand
    delivered = {(r.get('msg-id'), r.get('seat')) for r in rows if r.get('kind') == 'delivery'}
    delivered |= {(r.get('msg-id'), r.get('seat')) for _, r in store.valid_fetched_deliveries(rows)}
    disposed = {(r.get('msg-id'), r.get('seat')) for r in rows
                if r.get('kind') == DISPOSITION_KIND and r.get('event') == 'DEFERRED'}
    owed = []
    for record in admissions:
        mid, fc = record.get('id'), record['focus_commit']
        if not isinstance(mid, str):
            continue
        for seat in fc.get('queued') or []:
            if (mid, seat) not in delivered and mid not in recalled:
                owed.append({'kind': 'delivery', 'msg-id': mid, 'seat': seat, 'event': 'QUEUED'})
        for seat, pid in sorted((fc.get('deferred') or {}).items()):
            if (mid, seat) not in disposed:
                owed.append(_deferred_row(mid, seat, pid))
        for seat, pid in sorted((fc.get('pass_through') or {}).items()):
            owed.append({'kind': PERIOD_KIND, 'phase': 'end', 'period-id': pid, 'seat': seat,
                         'cause': 'pass-through', 'actor': str(record.get('from')),
                         'reason': f"message {mid} authored under human_authority",
                         'epoch': _epoch_of(record.get('ts'))})
    return owed


def _deferred_row(msg_id: str, seat: str, period_id: str) -> Dict[str, Any]:
    return {'kind': DISPOSITION_KIND, 'event': 'DEFERRED', 'msg-id': msg_id, 'seat': seat,
            'detail': f"focus: {period_id}", 'period-id': period_id}


def _write_owed(row: Dict[str, Any], now: float) -> Dict[str, Any] | None:
    """One owed row, idempotently: a period's end only while it has none."""
    if row['kind'] == 'delivery':
        return receipts.journal(row['msg-id'], row['seat'], 'QUEUED')
    if row['kind'] == DISPOSITION_KIND:
        return _append({**row, 'ts': store.now_iso()})
    starts, ends = periods(receipts.strict_rows())
    if row['period-id'] in ends or row['period-id'] not in starts:
        return None
    return _end_unlocked(starts[row['period-id']], row['cause'], row['actor'], row['reason'],
                         row['epoch'] if isinstance(row.get('epoch'), (int, float)) else now)


_DAEMON_CURSOR: Dict[tuple, int] = {}


def _log_key() -> tuple:
    try:
        st = store.LOG_FILE.stat()
        return (str(store.LOG_FILE), st.st_dev, st.st_ino)
    except OSError:
        return (str(store.LOG_FILE), None, None)


def _activation_offset(rows) -> int:
    """Where the message log stood at the first policy row: no earlier admission carries evidence."""
    first = next((r for r in rows if r.get('kind') == POLICY_KIND), None)
    return first['log_offset'] if first is not None and type(first.get('log_offset')) is int else 0


def settle_unlocked(now: float | None = None, *, rows=None, scope: str = 'periods') -> list[Dict[str, Any]]:
    """Write every row the record owes, once each; the caller holds the nudge lock.

    First the admissions' owed QUEUED, DEFERRED and pass-through ends, read from
    the canonical log forward from a byte position chosen by *scope*:

    * ``periods``: the earliest unended period's start (sends, chokepoints, acts);
      with no unended period, no admission is read;
    * ``activation``: the first policy row (a declaration);
    * ``daemon``: this process's cursor, which starts at the activation and
      advances only past admissions whose rows were all written.

    Then the ends the journal makes due (expiry, deactivation, a withdrawal to a
    reader). Fails open: a record it cannot read is left for the next settle, and
    a write that fails stops it. Returns the rows written. *rows*, when given, is
    the caller's read of the journal under the same lock.
    """
    if not switched_on_once():
        return []
    now = time.time() if now is None else now
    written: list[Dict[str, Any]] = []
    try:
        rows = receipts.strict_rows() if rows is None else rows
        projection(rows, now)  # a malformed record settles nothing
        if scope == 'activation':
            offset = _activation_offset(rows)
        elif scope == 'daemon':
            offset = _DAEMON_CURSOR.get(_log_key(), _activation_offset(rows))
        else:
            starts, ends = periods(rows)
            unended = [r['log_offset'] for pid, r in starts.items() if pid not in ends]
            offset = min(unended) if unended else None
        if offset is not None:
            admissions, through = _admissions_from(offset)
            for row in _owed_by_admissions(rows, admissions):
                done = _write_owed(row, now)
                if done is not None:
                    written.append(done)
            if scope == 'daemon':
                _DAEMON_CURSOR[_log_key()] = through
        for owed in projection(receipts.strict_rows() if written else rows, now)['owed'].values():
            done = _end_unlocked(owed['start'], owed['cause'], owed['actor'], owed['reason'], owed['epoch'])
            if done is not None:
                written.append(done)
    except (Refused, ValueError, OSError):
        pass
    return written


def settle(now: float | None = None, *, daemon: bool = False) -> list[Dict[str, Any]]:
    """The daemon's first act on start and on each pass, before any pointer selection."""
    if not switched_on_once():
        return []
    with receipts._nudge_lock():
        return settle_unlocked(now, scope='daemon' if daemon else 'periods')


def describe(row: Dict[str, Any]) -> str:
    """One log line for a row ``settle`` wrote."""
    if row.get('kind') == PERIOD_KIND:
        return f"focus period {row['period-id']} of {row['seat']} ended: {row['cause']}"
    return f"focus evidence repaired: {row.get('event')} of {row.get('msg-id')} for {row.get('seat')}"


def before_commit_unlocked(record: Dict[str, Any], author_role: str | None, queued: list[str],
                           now: float | None = None) -> Dict[str, Any] | None:
    """Inside a message's commit, before its canonical append, under the nudge lock.

    Returns None while no policy row exists: the commit is then exactly today's.
    Otherwise decides §3.2's deferral and §3.4's pass-through per recipient, sets
    the store-owned ``focus_commit`` on the record (so the admission itself carries
    them), and returns the plan for ``after_commit_unlocked``. Fails open: an
    unreadable or malformed record defers nothing and ends nothing.
    """
    if not switched_on_once():
        return None
    now = time.time() if now is None else now
    deferred: Dict[str, Dict[str, Any]] = {}
    ending: Dict[str, Dict[str, Any]] = {}
    try:
        rows = receipts.strict_rows()
        view = projection(rows, now)
        if not view['recorded']:
            return None
        recipients = record.get('mailbox_recipients') or []
        if any(seat in view['active'] for seat in recipients) and settle_unlocked(now, rows=rows):
            view = projection(receipts.strict_rows(), now)
        for seat in recipients:
            start = view['active'].get(seat)
            if start is not None:
                (ending if author_role == 'human_authority' else deferred)[seat] = start
    except (Refused, ValueError, OSError):
        deferred, ending = {}, {}
    record['focus_commit'] = {'queued': list(queued),
                              'deferred': {s: st['period-id'] for s, st in sorted(deferred.items())},
                              'pass_through': {s: st['period-id'] for s, st in sorted(ending.items())}}
    return {'queued': list(queued), 'deferred': deferred, 'ending': ending, 'now': now}


def after_commit_unlocked(record: Dict[str, Any], plan: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    """After the canonical append, under the same lock: QUEUED, then DEFERRED, then the ends.

    A row that cannot be written never strands the admission; it stays owed by
    the record's ``focus_commit`` and ``settle_unlocked`` writes it. Returns
    seat -> period for the send result.
    """
    for row in _owed_by_admissions([], [record]):
        try:
            _write_owed(row, plan['now'])
        except OSError:
            continue
    return plan['deferred']


def withdrawal_unlocked(event: Dict[str, Any], now: float | None = None) -> list[Dict[str, Any]]:
    """§3.4: a withdrawal notice to a seat that fetched the message ends that seat's period.

    Called once, at the withdrawal's admission under the nudge lock; the
    admitted event itself is the evidence, so an end that fails here is owed in
    the projection and written by the next settle. Replays never append the
    event again, so a replay ends no later period.
    """
    if not switched_on_once() or event.get('kind') != 'withdraw':
        return []
    try:
        return settle_unlocked(time.time() if now is None else now)
    except OSError:
        return []


# --- the acts -------------------------------------------------------------------------------

def _actor_role(actor: str) -> str | None:
    parts = store._read_participants_unlocked()
    return (parts.get(actor) or {}).get('role')


def _read_for_act(now: float):
    """Strict reads every act shares; typed refusals for each kind of failure."""
    try:
        rows = receipts.strict_rows()
    except (ValueError, OSError):
        raise Refused('focus_policy_degraded') from None
    current = policy(rows)
    _heal_sentinel(current)
    try:
        periods(rows)
    except Refused:
        raise Refused('focus_policy_degraded') from None
    return rows, current


def _heal_sentinel(current: Dict[str, Any] | None) -> None:
    """Under the nudge lock: a recorded policy row always has its sentinel.

    The gates read the sentinel first; an act that finds a policy row without it
    (a sentinel removed by hand) restores it before deciding anything.
    """
    if current is not None and not switched_on_once():
        _write_sentinel()


def _admission_gaps(rows, seat: str, offset: int) -> list[str]:
    """Message ids whose admission owes *seat* a QUEUED row the journal still lacks."""
    return sorted({row['msg-id'] for row in _owed_by_admissions(rows, _admissions_from(offset)[0])
                   if row.get('seat') == seat and row['kind'] == 'delivery'})


def _policy_row_recorded(generation: str) -> bool:
    """Whether the journal holds the policy row; an unreadable journal counts as yes."""
    try:
        return any(r.get('kind') == POLICY_KIND and r.get('generation') == generation
                   for r in receipts.strict_rows())
    except (ValueError, OSError):
        return True


def set_policy(*, presented_token: str, maximum: int | None, expected_generation: str,
               reason: str, clock=time.time) -> Dict[str, Any]:
    """Activation, a new maximum, or deactivation: one CAS row, the principal's alone."""
    if expected_generation != 'none' and not _is_digest(expected_generation):
        raise Refused('focus_expected_generation')
    if maximum is not None and (type(maximum) is not int or not 1 <= maximum <= MAXIMUM_BOUND):
        raise Refused('focus_maximum_out_of_bounds')
    reason = valid_reason(reason, required=True)

    def act(actor):
        if _actor_role(actor) != 'human_authority':
            raise Refused('focus_policy_principal_only')
        with receipts._nudge_lock():
            now = clock()
            rows = receipts.strict_rows()
            current = policy(rows)
            _heal_sentinel(current)
            if expected_generation != (current['generation'] if current else 'none'):
                raise Refused('focus_stale_policy_generation')
            row = {'kind': POLICY_KIND, 'event': 'recorded',
                   'state': 'active' if maximum is not None else 'inactive',
                   'maximum_minutes': maximum, 'previous_generation': expected_generation,
                   'requester': actor, 'reason': reason, 'log_offset': _log_size(),
                   'ts': store.now_iso()}
            row['generation'] = digest(row)
            created = not switched_on_once()
            _write_sentinel()  # first, so a policy row never exists without it
            try:
                _append(row)
            except BaseException as exc:
                # The act is committed once its row is in the journal: append_durable
                # can fail after the row is written (the directory fsync).
                recorded = _policy_row_recorded(row['generation'])
                if not recorded or not isinstance(exc, OSError):
                    if created and not recorded:
                        sentinel_path().unlink(missing_ok=True)
                    raise
            # A deactivation's ends are owed from the moment its row is recorded: no
            # period defers after it, and these ends are written now or by the next settle.
            settle_unlocked(now)
            return row
    return store.authenticated_registry_act(presented_token, act)


def declare(*, presented_token: str, minutes, reason=None, seat: str | None = None,
            clock=time.time) -> Dict[str, Any]:
    """§3.1: a declaration for the token's own seat, or by the principal for any seat."""
    reason = valid_reason(reason, required=False)

    def act(actor):
        target = seat or actor
        parts = store._read_participants_unlocked()
        role = (parts.get(actor) or {}).get('role')
        with receipts._nudge_lock():
            now = clock()
            rows, current = _read_for_act(now)
            if current is None or current['state'] != 'active':
                raise Refused('focus_inactive')
            # An admitted withdrawal whose notices are not yet materialized is
            # completed first, so its notice to the seat is pending, not missed.
            import recall
            try:
                recall.recover_unlocked()
            except Exception:
                raise Refused('pending_unknown') from None
            rows, current = _read_for_act(now)
            if target != actor and role != 'human_authority':
                raise Refused('not_the_seat')
            if target not in parts or not store.has_mailbox(parts[target]):
                raise Refused('unknown_seat')
            if type(minutes) is not int or minutes < 1:
                raise Refused('length_must_be_a_positive_whole_number_of_minutes')
            if minutes > current['maximum_minutes']:
                raise Refused('over_maximum')
            # Every owed row first, including any admission's QUEUED back to the
            # activation: mail committed before this declaration is then pending.
            if settle_unlocked(now, rows=rows, scope='activation'):
                rows, current = _read_for_act(now)
            if target in projection(rows, now)['active']:
                raise Refused('active')
            try:
                pending = receipts.pending_message_ids(target)
                gaps = _admission_gaps(rows, target, _activation_offset(rows))
            except Exception:
                raise Refused('pending_unknown') from None
            if pending:
                raise Refused('pending_mail')
            if gaps:
                raise Refused('pending_unknown')
            if outstanding_attempts(rows, target):
                raise Refused('attempt_outstanding')
            row = {'kind': PERIOD_KIND, 'phase': 'start', 'period-id': store.new_id('focus'),
                   'seat': target, 'actor': actor, 'minutes': minutes, 'start_epoch': now,
                   'end_epoch': now + 60 * minutes, 'reason': reason,
                   'policy_generation': current['generation'],
                   'listed_pre': unknown_attempts(rows, target), 'log_offset': _log_size(),
                   'ts': store.now_iso()}
            return _append(row)
    return store.authenticated_registry_act(presented_token, act)


def release(*, presented_token: str, clock=time.time) -> Dict[str, Any]:
    """The seat's own end; needs no reason (§3.5)."""
    def act(actor):
        with receipts._nudge_lock():
            now = clock()
            rows, _ = _read_for_act(now)
            if settle_unlocked(now, rows=rows):
                rows = receipts.strict_rows()
            start = projection(rows, now)['active'].get(actor)
            if start is None:
                raise Refused('no_active_period')
            return _end_unlocked(start, 'released', actor, None, now)
    return store.authenticated_registry_act(presented_token, act)


def break_period(*, presented_token: str, seat: str, reason, clock=time.time) -> Dict[str, Any]:
    """§3.5: the principal, or a seat holding the Chief of Staff role, ends another seat's period."""
    reason = valid_reason(reason, required=True)

    def act(actor):
        role = _actor_role(actor)
        if role not in {'human_authority', 'chief_of_staff'}:
            raise Refused('break_not_authorized')
        if seat == actor:
            raise Refused('own_period_release_it')
        with receipts._nudge_lock():
            now = clock()
            rows, _ = _read_for_act(now)
            if settle_unlocked(now, rows=rows):
                rows = receipts.strict_rows()
            start = projection(rows, now)['active'].get(seat)
            if start is None:
                raise Refused('no_active_period')
            return _end_unlocked(start, 'broken', actor, reason, now)
    return store.authenticated_registry_act(presented_token, act)


# --- what everyone sees (§3.9) ------------------------------------------------------------

def show(seat: str | None = None, *, now: float | None = None) -> Dict[str, Any]:
    """The policy and the active periods with their pending counts; never writes."""
    now = time.time() if now is None else now
    if not switched_on_once():
        return {'state': 'inactive', 'maximum_minutes': None, 'policy_generation': 'none', 'periods': {}}
    try:
        rows = receipts.strict_rows()
    except (ValueError, OSError):
        return {'state': 'focus_policy_degraded', 'periods': {}}
    try:
        view = projection(rows, now)
    except Refused as exc:
        # §3.10: nothing is deferred, and no period is shown as if it were.
        return {'state': str(exc), 'periods': {}}
    current, running = view['policy'], view['active']
    state = 'inactive' if current is None or current['state'] != 'active' else 'active'
    out = {}
    for name, start in sorted(running.items()):
        if seat is not None and name != seat:
            continue
        out[name] = {'period-id': start['period-id'], 'ends_at': _iso(start['end_epoch']),
                     'reason': start['reason'], 'pending': len(receipts.pending_message_ids(name))}
    return {'state': state, 'maximum_minutes': current['maximum_minutes'] if current else None,
            'policy_generation': current['generation'] if current else 'none', 'periods': out}


def status_view(now: float | None = None) -> Dict[str, Any] | None:
    """The status surface's snapshot; None until a policy row was recorded.

    The sentinel alone does not show the field: a sentinel whose first policy row
    was never written leaves the surface as it was before the feature existed.
    """
    if not switched_on_once():
        return None
    view = show(now=now)
    if view.get('state') == 'inactive' and view.get('policy_generation') == 'none':
        return None
    return view


def panel_field(seat: str, snapshot: Dict[str, Any]) -> Dict[str, Any] | None:
    """The seat row's focus value for the status surface, from one ``show`` snapshot."""
    if snapshot.get('state') in {'focus_policy_degraded', 'focus_policy_unavailable'}:
        return {'state': snapshot['state']}
    period = snapshot.get('periods', {}).get(seat)
    if period is None:
        return None
    return {'ends_at': period['ends_at'], 'pending': period['pending'], 'reason': period['reason']}
