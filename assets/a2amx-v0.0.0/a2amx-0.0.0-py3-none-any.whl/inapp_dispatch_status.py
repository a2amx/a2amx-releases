"""Authenticated daemon observations, never an arming grant or liveness claim.

The atomic snapshot remains usable when the shared receipt history is corrupt.
It is diagnostic only: dispatch/recovery never consumes it as authority/history.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import tempfile
import uuid

import store

_INSTANCE = uuid.uuid4().hex
_STARTED = store.now_iso()
_last_log = None


def path():
    return store.STORE_DIR / "inapp-dispatch-status.json"


def read():
    p = path()
    try:
        if p.is_symlink():
            return None
        value = json.loads(p.read_text())
        return value if isinstance(value, dict) and value.get("kind") == "inapp-dispatch" else None
    except (OSError, ValueError):
        return None


def _build():
    h = hashlib.sha256()
    for name in ("inapp_socket.py", "inapp_dispatch.py", "inapp_wake_route.py", "inapp_dispatch_status.py",
                 "claude_startup_state.py"):
        h.update(name.encode())
        h.update(Path(__file__).with_name(name).read_bytes())
    return h.hexdigest()


def _write(value):
    p = path()
    if p.is_symlink():
        raise ValueError("diagnostic snapshot is a symlink")
    p.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=".inapp-status-", dir=p.parent)
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(value, f, sort_keys=True)
            f.write("\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(name, p)
        directory = os.open(str(p.parent), os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        Path(name).unlink(missing_ok=True)


def report(*, token, enabled, participants, results=(), fault=None, phase="running", log):
    """Only a valid daemon-seat credential may persist its own observations.

    Role refusal is itself reportable; this grants no dispatch authority. A
    demoted/absent/expired credential cannot be promoted by this snapshot.
    """
    global _last_log
    actor, why = store.token_verdict(token) if token else (None, "missing")
    authenticated = actor is not None and actor.get("participant_id") == store.DAEMON_SEAT
    seats = {}
    for seat, (ok, detail) in results:
        route = (participants.get(seat) or {}).get("wake_route")
        seats[seat] = {"ok": bool(ok), "reason": detail, "route": route}
    state = "stopped" if phase == "stopped" else ("enabled" if enabled else "disabled")
    failures = {s: row["reason"] for s, row in seats.items()
                if not row["ok"] and row["reason"] not in {'awaiting_hook', 'held_uncertain'}}
    note = {"state": state, "fault": fault, "refusals": failures,
            "reporter": "authenticated" if authenticated else "unavailable:" + why}
    key = json.dumps(note, sort_keys=True)
    if key != _last_log:
        log("Claude socket dispatcher observation: " + key)
        _last_log = key
    if not authenticated:
        return False
    old = read()
    value = {"kind": "inapp-dispatch", "instance": _INSTANCE, "pid": os.getpid(),
             "started": _STARTED, "host_id": "local", "requester": store.DAEMON_SEAT,
             "state": state, "phase": phase, "fault": fault, "seats": seats, "refusals": failures,
             "build_digest": old.get("build_digest") if old and old.get("instance") == _INSTANCE else _build()}
    if old and {k: v for k, v in old.items() if k != "ts"} == value:
        return True
    value["ts"] = store.now_iso()
    _write(value)
    return True
