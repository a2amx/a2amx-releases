"""Pointer-only Claude socket write, never acceptance or a message fetch.

The macOS peer connection sends one user frame and no authentication line.
Native inbound controls still apply. Successful submission is not acceptance. Peer data,
transcripts, hook logs and another process's environment are never inspected.
The owner test is the adopted interim observation, not enforced exclusivity.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import socket
import stat
import subprocess
import time

from wake_hook_core import pointer_line

WRITE_SECONDS = 5.0


class Refused(Exception):
    def __init__(self, reason):
        super().__init__(reason)
        self.reason = reason


@dataclass(frozen=True)
class WriteResult:
    # submitted does NOT mean accepted; only a correlated store event can do that.
    result: str
    reason: str


def frame(pointer) -> bytes:
    """A peer message only: never assert the recipient's own-child identity."""
    if pointer_line(pointer) != pointer:
        raise Refused("protocol_unsupported")
    return (json.dumps({"type": "user", "message": {"role": "user", "content": pointer}}) + "\n").encode()


def process_metadata(pid):
    """Only uid and start time; no command line or environment."""
    result = subprocess.run(["/bin/ps", "-p", str(pid), "-o", "uid=", "-o", "lstart="],
                            capture_output=True, text=True, timeout=2,
                            env={"PATH": "/usr/bin:/bin", "LC_ALL": "C", "LANG": "C"})
    text = result.stdout.strip()
    if not text and result.returncode == 1:
        raise Refused("no_process")
    if result.returncode != 0:
        raise Refused("owner_unresolved")
    fields = text.split(maxsplit=1)
    try:
        uid = int(fields[0])
        # ps lstart is local wall time; astimezone attaches the host's local zone.
        started = datetime.strptime(fields[1], "%a %b %d %H:%M:%S %Y").astimezone().timestamp()
    except (ValueError, IndexError):
        raise Refused("owner_unresolved") from None
    return uid, started


def owner_check(route, *, metadata=process_metadata, lstat=os.lstat, uid=os.getuid):
    ref = route.get("ref")
    try:
        p = Path(ref)
        match = re.fullmatch(r"([1-9][0-9]*)\.sock", p.name)
        declared = datetime.fromisoformat(route["declared_at"])
        if (not p.is_absolute() or not match or declared.utcoffset() is None
                or str(p) != ref or ".." in p.parts):
            raise Refused("owner_mismatch")
        s = lstat(ref)
        if not stat.S_ISSOCK(s.st_mode) or s.st_uid != uid():
            raise Refused("owner_mismatch")
        process_uid, started = metadata(int(match[1]))
        # Seconds-only start metadata cannot prove ordering within the same second.
        if process_uid != uid() or started >= int(declared.timestamp()):
            raise Refused("owner_mismatch")
    except Refused:
        raise
    except FileNotFoundError:
        raise Refused("socket_unavailable") from None
    except (OSError, ValueError, TypeError, KeyError, subprocess.SubprocessError):
        raise Refused("owner_unresolved") from None


def write(route, pointer, *, ownership=owner_check,
          connect=socket.socket, clock=time.monotonic):
    deadline = clock() + WRITE_SECONDS
    ownership(route)
    wire = frame(pointer)
    peer = None
    def remaining():
        left = deadline-clock()
        if left <= 0:
            raise TimeoutError('socket attempt deadline')
        return left
    try:
        remaining()
        peer = connect(socket.AF_UNIX, socket.SOCK_STREAM)
        peer.settimeout(remaining())
        peer.connect(route["ref"])
    except OSError:
        if peer is not None:
            peer.close()
        return WriteResult("refused", "socket_unavailable")
    attempted = False
    try:
        peer.settimeout(remaining())
        attempted = True
        peer.sendall(wire)
        return WriteResult("submitted", "awaiting_hook")
    except OSError as exc:
        # Even a partial frame write is possibly submitted. Do not retry.
        if not attempted:
            return WriteResult("refused", "socket_unavailable")
        return WriteResult("uncertain", "write_error:" + type(exc).__name__)
    finally:
        peer.close()
