"""Per-seat private-tmux launcher (Phase A A.5.1/A.5.4)."""

from __future__ import annotations

import stage1_features

import shlex
import os
import stat
from functools import partial
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping

import store
from seat_socket import registered_session, registered_socket
from tmux_bridge import TmuxResult, _run_tmux


@dataclass(frozen=True)
class LaunchResult:
    seat: str
    socket: str
    session: str
    pane_log: str
    history_limit: int
    pane_log_evidence: str = "OUTPUT ONLY — cannot evidence input"


def _absolute_directory(value: Any, field: str, *, must_exist: bool) -> Path:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"registered {field} must be a non-empty absolute path")
    path = Path(value)
    if not path.is_absolute():
        raise ValueError(f"registered {field} must be an absolute path")
    if path.is_symlink():
        raise ValueError(f"registered {field} must not be a symlink")
    if must_exist and not path.is_dir():
        raise ValueError(f"registered {field} must be an existing directory")
    return path


def launch(seat: str, *,
           presented_token: str | None = None,
           interactive: bool = False,
           claude_permission_mode: str | None = None,
           participants: Mapping[str, Mapping[str, Any]] | None = None,
           tmux_runner: Callable[..., TmuxResult] = _run_tmux) -> LaunchResult:
    """Authorize before launch; the tmux bridge sanitizes child environments.

    The private server cannot retain the invoker's credential selectors for later
    panes. seat_launch_line also isolates CLI activation in an older pane.
    """
    return store.authenticated_registry_act(
        presented_token, lambda actor: _launch(seat, participants=participants, interactive=interactive,
                                               claude_permission_mode=claude_permission_mode,
                                               tmux_runner=tmux_runner), provisioning=True)


def _launch(seat: str, *, participants=None, interactive=False, claude_permission_mode=None,
            tmux_runner=_run_tmux) -> LaunchResult:
    """Launch ``seat`` on its registry-declared private tmux socket."""
    stage1_features.require_private('terminal_agents')
    if not interactive and claude_permission_mode is not None:
        raise ValueError('cli_permission_mode_requires_interactive')
    registry = participants if participants is not None else store.load_participants()
    participant = registry.get(seat)
    if not isinstance(participant, Mapping):
        raise ValueError(f"seat {seat!r} is not registered")
    # The public caller holds the registry/launch fence. A supplied launch
    # snapshot cannot override a newly parked or retired durable identity.
    durable_registry = store.load_participants()
    if seat not in durable_registry:
        raise ValueError(f"seat {seat!r} is not registered")
    durable = durable_registry[seat]
    for row in (durable, participant):
        if store.inactive_participant(row):
            reason = "seat_retired" if row.get("retired_at") else "seat_parked"
            raise store.RegistryMutationRefused(reason, f"{seat!r} is inactive; ask the Chief of Staff")
    if participant.get("hosting_kind") != "tmux-hosted":
        raise ValueError(f"seat {seat!r} is not declared tmux-hosted")

    socket_value = registered_socket(seat, registry)
    session = registered_session(participant)
    socket_path = Path(socket_value)
    socket_dir = _absolute_directory(str(socket_path.parent), "tmux socket directory",
                                     must_exist=False)
    workspace = _absolute_directory(participant.get("workspace_dir"), "workspace_dir",
                                    must_exist=True)
    _absolute_directory(participant.get("config_dir"), "config_dir", must_exist=True)
    history_limit = participant.get("history_limit")
    if isinstance(history_limit, bool) or not isinstance(history_limit, int) \
            or history_limit <= 0:
        raise ValueError("registered history_limit must be a positive integer")

    command = []
    if interactive:
        # Use the durable row while the caller holds the provisioning fence.
        # This path neither changes roles nor types an activation into a pane.
        if participant != durable:
            raise ValueError('interactive launch requires the current durable declaration')
        stage1_features.require_private('terminal_agents')
        from cli_kit import launch_spec
        plan = launch_spec(seat, durable, claude_permission_mode=claude_permission_mode)
        command = plan['argv']
        if plan['kind'] == 'claude-cli':
            from launch_environment import interactive_claude_env
            child_environment = interactive_claude_env(
                store_dir=store.STORE_DIR, vendor_profile_dir=plan['vendor_profile_dir'])
            # The private server itself is born with this environment, not just
            # the first client. Keep the same environment through setup/cleanup.
            tmux_runner = partial(tmux_runner, environment=child_environment)

    if socket_dir.exists():
        info = socket_dir.lstat()
        if socket_dir.is_symlink() or not socket_dir.is_dir() \
                or info.st_uid != os.getuid() \
                or stat.S_IMODE(info.st_mode) != 0o700:
            raise ValueError(
                "existing tmux socket directory must be owner-controlled mode 0700")
    else:
        socket_dir.mkdir(mode=0o700, parents=True)
    if socket_path.exists():
        raise ValueError("registered tmux_socket already exists; refusing to join a server")
    pane_log = socket_dir / "pane.log"
    if pane_log.is_symlink():
        raise ValueError("pane.log must not be a symlink")

    commands = (
        ("-S", str(socket_path), "new-session", "-d", "-s", session, "-c", str(workspace), *command),
        # tmux history-limit is window-scoped: set and read back the targeted
        # registered session's window, rather than the unrelated global value.
        ("-S", str(socket_path), "set-window-option", "-t", session,
         "history-limit", str(history_limit)),
        ("-S", str(socket_path), "show-window-options", "-v", "-t", session,
         "history-limit"),
        ("-S", str(socket_path), "pipe-pane", "-O", "-t", session,
         f"cat >> {shlex.quote(str(pane_log))}"),
    )
    for index, command in enumerate(commands):
        result = tmux_runner(*command)
        if not result.ok:
            if index > 0:
                # This server was created only after the absent-socket and
                # unique-owner checks above, so cleanup cannot target a
                # pre-existing or unrelated server.
                tmux_runner("-S", str(socket_path), "kill-server")
            raise RuntimeError(result.stderr or f"tmux command failed: {command!r}")
        if index == 2 and result.stdout != str(history_limit):
            tmux_runner("-S", str(socket_path), "kill-server")
            raise RuntimeError(
                "registered history_limit readback mismatch: "
                f"expected {history_limit}, observed {result.stdout!r}")
    return LaunchResult(
        seat=seat, socket=str(socket_path), session=session,
        pane_log=str(pane_log), history_limit=history_limit,
    )


def attach_argv(seat: str, *,
                participants: Mapping[str, Mapping[str, Any]] | None = None) -> list[str]:
    """Return an attach argv bound to the seat's exact registered private socket."""
    registry = participants if participants is not None else store.load_participants()
    participant = registry.get(seat)
    if not isinstance(participant, Mapping) or participant.get("hosting_kind") != "tmux-hosted":
        raise ValueError(f"seat {seat!r} is not registered tmux-hosted")
    socket_path = registered_socket(seat, registry)
    session = registered_session(participant)
    return ["tmux", "-S", socket_path, "attach", "-t", session]
