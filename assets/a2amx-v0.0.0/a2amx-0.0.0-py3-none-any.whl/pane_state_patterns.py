"""Closed, conservative terminal-state signatures (row 633).

Each alternative is a tuple of expressions that must ALL occur in the bounded
input region. These are UI signatures, not words searched in conversation text.
The corresponding fixtures are synthetic; they do not qualify a native version.
Unrecognized versions/screens remain unknown. Nothing here reads a pane.
"""

# Recorded in shipped pattern data, not an ambient setting. Without a known
# input region an old blocking notice cannot establish a permanent hold.
UNANCHORED_HOLD_SECONDS = 60.0

# Only recognizable menu continuations may follow a selected choice. A later
# unknown prompt/output means the old menu is not a proven live input region.
MENU_CONTINUATIONS = (
    r"^\d+\.\s+.{1,256}$",
    r"^(?:Yes|No|Allow once|Allow always|Always allow|Deny)$",
    r"^(?:Enter to (?:confirm|select)|Esc to cancel|Press Enter to (?:confirm|select))(?:\s*[·/|]\s*(?:Enter to (?:confirm|select)|Esc to cancel))?$",
)

PATTERNS = {
    "claude": {
        "dialog": (
            (r"^Do you trust (?:the files in this folder|this (?:folder|workspace))\??$",
             r"^[❯>]\s*1\.\s*Yes(?:,.*)?$"),
            (r"^Do you want to proceed\?$", r"^[❯>]\s*1\.\s*Yes(?:,.*)?$"),
            (r"^Select login method:$", r"^[❯>]\s*1\.\s*Claude account.*$"),
            (r"^Bypass Permissions mode$", r"^[❯>]\s*\d+\.\s*Yes, I accept$"),
        ),
        "limit": ((r"^You['’]ve hit your limit(?:\s*[·—-]\s*resets .+)?$",),
                  (r"^Rate limit reached(?:\s*[·—-]\s*retry after .+)?$",)),
        "in_turn": ((r"^[✻✽✶✢✳●]\s*[^\r\n]{1,100}(?:…|\.\.\.)\s*\(esc to interrupt[^\r\n]{0,100}\)$",),),
        "idle": ((r"^❯\s*$", r"^\? for shortcuts$"),),
    },
    "codex": {
        "dialog": (
            (r"^Would you like to run the following command\?$", r"^›\s*1\.\s*Yes, proceed.*$"),
            (r"^Do you trust (?:the contents of )?this directory\?$", r"^›\s*1\.\s*Yes(?:,.*)?$"),
            (r"^Sign in to Codex$", r"^›\s*1\.\s*Sign in with ChatGPT$"),
            (r"^Would you like to (?:apply|make) (?:these|the following) changes\?$",
             r"^›\s*1\.\s*Yes(?:,.*)?$"),
        ),
        "limit": ((r"^You['’]ve hit your usage limit(?:[. ]+.*)?$",),
                  (r"^Rate limit reached(?:[. ]+.*)?$",)),
        "in_turn": ((r"^[•●]\s*[^\r\n]{1,100}\(\d+(?:m \d+)?s\s*[•·]\s*esc to interrupt\)$",),),
        "idle": ((r"^›\s*$", r"^\? for shortcuts(?:\s+\d+% context left)?$"),),
    },
    "gemini": {
        "dialog": (
            (r"^Do you trust the files in this folder\?$", r"^[●❯>]\s*(?:1\.\s*)?Yes(?:,.*)?$"),
            (r"^Allow execution(?: of this tool)?\?$", r"^[●❯>]\s*(?:1\.\s*)?Allow once$"),
            (r"^How would you like to authenticate(?: for this project)?\?$",
             r"^[●❯>]\s*(?:1\.\s*)?Login with Google$"),
        ),
        "limit": ((r"^You have exhausted your daily quota(?:[. ]+.*)?$",),
                  (r"^Rate limit exceeded(?:[. ]+.*)?$",)),
        "in_turn": ((r"^[⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏]\s*[^\r\n]{1,100}\(esc to cancel[^\r\n]{0,100}\)$",),),
        "idle": ((r"^>\s*(?:Type your message or @path/to/file)?$", r"^\? for shortcuts$"),),
    },
}
