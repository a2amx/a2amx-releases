"""Stage 1's runtime requirement, checked before a first run and shown by `doctor` (B1).

The release is a plain wheel: it does not carry its runtime, so four things must already be on
the Mac. Each check reads only a documented interface: the platform, the interpreter's version,
the PATH, and the Claude desktop app's own Info.plist. Whether the app is signed in has no
documented interface; it is stated as a requirement and shown by the user's open-and-trust act,
never probed. A missing piece is named in one sentence with its remedy, and no remedy sends the
user to a portal or another app's console (the principal's rule of 2026-10-07).
"""
from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
import plistlib
import shutil
import sys
from typing import Callable, Iterable, Sequence

CLAUDE_BUNDLE_ID = "com.anthropic.claudefordesktop"
PYTHON_MINIMUM = (3, 13)


@dataclass(frozen=True)
class Check:
    name: str
    ok: bool
    found: str          # what was found, shown when the check passes
    missing: str        # the one sentence naming the missing piece and its remedy


def claude_app_dirs(home: Path | None = None) -> list[Path]:
    """Where macOS installs an application: the system folder first, then the user's own."""
    home = home if home is not None else Path(os.path.expanduser("~"))
    return [Path("/Applications/Claude.app"), home / "Applications" / "Claude.app"]


def _claude_app(paths: Iterable[Path]) -> tuple[Path, str] | None:
    """The first installed Claude desktop app, by its own bundle identifier, and its version."""
    for app in paths:
        try:
            with open(app / "Contents" / "Info.plist", "rb") as handle:
                info = plistlib.load(handle)
        except (OSError, plistlib.InvalidFileException, ValueError):
            continue
        if isinstance(info, dict) and info.get("CFBundleIdentifier") == CLAUDE_BUNDLE_ID:
            version = info.get("CFBundleShortVersionString")
            return app, version if isinstance(version, str) else "unknown version"
    return None


def run(*, platform: str | None = None, version_info: Sequence[int] | None = None,
        which: Callable[[str], str | None] = shutil.which,
        app_paths: Iterable[Path] | None = None) -> list[Check]:
    """Every prerequisite, in the order a stranger would fix them."""
    platform = sys.platform if platform is None else platform
    version = tuple(sys.version_info[:3] if version_info is None else version_info)
    checks = [Check(
        "macOS", platform == "darwin", "macOS",
        "This release runs on macOS only: install it on a Mac.")]
    shown = ".".join(str(part) for part in version[:3])
    checks.append(Check(
        "Python", version[:2] >= PYTHON_MINIMUM, f"Python {shown}",
        f"Python 3.13 or later is required and this is Python {shown}: run "
        "`uv python install 3.13`, then install this product again with the install line."))
    installer = which("uv") or which("pipx")
    checks.append(Check(
        "uv or pipx", bool(installer), f"installer {installer}",
        "Neither uv nor pipx is on your PATH: install uv with "
        "`curl -LsSf https://astral.sh/uv/install.sh | sh`, then open a new terminal."))
    app = _claude_app(claude_app_dirs() if app_paths is None else app_paths)
    checks.append(Check(
        "Claude desktop app", app is not None,
        f"Claude desktop app {app[1]} at {app[0]}" if app else "",
        "The Claude desktop app is not installed: install it, sign in to it, then run this again."))
    return checks


def first_missing(checks: Sequence[Check]) -> Check | None:
    return next((check for check in checks if not check.ok), None)


# The product keeps its configuration in files, never in a variable a person sets: an app opened
# from the Dock does not see a shell's variables, so nothing exported would reach the desktop app
# or its hooks. A variable found in the shell is reported as information, by name, never by value.
VENDOR_KEYS = {
    "ANTHROPIC_API_KEY": "a Claude Code session started from this shell bills that key, "
                         "not your Claude subscription",
    "ANTHROPIC_AUTH_TOKEN": "a Claude Code session started from this shell sends that token, "
                            "not your Claude subscription's sign-in",
    "OPENAI_API_KEY": "a tool started from this shell may bill that key; this release does not use it",
    "GEMINI_API_KEY": "a tool started from this shell may bill that key; this release does not use it",
    "GOOGLE_API_KEY": "a tool started from this shell may bill that key; this release does not use it",
}


def environment_notes(env=None) -> list[str]:
    """One line per vendor-key or PSQR_ variable set in this shell, naming it and its effect."""
    env = os.environ if env is None else env
    import product_identity
    if product_identity.is_public():
        notes = []
        if any(name in VENDOR_KEYS for name in env):
            notes.append("Vendor credentials are present in this shell; this release uses the "
                         "desktop app's sign-in and needs no vendor key.")
        if any(name in env for name in ("PSQR_OWNER", "PSQR_STORE_DIR")):
            notes.append("Legacy owner/store selectors are ignored by this public installation; configure it through "
                         "its local files, not shell settings.")
        return notes
    notes = []
    for name in sorted(env):
        if name in VENDOR_KEYS:
            notes.append(f"{name} is set in this shell: {VENDOR_KEYS[name]}; the desktop app does not see it.")
        elif name.startswith("PSQR_"):
            notes.append(f"{name} is set in this shell: the product keeps its settings in files and "
                         "does not need it; the desktop app does not see it.")
    return notes

