"""Public hook context over the unchanged authenticated client protocol.

The managed installer copies this template into the seat and pins its bytes.
Only fixed protocol header/status lines are relabeled; the JSON message line is
never edited. The shared client catalog stays byte-identical for private kits.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys

from harness_facts import collect
from wake_hook_client import CliEndpoint
from wake_hook_core import CLAUDE_OUTPUT_BYTES, run_prompt

BRAND = 'Quovisto'
CONFIG_NAME = 'quovisto-runtime-pins.json'


def _checked_file(path, limit):
    if path.resolve() != path:
        raise ValueError('hook input is not canonical')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        if (not stat.S_ISREG(before.st_mode) or before.st_uid != os.getuid()
                or before.st_mode & 0o022):
            raise ValueError('hook input is unsafe')
        raw = stream.read(limit+1)
        after = os.fstat(stream.fileno())
    fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    if len(raw) > limit or any(getattr(before, k) != getattr(after, k) for k in fields):
        raise ValueError('hook input changed or is oversized')
    return raw


def verify_local(script, home):
    """The local prompt script checks its recorded pin before any mail fetch."""
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('duplicate config key')
            result[key] = value
        return result
    config = json.loads(_checked_file(script.parent/CONFIG_NAME, 32768), object_pairs_hook=unique)
    if (not isinstance(config, dict) or config.get('schema') != 'orch.claude-runtime-pins.v3'
            or config.get('home') != str(home) or config.get('prompt_hook_name') != script.name
            or config.get('prompt_hook_sha256') != hashlib.sha256(_checked_file(script, 1024*1024)).hexdigest()):
        raise ValueError('prompt hook pin mismatch')


def public_context(text, brand):
    if not isinstance(brand, str) or re.fullmatch(r'[A-Za-z][A-Za-z0-9 .-]{0,63}', brand) is None:
        raise ValueError('invalid product display name')
    # The authenticated core emits its messages as one escaped JSON line, never
    # a raw message-body line. These exact markers are protocol framing only.
    prefixes = ('ORCH mail:', 'ORCH hook fetch failed:',
                'ORCH hook fetch failed for this prompt;')
    statuses = {'ORCH hook activity recording unconfirmed; mail fetch committed.\n',
                'ORCH neutral grounding: no expectations adopted; nothing is compared.\n'}
    result = []
    for index, line in enumerate(text.splitlines(keepends=True)):
        if (index == 0 and line.startswith(prefixes)) or line in statuses:
            line = brand + line[4:]
        result.append(line)
    output = ''.join(result)
    if len(output.encode()) > CLAUDE_OUTPUT_BYTES:
        raise ValueError('public hook output exceeds bound')
    return output


def handle(payload, *, home, environ, brand=BRAND, endpoint_factory=CliEndpoint):
    if (not isinstance(payload, dict) or payload.get('hook_event_name') != 'UserPromptSubmit'
            or not isinstance(payload.get('prompt'), str)):
        return ''
    if not isinstance(brand, str) or re.fullmatch(r'[A-Za-z][A-Za-z0-9 .-]{0,63}', brand) is None:
        return ''
    endpoint = endpoint_factory(home)
    endpoint.session_id = payload.get('session_id')
    endpoint.harness = collect(environ, payload.get('harness'))
    # At most the index plus the two fixed status lines grow. No message is
    # sliced to make room; the original core performs whole-message elision.
    reserve = 3*max(0, len(brand.encode())-4)
    output = run_prompt(payload['prompt'], environ.get('CLAUDE_CODE_HOST_SESSION_ID'),
                        endpoint, budget=CLAUDE_OUTPUT_BYTES-reserve, post_pointer=True)
    return public_context(output, brand)


def main(*, brand=None):
    class QuietParser(argparse.ArgumentParser):
        def error(self, message):
            raise ValueError('invalid hook arguments')
    try:
        script = Path(__file__).absolute()
        directory = script.parent
        local = directory.name == '.claude'
        parser = QuietParser(add_help=False)
        parser.add_argument('--home', required=not local)
        args = parser.parse_args()
        home = directory.parent if local else Path(args.home).resolve()
        if local and args.home is not None and Path(args.home).resolve() != home:
            raise ValueError('hook home differs')
        if local:
            try:
                verify_local(script, home)
            except Exception:
                print(BRAND+' hook integrity check failed; no mail was fetched.', file=sys.stderr)
                return 1
        output = handle(json.load(sys.stdin), home=home, environ=os.environ,
                        brand=BRAND if brand is None else brand)
    except Exception:
        output = ''
    sys.stdout.write(output)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
