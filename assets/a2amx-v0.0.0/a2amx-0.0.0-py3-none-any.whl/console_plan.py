"""The plan view's reader: the latest sealed build-coordination cut, by its consumer contract v1.0.

The publisher keeps a mutable locator, `QV_BUILD_COORDINATION/LATEST`, beside immutable numbered cut
directories under one configured root. This module follows the contract's read protocol and never
writes: it reads the locator once, opens only the cut directory the locator names beneath that root
(no symlink, no other directory), checks the locator's pin against the cut's SHA256SUMS, verifies every
manifest member, validates the data against the v1.0 schema (pinned by hash) and checks the identifiers
and dependency targets. Anything that fails keeps the last verified cut, marked stale with the failure,
or answers unavailable when there is none; a partial cut is never shown. Unconfigured, it is unavailable.
"""
import copy
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import threading

from console_files import digest, directory, packet, read

ROOT_ENV = 'PSQR_CONSOLE_PLAN_DIR'
SERIES = 'QV_BUILD_COORDINATION'
LOCATOR = 'LATEST'
MANIFEST = 'SHA256SUMS'
DATA_FILE = 'BUILD_ITEMS.json'
SCHEMA_FILE = 'BUILD_ITEMS.schema.json'
HEAD_FILE = 'THE_PLAN_IN_ONE_SCREEN.html'
CONTRACT_VERSION = '1.0'
# The v1.0 data schema by hash. A different schema is a different contract, which this reader refuses
# rather than guessing at ("readers reject unsupported versions").
SCHEMA_SHA256 = 'ed73bfd960f786bbac1b087d9f5d2afa76f0c50219c28436747669ff7a6c7cac'
MAX_LOCATOR_BYTES = 4096
MAX_MANIFEST_BYTES = 1024 * 1024  # as console_files.packet reads it
HEX64 = re.compile(r'[0-9a-f]{64}')
DATE_TIME = re.compile(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})')
LOCATOR_FIELDS = {'schema_version', 'series', 'cut', 'packet_directory', 'manifest_file',
                  'manifest_sha256', 'data_file', 'head_file', 'published_at_utc'}
# The JSON Schema keywords this reader evaluates. Any other keyword refuses the cut: a validator that
# skipped a keyword it did not know would pass data the schema forbids.
KEYWORDS = {'$schema', '$id', 'type', 'const', 'enum', 'pattern', 'minimum', 'format', 'properties',
            'required', 'additionalProperties', 'items'}
TYPES = {'object': dict, 'array': list, 'string': str, 'boolean': bool, 'null': type(None)}


def _json(data):
    def pairs(items):
        keys = [key for key, _ in items]
        if len(keys) != len(set(keys)):
            raise ValueError('duplicate JSON key')
        return dict(items)

    def constant(name):
        raise ValueError(f'non-finite JSON number {name}')

    return json.loads(data.decode('utf-8'), object_pairs_hook=pairs, parse_constant=constant)


def _date_time(value):
    if not DATE_TIME.fullmatch(value):
        return False
    try:
        return datetime.fromisoformat(value).tzinfo is not None
    except ValueError:
        return False


def _is(kind, value):
    if kind == 'integer':
        return isinstance(value, int) and not isinstance(value, bool)
    if kind == 'number':
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if kind not in TYPES:
        raise ValueError(f'unsupported schema type {kind}')
    return isinstance(value, TYPES[kind]) and not (kind != 'boolean' and isinstance(value, bool))


def _same(left, right):
    return type(left) is type(right) and left == right


def validate(schema, value, where='$'):
    """Validate `value` against the subset of JSON Schema the v1.0 schema uses; raise ValueError."""
    unknown = set(schema) - KEYWORDS
    if unknown:
        raise ValueError(f'unsupported schema keyword {sorted(unknown)[0]}')
    if 'type' in schema:
        kinds = schema['type'] if isinstance(schema['type'], list) else [schema['type']]
        if not any(_is(kind, value) for kind in kinds):
            raise ValueError(f'{where}: expected {"/".join(kinds)}')
    if 'const' in schema and not _same(value, schema['const']):
        raise ValueError(f'{where}: expected {schema["const"]!r}')
    if 'enum' in schema and not any(_same(value, choice) for choice in schema['enum']):
        raise ValueError(f'{where}: not one of the allowed values')
    if isinstance(value, str):
        if 'pattern' in schema:
            # ECMA `$` ends the string; Python's also matches before a final newline.
            pattern = schema['pattern']
            if pattern.endswith('$') and not pattern.endswith('\\$'):
                pattern = pattern[:-1] + r'\Z'
            if not re.search(pattern, value):
                raise ValueError(f'{where}: does not match its pattern')
        if 'format' in schema:
            if schema['format'] != 'date-time':
                raise ValueError(f'unsupported schema format {schema["format"]}')
            if not _date_time(value):
                raise ValueError(f'{where}: not an RFC 3339 date-time')
    if 'minimum' in schema and _is('number', value) and value < schema['minimum']:
        raise ValueError(f'{where}: below its minimum')
    if isinstance(value, dict):
        if schema.get('additionalProperties', False) is not False:
            raise ValueError('unsupported schema: only closed objects are evaluated')
        properties = schema.get('properties', {})
        for name in schema.get('required', []):
            if name not in value:
                raise ValueError(f'{where}: missing {name}')
        for name, item in value.items():
            if name not in properties:
                raise ValueError(f'{where}: unexpected field {name}')
            validate(properties[name], item, f'{where}.{name}')
    if isinstance(value, list) and 'items' in schema:
        for index, item in enumerate(value):
            validate(schema['items'], item, f'{where}[{index}]')


def locator(data):
    """Read protocol step 1: the locator is one bounded JSON object of the v1.0 shape."""
    pointer = _json(data)
    if not isinstance(pointer, dict) or set(pointer) != LOCATOR_FIELDS:
        raise ValueError('locator does not have the v1.0 fields')
    if not _same(pointer['schema_version'], CONTRACT_VERSION) or not _same(pointer['series'], SERIES):
        raise ValueError('unsupported locator version or series')
    if not _is('integer', pointer['cut']) or pointer['cut'] < 3:
        raise ValueError('locator cut is not a v1.0 cut number')
    if (not _same(pointer['manifest_file'], MANIFEST) or not _same(pointer['data_file'], DATA_FILE)
            or not _same(pointer['head_file'], HEAD_FILE)):
        raise ValueError('locator names files outside the v1.0 contract')
    if not isinstance(pointer['manifest_sha256'], str) or not HEX64.fullmatch(pointer['manifest_sha256']):
        raise ValueError('locator pin is not a SHA-256')
    if not isinstance(pointer['packet_directory'], str) or not isinstance(pointer['published_at_utc'], str) \
            or not _date_time(pointer['published_at_utc']):
        raise ValueError('locator directory or publication time is malformed')
    return pointer


def consistent(data, pointer, members):
    """Read protocol step 4, beyond the schema: identities, order and every internal target."""
    if data['cut'] != pointer['cut'] or data['series'] != pointer['series']:
        raise ValueError('data cut or series differs from the locator')
    milestones = [m['id'] for m in data['milestones']]
    items = [i['id'] for i in data['items']]
    orders = [m['order'] for m in data['milestones']]
    if len(set(milestones)) != len(milestones) or len(set(items)) != len(items):
        raise ValueError('duplicate milestone or item ID')
    if len(set(orders)) != len(orders):
        raise ValueError('duplicate milestone order')
    known = {'milestone': set(milestones), 'item': set(items)}
    for record in data['items']:
        if record['milestone'] not in known['milestone']:
            raise ValueError(f'item {record["id"]} names an unknown milestone')
    for record in data['milestones'] + data['items']:
        for dependency in record['dependency']:
            kind, target = dependency['target_type'], dependency['target_id']
            if kind == 'external' and target is not None:
                raise ValueError(f'{record["id"]}: an external dependency names a target ID')
            if kind != 'external' and target not in known[kind]:
                raise ValueError(f'{record["id"]}: dependency target {target} is not in this cut')
    if any(name not in members for name in data['source_files']):
        raise ValueError('a source file is not a manifest member')


def canonical_directory(root, name):
    """The one spelling a locator may use for a cut: the configured root as written, a slash, the name."""
    text = str(root)
    if any(part in ('.', '..') for part in text.split('/')):
        raise ValueError('the configured root is not a canonical path')
    return text.rstrip('/') + '/' + name


class Plan:
    def __init__(self, root=None):
        configured = root if root is not None else os.environ.get(ROOT_ENV)
        self.root = Path(configured) if configured else None
        self._last = None
        self._lock = threading.Lock()

    def _read(self):
        canonical_directory(self.root, SERIES)  # the configured root itself must be a canonical spelling
        with directory(self.root, SERIES) as fd:
            pointer = locator(read(fd, LOCATOR, limit=MAX_LOCATOR_BYTES))
        # Step 2: only the numbered directory beneath the configured root, in exactly its canonical
        # spelling, compared as written. Nothing in the untrusted path is resolved or normalised:
        # resolving accepted a symlink elsewhere leading to the right cut, and normalising erased a
        # symlink followed by ".." (STF-PLN-001). The only components are the operator's configured root
        # and the cut's name, and the directory is then opened beneath the root without following a
        # symlink.
        name = f'{SERIES}_{pointer["cut"]:02d}'
        declared = pointer['packet_directory']
        if declared != canonical_directory(self.root, name):
            raise ValueError('locator names a directory other than its numbered cut beneath the root')
        with directory(self.root, name) as fd:
            # Step 3: the pin first, on the bounded manifest alone, before any member is opened
            # (STF-PLN-002); then every member, from the bytes that were hashed.
            if digest(read(fd, MANIFEST, limit=MAX_MANIFEST_BYTES)) != pointer['manifest_sha256']:
                raise ValueError('SHA256SUMS does not match the locator pin')
            verification, contents = packet(fd)
        if verification['manifest_sha256'] != pointer['manifest_sha256']:
            raise ValueError('SHA256SUMS changed after its pin was checked')
        if not verification['verified']:
            raise ValueError('a member does not match its manifest hash')
        if any(member not in contents for member in (DATA_FILE, SCHEMA_FILE, HEAD_FILE)):
            raise ValueError('a contract file is not a manifest member')
        # Step 4: the pinned schema, then identities and targets.
        if digest(contents[SCHEMA_FILE]) != SCHEMA_SHA256:
            raise ValueError('unsupported data schema')
        data = _json(contents[DATA_FILE])
        validate(_json(contents[SCHEMA_FILE]), data)
        consistent(data, pointer, contents)
        return {'cut': pointer['cut'], 'manifest_sha256': pointer['manifest_sha256'],
                'published_at_utc': pointer['published_at_utc'], 'members_verified': len(contents),
                'verified_at': datetime.now(timezone.utc).isoformat(), 'plan': data}

    def snapshot(self):
        read_at = datetime.now(timezone.utc).isoformat()
        with self._lock:
            error = None
            try:
                if self.root is None:
                    raise LookupError
                self._last = self._read()
            except LookupError:
                error = f'Plan unavailable: set {ROOT_ENV}.'
            except OSError as exc:
                error = f'Plan source unreadable ({exc.strerror or type(exc).__name__}).'
            except (ValueError, UnicodeError, RecursionError) as exc:
                error = f'Plan cut refused: {exc}.'
            if self._last is None:
                return {'status': 'error', 'error': error, 'read_at': read_at}
            return {'status': 'ok', 'freshness': 'stale' if error else 'current', 'error': error,
                    'read_at': read_at, **copy.deepcopy(self._last)}
