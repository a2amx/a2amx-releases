"""Standalone product Claude SessionStart template, rendered into a seat home.

Derived from the qualified generation-2 kit. The product supplies runtime
pins; authenticated store reads supply grounding and model expectations. Native
invocation is not proved by same-user file hashes. No transcript is read.
"""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import random
import selectors
import stat
import subprocess
import sys
import time
import uuid
from datetime import datetime

CONFIG_NAME = 'orch-runtime-pins.json'
PRODUCT_PREFIX = 'orch'
INPUT_BYTES = 16384
# A legal 64 KiB hookset is nested in its record, grounding and interface
# snapshot. Bound the complete command output, not only the inner spec.
OUTPUT_BYTES = 131072
STOP_NAME = '.'+PRODUCT_PREFIX+'-session-start.stop'
DECLARATION_WAIT_SECONDS = 15.0
HOOK_TIMEOUT_SECONDS = 45
WORK_SECONDS = 40.0
READ_FIRST_SECONDS = 5.0
READ_RETRY_SECONDS = 10.0
FINISH_RESERVE_SECONDS = DECLARATION_WAIT_SECONDS + 3.0
EVIDENCE_ROW_BYTES = 2048
# Only fixed product reason codes are logged; arbitrary exception text is not.
DIAGNOSTIC_CODES = frozenset(['product_identity_binding_missing', 'product_identity_binding_invalid', 'product_identity_changed', 'product_identity_render_mismatch', 'product_identity_template_mismatch', 'command_failed_outcome_requires_receipts', 'command_output_bound_outcome_unknown', 'command_timeout_outcome_unknown', 'configuration_directory_symlink_or_name', 'configuration_mismatch', 'declaration_generation_mismatch_outcome_unknown', 'declaration_reply_mismatch_outcome_unknown', 'evidence_type_owner_mode_or_size', 'evidence_write_incomplete_outcome_unknown', 'grounding_catalog_mismatch', 'grounding_installed_kit_pin_mismatch', 'grounding_model_shape', 'grounding_record_binding', 'grounding_record_missing', 'grounding_snapshot_shape', 'hook_interface_deployed_source_mismatch', 'hook_interface_schema', 'hook_interface_stale_sources', 'hook_interface_version_refused', 'hookset_client_interface_binding', 'hookset_interface_snapshot_binding', 'hookset_interface_snapshot_shape', 'hookset_record_binding', 'hookset_record_missing_or_shape', 'hookset_route_generation', 'hookset_snapshot_shape', 'input_not_object', 'input_timeout', 'input_too_large', 'installed_module_origin_mismatch', 'installed_source_pin', 'interpreter_changed_during_read', 'interpreter_file_unsafe', 'interpreter_path_changed', 'interpreter_path_invalid', 'interpreter_pin_mismatch', 'invalid_seat_identity', 'lock_owner_or_type', 'model_setting_mismatch', 'native_credential_missing', 'native_session_missing', 'noncanonical_or_missing_home', 'nonregular_or_oversize_file', 'oversize_file', 'payload_model_shape', 'prior_refresh_failure_requires_disposition', 'process_changed_after_snapshot', 'process_changed_or_clock_unresolved', 'process_clock_unresolved', 'process_owner', 'socket_path_mismatch', 'socket_type_or_owner', 'unexpected_arguments', 'unexpected_store_override', 'unsupported_home_spelling', 'wrong_execution_directory', 'wrong_workspace'])
# Claude desktop on macOS publishes per-process messaging sockets in this directory.
CLAUDE_SOCKET_DIR = Path('/private/tmp/cc-socks')


class Stop(Exception):
    pass


class StartupHeld(Stop):
    """Read-only grounding did not complete; no declaration was attempted."""


def recovery_enabled(config):
    policy = config.get('startup_recovery_policy', 'legacy')
    if policy not in {'legacy', 'held-v1'}:
        raise Stop('configuration_mismatch')
    return policy == 'held-v1'


def grounding_read(argv, *, cwd, env, command, config, progress, sleep=time.sleep):
    """One bounded retry of a read only. Never wrap or retry wake-declare."""
    if not recovery_enabled(config):
        return command(argv, cwd=cwd, env=env)
    deadline = progress.started + WORK_SECONDS
    if deadline - progress.clock() < READ_FIRST_SECONDS + FINISH_RESERVE_SECONDS:
        raise StartupHeld('grounding_read_budget_exhausted')
    try:
        return command(argv, cwd=cwd, env=env, timeout=READ_FIRST_SECONDS)
    except Stop as exc:
        if str(exc) != 'command_timeout_outcome_unknown' or progress.declaration_state != 'not_attempted':
            raise
    jitter = random.uniform(0., 0.5)
    if deadline - progress.clock() < jitter + READ_RETRY_SECONDS + FINISH_RESERVE_SECONDS:
        raise StartupHeld('grounding_read_budget_exhausted')
    sleep(jitter)
    progress.mark('grounding_snapshot_retry_wait')
    try:
        return command(argv, cwd=cwd, env=env, timeout=READ_RETRY_SECONDS)
    except Stop as exc:
        if str(exc) != 'command_timeout_outcome_unknown':
            raise
        raise StartupHeld('grounding_read_timeout') from None


def record_start_state(fd, directory, config, seat, payload, progress, state, reason,
                       *, installation_sha256):
    """Typed local evidence for the daemon observer; no message/env contents."""
    value = {
        'schema': 'orch.claude-start-state.v2', 'id': 'start-' + uuid.uuid4().hex,
        'seat': seat, 'source': payload['source'], 'state': state, 'reason': reason,
        'recorded_at': datetime.now().astimezone().isoformat(),
        'declaration_state': progress.declaration_state,
        'source_sha256': config['session_start_sha256'],
        'installation_sha256': installation_sha256,
    }
    if not is_digest(installation_sha256) or len(json.dumps(value).encode()) > 1000:
        raise Stop('evidence_write_incomplete_outcome_unknown')
    append_evidence(fd, directory, value)


class Progress:
    """Local timing and fixed step labels; never command/payload/environment text."""
    def __init__(self, clock=None):
        self.clock = clock or time.monotonic
        self.started = self.step_started = self.clock()
        self.step = 'entry'
        self.declaration_state = 'not_attempted'

    def mark(self, step):
        self.step, self.step_started = step, self.clock()

    def timing(self):
        now = self.clock()
        return {'elapsed_ms': max(0, round((now-self.started)*1000)),
                'step_elapsed_ms': max(0, round((now-self.step_started)*1000))}


def append_evidence(fd, directory, value):
    data = (json.dumps(value,sort_keys=True)+'\n').encode()
    # Separate a preceding partial write from this complete diagnostic. Preserve
    # its bytes; a reader may report that torn line but can read the next one.
    size = os.fstat(fd).st_size
    prefix = b'\n' if size and os.pread(fd, 1, size-1) != b'\n' else b''
    if len(data)>EVIDENCE_ROW_BYTES or os.write(fd,prefix+data)!=len(prefix+data):
        raise Stop('evidence_write_incomplete_outcome_unknown')
    os.fsync(fd)
    directory_fd = os.open(directory, os.O_RDONLY)
    try: os.fsync(directory_fd)
    finally: os.close(directory_fd)


def record_failure(fd, directory, seat, payload, progress, exc):
    name = type(exc).__name__
    if name not in {'Stop','OSError','PermissionError','FileNotFoundError','TimeoutError',
                    'ValueError','KeyError','TypeError','JSONDecodeError','BrokenPipeError'}:
        name = 'Exception'
    reason = str(exc) if isinstance(exc, Stop) and str(exc) in DIAGNOSTIC_CODES else 'unclassified_exception'
    append_evidence(fd, directory, {'schema':'orch.claude-start-evidence.v3',
        'result':'failed', 'seat':seat, 'source':payload['source'],
        'recorded_at':datetime.now().astimezone().isoformat(),
        'exception_type':name, 'reason':reason, 'step':progress.step,
        'declaration_state':progress.declaration_state,
        'declaration_wait_seconds':DECLARATION_WAIT_SECONDS, **progress.timing()})


def interpreter_identity(path):
    """Hash the resolved executable in chunks, independently of JSON limits.

    Keep the caller's venv path for execution; this identity pins its target.
    Nonregular, nonexecutable or writable-by-others targets still refuse.
    """
    try:
        resolved = Path(path).resolve(strict=True)
        fd = os.open(resolved, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except (OSError, RuntimeError):
        raise Stop('interpreter_path_invalid') from None
    try:
        before = os.fstat(fd)
        if (not stat.S_ISREG(before.st_mode) or before.st_uid not in {0, os.getuid()}
                or before.st_mode & 0o022 or not before.st_mode & 0o111):
            raise Stop('interpreter_file_unsafe')
        remaining = before.st_size
        digest = hashlib.sha256()
        while remaining:
            chunk = os.read(fd, min(1024 * 1024, remaining))
            if not chunk:
                raise Stop('interpreter_changed_during_read')
            digest.update(chunk)
            remaining -= len(chunk)
        after = os.fstat(fd)
        fields = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
        if any(getattr(before, k) != getattr(after, k) for k in fields):
            raise Stop('interpreter_changed_during_read')
    finally:
        os.close(fd)
    return resolved, digest.hexdigest()


def regular_bytes(path, limit=4*1024*1024):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as f:
        s = os.fstat(f.fileno())
        if (not stat.S_ISREG(s.st_mode) or s.st_uid not in {0, os.getuid()}
                or s.st_mode & 0o022 or s.st_size > limit):
            raise Stop('nonregular_or_oversize_file')
        data = f.read(limit + 1)
        if len(data) > limit:
            raise Stop('oversize_file')
        return data


def read_input(fd, timeout=2):
    """Bound both bytes and missing EOF; never follow transcript_path."""
    deadline = time.monotonic() + timeout
    data = bytearray()
    # macOS kqueue does not accept regular files; read those directly.
    if stat.S_ISREG(os.fstat(fd).st_mode):
        data.extend(os.read(fd, INPUT_BYTES + 1))
    else:
        with selectors.DefaultSelector() as sel:
            sel.register(fd, selectors.EVENT_READ)
            while True:
                left = deadline - time.monotonic()
                if left <= 0 or not sel.select(left):
                    raise Stop('input_timeout')
                chunk = os.read(fd, min(4096, INPUT_BYTES + 1 - len(data)))
                if not chunk:
                    break
                data.extend(chunk)
                if len(data) > INPUT_BYTES:
                    raise Stop('input_too_large')
    if len(data) > INPUT_BYTES:
        raise Stop('input_too_large')
    value = json.loads(data)
    if not isinstance(value, dict):
        raise Stop('input_not_object')
    return value


def bounded_command(argv, *, cwd, env, timeout=5):
    """No shell; output held privately and never forwarded on errors.

    Timeout/oversize after starting the CLI is indeterminate. Kill/reap only our
    child, retain store evidence, and never retry a possibly committed declare.
    """
    p = subprocess.Popen(argv, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    buffers = {p.stdout: bytearray(), p.stderr: bytearray()}
    try:
        with selectors.DefaultSelector() as sel:
            for stream in buffers:
                sel.register(stream, selectors.EVENT_READ)
            deadline = time.monotonic() + timeout
            while sel.get_map():
                left = deadline - time.monotonic()
                if left <= 0:
                    raise Stop('command_timeout_outcome_unknown')
                for key, _ in sel.select(left):
                    chunk = os.read(key.fd, 4096)
                    if not chunk:
                        sel.unregister(key.fileobj)
                    else:
                        buffers[key.fileobj].extend(chunk)
                        if sum(map(len, buffers.values())) > OUTPUT_BYTES:
                            raise Stop('command_output_bound_outcome_unknown')
            rc = p.wait(timeout=max(0.001, deadline-time.monotonic()))
        if rc:
            if bytes(buffers[p.stderr]).strip() == b'grounding_record_missing':
                raise Stop('grounding_record_missing')
            raise Stop('command_failed_outcome_requires_receipts')
        return bytes(buffers[p.stdout])
    finally:
        if p.poll() is None:
            p.kill()
        p.wait()
        p.stdout.close()
        p.stderr.close()


def canonical_home(value):
    # Permission rules use the exact approved unquoted command form. Refuse
    # characters that could change that form rather than invent escaping rules.
    if not isinstance(value, str) or not re.fullmatch(r'/[A-Za-z0-9_./-]+', value):
        raise Stop('unsupported_home_spelling')
    home = Path(value)
    if str(home) != value or '..' in home.parts or home.resolve() != home or not home.is_dir():
        raise Stop('noncanonical_or_missing_home')
    return home


def installed_identity(config):
    if (not isinstance(config, dict) or not isinstance(config.get('seat'), str)
            or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,31}', config['seat'])):
        raise Stop('invalid_seat_identity')
    return config['seat'], canonical_home(config.get('home'))


def expectations(snapshot, payload, seat, config):
    if (not isinstance(snapshot, dict) or set(snapshot) !=
            {'grounding', 'catalog_digest', 'model', 'installed_kit_pin', 'hookset'}):
        raise Stop('grounding_snapshot_shape')
    row = snapshot['grounding']
    if row is None:
        raise Stop('grounding_record_missing')
    neutral = (isinstance(row, dict) and row.get('basis') == 'no-expectations-adopted'
               and all(k in row and row[k] is None
                       for k in ('norms_sha256', 'standard_revision', 'addenda')))
    if (not isinstance(row, dict) or row.get('kind') != 'seat-grounding' or row.get('seat') != seat
            or (not neutral and (row.get('basis') == 'no-expectations-adopted'
                or not is_digest(row.get('norms_sha256'))
                or type(row.get('standard_revision')) is not int or row['standard_revision'] < 1
                or type(row.get('addenda')) is not int or row['addenda'] < 0))
            or row.get('generation') != digest({k:v for k,v in row.items() if k != 'generation'})):
        raise Stop('grounding_record_binding')
    catalog = json.loads(regular_bytes(Path(config['runtime_root'])/'claude_hook_interface.json', 32768))
    validate_interface(catalog)
    if snapshot['catalog_digest'] != digest(catalog):
        raise Stop('grounding_catalog_mismatch')
    record = (snapshot.get('hookset') or {}).get('record')
    if not isinstance(record, dict) or snapshot['installed_kit_pin'] != record.get('digest'):
        raise Stop('grounding_installed_kit_pin_mismatch')
    model = snapshot['model']
    if (not isinstance(model, dict) or set(model) != {'value', 'source'} or model['source'] != 'DECLARED'
            or (model['value'] is not None and (not isinstance(model['value'], str)
                or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}', model['value'])))):
        raise Stop('grounding_model_shape')
    observed = payload.get('model')
    if observed is not None and (not isinstance(observed, str) or len(observed) > 128
                                or any(ord(c) < 32 for c in observed)):
        raise Stop('payload_model_shape')
    if not neutral and observed is not None and model['value'] is not None and observed != model['value']:
        raise Stop('model_setting_mismatch')
    return {'grounding_mode': 'neutral' if neutral else 'adopted',
            'norms_sha256': row['norms_sha256'], 'standard_revision': row['standard_revision'],
            'addenda': row['addenda'], 'grounding_generation': row['generation'],
            'catalog_digest': snapshot['catalog_digest'],
            'installed_kit_pin': {'kind': 'claude', 'value': snapshot['installed_kit_pin']},
            'model': model, 'observed_model': observed,
            'model_observation': 'not displayed' if observed is None else 'native hook payload; not independent attestation'}


def open_evidence(directory):
    path = directory/('.'+PRODUCT_PREFIX+'-session-start-evidence.jsonl')
    fd = os.open(path, os.O_RDWR|os.O_APPEND|os.O_CREAT|os.O_NOFOLLOW|os.O_NONBLOCK, 0o600)
    try:
        info = os.fstat(fd)
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                or info.st_mode & 0o077 or info.st_size > 1024*1024 - 2*EVIDENCE_ROW_BYTES - 1):
            raise Stop('evidence_type_owner_mode_or_size')
        return fd
    except BaseException:
        os.close(fd)
        raise


def record_evidence(fd, directory, seat, payload, expectation, generation):
    value = {'schema':'orch.claude-start-evidence.v3', 'seat':seat,
             'source':payload['source'], 'route_generation':generation,
             'recorded_at':datetime.now().astimezone().isoformat(),
             'grounding_generation':expectation['grounding_generation'],
             'installed_kit_pin':expectation['installed_kit_pin']}
    append_evidence(fd, directory, value)


CLIENT_SOURCES = {'wake_hook_claude.py', 'wake_hook_client.py', 'wake_hook_core.py', 'harness_facts.py'}


def validate_interface(value):
    if (not isinstance(value, dict) or set(value) != {'schema', 'version', 'sources'}
            or value['schema'] != 'orch.claude-hook-interface.v1'
            or type(value['version']) is not int or not 1 <= value['version'] <= 1000000
            or not isinstance(value['sources'], dict) or set(value['sources']) != CLIENT_SOURCES
            or not all(is_digest(h) for h in value['sources'].values())):
        raise Stop('hook_interface_schema')


def validate_runtime(config):
    if config.get('schema') != 'orch.claude-runtime-pins.v3':
        raise Stop('configuration_mismatch')
    recovery_enabled(config)
    if recovery_enabled(config) and not is_digest(config.get('installation_id')):
        raise Stop('configuration_mismatch')
    root = canonical_home(config['runtime_root'])
    validate_product_identity(config, root)
    python = Path(config['python'])
    if not python.is_absolute() or str(python) != config['python'] or '..' in python.parts:
        raise Stop('interpreter_path_invalid')
    account = canonical_home(config['account_home'])
    client = config.get('interface')
    validate_interface(client)
    current = json.loads(regular_bytes(root/'claude_hook_interface.json', 32768))
    validate_interface(current)
    if client['sources'] != current['sources']:
        raise Stop('hook_interface_stale_sources')
    if client['version'] not in {current['version'], current['version'] - 1}:
        raise Stop('hook_interface_version_refused')
    for name, expected in client['sources'].items():
        if hashlib.sha256(regular_bytes(root/name)).hexdigest() != expected:
            raise Stop('hook_interface_deployed_source_mismatch')
    resolved, python_sha256 = interpreter_identity(python)
    if str(resolved) != config['python_realpath']:
        raise Stop('interpreter_path_changed')
    if python_sha256 != config['python_sha256']:
        raise Stop('interpreter_pin_mismatch')
    modules = {Path(name).stem: str(root/name) for name in client['sources']}
    code = ('import importlib.util,json; names=' + repr(list(modules)) + '; '
            'print(json.dumps({n:(getattr(importlib.util.find_spec(n),"origin",None)) for n in names}))')
    origins = bounded_command([str(python),'-I','-c',code], cwd=root,
                              env={'PATH':'/usr/bin:/bin','HOME':str(account)}, timeout=2)
    if json.loads(origins) != modules:
        raise Stop('installed_module_origin_mismatch')


def validate_product_identity(config, root):
    """The rendered names are pins, not instructions supplied by the session."""
    binding = config.get('product_identity')
    profile_path = root/'product_profile.json'
    if binding is None:
        # Existing private kits predate profiles. They remain private only;
        # absence must never let a public runtime inherit an estate name/pin.
        if profile_path.exists():
            profile = json.loads(regular_bytes(profile_path, 16384))
            if profile.get('edition') != 'private':
                raise Stop('product_identity_binding_missing')
        return
    if (not isinstance(binding, dict) or set(binding) != {
            'profile_sha256', 'module_sha256', 'commands', 'home_directory'}
            or not is_digest(binding['profile_sha256']) or not is_digest(binding['module_sha256'])):
        raise Stop('product_identity_binding_invalid')
    raw = regular_bytes(profile_path, 16384)
    if (hashlib.sha256(raw).hexdigest() != binding['profile_sha256']
            or hashlib.sha256(regular_bytes(root/'product_identity.py')).hexdigest() != binding['module_sha256']):
        raise Stop('product_identity_changed')
    profile = json.loads(raw)
    if (profile.get('commands') != binding['commands']
            or profile.get('home_directory') != binding['home_directory']):
        raise Stop('product_identity_render_mismatch')
    if (not isinstance(binding['commands'], dict)
            or binding['commands'].get('main') != PRODUCT_PREFIX):
        raise Stop('product_identity_template_mismatch')


def socket_metadata(ref):
    p = Path(ref)
    sockets = CLAUDE_SOCKET_DIR
    # Accept a parent alias only when it resolves to the pinned socket directory
    # and the same leaf. lstat below still rejects a symlink leaf.
    if (not p.is_absolute() or str(p) != ref or '..' in p.parts
            or p.parent.resolve() != sockets or p.resolve() != sockets / p.name
            or not re.fullmatch(r'[1-9][0-9]*\.sock', p.name)):
        raise Stop('socket_path_mismatch')
    s = p.lstat()
    if not stat.S_ISSOCK(s.st_mode) or s.st_uid != os.getuid():
        raise Stop('socket_type_or_owner')
    raw = bounded_command(['/bin/ps','-p',p.stem,'-o','uid=','-o','lstart='], cwd=p.parent,
                          env={'PATH':'/usr/bin:/bin','LC_ALL':'C','LANG':'C'}, timeout=2)
    fields = raw.decode().strip().split(maxsplit=1)
    if int(fields[0]) != os.getuid():
        raise Stop('process_owner')
    born = datetime.strptime(fields[1], '%a %b %d %H:%M:%S %Y').astimezone().timestamp()
    return born


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     ensure_ascii=True, allow_nan=False).encode()).hexdigest()


def is_digest(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def qualification(raw, seat, home, source, config):
    """Use only the authenticated own-seat snapshot, never a local generation cache.

    The authenticated product endpoint validates the record and installed pins.
    Recheck identity, digests and response shape here; the receiver rechecks the
    record and route generations under its mutation locks on the next command.
    """
    snapshot = json.loads(raw)
    if not isinstance(snapshot, dict) or set(snapshot) != {'record', 'previous_generation', 'interface'}:
        raise Stop('hookset_snapshot_shape')
    record = snapshot['record']
    if (not isinstance(record, dict) or set(record) !=
            {'spec', 'digest', 'generation', 'record_id', 'recorded_at', 'provisioner'}):
        raise Stop('hookset_record_missing_or_shape')
    spec = record['spec']
    if (not isinstance(spec, dict) or spec.get('schema') != 'orch.claude-hookset.v2'
            or spec.get('seat') != seat or spec.get('home') != str(home)
            or record['digest'] != digest(spec)
            or record['generation'] != digest({k:v for k,v in record.items() if k != 'generation'})):
        raise Stop('hookset_record_binding')
    client = config.get('interface')
    validate_interface(client)
    if spec.get('interface') != client:
        raise Stop('hookset_client_interface_binding')
    summary = snapshot['interface']
    if not isinstance(summary, dict) or set(summary) != {'current', 'policy'}:
        raise Stop('hookset_interface_snapshot_shape')
    validate_interface(summary['current'])
    policy = summary['policy']
    if (summary['current']['sources'] != client['sources'] or not isinstance(policy, dict)
            or policy.get('catalog_digest') != digest(summary['current'])
            or policy.get('generation') != digest({k:v for k,v in policy.items() if k != 'generation'})):
        raise Stop('hookset_interface_snapshot_binding')
    previous = snapshot['previous_generation']
    if previous != 'none' and not is_digest(previous):
        raise Stop('hookset_route_generation')
    return {'digest':record['digest'], 'generation':record['generation'], 'source':source,
            'interface_version':client['version'], 'interface_digest':digest(client)}, previous


def declaration(payload, environ, *, check_runtime=validate_runtime,
                metadata=socket_metadata, command=bounded_command,
                wall=time.time, sleep=time.sleep, config=None, progress=None):
    progress = progress or Progress()
    progress.mark('native_identity')
    if payload.get('hook_event_name') != 'SessionStart' or payload.get('source') not in {'startup','resume','compact'}:
        return None
    seat, home = installed_identity(config)
    if payload.get('cwd') != str(home) or home.resolve() != home:
        raise Stop('wrong_workspace')
    if payload['source'] == 'compact':
        # Compaction is context recovery, not a new native route incarnation.
        # Repeat the authenticated grounding read without refreshing a delivery
        # budget, asking for native socket metadata.
        if any(k.startswith(('ORCH_', 'PSQR_')) for k in environ):
            raise Stop('unexpected_store_override')
        progress.mark('runtime_check')
        check_runtime(config)
        account = canonical_home(config['account_home'])
        argv = [config['python'], '-I', '-m', 'orch_cli', '--token-file',
                str(home/'.orch/token'), 'seat', 'grounding-show', seat]
        env = {'PATH':'/usr/bin:/bin','HOME':str(account),'LANG':'C','LC_ALL':'C'}
        progress.mark('grounding_snapshot_wait')
        snapshot = json.loads(grounding_read(argv, cwd=home, env=env,
            command=command, config=config, progress=progress, sleep=sleep))
        progress.mark('grounding_snapshot_validate')
        expected = expectations(snapshot, payload, seat, config)
        _, previous = qualification(json.dumps(snapshot['hookset']), seat, home, 'compact', config)
        return previous, expected
    ref = environ.get('CLAUDE_CODE_MESSAGING_SOCKET', '')
    session = environ.get('CLAUDE_CODE_HOST_SESSION_ID', '')
    if not session.startswith('local_') or str(uuid.UUID(session[6:])) != session[6:]:
        raise Stop('native_session_missing')
    # Reject store redirection; the deployed CLI resolves the normal locator.
    if any(k.startswith(('ORCH_', 'PSQR_')) for k in environ):
        raise Stop('unexpected_store_override')
    progress.mark('runtime_check')
    check_runtime(config)
    progress.mark('socket_metadata')
    born = metadata(ref)
    delay = born + 1.05 - wall()
    if delay > 1.1:
        raise Stop('process_clock_unresolved')
    if delay > 0:
        sleep(delay)
    if metadata(ref) != born or int(wall()) <= born:
        raise Stop('process_changed_or_clock_unresolved')
    python = Path(config['python'])
    account = canonical_home(config['account_home'])
    prefix = [str(python), '-I', '-m', 'orch_cli', '--token-file', str(home/'.orch/token')]
    env = {'PATH':'/usr/bin:/bin','HOME':str(account),'LANG':'C','LC_ALL':'C'}
    progress.mark('grounding_snapshot_wait')
    raw_snapshot = grounding_read(prefix + ['seat', 'grounding-show', seat],
        cwd=home, env=env, command=command, config=config, progress=progress, sleep=sleep)
    progress.mark('grounding_snapshot_validate')
    snapshot = json.loads(raw_snapshot)
    expected = expectations(snapshot, payload, seat, config)
    qualified, previous = qualification(json.dumps(snapshot['hookset']), seat, home, payload['source'], config)
    # A slow snapshot must not disguise a replaced process.
    progress.mark('socket_recheck')
    if metadata(ref) != born:
        raise Stop('process_changed_after_snapshot')
    if recovery_enabled(config) and progress.started + WORK_SECONDS - progress.clock() < FINISH_RESERVE_SECONDS:
        raise StartupHeld('grounding_read_budget_exhausted')
    # The store canonicalizes the route reference. Submit and
    # compare that spelling too, after validating the original native reference.
    ref = str(Path(ref).resolve())
    argv = prefix + ['seat', 'wake-declare', seat, '--kind', 'inapp-socket',
            '--ref', ref, '--session-ref', session, '--hook-home', str(home),
            '--session-start-source', payload['source'], '--hook-set-digest', qualified['digest'],
            '--hook-set-generation', qualified['generation'], '--previous-generation', previous,
            '--hook-interface-version', str(qualified['interface_version']),
            '--hook-interface-digest', qualified['interface_digest'],
            '--grounding-generation', expected['grounding_generation']]
    progress.mark('declaration_wait')
    progress.declaration_state = 'unknown'
    raw = command(argv, cwd=home, env=env, timeout=DECLARATION_WAIT_SECONDS)
    progress.mark('declaration_reply_validate')
    result = json.loads(raw)
    route = result['route']; receipt = result['receipt']
    if (route.get('ref') != ref or route.get('session_ref') != session
            or route.get('kind') != 'inapp-socket' or route.get('qualification') != qualified
            or receipt.get('event') != 'declared' or receipt.get('seat') != seat
            or receipt.get('route') != route):
        raise Stop('declaration_reply_mismatch_outcome_unknown')
    generation = hashlib.sha256(json.dumps(route,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    if receipt.get('generation') != generation or generation == previous:
        raise Stop('declaration_generation_mismatch_outcome_unknown')
    progress.declaration_state = 'confirmed'
    return generation, expected


def main():
    progress = Progress()
    lock = None
    evidence = None
    locked = False
    stop_path = None
    try:
        if sys.argv[1:]:
            raise Stop('unexpected_arguments')
        progress.mark('input')
        payload = read_input(sys.stdin.fileno())
        if payload.get('hook_event_name') != 'SessionStart' or payload.get('source') not in {'startup','resume','compact'}:
            return 0
        # Configuration is adjacent to the installed hook, not selected by cwd.
        directory = Path(__file__).absolute().parent
        if directory.resolve() != directory or directory.name != '.claude':
            raise Stop('configuration_directory_symlink_or_name')
        progress.mark('configuration')
        config_bytes = regular_bytes(directory/CONFIG_NAME, 65536)
        installation_sha256 = hashlib.sha256(config_bytes).hexdigest()
        config = json.loads(config_bytes)
        seat, home = installed_identity(config)
        if Path.cwd() != home or directory != home/'.claude':
            raise Stop('wrong_execution_directory')
        progress.mark('installed_source_pin')
        if hashlib.sha256(regular_bytes(Path(__file__).absolute())).hexdigest() != config['session_start_sha256']:
            raise Stop('installed_source_pin')
        progress.mark('startup_lock')
        lock = os.open(directory/('.'+PRODUCT_PREFIX+'-session-start.lock'), os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW, 0o600)
        info = os.fstat(lock)
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid():
            raise Stop('lock_owner_or_type')
        fcntl.flock(lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
        locked = True
        stop_path = directory/STOP_NAME
        if stop_path.exists() or stop_path.is_symlink():
            raise Stop('prior_refresh_failure_requires_disposition')
        progress.mark('evidence_open')
        evidence = open_evidence(directory)
        generation, expected = declaration(payload, os.environ, config=config, progress=progress)
        if payload['source'] in {'startup', 'resume'}:
            progress.declaration_state = 'confirmed'
        progress.mark('success_evidence')
        record_evidence(evidence, directory, seat, payload, expected, generation)
        if recovery_enabled(config):
            record_start_state(evidence, directory, config, seat, payload, progress, 'ready', 'grounding_ready',
                               installation_sha256=installation_sha256)
        progress.mark('context_output')
        context = ((f'{PRODUCT_PREFIX.upper()} neutral grounding: no expectations adopted; no grounding or model comparison. '
                    'Runtime and installed-kit integrity checks still apply. '
                    if expected['grounding_mode'] == 'neutral' else
                    f'{PRODUCT_PREFIX.upper()} grounding expectations from your authenticated store record. '
                    'Compare these with your measured grounding; a declared model is not a runtime observation. ')
                   + json.dumps(expected, sort_keys=True))
        print(json.dumps({'hookSpecificOutput': {'hookEventName': 'SessionStart', 'additionalContext': context}}))
        return 0
    except Exception as exc:
        if (isinstance(exc, StartupHeld) and evidence is not None and locked
                and progress.declaration_state == 'not_attempted'):
            try:
                record_start_state(evidence, directory, config, seat, payload, progress,
                                   'held', str(exc), installation_sha256=installation_sha256)
            except Exception:
                # Without durable evidence this cannot silently become a
                # retryable read hold. The ordinary safety latch remains.
                print(f'{PRODUCT_PREFIX.upper()}_SESSIONSTART_EVIDENCE_UNCONFIRMED: startup hold could not be persisted.', file=sys.stderr)
            else:
                print(f'{PRODUCT_PREFIX.upper()}_SESSIONSTART_HELD: grounding read unavailable; no declaration attempted. A later native start may retry.', file=sys.stderr)
                return 1
        # Persist the bounded diagnostic BEFORE the latch. If evidence itself
        # failed, do not hide that failure or omit the safety latch.
        if evidence is not None:
            try:
                record_failure(evidence, directory, seat, payload, progress, exc)
                if recovery_enabled(config):
                    record_start_state(evidence, directory, config, seat, payload, progress,
                                       'refused', 'startup_refused', installation_sha256=installation_sha256)
            except Exception:
                print(f'{PRODUCT_PREFIX.upper()}_SESSIONSTART_EVIDENCE_UNCONFIRMED: diagnostic could not be persisted.',file=sys.stderr)
        elif locked and stop_path is not None and not stop_path.exists():
            print(f'{PRODUCT_PREFIX.upper()}_SESSIONSTART_EVIDENCE_UNCONFIRMED: diagnostic file unavailable.',file=sys.stderr)
        # Preserve a refusal/uncertain result across a later automatic start.
        # Only an operator disposition may clear this latch; this kit has no
        # reset command. A latch write failure is still a STOP, never success.
        if locked and stop_path is not None:
            try:
                fd = os.open(stop_path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
                with os.fdopen(fd,'wb') as f:
                    f.write((PRODUCT_PREFIX.upper()+'_SESSIONSTART_STOP: preserve receipts; no automatic retry.\n').encode())
                    f.flush();os.fsync(f.fileno())
                fd = os.open(stop_path.parent,os.O_RDONLY)
                try:os.fsync(fd)
                finally:os.close(fd)
            except FileExistsError:
                pass
            except OSError:
                print(f'{PRODUCT_PREFIX.upper()}_SESSIONSTART_LATCH_UNCONFIRMED: stop further starts and preserve evidence.',file=sys.stderr)
        # Deliberately omit exception text, captured output, payload and env.
        if isinstance(exc, Stop) and str(exc) == 'grounding_record_missing':
            print('grounding_record_missing', file=sys.stderr)
        print(f'{PRODUCT_PREFIX.upper()}_SESSIONSTART_STOP: route refresh refused or uncertain; inspect durable route receipts before any wake; do not retry automatically.', file=sys.stderr)
        return 1
    finally:
        if evidence is not None:
            os.close(evidence)
        if lock is not None:
            os.close(lock)


if __name__ == '__main__':
    sys.exit(main())
