"""Shared registry mutation seam; per-kind predicates remain distinct."""
from desktop_support import optional as optional_desktop
codex_wake_route = optional_desktop('codex_wake_route')
inapp_wake_route = optional_desktop('inapp_wake_route')
agy_wake_route = optional_desktop('agy_wake_route')


def check_registry_change(seat, actor, before, after):
    old = (before.get(seat) or {}).get('wake_route')
    new = (after.get(seat) or {}).get('wake_route')
    selected = new if new is not None else old
    if any(isinstance(route, dict) and route.get('kind') == 'launched' for route in (old, new)):
        from launched_gateway import check_registry_change as check_launched
        return check_launched(seat, actor, before, after)
    if isinstance(selected, dict):
        if selected.get('kind') == 'inapp-socket':
            if inapp_wake_route is None: raise ValueError('desktop route unavailable')
            return inapp_wake_route.check_registry_change(seat,actor,before,after)
        if selected.get('kind') == 'agy-desktop':
            if agy_wake_route is None: raise ValueError('desktop route unavailable')
            return agy_wake_route.check_registry_change(seat,actor,before,after)
    if codex_wake_route is None: raise ValueError('desktop route unavailable')
    return codex_wake_route.check_registry_change(seat,actor,before,after)
