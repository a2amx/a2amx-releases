"""Narrow, read-only transcript facts joined to existing store read interfaces.

Only the Claude JSONL adapter has a measured structural census. Unknown
harnesses never open a transcript. Payloads are opaque: only closed block
metadata and an exact whole-user-prompt pointer can escape their envelope.
No free text, filenames, tool arguments/results or exception details are output.
"""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
from zoneinfo import ZoneInfo

from digest_config import MODEL_WINDOWS, POINTER_WINDOW_SECONDS

MODEL = re.compile(r'[a-z0-9.\-]{1,64}\Z', re.ASCII)
POINTER = re.compile(r'mail: (msg-[0-9a-f]{10})\Z', re.ASCII)
MESSAGE_ID = re.compile(r'msg-[0-9a-f]{10}\Z', re.ASCII)
IDENTITY = re.compile(r'[A-Za-z][A-Za-z0-9_.\-]{0,63}\Z', re.ASCII)
TOKEN_RUN = re.compile(r'[A-Za-z0-9_-]{28,}', re.ASCII)
UUID = re.compile(r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}', re.ASCII)
MAX_RECORD_BYTES = 1024 * 1024
USAGE_FIELDS = ('input_tokens', 'output_tokens', 'cache_read_input_tokens', 'cache_creation_input_tokens')
COUNTERS = ('read', 'unknown', 'invalid_records', 'torn_tails', 'oversized_records',
            'input_errors', 'invalid_usage', 'invalid_fields', 'sidechains', 'unknown_blocks')
HARNESSES = frozenset({'claude', 'codex', 'gemini', 'antigravity', 'kimi', 'human'})
FETCH_VIA = frozenset({'hook', 'mail', 'inbox', 'http', 'console', 'pull'})


def render(value):
    text = json.dumps(value, ensure_ascii=True, sort_keys=True, allow_nan=False)
    return TOKEN_RUN.sub('<masked>', UUID.sub('<masked>', text)) + '\n'


def _number(value):
    return value if type(value) is int and 0 <= value <= 2**53 - 1 else None


def _instant(value):
    if not isinstance(value, str) or len(value) > 40:
        return None
    try:
        dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
        return dt.astimezone(timezone.utc) if dt.tzinfo is not None else None
    except (ValueError, OverflowError):
        return None


def _iso(value):
    return value.isoformat() if value is not None else None


def _key(value):
    # Correlation only, never an output field. Raw ids need not be trusted text.
    if not isinstance(value, str) or not value or len(value) > 256:
        return None
    return hashlib.sha256(value.encode()).digest()


def _identity(value):
    if (isinstance(value, str) and IDENTITY.fullmatch(value)
            and not TOKEN_RUN.search(value) and not UUID.search(value)):
        return value
    return 'seat-' + hashlib.sha256(str(value).encode()).hexdigest()[:12]


def _harness(participant):
    family = participant.get('family')
    family = family.casefold() if isinstance(family, str) else None
    if family in HARNESSES:
        return family
    return 'human' if participant.get('kind') == 'human' else 'unknown'


def _model(value):
    return value if (isinstance(value, str) and MODEL.fullmatch(value)
                     and not TOKEN_RUN.search(value)) else 'unknown'


def _regular_read(path):
    """No symlink (including parent aliases), FIFO, directory, or write flags."""
    path = Path(path)
    if not path.is_absolute() or path.resolve() != path:
        raise ValueError('input unavailable')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise ValueError('input unavailable')
        handle = os.fdopen(fd, 'rb')
    except BaseException:
        os.close(fd)
        raise
    return handle


def _config(root):
    try:
        with _regular_read(root / 'digest_config.json') as handle:
            raw = handle.read(MAX_RECORD_BYTES + 1)
    except FileNotFoundError:
        return {'version': 1, 'seats': {}}
    if len(raw) > MAX_RECORD_BYTES:
        raise ValueError('configuration unavailable')
    config = json.loads(raw)
    if not isinstance(config, dict):
        raise ValueError('configuration unavailable')
    return config


def _settings(config):
    if (type(config.get('version', 1)) is not int or config.get('version', 1) != 1
            or not isinstance(config.get('seats', {}), dict)):
        raise ValueError('configuration unavailable')
    zone = config.get('timezone', 'UTC')
    zone = timezone.utc if zone == 'UTC' else ZoneInfo(zone)
    seconds = config.get('pointer_window_seconds', POINTER_WINDOW_SECONDS)
    if _number(seconds) is None or not 1 <= seconds <= 86400:
        raise ValueError('configuration unavailable')
    windows = dict(MODEL_WINDOWS)
    overrides = config.get('model_windows', {})
    if not isinstance(overrides, dict):
        raise ValueError('configuration unavailable')
    for model, window in overrides.items():
        if _model(model) == 'unknown' or _number(window) is None or not 1 <= window <= 100_000_000:
            raise ValueError('configuration unavailable')
        windows[model] = window
    return zone, seconds, windows


def _whole_pointer(content):
    if (isinstance(content, list) and len(content) == 1 and isinstance(content[0], dict)
            and content[0].get('type') == 'text'):
        content = content[0].get('text')
    if isinstance(content, str) and (match := POINTER.fullmatch(content)):
        return match[1]
    return None


def _scan(path, now):
    counts = Counter({name: 0 for name in COUNTERS})
    turns, pending, finished, pointers = {}, {}, set(), []
    last = None
    last_turn = None
    failures = 0
    # A damaged/unknown row has no trusted timestamp. The next recognized
    # timestamp bounds it conservatively; an unresolved tail stays unbounded.
    gap = False
    uncertain_through = None
    try:
        with _regular_read(path) as handle:
            # Snapshot the extent: do not chase an actively appending writer.
            remaining = os.fstat(handle.fileno()).st_size
            while remaining:
                line = handle.readline(min(remaining, MAX_RECORD_BYTES + 1))
                remaining -= len(line)
                if not line:
                    break
                if len(line) > MAX_RECORD_BYTES:
                    counts['oversized_records'] += 1
                    gap = True
                    while remaining and not line.endswith(b'\n'):
                        line = handle.readline(min(remaining, MAX_RECORD_BYTES + 1))
                        remaining -= len(line)
                        if not line: break
                    continue
                if not line.strip():
                    continue
                if not line.endswith(b'\n'):
                    counts['torn_tails'] += 1
                    gap = True
                    continue
                try:
                    rec = json.loads(line)
                except (ValueError, UnicodeError, RecursionError):
                    counts['invalid_records'] += 1
                    gap = True
                    continue
                counts['read'] += 1
                if not isinstance(rec, dict) or rec.get('type') not in ('assistant', 'user', 'system'):
                    counts['unknown'] += 1
                    gap = True
                    continue
                if rec.get('isSidechain') is True:
                    counts['sidechains'] += 1
                    continue
                when = _instant(rec.get('timestamp'))
                if when is None or when > now or (last is not None and when < last):
                    counts['invalid_fields'] += 1
                    gap = True
                    continue
                last = when
                if gap:
                    uncertain_through = when
                    gap = False
                kind = rec['type']
                if kind == 'system':
                    continue  # metadata and content remain opaque
                msg = rec.get('message')
                if not isinstance(msg, dict) or msg.get('role') != kind:
                    counts['invalid_fields'] += 1
                    uncertain_through = when
                    continue
                prior_errors = sum(counts[k] for k in ('invalid_fields', 'invalid_usage', 'unknown_blocks'))
                if kind == 'assistant':
                    key = _key(msg.get('id'))
                    raw_usage = msg.get('usage')
                    usage = (tuple(_number(raw_usage.get(f)) for f in USAGE_FIELDS)
                             if isinstance(raw_usage, dict) else None)
                    if usage is None or None in usage:
                        counts['invalid_usage'] += 1
                        usage = None
                    turn = {'when': when, 'usage': usage, 'model': _model(msg.get('model')),
                            'response_key': key}
                    last_turn = turn
                    if key is None:
                        counts['invalid_fields'] += 1
                    else:
                        if key in turns:
                            old = turns[key]
                            if old['usage'] != usage or old['model'] != turn['model']:
                                counts['invalid_usage'] += 1
                                old['usage'] = None  # conflicting duplicate: no invented total
                                last_turn['usage'] = None
                        else:
                            turns[key] = turn
                content = msg.get('content')
                pointer = _whole_pointer(content) if kind == 'user' and rec.get('isMeta') is not True else None
                if pointer:
                    pointers.append({'id': pointer, 'when': when, 'queued': bool(pending)})
                if isinstance(content, list):
                    for block in content:
                        if not isinstance(block, dict):
                            counts['unknown_blocks'] += 1
                            continue
                        block_type = block.get('type')
                        if block_type == 'tool_use' and kind == 'assistant':
                            key = _key(block.get('id'))
                            if key is not None and key not in finished:
                                pending.setdefault(key, when)
                            elif key is None:
                                counts['invalid_fields'] += 1
                        elif block_type == 'tool_result' and kind == 'user':
                            key = _key(block.get('tool_use_id'))
                            error = block.get('is_error', False)
                            if key is None or type(error) is not bool:
                                counts['invalid_fields'] += 1
                                continue
                            if key not in finished:
                                pending.pop(key, None)
                                finished.add(key)
                                failures = failures + 1 if error else 0
                        elif block_type not in ('text', 'thinking', 'redacted_thinking', 'image', 'document'):
                            counts['unknown_blocks'] += 1
                        # Never inspect input, tool-result content, names or nested payloads.
                if sum(counts[k] for k in ('invalid_fields', 'invalid_usage', 'unknown_blocks')) > prior_errors:
                    uncertain_through = when
    except (OSError, ValueError, UnicodeError, RecursionError):
        counts['input_errors'] += 1
    return {'counts': counts, 'turns': turns, 'pending': pending, 'pointers': pointers,
            'last': last, 'last_turn': last_turn, 'failures': failures,
            'coverage': {'available': not counts['input_errors'], 'trailing_gap': gap,
                         'uncertain_through': uncertain_through}}


def _view(participant, mapping, now, zone, windows):
    empty = {'transcript': 'no transcript', 'session': None, 'model': 'unknown',
             'context_tokens': None, 'tokens_today': None, 'turns_today': None,
             'last_activity': None, 'activity': 'unknown', 'minutes_since_activity': None,
             'busy_minutes': None, 'busy_without_record_minutes': None,
             'failed_tool_results': None, 'records': dict.fromkeys(COUNTERS, 0),
             'usage_complete': False}
    if not isinstance(mapping, dict) or not mapping.get('files'):
        return empty, [], None
    if _harness(participant) != 'claude' or mapping.get('format') != 'claude-jsonl-v1':
        empty['transcript'] = 'unqualified harness'
        return empty, [], None
    paths = mapping.get('files')
    current = mapping.get('current_file')
    seat_home = mapping.get('seat_home')
    if (not isinstance(paths, list) or not all(isinstance(p, str) for p in paths)
            or len(set(paths)) != len(paths) or current not in paths
            or not isinstance(seat_home, str) or not Path(seat_home).is_absolute()
            or (participant.get('workspace_dir') and participant['workspace_dir'] != seat_home)):
        empty['transcript'] = 'mapping unavailable'
        return empty, [], None
    scans = {path: _scan(path, now) for path in paths}
    active = scans[current]
    counts = Counter()
    turns = {}
    for scan in scans.values():
        counts.update(scan['counts'])
        for key, turn in scan['turns'].items():
            if key not in turns:
                turns[key] = dict(turn)
            else:
                previous = turns[key]
                if previous['usage'] != turn['usage'] or previous['model'] != turn['model']:
                    counts['invalid_usage'] += 1
                    previous['usage'] = None
                # A copied response keeps its earliest observed day; a changed
                # wrapper timestamp is not a conflict in its usage or model.
                previous['when'] = min(previous['when'], turn['when'])
    empty['records'] = {key: counts[key] for key in COUNTERS}
    # Whole-day usage completeness is independent of current pointer coverage.
    complete = not any(counts[k] for k in ('input_errors', 'invalid_records', 'oversized_records',
                                          'invalid_usage', 'invalid_fields', 'torn_tails', 'unknown_blocks'))
    empty['usage_complete'] = complete
    empty['transcript'] = 'input unavailable' if active['counts']['input_errors'] else 'observed'
    empty['session'] = 'session-' + hashlib.sha256(Path(current).stem.encode()).hexdigest()[:12]
    today = [t for t in turns.values() if t['when'].astimezone(zone).date() == now.astimezone(zone).date()]
    empty['turns_today'] = len(today)
    if not counts['input_errors'] and all(t['usage'] is not None for t in today):
        empty['tokens_today'] = {'in': sum(t['usage'][0] for t in today),
                                'out': sum(t['usage'][1] for t in today),
                                'cache': sum(t['usage'][2] + t['usage'][3] for t in today)}
    if active['last_turn'] is not None and not active['counts']['input_errors']:
        turn = active['last_turn']
        empty['model'] = turn['model']
        # Cross-file conflicts invalidate the active response too, not only
        # its copied aggregate entry. Unrelated response conflicts stay local.
        aggregate = turns.get(turn['response_key'])
        if turn['usage'] is not None and (aggregate is None or aggregate['usage'] is not None):
            usage = turn['usage']
            empty['context_tokens'] = usage[0] + usage[2] + usage[3]
            if turn['model'] in windows:
                empty['context_percent'] = round(100 * empty['context_tokens'] / windows[turn['model']], 3)
    if active['last'] is not None and not active['counts']['input_errors']:
        empty['last_activity'] = _iso(active['last'])
        empty['activity'] = 'busy' if active['pending'] else 'idle'
        empty['minutes_since_activity'] = round((now - active['last']).total_seconds() / 60, 2)
        empty['failed_tool_results'] = active['failures']
        if active['pending']:
            empty['busy_minutes'] = round((now - min(active['pending'].values())).total_seconds() / 60, 2)
            empty['busy_without_record_minutes'] = empty['minutes_since_activity']
    return empty, active['pointers'], active['coverage']


def _uncertain_posts(seat, rows):
    """Join the pinned daemon nudge pre/post schema; never inspect its payload.

    codex_dispatch.at_chokepoint writes msg-id only on pre, and repeats the
    event, target, route and generation on post. An orphan/mismatched post
    cannot delay an unrelated pointer. Times remain typed, even if ahead of
    this measurement: absence must not be reported before a recorded post.
    """
    import store
    pres, posts = {}, {}
    for rec in rows:
        if (rec.get('kind') != 'nudge' or rec.get('route_kind') != 'codex-ipc'
                or rec.get('target seat') != seat):
            continue
        key, when = _key(rec.get('event-id')), _instant(rec.get('ts'))
        generation = _key(rec.get('generation'))
        if key is None or when is None or generation is None:
            continue
        if rec.get('phase') == 'pre':
            mid = rec.get('msg-id')
            if (isinstance(mid, str) and MESSAGE_ID.fullmatch(mid)
                    and rec.get('requester') == store.DAEMON_SEAT
                    and rec.get('credential_role') == 'daemon'):
                pres[key] = (mid, when, generation)
        elif rec.get('phase') == 'post' and rec.get('result') == 'uncertain':
            pre = pres.get(key)
            if pre is not None and pre[1] <= when and pre[2] == generation:
                posts.setdefault(pre[0], []).append(when)
    return posts


def _observable_since(coverage, start):
    return (coverage is not None and coverage['available'] and not coverage['trailing_gap']
            and (coverage['uncertain_through'] is None or coverage['uncertain_through'] < start))


def _store_columns(seat, public_seat, receipt_rows, unread, now, pointers, observable, window):
    import store
    receipt_rows = [r for r in receipt_rows if isinstance(r, dict)]
    uncertain = _uncertain_posts(seat, receipt_rows)
    pokes = {}
    latest_kinds = {}
    for rec in receipt_rows:
        if not isinstance(rec, dict): continue
        mid, when = rec.get('msg-id'), _instant(rec.get('ts'))
        if (rec.get('kind') == 'delivery' and rec.get('event') == 'POKED' and rec.get('seat') == seat
                and isinstance(mid, str) and MESSAGE_ID.fullmatch(mid) and when is not None and when <= now):
            pokes.setdefault(mid, []).append(when)
            if mid not in latest_kinds or when >= latest_kinds[mid][0]:
                latest_kinds[mid] = (when, rec.get('adapter'))
    unmeasured = {mid for mid, (_, kind) in latest_kinds.items()
                  if kind in ('inapp-socket', 'agy-desktop')}
    last_fetch = None
    fetches = {}
    for _, rec in store.valid_fetched_deliveries(receipt_rows):
        when = _instant(rec.get('ts'))
        if rec.get('seat') != seat or when is None or when > now: continue
        prior = [t for t in pokes.get(rec.get('msg-id'), []) if t <= when]
        if prior:
            fetches.setdefault(rec['msg-id'], []).append(when)
        if prior and (last_fetch is None or when > last_fetch[0]):
            via = rec.get('via', rec.get('adapter'))
            last_fetch = (when, (when - max(prior)).total_seconds(), via if isinstance(via, str) and via in FETCH_VIA else 'unknown')
    states = []
    for mid, times in sorted(pokes.items()):
        start = max(times)
        seen = sorted((p for p in pointers if p['id'] == mid and p['when'] >= start), key=lambda p: p['when'])
        queued = False
        if seen:
            queued = seen[0]['queued']
        if mid in unmeasured:
            state = 'unknown'
        elif any(when >= start for when in fetches.get(mid, [])):
            state = 'delivered'
        elif not _observable_since(observable, start):
            state = 'unknown'
        else:
            after_posts = all(now > when for when in uncertain.get(mid, []) if when >= start)
            state = 'missed' if (now - start).total_seconds() >= window and after_posts else 'pending'
        states.append({'id': mid, 'state': state, 'was_queued': queued})
    # Seat-wide fetch columns cannot certify the excluded pointer kinds.
    if unmeasured:
        last_fetch = None
    return {'unread_count': (sum(r.get('recipient') == seat for r in unread.get('rows', [])
                               if isinstance(r, dict)) if _instant(unread.get('cutover')) else None),
            'unread_boundary': 'known' if _instant(unread.get('cutover')) else 'unknown',
            'last_poke_to_fetch_seconds': last_fetch[1] if last_fetch else None,
            'last_fetch': _iso(last_fetch[0]) if last_fetch else None,
            'fetched_by': public_seat if last_fetch else None,
            'via': last_fetch[2] if last_fetch else None, 'pointers': states}


def build(registry, config, receipt_rows, unread_view, now):
    zone, window, windows = _settings(config)
    rows = []
    for seat, participant in sorted(registry.items()):
        if not isinstance(participant, dict):
            participant = {}
        public_seat = _identity(seat)
        view, pointers, observable = _view(participant, config.get('seats', {}).get(seat), now, zone, windows)
        harness = _harness(participant)
        rows.append({'seat': public_seat, 'harness': harness, **view,
                     **_store_columns(seat, public_seat, receipt_rows, unread_view, now, pointers, observable, window)})
    return {'version': 1, 'measured_at': _iso(now), 'day': now.astimezone(zone).date().isoformat(),
            'seats': rows}


def _write(path, output):
    path = Path(path)
    # Existing targets (including transcripts, hard links and symlinks) are refused.
    # No temp file, directory creation, rename, credential or cache write.
    if not path.is_absolute():
        raise ValueError('output unavailable')
    path = path.parent.resolve(strict=True) / path.name
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    with os.fdopen(fd, 'wb') as handle:
        os.fchmod(handle.fileno(), 0o600)
        handle.write(output.encode('utf-8'))
        handle.flush()
        os.fsync(handle.fileno())


def run(output=None, *, now=None):
    try:
        import store
        import receipts
        root = store.require_bound_store().resolve()
        now = now or datetime.now(timezone.utc)
        result = build(store.load_participants(), _config(root), receipts.rows(), store.unread_ledger(), now)
        rendered = render(result)
        destination = (Path(output).absolute() if output is not None else
                       root / 'run' / ('digest-' + now.strftime('%Y%m%dT%H%M%S%fZ') + '.json'))
        _write(destination, rendered)
        sys.stdout.write(rendered)
        return 0
    except Exception:
        # Parse, path, store and output failures must not echo source text or paths.
        sys.stderr.write('digest unavailable\n')
        return 2
