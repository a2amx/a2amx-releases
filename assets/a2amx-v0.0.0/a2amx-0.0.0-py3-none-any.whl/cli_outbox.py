"""Authenticated message staging, confined to the caller's own private outbox.

This is the mail capability's local data write, not a general filesystem tool.
It accepts bounded literal text, never an input path or an output path.
"""
from __future__ import annotations
import hashlib
import os
from pathlib import Path
import stat

import store
from private_file_io import canonical, directory, read_at, publish

MAX_BODY_BYTES = 65536


def prepare(value, *, presented_token, expected_actor=None):
    if not isinstance(value,str) or not value.strip():
        raise ValueError('message_file_text_required')
    data=value.encode('utf-8')
    if len(data)>MAX_BODY_BYTES:raise ValueError('message_file_too_large')
    sha=hashlib.sha256(data).hexdigest()
    def apply(actor):
        row=store._read_participants_unlocked().get(actor,{})
        if row.get('kind')!='agent' or store.inactive_participant(row):
            raise ValueError('message_file_active_agent_required')
        home=canonical(row.get('provisioned_home',''))
        if not home.is_dir():raise ValueError('message_file_home_unavailable')
        root=home/'.orch/outbox';name=sha+'.txt'
        with directory(root,create=True) as fd:
            old=read_at(fd,name)
            if old is not None:
                info=os.stat(name,dir_fd=fd,follow_symlinks=False)
                if info.st_nlink!=1 or stat.S_IMODE(info.st_mode)!=0o600 or old!=data:
                    raise ValueError('message_file_existing_file_invalid')
            else:publish(fd,name,data,None)
        return {'path':str(root/name),'sha256':sha,'bytes':len(data),'seat':actor,
                'created':old is None,'sent':False}
    return store.authenticated_registry_act(presented_token,apply,expected_actor=expected_actor)
