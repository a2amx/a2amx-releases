"""Deterministic verification sensors (META_HARNESS_PLAN Stage-1 spec, landed with Stage 3
per the 2026-07-02 re-scope — its consumer, real sandbox-edits through the adapters, now exists).

After a sandbox-edit, SENSORS run deterministic checks (tests, linters, type checks) on the
agent's worktree and gate promotion. A failure is **"revise, return to author"** — never a
block: the loop keeps running with structured feedback.

Two hard rules from the plan (refinement B, Gemini review):
  1. **Truthful structured feedback.** Never dump raw stderr back into the vendor loop (it
     drives repeat-the-same-fix spirals). Failures come back in a re-plan schema —
     ``[Harness Sensor] <name> failed …; state at <sha>; propose a different strategy`` —
     and every STATE CLAIM in that message is read from the actual worktree (git sha +
     dirty flag), never asserted. A sensor that lies about state is worse than a raw error.
  2. **Dead-end escalation** (§4.3.2, PairCoder): the same failure signature N times in a
     row is a loop, not progress — it trips an escalation (``convergence_signal`` on the
     ledger) instead of feeding the spiral another round.
"""
from __future__ import annotations

import subprocess
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import ledger

#: Feedback carries at most this much sensor output — the TAIL, where the actual error
#: usually is. Enough to act on, not enough to re-dump the world.
SUMMARY_TAIL_CHARS = 400


@dataclass(frozen=True)
class Sensor:
    """One deterministic check, run with the worktree as cwd. No LLM, no network."""
    name: str
    cmd: Tuple[str, ...]
    timeout_sec: int = 300


@dataclass(frozen=True)
class SensorResult:
    sensor: str
    ok: bool
    exit_code: Optional[int]       # None = timeout
    summary: str                   # tail of combined output, trimmed

    def signature(self) -> Tuple[str, Optional[int], str]:
        """Identity of a FAILURE for dead-end detection: sensor + exit code + first line.

        ``lines[0] if lines else ""`` (not ``…[0] if self.summary``): a non-empty ``summary``
        always yields ≥1 splitline today, but keying off the actual list makes the empty case
        local and obvious rather than resting on that CPython string invariant."""
        lines = self.summary.splitlines()
        return (self.sensor, self.exit_code, lines[0] if lines else "")


def worktree_state(worktree: str) -> str:
    """The ACTUAL state of the worktree, read not asserted: short sha + dirty marker."""
    try:
        sha = subprocess.run(["git", "rev-parse", "--short", "HEAD"], cwd=worktree,
                             capture_output=True, text=True, timeout=10)
        if sha.returncode != 0:
            return "unversioned worktree"
        dirty = subprocess.run(["git", "status", "--porcelain"], cwd=worktree,
                               capture_output=True, text=True, timeout=10)
        suffix = " + uncommitted changes" if dirty.stdout.strip() else ""
        return f"{sha.stdout.strip()}{suffix}"
    except Exception:
        return "state unreadable"


def run_sensor(sensor: Sensor, worktree: str) -> SensorResult:
    try:
        proc = subprocess.run(list(sensor.cmd), cwd=worktree, capture_output=True,
                              text=True, timeout=sensor.timeout_sec)
        out = (proc.stdout + proc.stderr).strip()
        return SensorResult(sensor.name, proc.returncode == 0, proc.returncode,
                            out[-SUMMARY_TAIL_CHARS:])
    except subprocess.TimeoutExpired:
        return SensorResult(sensor.name, False, None,
                            f"timed out after {sensor.timeout_sec}s")
    except Exception as e:  # missing binary etc. — a sensor that can't run has NOT passed
        return SensorResult(sensor.name, False, -1, f"sensor could not run: {e!r}")


def run_sensors(worktree: str, sensors: Sequence[Sensor]) -> List[SensorResult]:
    return [run_sensor(s, worktree) for s in sensors]


def feedback(results: Sequence[SensorResult], worktree: str) -> Optional[str]:
    """The re-plan message for the author, or None when everything passed.

    Truthful by construction: the state line is read from the worktree at call time, and
    the message says plainly that nothing was reverted (sensors never mutate the worktree).
    """
    failures = [r for r in results if not r.ok]
    if not failures:
        return None
    state = worktree_state(worktree)
    lines = []
    for f in failures:
        code = "timeout" if f.exit_code is None else f"exit {f.exit_code}"
        lines.append(f"[Harness Sensor] {f.sensor} failed ({code}): {f.summary}")
    lines.append(
        f"Worktree state: {state}. Your edit was NOT reverted. "
        "Propose a DIFFERENT strategy rather than resubmitting the same change.")
    return "\n".join(lines)


class DeadEndTracker:
    """Trips when the same failure signature repeats ``threshold`` times consecutively.

    Success or a DIFFERENT failure resets the streak (a changing error is progress; the
    identical error is a loop). On trip, a ``convergence_signal`` lands on the ledger
    (isolated — the escalation receipt never breaks the loop that triggered it) and the
    caller escalates to a human instead of feeding the spiral another round.
    """

    def __init__(self, threshold: int = 3):
        if threshold < 2:
            raise ValueError("a dead end needs at least 2 identical failures")
        self.threshold = threshold
        self._streaks: Dict[str, Tuple[tuple, int]] = {}

    def record(self, key: str, results: Sequence[SensorResult], *,
               actor_id: str = "System", task_id: Optional[str] = None) -> bool:
        """Feed one sensor round for ``key`` (a session/task id). True = dead end tripped."""
        failures = tuple(sorted(r.signature() for r in results if not r.ok))
        if not failures:
            self._streaks.pop(key, None)
            return False
        prev_sig, count = self._streaks.get(key, (None, 0))
        count = count + 1 if failures == prev_sig else 1
        self._streaks[key] = (failures, count)
        if count < self.threshold:
            return False
        self._streaks.pop(key, None)   # tripped — the escalation resets the streak
        try:
            ledger.emit("convergence_signal", actor_id=actor_id, task_id=task_id, payload={
                "signal": "dead_end",
                "key": key,
                "consecutive_identical_failures": count,
                "failures": [{"sensor": s, "exit_code": c, "first_line": l}
                             for (s, c, l) in failures],
            })
        except Exception:
            pass  # the receipt mirrors the trip; it never decides it
        return True
