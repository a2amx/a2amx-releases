"""Reviewed native-SDK versions used by every runtime and provisioning surface.

The project dependency declarations and provisioning manifest mirror this mapping because
their file formats cannot import Python.  Offline regression tests and the provisioning
loader fail closed if either mirror drifts from this source of truth.
"""

from types import MappingProxyType
from typing import Mapping

CLAUDE_AGENT_SDK_VERSION = "0.2.123"
OPENAI_CODEX_SDK_VERSION = "0.144.4"
GOOGLE_ANTIGRAVITY_SDK_VERSION = "0.1.7"

SDK_VERSIONS: Mapping[str, str] = MappingProxyType({
    "claude-agent-sdk": CLAUDE_AGENT_SDK_VERSION,
    "openai-codex": OPENAI_CODEX_SDK_VERSION,
    "google-antigravity": GOOGLE_ANTIGRAVITY_SDK_VERSION,
})
