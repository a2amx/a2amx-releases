"""Governor policy — the pure effect classifier (META_HARNESS_PLAN Stage 1).

Maps a **proposed effect** — `(actor_role, kind, paths/cwd/args)` — to a permission
**tier** and a **decision**, deterministically and with **no LLM**. This is the trust
anchor of the harness: it decides *what may happen* before an effect lands, so it is kept
small, pure, and fully unit-testable.

Tiers (paper §3.4.3):
  - **read-only**   → allowed for every role.
  - **sandbox-edit** (a write provably inside the agent's own worktree) → the **Writer core**
    (Claude / `coder`) may proceed; **Reviewer cores** (Gemini, Codex / `reviewer`) are denied;
    anyone else is denied (only the writer edits).
  - **full-access** (network, credentials, deploy, destructive FS, git merge/push/history, or
    ANY write outside the worktree) → **deny-all → escalate** to a human (the Z-gate).

Two fail-safe defaults (Gemini review, credited):
  1. **Unknown effect kinds default to full-access** (→ escalate), never allow.
  2. **Path containment is verified with `realpath`** — the target is canonicalised and must sit
     inside the canonicalised worktree root, which closes `../` traversal *and* symlink escapes.

Purity: this module imports nothing from `store`/`ledger`. It returns a `Decision`; the caller
(the action-seam adapter / governor, Stage 3) executes / escalates and emits the
`permission_decision` / `human_approval` ledger events. Authorization for full-access is decided
by the protected token store (the Z-gate, same commit series), never by this classifier alone.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

# --- tiers ---
READ_ONLY = "read-only"
SANDBOX_EDIT = "sandbox-edit"
FULL_ACCESS = "full-access"

# --- verdicts ---
ALLOW = "allow"
DENY = "deny"
ESCALATE = "escalate"

# --- roles (align with ledger role vocabulary) ---
WRITER_ROLES = frozenset({"coder"})               # the Writer Core (Claude)
REVIEWER_ROLES = frozenset({"reviewer"})          # the Reviewer Cores (Gemini, Codex)

# --- effect-kind taxonomy ---
# Read-only: observe, never mutate / never leave the machine.
READ_KINDS = frozenset({"read", "list", "search", "grep", "status", "diff", "stat"})
# Path-scoped mutations: sandbox-edit IF contained in the worktree, else full-access.
WRITE_KINDS = frozenset({"write", "edit", "create", "delete", "move"})
# Always full-access (escalate): leave the machine, touch secrets, mutate shared history,
# deploy, or run an unclassified shell command (which could do any of the above).
FULL_ACCESS_KINDS = frozenset({
    "network", "credential", "deploy", "destructive_fs",
    "git_merge", "git_push", "git_history", "shell",
})


@dataclass(frozen=True)
class ProposedEffect:
    """An effect an agent proposes, as the action seam would present it."""
    kind: str
    actor_role: str
    paths: List[str] = field(default_factory=list)   # targets for path-scoped kinds
    cwd: Optional[str] = None
    args: Dict[str, Any] = field(default_factory=dict)
    worktree_root: Optional[str] = None              # the agent's own sandbox root


@dataclass(frozen=True)
class Decision:
    verdict: str          # ALLOW | DENY | ESCALATE
    tier: str             # READ_ONLY | SANDBOX_EDIT | FULL_ACCESS
    reason: str
    effect: Optional[ProposedEffect] = None

    def allowed(self) -> bool:
        return self.verdict == ALLOW

    def to_payload(self) -> Dict[str, Any]:
        """Shape for a ledger ``permission_decision`` payload (caller emits it)."""
        return {
            "verdict": self.verdict,
            "tier": self.tier,
            "reason": self.reason,
            "kind": self.effect.kind if self.effect else None,
            "actor_role": self.effect.actor_role if self.effect else None,
        }


def _within_worktree(path: str, root: str) -> bool:
    """True iff ``path`` canonically resolves inside ``root`` (symlink/`..`-safe).

    A RELATIVE path is anchored to ``root`` — the agent's worktree — never to whatever
    cwd the governor process happens to have (Bugbot #40 + the first live Claude
    round-trip: process-cwd resolution made containment disagree with where the vendor
    harness actually writes). Absolute paths are judged as-is."""
    try:
        rroot = os.path.realpath(root)
        if not os.path.isabs(path):
            path = os.path.join(rroot, path)
        rp = os.path.realpath(path)
    except Exception:
        return False
    return rp == rroot or rp.startswith(rroot + os.sep)


def classify(effect: ProposedEffect) -> str:
    """Return the permission tier for an effect. Fail-safe: unknown → full-access."""
    kind = effect.kind
    if kind in FULL_ACCESS_KINDS:
        return FULL_ACCESS
    if kind in READ_KINDS:
        return READ_ONLY
    if kind in WRITE_KINDS:
        # A write is sandbox-edit ONLY if it is fully contained in the agent's own worktree:
        # every target path resolves inside it, AND (context-sensitive rule) the working
        # directory, if given, is inside it too. Otherwise — no worktree, no paths, a path
        # escape, or a cwd escape — it is full-access. Default-deny: an empty path list is
        # not "contained". realpath in _within_worktree closes `..` and symlink escapes.
        root = effect.worktree_root
        paths_ok = bool(root and effect.paths and all(_within_worktree(p, root) for p in effect.paths))
        cwd_ok = effect.cwd is None or (root is not None and _within_worktree(effect.cwd, root))
        if paths_ok and cwd_ok:
            return SANDBOX_EDIT
        return FULL_ACCESS
    return FULL_ACCESS   # unknown kind → fail safe


def evaluate(effect: ProposedEffect) -> Decision:
    """Classify the effect and return the governor's decision for it."""
    tier = classify(effect)
    if tier == READ_ONLY:
        return Decision(ALLOW, tier, "read-only effect — allowed for all roles", effect)
    if tier == SANDBOX_EDIT:
        if effect.actor_role in WRITER_ROLES:
            return Decision(ALLOW, tier, "writer core: sandbox-edit within its own worktree", effect)
        if effect.actor_role in REVIEWER_ROLES:
            return Decision(DENY, tier,
                            f"reviewer core ({effect.actor_role}) is read-only — cannot edit", effect)
        return Decision(DENY, tier,
                        f"role {effect.actor_role!r} may not sandbox-edit (only the writer core)", effect)
    # FULL_ACCESS
    return Decision(ESCALATE, tier,
                    "full-access effect requires human authorization (Z-gate)", effect)
