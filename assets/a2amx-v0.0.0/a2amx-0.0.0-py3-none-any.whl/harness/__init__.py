"""orch meta-harness package — the PEV governor above the vendor SDKs.

See docs/META_HARNESS_PLAN.md. Stage 1 lands the governor:
  - policy.py  — the pure, no-LLM effect → tier → decision classifier (this commit).
Later stages add sensors.py, adapter.py (+ per-vendor adapters), and referee.py.
"""
