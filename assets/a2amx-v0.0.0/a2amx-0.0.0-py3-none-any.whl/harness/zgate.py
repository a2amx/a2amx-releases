"""Legacy fingerprint-token consumption for action-seam escalation.

Rule A retires minting and git-hook installation after GC-7 removed the web mint
seam. These compatibility calls cannot create a new approval. The current merge
control is principal Z, CoS gate on reviewer exact-head FIT, guarded merge and
sealed receipt; see docs/PROVISION_MACHINE_01.md.
"""
from __future__ import annotations

import hashlib
import sys
from typing import Any, Dict, Optional

import ledger
import store
from harness import policy


def _token_preview(token: str) -> str:
    """A non-reversible tag for the ledger receipt — correlates mint↔resolve without
    ever putting the bearer secret in the append-only stream."""
    return "sha256:" + hashlib.sha256(token.encode()).hexdigest()[:16]


def mint(repo: str, base_sha: str, head_sha: str, *, auth_source: str,
         actor_id: Optional[str] = None, ttl_sec: int = store.APPROVAL_TTL_SEC) -> Dict[str, Any]:
    """Retired compatibility call; the store refuses without any mint or receipt."""
    store.mint_approval_token(repo, base_sha, head_sha, auth_source=auth_source, ttl_sec=ttl_sec)
    raise AssertionError("retired mint unexpectedly returned")


def authorize_merge(repo: str, base_sha: str, head_sha: str, presented_token: Optional[str], *,
                    actor_id: str, consume: bool = True,
                    emit_receipt: bool = True, consumer: str = "hook") -> policy.Decision:
    """The gate at merge time. A valid single-use token for THIS exact merge → ALLOW;
    otherwise the merge stays blocked → ESCALATE (no token, wrong fingerprint, stale base,
    expired, or already used). Emits a ``permission_decision`` receipt either way.

    ``consume=False`` VERIFIES without burning (store.peek_approval_token) — used by the
    action seam when a pre-merge hook is installed in the target repo, so ONE authorization
    burns exactly once, at the last checkpoint git actually runs (Bugbot #40 High:
    seam-consume + hook-consume double-burned the token and git blocked an authorized
    merge). With no hook installed the seam consumes here as before."""
    fp = store.approval_fingerprint(repo, base_sha, head_sha)
    rec = None
    ok = False
    if presented_token:
        if consume:
            rec = store.resolve_approval_token(presented_token, repo, base_sha, head_sha,
                                               via=consumer)
            ok = rec is not None
        else:
            ok = store.peek_approval_token(presented_token, repo, base_sha, head_sha)
    if ok:
        how = ("consumed" if consume else
               "verified — consumption deferred to the pre-merge hook")
        decision = policy.Decision(
            policy.ALLOW, policy.FULL_ACCESS,
            f"z-gate: single-use approval token {how} for this merge fingerprint", None)
    else:
        decision = policy.Decision(
            policy.ESCALATE, policy.FULL_ACCESS,
            "z-gate: no valid approval token for this merge fingerprint", None)
    # The receipt is an audit MIRROR, not the authorization — consuming the token above is the
    # authoritative act. So writing it is isolated and NEVER changes the outcome (Bugbot #40):
    # an already-consumed ALLOW must not flip to escalate (nor raise) just because the ledger
    # append failed, or the caller would re-escalate a merge that WAS authorized while the
    # burned single-use token strands it. A lost receipt is an audit GAP surfaced loudly — and
    # the human_approval receipt written at mint time still records who authorized this merge.
    if not emit_receipt:
        # the caller (the action seam) writes ONE receipt for the whole decision —
        # per-candidate gate receipts produced conflicting duplicate ledger lines (Bugbot).
        return decision
    try:
        ledger.emit("permission_decision", actor_id=actor_id, payload={
            "verdict": decision.verdict, "tier": decision.tier, "reason": decision.reason,
            "kind": "git_merge", "gate": "z-merge", "fingerprint": fp,
            "token_id": rec.get("id") if rec else None,
        })
    except Exception as e:  # noqa: BLE001 — an audit receipt must never break authorization
        sys.stderr.write(
            f"[zgate] AUDIT GAP: permission_decision receipt failed to write "
            f"(verdict={decision.verdict}, consumed_token={rec.get('id') if rec else None}, "
            f"fingerprint={fp}): {e!r}\n")
    return decision
