"""Convergence oracles — review state machine + verdict protocol (META_HARNESS_PLAN Stage 2).

Kills "implicit convergence" (§4.3.2): a review reaches ``converged`` only when an objective
oracle fires; otherwise it stays ``contested`` and escalates to a human — never silently
closes. ``converged`` is a precondition surfaced to the human; the human Z is the final
``converged → cleared``.

**One state owner — the existing task board.** Reviews are tasks (``kind="review"``) whose
transitions ride ``store.task_event`` / ``task_board`` (the same append-and-replay log as
every other task). The ledger ``convergence_signal`` events are the audit MIRROR, never the
state owner — there is no second board (duplicated logic drifts; this PR's #1 failure mode).

**Pinned snapshot.** A review binds to a ``(repo, base_sha, head_sha)`` fingerprint (reused
from the Z-gate: ``store.approval_fingerprint``). Reviewers vote against that immutable
version; a verdict whose fingerprint doesn't match is STALE — recorded for audit but dropped
from counting (it was cast against a different codebase). Verdicts are structured, never free
text: ``verdict ∈ {approve, block}`` plus ``tests_authored``.

Commit 1: the protocol, the state, fingerprint pinning, the ledger mirror. Commit 2: consensus
aggregation (dissent-preserving, contested→escalate) + the human ``clear``. Commit 3: the
``orch reviews`` operator surface. Commit 4 (this): the TEST-GATED oracle — ``run_test_gate``
runs ``harness/sensors`` on the pinned snapshot and casts an independent machine verdict, and
consensus now EXCLUDES self-authored-test approvals (the FlowGen self-test trap, §4.3.2).
"""
from __future__ import annotations

import subprocess
from typing import Any, Dict, List, Optional, Sequence

from mirror_diagnostics import record_failure
import ledger
import store
from harness import sensors as _sensors

#: task ``kind`` for review tasks (rides the existing task board)
REVIEW_KIND = "review"
#: closed verdict vocabulary — structured, never free text
VERDICTS = frozenset({"approve", "block"})

#: machine reviewer identity for the objective test-gated oracle (authored no code, so its
#: verdict is independent by construction — it never trips the self-test exclusion)
TEST_ORACLE_REVIEWER = "TestGate"

#: MH-023 / P156-P1 — HUMAN VERDICTS AND MACHINE RESULTS ARE DIFFERENT TYPES ON DIFFERENT PATHS.
#: An earlier cut exempted the machine's NAME from membership, which left an unlisted-voter path
#: open by construction: any caller could pass ``reviewer="TestGate"`` to the public
#: ``submit_verdict``. A per-round metadata flag was no better — it still let an authorized round
#: accept a caller-supplied string. ``TEST_ORACLE_REVIEWER`` is now RESERVED: refused in
#: ``submit_verdict`` and in ``open_review``'s reviewer list, ALWAYS, before any persistence.
#: The machine result rides THIS event, written only by ``run_test_gate`` under a fixed identity
#: with no caller-selected override, so there is nothing for a supplied string to reach.
EV_MACHINE = "machine_gate_result"

#: review lifecycle task events (store.task_event names)
EV_OPENED = "review_opened"
EV_VERDICT = "verdict"
EV_CONVERGED = "converged"      # emitted by the commit-2 oracle
EV_CONTESTED = "contested"      # emitted by the commit-2 oracle
EV_CLEARED = "cleared"          # the human Z (commit 2/3)
EV_REOPENED = "reopened"        # oracle reverts a settled review to open when signal drops

#: terminal review states (a review is settled once one is reached)
_TERMINAL = {EV_CONVERGED: "converged", EV_CONTESTED: "contested", EV_CLEARED: "cleared"}
#: all state-setting events -> the state they set (terminal + the reopen-to-open transition)
_STATE_EVENT = {**_TERMINAL, EV_REOPENED: "open"}


def _fingerprint(repo: str, base_sha: str, head_sha: str) -> Dict[str, str]:
    """Normalized pinned-snapshot identity — the SAME shape the Z-gate uses, so a review
    and a later merge speak one fingerprint vocabulary."""
    return store.approval_fingerprint(repo, base_sha, head_sha)


def _worktree_at_head(worktree: str, head_sha: str) -> bool:
    """True iff ``worktree``'s current commit IS the review's pinned ``head_sha`` — resolved
    through the worktree's own git so short/long shas and refs compare equal. The test-gated
    oracle MUST run against the pinned snapshot: a worktree on a different commit would produce
    a verdict that matches the fingerprint yet reflects the wrong tree (Bugbot PR #40)."""
    try:
        cur = subprocess.run(["git", "rev-parse", "HEAD"], cwd=worktree,
                             capture_output=True, text=True, timeout=10)
        want = subprocess.run(["git", "rev-parse", "--verify", f"{head_sha}^{{commit}}"],
                              cwd=worktree, capture_output=True, text=True, timeout=10)
        if cur.returncode != 0 or want.returncode != 0:
            return False
        return cur.stdout.strip() == want.stdout.strip()
    except Exception:
        return False


def _mirror(actor_id: str, signal: str, task_id: str, payload: Dict[str, Any]) -> None:
    """Mirror a review transition to the ledger as a convergence_signal (audit only —
    isolated so a ledger failure never breaks the task-board state that owns the review)."""
    try:
        ledger.emit("convergence_signal", actor_id=actor_id, task_id=task_id,
                    payload={"signal": signal, **payload})
    except Exception as exc:
        record_failure('convergence', exc)


def open_review(repo: str, base_sha: str, head_sha: str, *, reviewers: List[str],
                opener: str, title: str = "", task_id: Optional[str] = None) -> str:
    """Start a review round pinned to a snapshot. Reviewers check out ``head_sha`` in their
    own worktree (the task carries repo+shas — no live-synced diff). Returns the task_id."""
    if TEST_ORACLE_REVIEWER in reviewers:
        raise ValueError(
            f"{TEST_ORACLE_REVIEWER!r} is RESERVED and cannot be a required lens — the machine "
            "gate is not a lens and can never supply required-set coverage (P156-P2)")
    fp = _fingerprint(repo, base_sha, head_sha)
    rec = store.task_event(EV_OPENED, task_id=task_id, actor=opener, kind=REVIEW_KIND,
                           title=title, reviewers=list(reviewers), fingerprint=fp)
    _mirror(opener, "review_opened", rec["task_id"],
            {"fingerprint": fp, "reviewers": list(reviewers), "title": title})
    return rec["task_id"]


def submit_verdict(task_id: str, reviewer: str, verdict: str,
                   repo: str, base_sha: str, head_sha: str, *,
                   tests_authored: bool = False) -> Dict[str, Any]:
    """Record one structured verdict against a review. A verdict whose fingerprint doesn't
    match the review's pinned snapshot is marked ``stale`` (recorded for audit, dropped from
    counting by the commit-2 oracle). Raises on an unknown verdict or unknown review, or on a
    verdict against a ``cleared`` review — the human Z is final, so a later vote could never
    change anything and must not accrete as if it might (Bugbot PR #40). A vote on a
    ``converged``/``contested`` review IS accepted: those are re-evaluable, so a late block can
    still reopen the oracle (see ``evaluate_consensus``)."""
    if verdict not in VERDICTS:
        raise ValueError(f"verdict must be one of {sorted(VERDICTS)}, got {verdict!r}")
    if reviewer == TEST_ORACLE_REVIEWER:
        raise ValueError(
            f"{TEST_ORACLE_REVIEWER!r} is RESERVED for the machine gate and can NEVER be cast "
            "through submit_verdict — machine results ride their own typed event (P156-P1)")
    review = review_status(task_id)
    if review is None:
        raise ValueError(f"no review task {task_id!r}")
    if review["state"] == "cleared":
        raise ValueError(f"review {task_id!r} is cleared (the human Z is final) — "
                         "no further verdicts")
    if reviewer not in review["reviewers"]:
        raise ValueError(
            f"reviewer {reviewer!r} is not a required reviewer of {task_id!r} "
            f"(required: {review['reviewers']}) — an unlisted label is refused and NOT recorded")
    fp = _fingerprint(repo, base_sha, head_sha)
    stale = review["fingerprint"] != fp
    store.task_event(EV_VERDICT, task_id=task_id, actor=reviewer, kind=REVIEW_KIND,
                     verdict=verdict, fingerprint=fp, tests_authored=bool(tests_authored),
                     stale=stale)
    _mirror(reviewer, "verdict", task_id,
            {"verdict": verdict, "fingerprint": fp,
             "tests_authored": bool(tests_authored), "stale": stale})
    return {"recorded": True, "stale": stale}


def _task_events():
    """Stream complete task records through every batch, retaining the offset."""
    offset = 0
    while True:
        events, next_offset = store.read_jsonl(store.TASKS_FILE, offset)
        yield from events
        if next_offset == offset:
            return
        offset = next_offset


def review_status(task_id: str) -> Optional[Dict[str, Any]]:
    """Replay the task log for one review → its current state. None if not a review task.

    Returns ``{task_id, fingerprint, reviewers, opener, state, verdicts}`` where each verdict
    is ``{reviewer, verdict, tests_authored, stale, fingerprint}`` and ``state`` is
    ``open`` until a terminal event (``converged``/``contested``/``cleared``) lands. The
    consensus DECISION that emits those terminal events is commit 2; this is the read side.
    """
    opened = None
    verdicts: List[Dict[str, Any]] = []
    machine: Optional[Dict[str, Any]] = None
    state = "open"
    for e in _task_events():
        if e.get("task_id") != task_id:
            continue
        ev = e.get("event")
        if ev == EV_OPENED:
            opened = e
        elif ev == EV_VERDICT:
            verdicts.append({
                "reviewer": e.get("actor", ""),
                "verdict": e.get("verdict"),
                "tests_authored": bool(e.get("tests_authored", False)),
                "stale": bool(e.get("stale", False)),
                "fingerprint": e.get("fingerprint"),
            })
        elif ev == EV_MACHINE:
            machine = {                # LATEST machine result wins (pass->block, block->pass)
                "verdict": e.get("verdict"),
                "passed": bool(e.get("passed", False)),
                "stale": bool(e.get("stale", False)),
                "fingerprint": e.get("fingerprint"),
            }
        elif ev in _STATE_EVENT:
            state = _STATE_EVENT[ev]   # terminal event, or a reopen back to "open"
    if opened is None:
        return None
    return {
        "task_id": task_id,
        "fingerprint": opened.get("fingerprint"),
        "reviewers": list(opened.get("reviewers", [])),
        "opener": opened.get("actor", ""),
        "state": state,
        "verdicts": verdicts,
        "machine": machine,            # None when no gate has run; the LATEST result otherwise
    }


def list_reviews() -> List[Dict[str, Any]]:
    """All reviews (each a full review_status), oldest-opened first — the operator view's
    data layer. A task is a review iff it has a review_opened event.

    Known cost: listing R reviews performs R+1 full task-log scans, O(R * N)
    for N records. This correctness repair retains the existing per-review
    fold; one-pass accumulation is a separate measured optimization.
    """
    ids: List[str] = []
    seen = set()
    for e in _task_events():
        tid = e.get("task_id")
        if e.get("event") == EV_OPENED and tid and tid not in seen:
            seen.add(tid)
            ids.append(tid)
    return [r for r in (review_status(tid) for tid in ids) if r is not None]


def _live_votes(review: Dict[str, Any]) -> List[Dict[str, Any]]:
    """One live, INDEPENDENT verdict per DISTINCT reviewer — the latest wins (a reviewer may
    revise). Two exclusions:
      - STALE verdicts (cast against a different snapshot) never count;
      - a self-authored-test APPROVAL (``verdict=approve`` + ``tests_authored``) is excluded —
        the FlowGen self-test trap (roadmap Stage 2 line 72): a reviewer can't vouch for code
        by pointing at tests it wrote itself. A ``block`` ALWAYS counts, even self-authored —
        dissent is never hidden, only self-validation is.
    Latest-wins is resolved FIRST, then the provenance exclusion — so a reviewer whose current
    stance is a self-authored approval gets no counted vote (not their earlier independent one)."""
    latest: Dict[str, Dict[str, Any]] = {}
    for v in review["verdicts"]:
        if not v.get("stale") and v.get("reviewer"):
            latest[v["reviewer"]] = v          # later verdict overwrites earlier
    return [v for v in latest.values()
            if not (v.get("verdict") == "approve" and v.get("tests_authored"))]


def live_tally(review: Dict[str, Any]) -> Dict[str, int]:
    """The vote counts the oracle would actually use — one latest independent verdict per
    reviewer, self-authored approvals excluded — so an operator view matches
    ``evaluate_consensus`` instead of counting raw verdict rows (Bugbot PR #40: the CLI must
    not show quorum the oracle would reject, or inflate counts when reviewers revise)."""
    # SIBLING OF BB156-2, found while writing that arm: this is the OPERATOR view and its whole
    # purpose is to agree with the oracle. Feeding it unfiltered votes would show a quorum the
    # oracle rejects — the exact disagreement this function exists to prevent. Same authority at
    # both ends: only labels on the opened required list count.
    required = set(review.get("reviewers") or [])
    votes = [v for v in _live_votes(review) if v["reviewer"] in required]
    return {"approve": sum(v["verdict"] == "approve" for v in votes),
            "block": sum(v["verdict"] == "block" for v in votes)}


def _settle(task_id: str, event: str, review: Dict[str, Any], reason: str,
            tally: Dict[str, Any]) -> Dict[str, Any]:
    """Write the terminal review event (task board owns it) + mirror to the ledger. The
    oracle acts as the system_governor."""
    store.task_event(event, task_id=task_id, actor="System", kind=REVIEW_KIND,
                     reason=reason, fingerprint=review["fingerprint"], tally=tally)
    _mirror("System", _STATE_EVENT[event], task_id,
            {"reason": reason, "fingerprint": review["fingerprint"], "tally": tally})
    return review_status(task_id)


def run_test_gate(task_id: str, worktree: str,
                  sensors: Sequence["_sensors.Sensor"]) -> Dict[str, Any]:
    """The TEST-GATED oracle — above consensus in objectivity (roadmap Stage 2 line 69:
    *test-gated (correctness) > consensus*). Runs the deterministic sensor suite on the
    review's PINNED snapshot (the harness checks ``head_sha`` out into ``worktree``) and casts
    a MACHINE verdict from the real result: ``approve`` iff every sensor passes, else
    ``block``. Correctness is fact; consensus is opinion.

    The machine authored no code, so its verdict is independent by construction
    (``tests_authored=False`` → never excluded by the self-test guard) and, pinned to the
    review's own fingerprint, never stale. A failing suite blocks → the consensus oracle turns
    it ``contested`` → escalates, carrying TRUTHFUL sensor feedback (``sensors.feedback`` — a
    re-plan message read from the actual worktree, never a raw stderr dump). Returns
    ``{verdict, passed, results, feedback}``; ``feedback`` is the author's re-plan message on
    failure (``None`` when all passed)."""
    review = review_status(task_id)
    if review is None:
        raise ValueError(f"no review task {task_id!r}")
    # SPLITTING THE PATHS DROPPED A GUARD THAT LIVED ON THE HUMAN ONE. submit_verdict refuses a
    # verdict against a CLEARED review because the human Z is final and a later vote could never
    # change anything; routing the machine off that function silently exempted it, so a gate run
    # could accrete onto a finalized review. The rule belongs to the REVIEW, not to one path.
    if review["state"] == "cleared":
        raise ValueError(
            f"review {task_id!r} is cleared (the human Z is final) — the test gate must not "
            "record a result against it")
    fp = review["fingerprint"] or {}
    head = fp.get("head_sha")
    if not _worktree_at_head(worktree, head):
        raise ValueError(
            f"worktree {worktree!r} is not checked out at the review's pinned head_sha "
            f"{head!r} — check out the pinned snapshot before running the test gate "
            "(otherwise the verdict would reflect the wrong tree)")
    results = _sensors.run_sensors(worktree, list(sensors))
    passed = all(r.ok for r in results)
    verdict = "approve" if passed else "block"
    # THE TASK BOARD IS THE CONTROL-STATE OWNER. The machine result is written as a TYPED board
    # event under a FIXED identity — never through submit_verdict, which is the human path and
    # refuses this name outright. The ledger mirror below is AUDIT ONLY: if it fails, the board
    # event still stands, still replays, and still controls the oracle.
    store.task_event(EV_MACHINE, task_id=task_id, actor=TEST_ORACLE_REVIEWER, kind=REVIEW_KIND,
                     verdict=verdict, passed=bool(passed), fingerprint=fp,
                     stale=(review["fingerprint"] != fp))
    fb = _sensors.feedback(results, worktree)      # None iff everything passed
    _mirror(TEST_ORACLE_REVIEWER, "test_gate", task_id, {
        "passed": passed, "verdict": verdict,
        "sensors": [{"sensor": r.sensor, "ok": r.ok, "exit_code": r.exit_code}
                    for r in results],
        "feedback": fb,
    })
    return {"verdict": verdict, "passed": passed, "results": results, "feedback": fb}


def evaluate_consensus(task_id: str, *, min_votes: int = 2) -> Dict[str, Any]:
    """The CONSENSUS oracle — orch's signature (it already runs distinct vendors).

    Considers only LIVE verdicts, one per distinct reviewer. The decision preserves dissent
    rather than outvoting it (roadmap II.3 — never hide dissent behind a silent majority):
      - ANY ``block`` → ``contested`` → escalate to the human (a lone blocker is surfaced,
        not outvoted);
      - ≥ ``min_votes`` distinct reviewers and ALL of them ``approve`` → ``converged``
        (a precondition surfaced to the human — NOT auto-merge; the human Z is the final
        ``converged → cleared``);
      - otherwise → still ``open`` (not enough signal yet).
    RE-EVALUABLE, not one-shot: ``converged`` and ``contested`` are oracle-produced
    preconditions, not final — a LATE block flips ``converged → contested`` and a withdrawn
    block flips ``contested → converged`` (Bugbot PR #40: a settled review must not swallow
    dissent). Only ``cleared`` — the human Z — is final and returned untouched. Emits a terminal
    event ONLY on a state change, so re-running with the same votes is a genuine no-op (no
    duplicate ledger records). Consensus is agreement only — test provenance
    (``tests_authored``) is the TEST-GATED oracle's concern, not this one."""
    review = review_status(task_id)
    if review is None:
        raise ValueError(f"no review task {task_id!r}")
    if review["state"] == "cleared":
        return review                          # the human Z is final — never re-evaluated
    # BB156-2: ENFORCING MEMBERSHIP ON THE WRITE PATH DOES NOT CLEAN THE READ PATH. Replay can
    # still surface EV_VERDICT rows for labels that are not on the opened list — legacy rows
    # written before this fix, pre-split TestGate rows, or a tampered log — and those were being
    # fed straight into the quorum count and the all-approve test. A one-lens round could reach
    # converged on them. The required set is the authority at BOTH ends: nothing off the list
    # counts, whatever the log happens to contain.
    required = set(review["reviewers"])
    votes = [v for v in _live_votes(review) if v["reviewer"] in required]
    approvals = [v for v in votes if v["verdict"] == "approve"]
    blocks = [v for v in votes if v["verdict"] == "block"]

    # P156-P2: COVERAGE OF THE OPENED REQUIRED SET, not merely a vote count. min_votes alone let
    # a round of [A, B, C] converge on A and B — a SUBSET reading as the whole, while the record
    # still listed all three as required.
    missing = sorted(required - {v["reviewer"] for v in votes})

    # The machine gate is a SEPARATE TYPE on a separate path. A machine APPROVAL never supplies
    # human coverage and never manufactures a vote — it is not in `votes` and cannot be. A
    # machine BLOCK contests even when human coverage is incomplete, because a failing
    # correctness gate is a fact and does not wait for opinions.
    mach = review.get("machine")
    mach_live = mach if (mach and not mach.get("stale")) else None
    mach_blocks = bool(mach_live and mach_live.get("verdict") == "block")

    tally = {"approve": len(approvals), "block": len(blocks),
             "voters": sorted(v["reviewer"] for v in votes),
             "required": sorted(required), "missing_required": missing,
             "machine": (mach_live or {}).get("verdict")}
    if blocks or mach_blocks:
        target, reason = EV_CONTESTED, (
            "surfaced dissent: a required lens blocked — escalated to human" if blocks
            else "the test gate FAILED — a correctness block does not wait for human coverage")
    elif not missing and len(votes) >= min_votes and len(approvals) == len(votes):
        target, reason = EV_CONVERGED, \
            "every required lens approves (surfaced for human Z)"
    elif review["state"] in ("converged", "contested"):
        # was settled, but the signal has since dropped below quorum (a lone blocker withdrew,
        # or a vote became a self-authored-test approval that _live_votes excludes) — REVERT to
        # open so the state never disagrees with live_tally (Bugbot PR #40). Not a no-op here:
        # leaving a stale terminal state lets a human clear on a precondition that no longer holds.
        target, reason = EV_REOPENED, "consensus dropped below quorum — reverted to open"
    else:
        return review                          # already open, still insufficient — genuine no-op
    if _STATE_EVENT[target] == review["state"]:
        return review                          # already in the target state — no duplicate event
    return _settle(task_id, target, review, reason, tally)


def clear(task_id: str, *, cleared_by: str, override_reason: Optional[str] = None) -> Dict[str, Any]:
    """The human Z: the final ``converged → cleared``. A ``contested`` review can be cleared
    too, but only as a LOUD override (``override_reason`` required — a human forcing past
    surfaced dissent must say why; recorded on the ledger). An ``open`` review can't be
    cleared (run the oracle first). Idempotent once cleared."""
    review = review_status(task_id)
    if review is None:
        raise ValueError(f"no review task {task_id!r}")
    if review["state"] == "cleared":
        return review
    if review["state"] == "open":
        raise ValueError("review is not settled — run evaluate_consensus first")
    if review["state"] == "contested" and not override_reason:
        raise ValueError("clearing a contested review requires an override_reason "
                         "(a human forcing past surfaced dissent must say why)")
    store.task_event(EV_CLEARED, task_id=task_id, actor=cleared_by, kind=REVIEW_KIND,
                     prior_state=review["state"], override_reason=override_reason,
                     fingerprint=review["fingerprint"])
    _mirror(cleared_by, "cleared", task_id,
            {"prior_state": review["state"], "override_reason": override_reason,
             "fingerprint": review["fingerprint"]})
    return review_status(task_id)
