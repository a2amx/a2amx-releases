"""Signed, receipted quarantine dispositions; original messages never change.

An immutable decision is the admission receipt. Completion is a separate
durable marker. Recovery completes that already-admitted decision, never
creates authority from a seat token or changes its recipients or message.
"""
from __future__ import annotations

import base64
import copy
import errno
import hashlib
import json
import os
import re
import stat
import tempfile
import time
import uuid
from functools import lru_cache
from pathlib import Path

import authority
import receipts
import store


class Refused(ValueError):
    pass


ITEM_FAILURES = frozenset({
    "quarantine_storage_invalid", "quarantine_item_symlink", "quarantine_record_conflict",
    "quarantine_store_mismatch", "quarantine_completion_conflict", "quarantine_recipient_changed",
    "quarantine_incomplete_record_conflict", "quarantine_message_missing_or_ambiguous",
    "message_not_quarantined", "quarantine_inbox_incomplete", "quarantine_inbox_invalid",
    "quarantine_inbox_conflict", "quarantine_record_missing",
})


class ItemRefused(Refused):
    """One disposition cannot proceed; independent items may still be handled.

    Shared journal/namespace integrity and other I/O failures are deliberately
    not this type and must still fail the enclosing operation.
    """
    def __init__(self, reason):
        if reason not in ITEM_FAILURES:
            raise Refused("quarantine_failure_unclassified")
        super().__init__(reason)


def fingerprint(value):
    # Store messages may contain integers larger than the JCS safe range.
    # Preserve them exactly; the small signed request itself uses RFC 8785.
    data = json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=True, allow_nan=False).encode("ascii")
    return hashlib.sha256(data).hexdigest()


def store_ref():
    return hashlib.sha256(str(store.require_bound_store().resolve()).encode()).hexdigest()


def _root():
    root = store.STORE_DIR / "quarantine-dispositions"
    if root.is_symlink() or (root.exists() and not root.is_dir()):
        raise Refused("quarantine_storage_invalid")
    return root


def _path(mid, *, complete=False):
    name = hashlib.sha256(mid.encode()).hexdigest()
    return _root() / (name + (".complete.json" if complete else ".json"))


def _issue_path(mid, reason):
    return _path(mid).with_suffix(".issue-" + hashlib.sha256(reason.encode()).hexdigest() + ".json")


def _read(path):
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except FileNotFoundError:
        return None
    with os.fdopen(fd, "rb") as stream:
        if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
            raise Refused("quarantine_storage_invalid")
        raw = stream.read(65537)
    if len(raw) > 65536:
        raise Refused("quarantine_storage_invalid")
    try:
        def unique(pairs):
            value = {}
            for key, item in pairs:
                if key in value:
                    raise ValueError()
                value[key] = item
            return value
        value = json.loads(raw, object_pairs_hook=unique)
        if type(value) is not dict:
            raise ValueError()
        return value
    except (ValueError, UnicodeError, RecursionError):
        raise Refused("quarantine_storage_invalid") from None


def _read_item(path):
    # Resolve _root/_path before this boundary: namespace failures stay global.
    try:
        return _read(path)
    except Refused as exc:
        raise ItemRefused(str(exc)) from None
    except OSError as exc:
        if exc.errno == errno.ELOOP:
            raise ItemRefused("quarantine_item_symlink") from None
        raise


def _write_once(path, value):
    previous = _read_item(path)
    if previous is not None:
        if previous != value:
            raise ItemRefused("quarantine_record_conflict")
        store._fsync_dir(path.parent)
        return
    store._private_directory(path.parent)
    store._fsync_dir(path.parent.parent)
    fd, name = tempfile.mkstemp(prefix=".quarantine-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, allow_nan=False)
            stream.write("\n"); stream.flush(); os.fsync(stream.fileno())
        os.replace(name, path)
        store._fsync_dir(path.parent)
    finally:
        Path(name).unlink(missing_ok=True)


def _validate_row(row):
    text_fields = ("msg-id", "message_sha256", "actor", "key_id", "ts", "event-id", "authorization_sha256")
    if (type(row) is not dict or row.get("kind") != "quarantine-disposition"
            or type(row.get("v")) is not int or row["v"] != 1
            or not isinstance(row.get("action"), str) or row["action"] not in {"release", "discard"}
            or any(not isinstance(row.get(k), str) or not row[k] for k in text_fields)
            or any(type(row.get(k)) is not list or any(not isinstance(p, str) or not p for p in row[k])
                   for k in ("recipients", "recorded_recipients"))
            or len(set(row["recipients"])) != len(row["recipients"])
            or not set(row["recipients"]) <= set(row["recorded_recipients"])
            or (row["action"] == "discard" and row["recipients"])
            or type(row.get("authorization")) is not dict
            or set(row["authorization"]) != {"payload", "signature"}
            or not isinstance(row["authorization"]["signature"], str)
            or not row["authorization"]["signature"]
            or type(row["authorization"].get("payload")) is not dict):
        raise ItemRefused("quarantine_record_conflict")
    try:
        digest = fingerprint(row["authorization"])
    except (ValueError, TypeError, RecursionError):
        raise ItemRefused("quarantine_record_conflict") from None
    if row["authorization_sha256"] != digest or row["event-id"] != "qdisp-" + digest:
        raise ItemRefused("quarantine_record_conflict")
    payload = row["authorization"]["payload"]
    if any(payload.get(a) != row.get(b) for a, b in
           (("actor", "actor"), ("key_id", "key_id"), ("action", "action"),
            ("message_id", "msg-id"), ("message_sha256", "message_sha256"))):
        raise ItemRefused("quarantine_record_conflict")
    if payload.get("store_ref") != store_ref():
        raise ItemRefused("quarantine_store_mismatch")
    return row


def _decision(message):
    row = _read_item(_path(message["id"]))
    if row is None:
        return None
    _validate_row(row)
    try:
        digest = fingerprint(message)
    except (ValueError, TypeError, RecursionError):
        raise ItemRefused("quarantine_record_conflict") from None
    if (row["msg-id"] != message["id"] or row["message_sha256"] != digest
            or row["recorded_recipients"] != message.get("recipients")):
        raise ItemRefused("quarantine_record_conflict")
    return row


def released(message):
    if (message.get("vet") or {}).get("verdict") != "QUARANTINED":
        return False
    return _status(message)["state"] in {"releasing", "released"}


def status(message):
    """Read-only status; a bad item is visible without hiding healthy rows."""
    try:
        return _status(message)
    except ItemRefused as exc:
        return {"state": "incomplete", "blocked": True, "reason": str(exc)}


def _check_recipients(row):
    participants = store.load_participants()
    if any(pid not in participants or store.inactive_participant(participants[pid])
           or not store.has_mailbox(participants[pid]) for pid in row["recipients"]):
        raise ItemRefused("quarantine_recipient_changed")


def _status(message):
    row = _decision(message)
    if row is None:
        return {"state": "quarantined", "blocked": True}
    complete = _read_item(_path(message["id"], complete=True))
    expected = {"event-id": row["event-id"], "decision_sha256": fingerprint(row)}
    if complete is not None and complete != expected:
        raise ItemRefused("quarantine_completion_conflict")
    if complete is None and row["action"] == "release":
        _check_recipients(row)
    if complete is None:
        issues = []
        # The closed reason set bounds read work per item, independent of the
        # size of the retained disposition history. No directory-wide scan.
        for reason in sorted(ITEM_FAILURES):
            issue = _read_item(_issue_path(message["id"], reason))
            if issue is None:
                continue
            if (issue.get("kind") != "quarantine-incomplete"
                    or issue.get("event-id") != row["event-id"]
                    or issue.get("decision_sha256") != fingerprint(row)
                    or issue.get("reason") != reason
                    or not isinstance(issue.get("observed_at"), str)):
                raise ItemRefused("quarantine_incomplete_record_conflict")
            issues.append(issue)
        if issues:
            raise ItemRefused(max(issues, key=lambda r: r["observed_at"])["reason"])
    return {"state": ("released" if row["action"] == "release" else "discarded")
            if complete else ("releasing" if row["action"] == "release" else "discarding"),
            "blocked": row["action"] != "release", "actor": row["actor"], "key_id": row["key_id"],
            "event-id": row["event-id"], "ts": row["ts"], "recipients": list(row["recipients"])}


def _message(mid):
    # Authorization fingerprints bind canonical bytes, never a recall read view.
    found = [row for row in store._read_from_to_eof(0) if row.get("id") == mid]
    if len(found) != 1:
        raise ItemRefused("quarantine_message_missing_or_ambiguous")
    message = found[0]
    if not isinstance(message.get("vet"), dict) or message["vet"].get("verdict") != "QUARANTINED":
        raise ItemRefused("message_not_quarantined")
    return message


def _inbox_contains(stream, message):
    found = False
    for line in stream:
        if not line.endswith("\n"):
            raise ItemRefused("quarantine_inbox_incomplete")
        try:
            row = json.loads(line)
        except (ValueError, RecursionError):
            raise ItemRefused("quarantine_inbox_invalid") from None
        if not isinstance(row, dict):
            raise ItemRefused("quarantine_inbox_invalid")
        if row.get("id") == message["id"]:
            if found or row != message:
                raise ItemRefused("quarantine_inbox_conflict")
            found = True
    return found


def _inspect_rows(stream, message):
    try:
        return _inbox_contains(stream, message)
    except UnicodeError:
        raise ItemRefused("quarantine_inbox_invalid") from None


def _inspect_inbox(pid, message):
    """Validate a pending item's existing inbox without creating or repairing it."""
    try:
        fd = os.open(store.inbox_path(pid), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except FileNotFoundError:
        return
    except OSError as exc:
        if exc.errno == errno.ELOOP:
            raise ItemRefused("quarantine_inbox_invalid") from None
        raise
    import fcntl
    with os.fdopen(fd, "r", encoding="utf-8") as stream:
        if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
            raise ItemRefused("quarantine_inbox_invalid")
        fcntl.flock(stream.fileno(), fcntl.LOCK_SH)
        _inspect_rows(stream, message)


def _append_inbox_once(pid, message):
    """Whole-file exact-ID check; no bounded-tail duplicate window on retry."""
    path = store.inbox_path(pid)
    fd = os.open(path, os.O_RDWR | os.O_APPEND | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
    import fcntl
    with os.fdopen(fd, "r+", encoding="utf-8") as stream:
        if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
            raise ItemRefused("quarantine_inbox_invalid")
        os.fchmod(stream.fileno(), 0o600)
        fcntl.flock(stream.fileno(), fcntl.LOCK_EX)
        found = _inspect_rows(stream, message)
        if not found:
            store._append_jsonl_to_locked_file(stream, message)
        else:
            os.fsync(stream.fileno())
        store._fsync_dir(path.parent)
        return not found


def _finish(message, row):
    """Called under registry + delivery fences; finish the committed decision."""
    complete_path = _path(message["id"], complete=True)
    complete = {"event-id": row["event-id"], "decision_sha256": fingerprint(row)}
    previous = _read_item(complete_path)
    if previous is not None:
        if previous != complete:
            raise ItemRefused("quarantine_completion_conflict")
        return []
    if row["action"] == "release":
        _check_recipients(row)
        for pid in row["recipients"]:
            _inspect_inbox(pid, message)
    # If the first call lost the directory-fsync result, establish durability
    # of the same immutable admission before any delivery is resumed.
    _write_once(_path(message["id"]), row)
    # The immutable admission is durable even if this journal mirror failed.
    matches = [r for r in receipts.strict_rows()
               if r.get("kind") == "quarantine-disposition" and r.get("event-id") == row["event-id"]]
    if matches and matches != [row]:
        raise Refused("quarantine_receipt_conflict")
    if not matches:
        receipts.append_durable(row)
    appended = []
    if row["action"] == "release":
        receipts._recover_fetched_transactions_unlocked()
        for pid in row["recipients"]:
            delivery = receipts._delivery_state(message["id"], pid)
            if delivery == "FETCHED":
                continue
            if _append_inbox_once(pid, message):
                appended.append(pid)
            if delivery not in {"QUEUED", "POKED"}:
                receipts.journal(message["id"], pid, "QUEUED", detail="governance-key release: " + row["event-id"])
    _write_once(complete_path, complete)
    return appended


def _finish_recording_failure(message, row):
    """Retain the first observation of each item failure; reads never write it."""
    try:
        return _finish(message, row)
    except ItemRefused as exc:
        reason = str(exc)
        path = _issue_path(message["id"], reason)
        binding = {"kind": "quarantine-incomplete", "event-id": row["event-id"],
                   "decision_sha256": fingerprint(row), "reason": reason}
        old = _read_item(path)
        if old is not None:
            if any(old.get(k) != v for k, v in binding.items()):
                raise ItemRefused("quarantine_incomplete_record_conflict")
        else:
            _write_once(path, {**binding, "observed_at": store.now_iso()})
        raise


def dispose(action, mid, authorization, *, presented_token=None):
    """The sole disposition boundary. Tokens are categorically not authority."""
    if presented_token is not None:
        raise Refused("quarantine_requires_governance_key_not_token")
    # Retain the exact verified value even if a programmatic caller mutates its
    # own dict concurrently; the caller never owns the admitted receipt object.
    import rfc8785
    authorization = json.loads(rfc8785.dumps(authorization))
    def act():
        message = _message(mid)
        parts = store._read_participants_unlocked()
        with receipts._nudge_lock():
            row = _decision(message)
            if row is not None and row["action"] != action:
                raise Refused("quarantine_already_disposed")
            # The exact admitted request resumes its committed decision. New or
            # different requests still need today's registered key/role/expiry.
            if row is None or fingerprint(authorization) != row["authorization_sha256"]:
                verdict = authority.verify_quarantine(authorization, participants=parts, action=action,
                    message_id=mid, message_sha256=fingerprint(message), store_ref=store_ref(), now=time.time())
            if row is None:
                targets = message.get("recipients")
                if (not isinstance(targets, list) or not targets
                        or any(not isinstance(pid, str) or not pid for pid in targets)
                        or (action == "release" and any(
                            pid not in parts or store.inactive_participant(parts[pid]) for pid in targets))):
                    raise Refused("quarantine_recipient_changed")
                row = {"v": 1, "kind": "quarantine-disposition", "event-id": "qdisp-" + fingerprint(authorization),
                       "action": action, "msg-id": mid, "message_sha256": fingerprint(message),
                       "actor": verdict["actor"], "key_id": verdict["key_id"], "ts": store.now_iso(),
                       "recorded_recipients": list(targets),
                       "recipients": [pid for pid in store.mailbox_targets(message)
                                      if action == "release" and store.has_mailbox(parts[pid])],
                       "authorization": authorization, "authorization_sha256": fingerprint(authorization)}
                _write_once(_path(mid), row)
            _finish_recording_failure(message, row)
            return {"id": mid, **status(message)}
    return store._registry_locked(act)


def sign(action, mid, key_file):
    """CLI convenience: private bytes stay in memory, identity comes from registration."""
    from cryptography.hazmat.primitives import serialization
    from cryptography.exceptions import UnsupportedAlgorithm
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    fd = os.open(key_file, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                or stat.S_IMODE(info.st_mode) != 0o600 or info.st_nlink != 1):
            raise Refused("governance_key_file_custody")
        raw = stream.read(16385)
    if len(raw) > 16384:
        raise Refused("governance_key_file_invalid")
    try:
        key = serialization.load_pem_private_key(raw, password=None)
        if not isinstance(key, Ed25519PrivateKey):
            raise ValueError()
    except (ValueError, TypeError, UnsupportedAlgorithm):
        raise Refused("governance_key_file_invalid") from None
    message = _message(mid)
    existing = _decision(message)
    if existing is not None and existing["action"] == action:
        # Ed25519 is deterministic: possession of the original private key can
        # reproduce its admitted authorization even after rotation/demotion.
        # This does not sign a new request or bypass any new-admission check.
        admitted = existing["authorization"]
        signature = base64.b64encode(key.sign(authority.quarantine_bytes(admitted["payload"]))).decode("ascii")
        if signature == admitted["signature"]:
            return copy.deepcopy(admitted)
    public = key.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo).decode("ascii")
    matches = [(pid, row) for pid, row in store.load_participants().items()
               if row.get("signing_key") == public]
    if len(matches) != 1:
        raise Refused("governance_key_not_uniquely_registered")
    actor, row = matches[0]
    payload = {"v": 1, "kind": "quarantine-disposition", "action": action,
               "message_id": mid, "message_sha256": fingerprint(message), "store_ref": store_ref(),
               "actor": actor, "key_id": row.get("signing_key_id"),
               "request_id": uuid.uuid4().hex, "expires_at": int(time.time()) + 120}
    return {"payload": payload, "signature": base64.b64encode(key.sign(authority.quarantine_bytes(payload))).decode("ascii")}


def repair(message):
    """Recover only an already-admitted decision; never re-vet or invent a grant."""
    def act():
        row = _decision(message)
        if row is None:
            return []
        with receipts._nudge_lock():
            return _finish_recording_failure(message, row)
    return store._registry_locked(act)


@lru_cache(maxsize=512)
def _released_message(log_path, inode, mid, digest):
    message = _message(mid)
    if fingerprint(message) != digest:
        raise ItemRefused("quarantine_record_conflict")
    return message


def pending_messages(*, on_incomplete=None):
    """Feed old released IDs to the daemon even after its log cursor passed them."""
    root = _root()
    if not root.exists():
        return []
    # A shared journal failure is not an item failure. Never suppress it in
    # the per-file boundary below, including when all items happen to be bad.
    receipts.strict_rows()
    pending = {mid for ids in receipts._pending_by_seat().values() for mid in ids}
    result = []
    for path in sorted(root.iterdir()):
        if path.suffix != ".json" or path.name.endswith(".complete.json") or ".issue-" in path.name:
            continue
        mid = None
        try:
            row = _validate_row(_read_item(path))
            mid = row["msg-id"]
            if path != _path(mid):
                raise ItemRefused("quarantine_record_conflict")
            if row["action"] != "release":
                continue
            message = copy.deepcopy(_released_message(str(store.LOG_FILE), store.LOG_FILE.stat().st_ino, mid, row["message_sha256"]))
            # Validate completion, but do not let a retained old failure prevent
            # recovery after its cause has been corrected. Completion supersedes
            # diagnostics without erasing them.
            current_row = _decision(message)
            if current_row is None:
                raise ItemRefused("quarantine_record_missing")
            complete = _read_item(_path(mid, complete=True))
            if complete is not None:
                if complete != {"event-id": current_row["event-id"], "decision_sha256": fingerprint(current_row)}:
                    raise ItemRefused("quarantine_completion_conflict")
                if mid not in pending:
                    continue
            repair(message)
            if any(receipts._delivery_state(mid, pid) in {"QUEUED", "POKED"} for pid in row["recipients"]):
                result.append(message)
        except ItemRefused as exc:
            if on_incomplete is not None:
                safe_id = mid if isinstance(mid, str) and re.fullmatch(r"msg-[A-Za-z0-9_-]{1,200}", mid) else None
                on_incomplete({"id": safe_id, "record_ref": hashlib.sha256(path.name.encode()).hexdigest(),
                               "state": "incomplete", "blocked": True, "reason": str(exc)})
    return result
