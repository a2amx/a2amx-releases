"""Offline release evidence primitives; no publication or runtime activation.

This module records what was measured. A digest binds bytes, not authority, and
an artifact inspection alone never qualifies native behavior or a stable release.
"""
from __future__ import annotations

from contextlib import contextmanager
from email.parser import BytesParser
from email.policy import compat32
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import zipfile

MAX_WHEEL_BYTES = 512 * 1024 * 1024
MAX_MEMBERS = 8192
MAX_UNPACKED_BYTES = 512 * 1024 * 1024
MAX_SOURCE_BYTES = 16 * 1024 * 1024
MAX_METADATA_BYTES = 128 * 1024
MAX_MANIFEST_BYTES = 1024 * 1024
DIGEST = re.compile(r'[0-9a-f]{64}')
WHEEL_NAME = re.compile(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,199}\.whl')


class Refused(ValueError):
    """Fixed reason only: do not echo artifact bytes, paths, or parser errors."""


@contextmanager
def regular(path, limit):
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except OSError:
        raise Refused('artifact_unreadable') from None
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        if not stat.S_ISREG(before.st_mode) or before.st_size > limit:
            raise Refused('artifact_type_or_bound')
        yield stream
        after = os.fstat(stream.fileno())
        fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
        if any(getattr(before, k) != getattr(after, k) for k in fields):
            raise Refused('artifact_changed')


def member_name(name):
    if (not isinstance(name, str) or not name or '\\' in name
            or any(ord(c) < 32 or ord(c) > 126 for c in name)
            or name.startswith('/') or name.endswith('/')
            or any(p in {'', '.', '..'} for p in name.split('/'))):
        raise Refused('member_name')
    return name


def checksum_manifest(path):
    with regular(path, MAX_MANIFEST_BYTES) as stream:
        raw = stream.read(MAX_MANIFEST_BYTES + 1)
        if len(raw) > MAX_MANIFEST_BYTES:
            raise Refused('manifest_bound')
    try:
        lines = raw.decode('ascii').splitlines()
    except UnicodeError:
        raise Refused('manifest_encoding') from None
    if not lines:
        raise Refused('manifest_empty')
    result = {}
    for line in lines:
        match = re.fullmatch(r'([a-f0-9]{64}) [ *](.+)', line)
        if not match:
            raise Refused('manifest_line')
        digest, name = match.groups()
        member_name(name)
        if name in result or name == 'SHA256SUMS':
            raise Refused('manifest_duplicate_or_self')
        result[name] = digest
    return result, hashlib.sha256(raw).hexdigest()


def _metadata(raw):
    try:
        msg = BytesParser(policy=compat32).parsebytes(raw)
        result = {}
        for header in ('Name', 'Version', 'Requires-Python'):
            values = msg.get_all(header, [])
            if len(values) != 1:
                raise Refused('metadata_required_field')
            value = str(values[0])
            if not value or len(value) > 200 or any(ord(c) < 32 or ord(c) > 126 for c in value):
                raise Refused('metadata_value')
            result[header] = value
        return result
    except Refused:
        raise
    except Exception:
        raise Refused('metadata_invalid') from None


def inspect_wheel(wheel, sums, *, single=False, required=None):
    """Hash one regular wheel and inspect its bounded metadata without extraction.

    The supplied manifest must bind its basename. Other manifest members are
    retained as declarations, not reported verified by this single-wheel reader.
    Source/export provenance and native qualification are separate obligations.
    """
    wheel = Path(wheel)
    if not WHEEL_NAME.fullmatch(wheel.name):
        raise Refused('wheel_name')
    entries, sums_digest = checksum_manifest(sums)
    if single and set(entries) != {wheel.name}:
        raise Refused('wheel_only_manifest_required')
    expected = entries.get(wheel.name)
    if expected is None:
        raise Refused('wheel_not_in_manifest')
    try:
        with regular(wheel, MAX_WHEEL_BYTES) as stream:
            sha = hashlib.sha256()
            size = 0
            while chunk := stream.read(1024 * 1024):
                size += len(chunk)
                if size > MAX_WHEEL_BYTES:
                    raise Refused('wheel_bound')
                sha.update(chunk)
            if sha.hexdigest() != expected:
                raise Refused('wheel_digest')
            stream.seek(0)
            with zipfile.ZipFile(stream) as archive:
                members = archive.infolist()
                if not members or len(members) > MAX_MEMBERS:
                    raise Refused('wheel_member_bound')
                seen = set(); metadata = []; unpacked = 0
                for entry in members:
                    name = member_name(entry.filename)
                    if name in seen or entry.flag_bits & 1:
                        raise Refused('wheel_duplicate_or_encrypted')
                    seen.add(name)
                    kind = stat.S_IFMT(entry.external_attr >> 16)
                    if kind not in {0, stat.S_IFREG}:
                        raise Refused('wheel_nonregular_member')
                    unpacked += entry.file_size
                    if unpacked > MAX_UNPACKED_BYTES:
                        raise Refused('wheel_unpacked_bound')
                    parts = PurePosixPath(name).parts
                    if len(parts) == 2 and parts[0].endswith('.dist-info') and parts[1] == 'METADATA':
                        metadata.append(entry)
                if len(metadata) != 1 or metadata[0].file_size > MAX_METADATA_BYTES:
                    raise Refused('wheel_metadata_count_or_bound')
                values = _metadata(archive.read(metadata[0]))
                for name, digest in (required or {}).items():
                    if name not in seen or archive.getinfo(name).file_size > MAX_SOURCE_BYTES:
                        raise Refused('wheel_required_member')
                    if hashlib.sha256(archive.read(name)).hexdigest()!=digest:
                        raise Refused('wheel_required_digest')
                record = {
                    'filename': wheel.name, 'sha256': sha.hexdigest(), 'bytes': size,
                    'checksum_manifest_sha256': sums_digest,
                    'verified_manifest_members': [wheel.name],
                    'metadata': {'name': values['Name'], 'version': values['Version'],
                                 'requires_python': values['Requires-Python']},
                }
        return record
    except Refused:
        raise
    except (OSError, ValueError, zipfile.BadZipFile, RuntimeError, NotImplementedError):
        raise Refused('wheel_invalid') from None


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True,
                       allow_nan=False)+'\n').encode('ascii')


def _unique(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise Refused('json_duplicate_key')
        out[key] = value
    return out


def _finite_float(text):
    import math
    value = float(text)
    if not math.isfinite(value):
        raise Refused('json_number')
    return value


def read_json(path):
    with regular(path, MAX_MANIFEST_BYTES) as stream:
        raw = stream.read(MAX_MANIFEST_BYTES+1)
        if len(raw) > MAX_MANIFEST_BYTES:
            raise Refused('json_bound')
    try:
        value = json.loads(raw, object_pairs_hook=_unique, parse_float=_finite_float,
                           parse_constant=lambda _: (_ for _ in ()).throw(Refused('json_number')))
    except (UnicodeError, ValueError, RecursionError):
        raise Refused('json_invalid') from None
    return value, hashlib.sha256(raw).hexdigest()


def shape(value, fields):
    if not isinstance(value, dict) or set(value) != set(fields):
        raise Refused('record_shape')


def is_digest(value):
    return isinstance(value, str) and DIGEST.fullmatch(value) is not None


def snapshot_inventory(snapshot):
    """Canonical final S1 inventory, not the private Git tree's byte digest."""
    shape(snapshot, {'schema','offering','tag','commit','tree','policy_sha256',
                     'extra_terms_sha256','files','sweep','internal_version'})
    if (type(snapshot['schema']) is not int or snapshot['schema'] != 2
            or snapshot['offering'] != 'S1' or snapshot['sweep'] != 'passed'
            or not is_digest(snapshot['policy_sha256'])
            or not is_digest(snapshot['extra_terms_sha256'])):
        raise Refused('snapshot_unqualified')
    version=snapshot['internal_version']
    if not isinstance(version,str) or not re.fullmatch(r'[0-9][A-Za-z0-9.+_-]{0,95}',version):
        raise Refused('internal_version_shape')
    entries = snapshot['files']
    if not isinstance(entries, list) or not 1 <= len(entries) <= MAX_MEMBERS:
        raise Refused('snapshot_inventory_bound')
    seen = set(); total = 0
    for entry in entries:
        shape(entry, {'path','source_path','mode','size','sha256','source_sha256'})
        name = member_name(entry['path'])
        member_name(entry['source_path'])
        if name in seen or name == 'SNAPSHOT_MANIFEST.json':
            raise Refused('snapshot_duplicate_or_self')
        seen.add(name)
        if (entry['mode'] not in {'100644','100755'} or type(entry['size']) is not int
                or not 0 <= entry['size'] <= MAX_SOURCE_BYTES or not is_digest(entry['sha256'])
                or entry['source_sha256'] != entry['sha256']):
            raise Refused('snapshot_entry')
        total += entry['size']
        if total > MAX_UNPACKED_BYTES:
            raise Refused('snapshot_total_bound')
    emitted = [{k:e[k] for k in ('path','mode','size','sha256')} for e in entries]
    return hashlib.sha256(canonical(sorted(emitted, key=lambda e:e['path']))).hexdigest()


def bind_build(snapshot, snapshot_sha256, build, wheel, identity):
    """Validate cross-bindings. This does not reperform the release pipeline's source build/sweep."""
    inventory = snapshot_inventory(snapshot)
    shape(build, {'schema','tag','commit','tree','snapshot_manifest_sha256',
                  'snapshot_tree_sha256','wheel'})
    if type(build['schema']) is not int or build['schema'] != 1:
        raise Refused('build_schema')
    for key in ('tag','commit','tree'):
        if build[key] != identity[key] or snapshot[key] != identity[key]:
            raise Refused('source_binding')
    if (build['snapshot_manifest_sha256'] != snapshot_sha256
            or build['snapshot_tree_sha256'] != inventory):
        raise Refused('snapshot_binding')
    expected = {'filename':wheel['filename'], 'size':wheel['bytes'],
                'sha256':wheel['sha256'], 'distribution':wheel['metadata']['name'],
                'version':wheel['metadata']['version'],
                'requires_python':wheel['metadata']['requires_python']}
    if build['wheel'] != expected:
        raise Refused('wheel_build_binding')
    if wheel['metadata']['version'] != identity['version']:
        raise Refused('tag_version_binding')
    return inventory


def git_read(repo, *args, limit=MAX_MANIFEST_BYTES):
    """Only fixed Git reads. Blob callers check immutable object size first."""
    import subprocess
    env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C',
         'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':os.devnull,'GIT_TERMINAL_PROMPT':'0',
         'GIT_NO_REPLACE_OBJECTS':'1','GIT_LITERAL_PATHSPECS':'1'}
    try:
        result=subprocess.run(['git','-C',str(repo),*args],env=env,
            stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=10)
    except (OSError, subprocess.TimeoutExpired):
        raise Refused('tag_read') from None
    if result.returncode or len(result.stdout)>limit:
        raise Refused('tag_read')
    return result.stdout


def tag_identity(repo, tag):
    """Resolve tag once. Its release version is checked against the public variant."""
    if not isinstance(tag,str) or not re.fullmatch(r'v[0-9]+\.[0-9]+\.[0-9]+(?:[a-zA-Z0-9.+-]*)',tag):
        raise Refused('tag_name')
    commit=git_read(repo,'rev-parse','--verify','refs/tags/'+tag+'^{commit}').decode().strip()
    if not re.fullmatch(r'[a-f0-9]{40}',commit): raise Refused('tag_oid')
    if git_read(repo,'rev-parse','--verify','HEAD').decode().strip()!=commit:
        raise Refused('tag_not_checked_out')
    tree=git_read(repo,'rev-parse','--verify',commit+'^{tree}').decode().strip()
    if not re.fullmatch(r'[a-f0-9]{40}',tree): raise Refused('tag_tree')
    return {'tag':tag,'commit':commit,'tree':tree,'version':tag[1:]}


def verify_sources(repo, identity, snapshot, wheel):
    """Prove exact source/remap hashes and read the selected public metadata.

    The release pipeline still owns selection, sweep and build qualification. No working-tree
    source bytes or replacement refs enter this check.
    """
    import tomllib
    snapshot_inventory(snapshot)
    # The internal version belongs to the original tagged root, independently
    # of the remapped public pyproject and of dirty checkout bytes.
    raw=git_read(repo,'ls-tree','-z',identity['commit'],'--','pyproject.toml')
    try:
        rows=raw.split(b'\0')
        if len(rows)!=2 or rows[1]!=b'':raise ValueError('root_shape')
        meta,path=rows[0].split(b'\t',1);mode,kind,oid=meta.decode('ascii').split()
        if (path!=b'pyproject.toml' or mode not in {'100644','100755'} or kind!='blob'
                or not re.fullmatch(r'[a-f0-9]{40}',oid)):
            raise ValueError('root_type')
        size=int(git_read(repo,'cat-file','-s',oid))
        if not 0<size<=MAX_METADATA_BYTES:raise ValueError('root_bound')
        data=git_read(repo,'cat-file','blob',oid,limit=MAX_METADATA_BYTES)
        if len(data)!=size:raise ValueError('root_size')
        internal=tomllib.loads(data.decode())['project']['version']
    except (ValueError,KeyError,TypeError):
        raise Refused('internal_version_source') from None
    if internal!=snapshot['internal_version']:
        raise Refused('internal_version_binding')
    project = None
    for entry in snapshot['files']:
        raw=git_read(repo,'ls-tree','-z',identity['commit'],'--',entry['source_path'])
        try:
            rows=raw.split(b'\0')
            if len(rows)!=2 or rows[1]!=b'':raise ValueError('tree_shape')
            meta,path=rows[0].split(b'\t',1);mode,kind,oid=meta.decode('ascii').split()
            if (path.decode('utf-8')!=entry['source_path'] or mode!=entry['mode']
                    or kind!='blob' or not re.fullmatch(r'[a-f0-9]{40}',oid)):
                raise ValueError('tree_binding')
            size=int(git_read(repo,'cat-file','-s',oid))
            if size!=entry['size'] or not 0<=size<=MAX_SOURCE_BYTES:raise ValueError('blob_size')
        except ValueError:
            raise Refused('tagged_member') from None
        data=git_read(repo,'cat-file','blob',oid,limit=MAX_SOURCE_BYTES)
        if len(data)!=size or hashlib.sha256(data).hexdigest()!=entry['source_sha256']:
            raise Refused('tagged_member_digest')
        if entry['path']=='pyproject.toml':
            if size>MAX_METADATA_BYTES: raise Refused('public_metadata_bound')
            try:
                project=tomllib.loads(data.decode())['project']
            except (UnicodeError,ValueError,KeyError,TypeError):
                raise Refused('public_metadata') from None
    if not isinstance(project,dict): raise Refused('public_metadata_missing')
    expected={'name':project.get('name'),'version':project.get('version'),
              'requires_python':project.get('requires-python')}
    if expected!=wheel['metadata'] or expected['version']!=identity['version']:
        raise Refused('public_metadata_binding')


def assemble_artifacts(*, repo, tag, wheel, wheel_sums, snapshot, build, required_wheel=None):
    """Bind artifacts only; this partial object cannot mean native qualification."""
    identity=tag_identity(repo,tag)
    snap,snap_digest=read_json(snapshot);built,build_digest=read_json(build)
    artifact=inspect_wheel(wheel,wheel_sums,single=True,required=required_wheel)
    inventory=bind_build(snap,snap_digest,built,artifact,identity)
    verify_sources(repo,identity,snap,artifact)
    return {'schema':'quovisto.release-artifacts.v1','source':identity,
            'wheel':artifact,'snapshot_manifest_sha256':snap_digest,
            'snapshot_tree_sha256':inventory,'build_record_sha256':build_digest,
            'qualification':'unqualified','reason':'native_evidence_not_evaluated'}


RECORD_SCHEMA = 'quovisto.release-qualification.v1'
EVIDENCE_SCHEMA = 'quovisto.release-evidence.v1'
CHECKS = ('hook_identity', 'background_resumption', 'wait_allowance',
          'socket_handover', 'socket_hold', 'compact_recovery')
STATES = {'PASS', 'FAIL', 'UNMEASURED'}
VERSION_KEYS = ('claude_app_build', 'claude_code_version')


def decode_json(raw):
    if not isinstance(raw,bytes) or len(raw)>MAX_MANIFEST_BYTES:
        raise Refused('record_bound')
    try:
        return json.loads(raw,object_pairs_hook=_unique,parse_float=_finite_float,
                          parse_constant=lambda _: (_ for _ in ()).throw(Refused('json_number')))
    except (UnicodeError,ValueError,RecursionError):
        raise Refused('record_json') from None


def observation(value):
    shape(value, {'value','status','source','evidence_sha256'})
    if value['status']=='unmeasured':
        if value != {'value':None,'status':'unmeasured','source':'unavailable','evidence_sha256':None}:
            raise Refused('observation_shape')
    elif value['status']=='observed':
        text=value['value']
        if (not isinstance(text,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9.+_-]{0,95}',text)
                or value['source']!='running_process' or not is_digest(value['evidence_sha256'])):
            raise Refused('observation_shape')
    else:
        raise Refused('observation_shape')


def profiles(value):
    if not isinstance(value,list) or len(value)>32: raise Refused('profiles_bound')
    seen=set()
    for profile in value:
        shape(profile, {'versions','checks'})
        shape(profile['versions'],VERSION_KEYS)
        for key in VERSION_KEYS:observation(profile['versions'][key])
        key=tuple(profile['versions'][key]['value'] for key in VERSION_KEYS)
        if key in seen: raise Refused('profile_duplicate')
        seen.add(key)
        shape(profile['checks'],CHECKS)
        for result in profile['checks'].values():
            shape(result,{'status','evidence_sha256'})
            if result['status'] not in STATES: raise Refused('check_status')
            if result['status']=='UNMEASURED':
                if result['evidence_sha256'] is not None: raise Refused('check_evidence')
            elif not is_digest(result['evidence_sha256']): raise Refused('check_evidence')


def cohort(value):
    """Validate anonymous, opt-in local results; identifiers prove no human identity."""
    shape(value,{'consent','attestation_sha256','trials'})
    if type(value['consent']) is not bool: raise Refused('cohort_consent')
    trials=value['trials']
    if not isinstance(trials,list) or len(trials)>100:raise Refused('cohort_bound')
    if not value['consent']:
        if trials or value['attestation_sha256'] is not None:raise Refused('cohort_not_consented')
        return
    if not is_digest(value['attestation_sha256']):raise Refused('cohort_attestation')
    seen=set(); receipts=set()
    for trial in trials:
        shape(trial,{'id','result','elapsed_ms','onboarding_acts','prerequisite_acts',
                     'unassisted','exchange_receipt_sha256'})
        if (not isinstance(trial['id'],str) or not re.fullmatch(r'[a-f0-9]{32}',trial['id'])
                or trial['id'] in seen):raise Refused('trial_id')
        seen.add(trial['id'])
        if trial['result'] not in {'PASS','FAIL','INCOMPLETE'}:raise Refused('trial_result')
        if type(trial['unassisted']) is not bool:raise Refused('trial_assistance')
        for k,maximum in [('elapsed_ms',604800000),('onboarding_acts',10000),('prerequisite_acts',10000)]:
            v=trial[k]
            if v is not None and (type(v) is not int or not 0<=v<=maximum):raise Refused('trial_number')
        receipt=trial['exchange_receipt_sha256']
        if receipt is not None and not is_digest(receipt):raise Refused('trial_receipt')
        if receipt is not None:
            if receipt in receipts:raise Refused('trial_duplicate_receipt')
            receipts.add(receipt)
        if trial['result']=='PASS' and (receipt is None or any(trial[k] is None for k in
                ('elapsed_ms','onboarding_acts','prerequisite_acts'))):raise Refused('trial_incomplete_pass')


def qualification_summary(value):
    native=sum(all(p['versions'][k]['status']=='observed' for k in VERSION_KEYS)
               and all(p['checks'][k]['status']=='PASS' for k in CHECKS) for p in value['profiles'])
    c=value['cohort']; trials=c['trials']
    first_hour=bool(c['consent'] and len(trials)>=5 and all(
        t['result']=='PASS' and t['unassisted'] and t['elapsed_ms']<=3600000
        and t['onboarding_acts']<=4 for t in trials))
    return {'native_profiles_qualified':native,'reported_first_hour_bar_met':first_hour,
            'opt_in_stage1_exchanges':sum(t['exchange_receipt_sha256'] is not None for t in trials),
            'release_status':'preview','release_word_inferred':False}


def compile_record(artifacts, evidence=None, evidence_sha256=None, *, generator_sha256):
    binding={'wheel_sha256':artifacts['wheel']['sha256'],
             'build_record_sha256':artifacts['build_record_sha256'],
             'kit_source_sha256':artifacts['snapshot_tree_sha256']}
    if evidence is None:
        if evidence_sha256 is not None:raise Refused('evidence_digest')
        measured_profiles=[]; measured_cohort={'consent':False,'attestation_sha256':None,'trials':[]}
    else:
        shape(evidence,{'schema','binding','profiles','cohort'})
        if (evidence['schema']!=EVIDENCE_SCHEMA or evidence['binding']!=binding
                or not is_digest(evidence_sha256)):raise Refused('evidence_binding')
        profiles(evidence['profiles']);cohort(evidence['cohort'])
        measured_profiles=evidence['profiles'];measured_cohort=evidence['cohort']
    if not is_digest(generator_sha256):raise Refused('generator_digest')
    artifact_copy={k:v for k,v in artifacts.items() if k not in {'schema','qualification','reason'}}
    value={'schema':RECORD_SCHEMA,'artifacts':artifact_copy,'binding':binding,
           'generator_sha256':generator_sha256,'evidence_sha256':evidence_sha256,
           'profiles':measured_profiles,'cohort':measured_cohort}
    value['qualification']=qualification_summary(value)
    wire=canonical(value)
    if len(wire)>MAX_MANIFEST_BYTES:raise Refused('record_bound')
    return wire


def validate_record(raw):
    value=decode_json(raw)
    if raw != canonical(value):raise Refused('record_noncanonical')
    shape(value,{'schema','artifacts','binding','generator_sha256','evidence_sha256',
                 'profiles','cohort','qualification'})
    if value['schema']!=RECORD_SCHEMA or not is_digest(value['generator_sha256']):raise Refused('record_schema')
    if value['evidence_sha256'] is not None and not is_digest(value['evidence_sha256']):raise Refused('evidence_digest')
    shape(value['binding'],{'wheel_sha256','build_record_sha256','kit_source_sha256'})
    if not all(is_digest(v) for v in value['binding'].values()):raise Refused('binding_digest')
    a=value['artifacts']
    shape(a,{'source','wheel','snapshot_manifest_sha256','snapshot_tree_sha256','build_record_sha256'})
    shape(a['source'],{'tag','commit','tree','version'})
    source=a['source']
    if (not isinstance(source['version'],str) or source['tag']!='v'+source['version']
            or not re.fullmatch(r'v[0-9]+\.[0-9]+\.[0-9]+(?:[a-zA-Z0-9.+-]*)',source['tag'])
            or any(not isinstance(source[k],str) or not re.fullmatch(r'[a-f0-9]{40}',source[k])
                   for k in ('commit','tree'))):raise Refused('record_source')
    for k in ('snapshot_manifest_sha256','snapshot_tree_sha256','build_record_sha256'):
        if not is_digest(a[k]):raise Refused('record_digest')
    wheel=a['wheel']
    shape(wheel,{'filename','sha256','bytes','checksum_manifest_sha256','verified_manifest_members','metadata'})
    if (not isinstance(wheel['filename'],str) or not WHEEL_NAME.fullmatch(wheel['filename'])
            or not is_digest(wheel['sha256']) or not is_digest(wheel['checksum_manifest_sha256'])
            or type(wheel['bytes']) is not int or not 0<wheel['bytes']<=MAX_WHEEL_BYTES
            or wheel['verified_manifest_members']!=[wheel['filename']]):raise Refused('record_wheel')
    shape(wheel['metadata'],{'name','version','requires_python'})
    for text in wheel['metadata'].values():
        if not isinstance(text,str) or not text or len(text)>200 or any(ord(c)<32 or ord(c)>126 for c in text):
            raise Refused('record_metadata')
    if wheel['metadata']['version']!=source['version']:raise Refused('record_version')
    if (a['wheel'].get('sha256')!=value['binding']['wheel_sha256']
            or a['snapshot_tree_sha256']!=value['binding']['kit_source_sha256']
            or a['build_record_sha256']!=value['binding']['build_record_sha256']):raise Refused('record_binding')
    profiles(value['profiles']);cohort(value['cohort'])
    if value['evidence_sha256'] is None and (value['profiles'] or value['cohort']['consent']):
        raise Refused('evidence_missing')
    if canonical(value['qualification'])!=canonical(qualification_summary(value)):
        raise Refused('qualification_claim')
    return value


def evaluate(raw, expected, observed):
    """Pure startup-consumer interface. Eligibility only; caller owns observation and lifecycle authority.

    expected pins must come from installed, qualified release records, never
    be copied from the untrusted record being evaluated. The kit source pin is
    the whole emitted inventory, not the per-home hookset or route generation.
    No current invocation is inferred from an installed binary or target label.
    """
    result={'schema':1,'record_digest':None,'eligible':False,'reason':'record_invalid',
            'checks':{'record':'FAIL','artifact_pins':'UNMEASURED',
                      'running_versions':'UNMEASURED','native_checks':'UNMEASURED'}}
    try:
        value=validate_record(raw)
    except (Refused,TypeError,KeyError,AttributeError,RecursionError):return result
    result['record_digest']=hashlib.sha256(raw).hexdigest();result['checks']['record']='PASS'
    try:
        shape(expected,{'record_sha256','wheel_sha256','build_record_sha256','kit_source_sha256'})
        if not all(is_digest(v) for v in expected.values()):raise Refused('expected_pins')
        actual={'record_sha256':result['record_digest'],**value['binding']}
        if expected!=actual:raise Refused('expected_pins')
    except (Refused,TypeError):
        result['reason']='artifact_pins_mismatch';result['checks']['artifact_pins']='FAIL';return result
    result['checks']['artifact_pins']='PASS'
    try:
        shape(observed,VERSION_KEYS)
        for key in VERSION_KEYS:observation(observed[key])
    except (Refused,TypeError,KeyError):
        result['reason']='running_observation_invalid';result['checks']['running_versions']='FAIL';return result
    if any(observed[k]['status']=='unmeasured' for k in VERSION_KEYS):
        result['reason']='running_versions_unmeasured';return result
    pair=tuple(observed[k]['value'] for k in VERSION_KEYS)
    matches=[p for p in value['profiles'] if tuple(p['versions'][k]['value'] for k in VERSION_KEYS)==pair]
    if not matches:
        result['reason']='running_versions_mismatch';result['checks']['running_versions']='FAIL';return result
    result['checks']['running_versions']='PASS'
    checks=matches[0]['checks'];statuses=[checks[k]['status'] for k in CHECKS]
    result['checks']['native_checks']='FAIL' if 'FAIL' in statuses else ('UNMEASURED' if 'UNMEASURED' in statuses else 'PASS')
    if result['checks']['native_checks']!='PASS':
        result['reason']='native_checks_unqualified';return result
    result.update(eligible=True,reason='qualified_pin_match')
    return result


def write_new(path, wire):
    """Publish complete bytes without replacement; errors never promise no effect."""
    import tempfile
    path=Path(path);parent=path.parent.resolve(strict=True)
    if path.name!='QUALIFICATION.json':raise Refused('output_name')
    temp=None
    try:
        fd,temp=tempfile.mkstemp(prefix='.qualification-',dir=parent)
        with os.fdopen(fd,'wb') as stream:
            stream.write(wire);stream.flush();os.fchmod(stream.fileno(),0o444);os.fsync(stream.fileno())
        os.link(temp,parent/path.name,follow_symlinks=False)
        dfd=os.open(parent,os.O_RDONLY)
        try:os.fsync(dfd)
        finally:os.close(dfd)
    except OSError:
        raise Refused('output_not_confirmed') from None
    finally:
        if temp is not None:os.unlink(temp)


def main(argv=None):
    import argparse
    parser=argparse.ArgumentParser(description='Assemble bounded offline release qualification; never publish or activate.')
    for option in ('repo','tag','wheel','wheel-sums','snapshot','build','output'):
        parser.add_argument('--'+option,required=True)
    parser.add_argument('--evidence')
    args=parser.parse_args(argv)
    try:
        with regular(Path(__file__),MAX_SOURCE_BYTES) as stream:own=hashlib.sha256(stream.read()).hexdigest()
        artifacts=assemble_artifacts(repo=args.repo,tag=args.tag,wheel=args.wheel,
            wheel_sums=args.wheel_sums,snapshot=args.snapshot,build=args.build,
            required_wheel={'stage1_release_qualification.py':own})
        snap,snap_sha=read_json(args.snapshot)
        if snap_sha!=artifacts['snapshot_manifest_sha256']:raise Refused('snapshot_changed')
        tool=[e for e in snap['files'] if e['path']=='stage1_release_qualification.py']
        if len(tool)!=1 or tool[0]['sha256']!=own:raise Refused('generator_source_binding')
        ev=ev_sha=None
        if args.evidence:ev,ev_sha=read_json(args.evidence)
        wire=compile_record(artifacts,ev,ev_sha,generator_sha256=own)
        validate_record(wire)
        write_new(args.output,wire)
        print(json.dumps({'state':'written','record_sha256':hashlib.sha256(wire).hexdigest(),
                          'qualification':json.loads(wire)['qualification']},sort_keys=True))
        return 0
    except Refused as exc:
        print(json.dumps({'state':'not_confirmed','reason':str(exc)}))
        return 1
    except (OSError,ValueError,KeyError,TypeError,AttributeError,RecursionError):
        print(json.dumps({'state':'refused','reason':'qualification_not_confirmed'}))
        return 1


if __name__=='__main__':
    raise SystemExit(main())
