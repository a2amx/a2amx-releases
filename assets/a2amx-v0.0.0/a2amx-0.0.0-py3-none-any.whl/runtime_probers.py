"""Bounded vendor-handle proof inputs for the SDK adapter-host architecture.

Claude keeps its reviewed predeclared transcript probe only for the legacy
drill path.  Native Claude, Codex, and Gemini SDKs create the vendor handle
inside the per-seat adapter host.  The
host reports one closed ``SDK_HANDLE_OBSERVED`` value after SDK creation and
the supervisor validates it here before signing the registry's separate
``HANDLE_ATTESTATION`` frame.

This module validates an observation; it does not claim that the vendor has
proved live exclusive ownership.  That real-vendor obligation remains open
until the Phase 3/7 live matrix exercises the authenticated control channel.
"""
from __future__ import annotations

import json
import math
import os
import re
import time
from pathlib import Path
from typing import Any, Dict

PROBE_TIMEOUT_DEFAULT = 20.0
PROBE_TIMEOUT_MAX = 300.0
SDK_HANDLE_OBSERVATION_SCHEMA = 1
SDK_HANDLE_OBSERVATION_MAX_BYTES = 4096
SDK_HANDLE_PROOF_KIND = {
    "claude": "claude_sdk_session",
    "codex": "codex_sdk_thread",
    "gemini": "antigravity_session",
}
_SDK_HANDLE_OBSERVATION_KEYS = frozenset({
    "schema_version", "type", "seat", "attempt_id", "runtime_id",
    "generation", "attempt_sha256", "family", "host_pid", "handle",
    "exclusive", "proof_kind", "proof_ref", "assurance",
})
_SDK_HANDLE_PROBE_REQUIRED_KEYS = frozenset({
    "kind", "observation", "seat", "attempt_id", "runtime_id",
    "generation", "attempt_sha256",
})
_SDK_HANDLE_PROBE_ALLOWED_KEYS = (
    _SDK_HANDLE_PROBE_REQUIRED_KEYS | frozenset({"not_before", "timeout"}))


class ProbeError(RuntimeError):
    """A handle observation failed closed or was ambiguous."""


def _deadline(cfg: Dict[str, Any]) -> float:
    timeout = cfg.get("timeout", PROBE_TIMEOUT_DEFAULT)
    if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) \
            or not math.isfinite(timeout) or timeout <= 0 \
            or timeout > PROBE_TIMEOUT_MAX:
        raise ProbeError(
            f"probe timeout must be finite in (0, {PROBE_TIMEOUT_MAX}], got {timeout!r}")
    return time.monotonic() + float(timeout)


def _nap(end: float, interval: float) -> None:
    remaining = end - time.monotonic()
    if remaining > 0:
        time.sleep(min(interval, remaining))


def _require(cfg: Dict[str, Any], key: str) -> str:
    value = cfg.get(key)
    if not isinstance(value, str) or not value:
        raise ProbeError(f"handle_probe.{key} required")
    return value


def _created_after(path: Path, not_before: float) -> bool:
    try:
        stat = os.stat(path)
    except OSError:
        return False
    created = getattr(stat, "st_birthtime", None)
    if created is None:
        created = stat.st_mtime
    return created >= not_before


def sanitize_claude_project(cwd: str) -> str:
    """Claude transcript directory spelling for one absolute cwd."""
    return re.sub(r"[^A-Za-z0-9]", "-", cwd)


def baseline_clear(cfg: Dict[str, Any]) -> bool:
    """Reject a planted Claude transcript before the legacy child exists."""
    if cfg.get("kind") != "claude":
        return True
    sid = _require(cfg, "session_id")
    cwd = _require(cfg, "cwd")
    root = Path(cfg.get("projects_root")
                or os.path.expanduser("~/.claude/projects"))
    return not (root / sanitize_claude_project(cwd) / f"{sid}.jsonl").exists()


def probe_claude(cfg: Dict[str, Any], child_pid: int) -> Dict[str, Any]:
    """Verify the exact launch-minted Claude transcript UUID."""
    del child_pid
    sid = _require(cfg, "session_id")
    cwd = _require(cfg, "cwd")
    root = Path(cfg.get("projects_root")
                or os.path.expanduser("~/.claude/projects"))
    path = root / sanitize_claude_project(cwd) / f"{sid}.jsonl"
    not_before = cfg.get("not_before")
    end = _deadline(cfg)
    while time.monotonic() < end:
        if path.is_file() and (not_before is None
                               or _created_after(path, not_before)):
            return {"kind": "session_uuid", "ref": sid}
        _nap(end, 0.2)
    raise ProbeError(
        f"claude transcript for predeclared session {sid} never appeared "
        f"(post-spawn) at {path}")


def _clean_string(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value \
            or any(char in value for char in "\r\n\0"):
        raise ProbeError(f"{label} must be a clean non-empty string")
    return value


def validate_sdk_handle_observation(
        observation: Any, *, family: str, host_pid: int,
        seat: str, attempt_id: str, runtime_id: str, generation: int,
        attempt_sha256: str) -> Dict[str, Any]:
    """Validate one post-SDK-creation observation from the named host.

    The expected attempt identity is mandatory supervisor context; the later
    attestation authenticates and persists that already-exact binding. Keeping
    this value closed and bounded prevents a beta SDK payload from becoming an
    unbound, unbounded, or ambiguous registry input.
    """
    if family not in SDK_HANDLE_PROOF_KIND:
        raise ProbeError("SDK host observation family must be codex or gemini")
    if isinstance(host_pid, bool) or not isinstance(host_pid, int) or host_pid <= 0:
        raise ProbeError("SDK host observation requires a positive host pid")
    expected_identity = {
        "seat": _clean_string(seat, "SDK probe seat"),
        "attempt_id": _clean_string(attempt_id, "SDK probe attempt_id"),
        "runtime_id": _clean_string(runtime_id, "SDK probe runtime_id"),
        "generation": generation,
        "attempt_sha256": attempt_sha256,
    }
    if isinstance(generation, bool) or not isinstance(generation, int) or generation <= 0:
        raise ProbeError("SDK probe generation must be a positive integer")
    if not isinstance(attempt_sha256, str) or len(attempt_sha256) != 64 \
            or any(char not in "0123456789abcdef" for char in attempt_sha256):
        raise ProbeError("SDK probe attempt_sha256 must be a SHA-256 digest")
    if not isinstance(observation, dict) \
            or set(observation) != _SDK_HANDLE_OBSERVATION_KEYS:
        raise ProbeError("SDK_HANDLE_OBSERVED has a non-closed shape")
    try:
        raw = json.dumps(
            observation, sort_keys=True, separators=(",", ":"),
            ensure_ascii=False, allow_nan=False).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise ProbeError("SDK_HANDLE_OBSERVED is not strict JSON") from exc
    if len(raw) > SDK_HANDLE_OBSERVATION_MAX_BYTES:
        raise ProbeError("SDK_HANDLE_OBSERVED exceeds the bounded size")
    if observation.get("schema_version") != SDK_HANDLE_OBSERVATION_SCHEMA \
            or observation.get("type") != "SDK_HANDLE_OBSERVED":
        raise ProbeError("SDK_HANDLE_OBSERVED schema/type mismatch")
    for key in ("seat", "attempt_id", "runtime_id"):
        _clean_string(observation.get(key), f"SDK_HANDLE_OBSERVED.{key}")
    observed_generation = observation.get("generation")
    if isinstance(observed_generation, bool) \
            or not isinstance(observed_generation, int) or observed_generation <= 0:
        raise ProbeError("SDK_HANDLE_OBSERVED.generation must be a positive integer")
    observed_digest = observation.get("attempt_sha256")
    if not isinstance(observed_digest, str) or len(observed_digest) != 64 \
            or any(char not in "0123456789abcdef" for char in observed_digest):
        raise ProbeError("SDK_HANDLE_OBSERVED.attempt_sha256 must be a SHA-256 digest")
    for key, expected in expected_identity.items():
        if observation.get(key) != expected:
            raise ProbeError(f"SDK_HANDLE_OBSERVED.{key} is not this attempt")
    if observation.get("family") != family:
        raise ProbeError("SDK_HANDLE_OBSERVED crossed adapter families")
    if observation.get("host_pid") != host_pid:
        raise ProbeError("SDK_HANDLE_OBSERVED is not from the observed adapter host")
    if observation.get("exclusive") is not True:
        raise ProbeError("SDK_HANDLE_OBSERVED does not claim exclusive adoption")
    expected_proof = SDK_HANDLE_PROOF_KIND[family]
    if observation.get("proof_kind") != expected_proof:
        raise ProbeError("SDK_HANDLE_OBSERVED proof kind does not match the family")
    _clean_string(observation.get("proof_ref"), "SDK_HANDLE_OBSERVED.proof_ref")
    try:
        import runtime_registry as rr
        handle = rr.validate_handle(observation.get("handle"))
        assurance = rr.validate_handle_assurance(
            observation.get("assurance"), family=family)
    except Exception as exc:
        raise ProbeError(f"SDK_HANDLE_OBSERVED proof is invalid: {exc}") from exc
    if handle["kind"] != "session_uuid":
        raise ProbeError("SDK host observations must carry a session_uuid handle")
    return {**observation, "handle": handle, "assurance": assurance}


def _probe_sdk(cfg: Dict[str, Any], child_pid: int, *,
               family: str, kind: str) -> Dict[str, Any]:
    keys = set(cfg) if isinstance(cfg, dict) else set()
    if not isinstance(cfg, dict) \
            or not _SDK_HANDLE_PROBE_REQUIRED_KEYS <= keys \
            or not keys <= _SDK_HANDLE_PROBE_ALLOWED_KEYS:
        raise ProbeError("SDK handle probe configuration has a non-closed shape")
    if cfg.get("kind") != kind:
        raise ProbeError("SDK handle probe kind does not match its family")
    # The supervisor adds spawn time after GO and the parser permits one
    # bounded timeout. They are known control metadata, never attempt identity;
    # validate them explicitly while preserving the mandatory closed core.
    not_before = cfg.get("not_before")
    if not_before is not None and (
            isinstance(not_before, bool)
            or not isinstance(not_before, (int, float))
            or not math.isfinite(not_before) or not_before <= 0):
        raise ProbeError("SDK handle probe not_before must be finite and positive")
    if "timeout" in cfg:
        _deadline({"timeout": cfg["timeout"]})
    clean = validate_sdk_handle_observation(
        cfg["observation"], family=family, host_pid=child_pid,
        seat=cfg["seat"], attempt_id=cfg["attempt_id"],
        runtime_id=cfg["runtime_id"], generation=cfg["generation"],
        attempt_sha256=cfg["attempt_sha256"])
    return clean["handle"]


def probe_codex_sdk(cfg: Dict[str, Any], child_pid: int) -> Dict[str, Any]:
    return _probe_sdk(cfg, child_pid, family="codex", kind="codex_sdk")


def probe_antigravity(cfg: Dict[str, Any], child_pid: int) -> Dict[str, Any]:
    return _probe_sdk(
        cfg, child_pid, family="gemini", kind="gemini_antigravity")


PROBERS = {
    "claude": probe_claude,
    "codex_sdk": probe_codex_sdk,
    "gemini_antigravity": probe_antigravity,
}


def probe(cfg: Dict[str, Any], child_pid: int) -> Dict[str, Any]:
    kind = (cfg or {}).get("kind")
    function = PROBERS.get(kind)
    if function is None:
        raise ProbeError(f"no vendor prober for kind {kind!r}")
    return function(cfg, child_pid)
