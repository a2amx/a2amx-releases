"""Memory-only, same-user local observation of the running daemon (row 633).

One request, one closed response, no pane text and no operation that writes state.
The socket inode is not a snapshot. A new daemon incarnation uses a different
path, so it neither adopts nor deletes another incarnation's socket.
"""
import json
import math
import os
from pathlib import Path
import re
import socket
import stat
import subprocess
import sys
import threading
import time

from pane_state import CLASSES, valid_reset_time

REQUEST = b'{"v":1}\n'
MAX_REPLY = 65536
TIMEOUT = 0.25
BIND_HELPER_TIMEOUT = 2.0
MAX_AGE = 15.0


def _address(sock, path, operation):
    """Keep the socket in the control directory even with a long HOME path.

    AF_UNIX limits the address string, not its directory's absolute location.
    A short-lived isolated helper uses the same socket fd with cwd=that directory;
    the daemon/panel never changes its process-wide cwd. It inherits no secrets.
    """
    if operation not in {"bind", "connect"}:
        raise ValueError("invalid socket operation")
    if len(os.fsencode(path)) < 100:
        getattr(sock, operation)(str(path))
        return
    program = ("import socket,sys; s=socket.socket(fileno=int(sys.argv[1])); "
               + "s." + operation + "(sys.argv[2]); s.detach()")
    result = subprocess.run([sys.executable, "-I", "-c", program, str(sock.fileno()), path.name],
        cwd=path.parent, env={"PATH": os.defpath}, pass_fds=(sock.fileno(),),
        capture_output=True, timeout=BIND_HELPER_TIMEOUT if operation == "bind" else TIMEOUT, check=False)
    if result.returncode or result.stdout or result.stderr:
        raise OSError("local observation socket unavailable")


def private_root():
    # Never create/repair from a panel read. First-run already owns this path.
    from product_identity import state_root
    path = state_root() / "run"
    for parent in (path.parent, path):
        st = parent.lstat()
        if (not stat.S_ISDIR(st.st_mode) or st.st_uid != os.getuid()
                or stat.S_IMODE(st.st_mode) != 0o700):
            raise ValueError("private service-control directory unavailable")
    return path


def endpoint(root, identity):
    instance = identity.get("instance")
    if not isinstance(instance, str) or not re.fullmatch(r"[0-9a-f]{32}", instance):
        raise ValueError("invalid daemon instance")
    return root / ("pane-" + instance[:16] + ".sock")


def _json(raw):
    def pairs(items):
        value = {}
        for key, item in items:
            if key in value:
                raise ValueError("duplicate response key")
            value[key] = item
        return value
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError("non-finite response")))


def validate(value, identity, *, now):
    if (not isinstance(value, dict) or set(value) != {"v", "pid", "proc_birth", "instance", "seats"}
            or type(value["v"]) is not int or value["v"] != 1
            or type(value["pid"]) is not int
            or any(value[k] != identity[k] for k in ("pid", "proc_birth", "instance"))
            or not isinstance(value["seats"], list) or len(value["seats"]) > 128):
        raise ValueError("unmatched daemon response")
    seen = set()
    for row in value["seats"]:
        if (not isinstance(row, dict) or set(row) != {"seat", "binding", "class", "changed_at", "measured_at", "reset_time"}
                or not isinstance(row["seat"], str) or not 1 <= len(row["seat"]) <= 128
                or any(ord(c) < 32 for c in row["seat"]) or row["seat"] in seen
                or not isinstance(row["binding"], str) or not re.fullmatch(r"[0-9a-f]{64}", row["binding"])
                or not isinstance(row["class"], str) or row["class"] not in CLASSES
                or not valid_reset_time(row["reset_time"])):
            raise ValueError("invalid pane-state row")
        seen.add(row["seat"])
        changed, measured = row["changed_at"], row["measured_at"]
        if (any(type(v) not in (int, float) or not math.isfinite(v) for v in (changed, measured))
                or not 0 <= changed <= measured <= now or now - measured >= MAX_AGE):
            raise ValueError("stale pane-state measurement")
    return value["seats"]


class Server:
    def __init__(self, identity, projection):
        self.identity = {k: identity[k] for k in ("pid", "proc_birth", "instance")}
        self.projection = projection
        self.socket = None
        self.thread = None
        self.stop = threading.Event()
        self.path = None
        self.inode = None

    def __enter__(self):
        self.path = endpoint(private_root(), self.identity)
        self.socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            _address(self.socket, self.path, "bind")  # refuses any existing target
            self.inode = self.path.lstat().st_ino
            os.chmod(self.path, 0o600)
            self.socket.listen(4)
            self.socket.settimeout(TIMEOUT)
            self.thread = threading.Thread(target=self._serve, name="pane-state-read", daemon=True)
            self.thread.start()
        except BaseException:
            # A timed-out helper may have bound the shared fd before it was
            # stopped. Adopt only that fd's own binding for cleanup, never an
            # existing socket that caused bind() to fail.
            try:
                if self.socket.getsockname() in {str(self.path), self.path.name}:
                    self.inode = self.path.lstat().st_ino
            except OSError:
                pass
            self.__exit__()
            raise
        return self

    def _serve(self):
        while not self.stop.is_set():
            try:
                connection, _ = self.socket.accept()
            except TimeoutError:
                continue
            except OSError:
                return
            with connection:
                try:
                    end = time.monotonic() + TIMEOUT
                    connection.settimeout(TIMEOUT)
                    data = bytearray()
                    while not data.endswith(b"\n") and len(data) <= len(REQUEST):
                        connection.settimeout(max(0.001, end - time.monotonic()))
                        if time.monotonic() >= end:
                            raise TimeoutError
                        chunk = connection.recv(len(REQUEST) + 1 - len(data))
                        if not chunk:
                            break
                        data.extend(chunk)
                    if data != REQUEST:
                        continue
                    value = {"v": 1, **self.identity, "seats": self.projection()}
                    # Closed schema applies at BOTH ends. Never serialize unexpected text.
                    # A stale seat invalidates that observation, not other fresh seats.
                    value["seats"] = [r for r in value["seats"] if time.monotonic() - r["measured_at"] < MAX_AGE]
                    validate(value, self.identity, now=time.monotonic())
                    raw = json.dumps(value, allow_nan=False).encode() + b"\n"
                    if len(raw) <= MAX_REPLY:
                        connection.settimeout(max(0.001, end - time.monotonic()))
                        connection.sendall(raw)
                except (OSError, ValueError, TypeError, KeyError, OverflowError):
                    pass  # No error payload or log can disclose pane/adapter content.

    def __exit__(self, *_):
        self.stop.set()
        if self.socket is not None:
            self.socket.close()
        if self.thread is not None:
            self.thread.join(TIMEOUT * 3)
        if self.path is not None and self.inode is not None:
            try:
                st = self.path.lstat()
                if st.st_ino == self.inode and stat.S_ISSOCK(st.st_mode) and st.st_uid == os.getuid():
                    self.path.unlink()
            except FileNotFoundError:
                pass


class ObservationService:
    """Missing control directory degrades observation, not durable mail service."""
    def __init__(self, identity, projection, log):
        self.server = Server(identity, projection)
        self.log = log

    def __enter__(self):
        try:
            self.server.__enter__()
        except (OSError, ValueError, subprocess.SubprocessError):
            self.log("pane-state observation socket unavailable")
        return self

    def __exit__(self, *_):
        self.server.__exit__()


def read_snapshot():
    """Fresh bounded read for CLI/web; any uncertainty yields no verified snapshot."""
    import service_lifecycle as lifecycle
    import store
    lease = None
    try:
        root = private_root()
        lease = lifecycle.Lease(store.STORE_DIR, "daemon", observe=True)
        identity = lease.read()
        if not lease.held():
            return None
        seen = lifecycle.process(identity["pid"], timeout=TIMEOUT)
        if (seen is None or seen["uid"] != os.getuid() or seen["state"].startswith("Z")
                or seen["birth"] != identity["proc_birth"]
                or not lifecycle.command_matches("daemon", seen["command"])):
            return None
        bound, _ = store.read_locator()
        if bound != store.STORE_DIR:
            return None
        path = endpoint(root, identity)
        st = path.lstat()
        if (not stat.S_ISSOCK(st.st_mode) or st.st_uid != os.getuid()
                or stat.S_IMODE(st.st_mode) != 0o600):
            return None
        end = time.monotonic() + TIMEOUT
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
            client.settimeout(TIMEOUT)
            _address(client, path, "connect")
            client.sendall(REQUEST)
            raw = bytearray()
            while len(raw) <= MAX_REPLY:
                remaining = end - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError
                client.settimeout(remaining)
                chunk = client.recv(min(8192, MAX_REPLY + 1 - len(raw)))
                if not chunk:
                    break
                raw.extend(chunk)
            if len(raw) > MAX_REPLY or not raw.endswith(b"\n"):
                return None
        current = path.lstat()
        if ((current.st_dev, current.st_ino, current.st_mode, current.st_uid)
                != (st.st_dev, st.st_ino, st.st_mode, st.st_uid)
                or lease.read() != identity or not lease.held()):
            return None
        value = _json(raw)
        validate(value, identity, now=time.monotonic())
        return value
    except (OSError, ValueError, TypeError, KeyError, OverflowError, subprocess.SubprocessError, lifecycle.Refused):
        return None
    finally:
        if lease is not None:
            lease.close()


def read():
    snapshot = read_snapshot()
    return snapshot["seats"] if snapshot is not None else []
