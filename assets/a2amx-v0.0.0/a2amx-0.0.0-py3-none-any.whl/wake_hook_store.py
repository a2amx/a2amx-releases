"""Authenticated UserPromptSubmit receipt and durable full-body hook fetch.

This is the store-side seam. The harness never reads log.jsonl. No hook post
settles a daemon attempt or exercises decision authority.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import tempfile
import time
import uuid

import receipts
import store
from wake_hook_core import pointer_line

FIELDS = frozenset({'event', 'pointer', 'session_ref', 'session_id'})


def _route(parts, actor, session_ref):
    route = (parts.get(actor) or {}).get('wake_route')
    return (route if isinstance(route, dict) and route.get('session_ref') == session_ref
            and route.get('kind') in {'inapp-socket', 'codex-ipc', 'agy-desktop'} else None)


def post(payload, *, presented_token, expected_actor=None, clock=time.time):
    def apply(actor):
        reason = None
        route = None
        if not isinstance(payload, dict) or set(payload) != FIELDS:
            reason = 'event_schema'
        elif payload.get('event') not in {'UserPromptSubmit', 'PreInvocation'}:
            reason = 'event_kind'
        elif pointer_line(payload.get('pointer')) != payload.get('pointer') or payload.get('pointer') is None:
            reason = 'invalid_pointer'
        elif not isinstance(payload.get('session_id'), str) or not payload['session_id']:
            reason = 'session_id_required'
        else:
            route = _route(store._read_participants_unlocked(), actor, payload.get('session_ref'))
            if route is None:
                reason = 'session_ref_mismatch'
            elif payload.get('event') == 'PreInvocation' and route.get('kind') != 'agy-desktop':
                reason = 'event_kind'
            elif payload.get('event') == 'UserPromptSubmit' and route.get('kind') == 'agy-desktop':
                reason = 'event_kind'
        with receipts._nudge_lock():
            if reason is None:
                mid = payload['pointer'].removeprefix('mail: ')
                message = receipts._select_messages({mid}).get(mid)
                if message is None or actor not in message.get('recipients', message.get('to', [])):
                    reason = 'pointer_not_addressed'
            if reason is not None:
                row = {'kind': 'seat-event-refused', 'seat': actor,
                       'event': 'UserPromptSubmit' if isinstance(payload, dict) and payload.get('event') == 'UserPromptSubmit' else 'unsupported',
                       'reason': reason, 'epoch': clock(), 'ts': store.now_iso()}
                receipts._append(row)
                return {'accepted': False, 'reason': reason}
            import hashlib
            generation = hashlib.sha256(json.dumps(route, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
            row = {'kind': 'seat_event', 'seat': actor, **payload,
                   'event-id': 'hook-' + uuid.uuid4().hex, 'generation': generation,
                   'epoch': clock(), 'ts': store.now_iso()}
            receipts._append(row)
            return {'accepted': True, 'event-id': row['event-id'], 'generation': generation}
    return store.authenticated_registry_act(presented_token, apply, expected_actor=expected_actor)


def _save_batch(home, messages):
    """Durable file first; a crash here cannot commit FETCHED."""
    home = Path(home)
    if not home.is_absolute() or home.resolve() != home:
        raise ValueError('hook home must be canonical')
    target = home / '.orch' / 'inbox'
    for directory in [home / '.orch', target]:
        if directory.is_symlink():
            raise ValueError('hook inbox path is a symlink')
        directory.mkdir(mode=0o700, exist_ok=True)
        parent_fd = os.open(directory.parent, os.O_RDONLY)
        try:
            os.fsync(parent_fd)
        finally:
            os.close(parent_fd)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    destination = target / ('hook-' + stamp + '-' + uuid.uuid4().hex + '.json')
    fd, temp = tempfile.mkstemp(prefix='.hook-', dir=target)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            json.dump(messages, stream, ensure_ascii=False)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, destination)
        fd = os.open(target, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
        return str(destination)
    finally:
        Path(temp).unlink(missing_ok=True)


def fetch(*, presented_token, home, session_ref, expected_actor=None, save_batch=_save_batch, harness=None, via="hook", agy_invocation=None):
    if via not in {"hook", "inbox"}:
        raise ValueError("invalid fetch source")
    import harness_facts
    facts = harness_facts.validate(harness) if harness is not None else None
    def apply(actor):
        # A refused event still fetches under the seat's authenticated identity.
        # A mismatched/undeclared session is recorded as such, never substituted
        # with the declared identity and never accepted by daemon reconciliation.
        participants = store._read_participants_unlocked()
        agy_wake_route = agy_recovery = None
        if agy_invocation is not None:
            from desktop_support import optional
            agy_wake_route = optional('agy_wake_route')
            agy_recovery = optional('agy_recovery')
            if agy_wake_route is None or agy_recovery is None:
                return {'accepted': False, 'reason': 'desktop_not_offered'}
        expected_home = store.seat_home(actor, override=(participants.get(actor) or {}).get('workspace_dir')).resolve()
        requested_home = expected_home if home is None and via == 'inbox' else Path(home)
        # Registry spelling can differ on a case-insensitive filesystem. Keep
        # requested-path checks; seat_home also places tokens/route credentials.
        try:
            home_matches = (requested_home.is_absolute()
                            and requested_home.resolve() == requested_home
                            and requested_home.is_dir()
                            and requested_home.samefile(expected_home))
        except (OSError, ValueError):
            home_matches = False
        if not home_matches:
            raise ValueError('hook home must equal the registered seat home')
        if agy_invocation is not None and (type(agy_invocation) is not int
                                          or agy_invocation < 0 or via != 'hook'):
            return {'accepted':False, 'reason':'session_ref_mismatch'}
        declaration = None
        neutral_grounding = False
        if agy_invocation == 0 and type(agy_invocation) is int:
            try:
                valid_conversation = False
                if (isinstance(session_ref, dict) and set(session_ref) == {'conversation_id'}
                        and isinstance(session_ref['conversation_id'], str)):
                    try:
                        valid_conversation = str(uuid.UUID(session_ref['conversation_id'])) == session_ref['conversation_id']
                    except ValueError:
                        pass
                if not valid_conversation:
                    raise ValueError('agy_conversation_id_missing_or_invalid')
                started = agy_wake_route.from_hook(actor, home=requested_home,
                    conversation_id=session_ref['conversation_id'], presented_token=presented_token)
                import seat_grounding
                neutral_grounding = seat_grounding.is_neutral(seat_grounding.current(actor, required=False))
                if started['initial_declaration']:
                    declaration = {'seat':actor, 'kind':'agy-desktop',
                                   'conversation_id':session_ref['conversation_id'],
                                   'generation':started['receipt']['generation'],
                                   'grounding_generation':started['receipt']['grounding_generation']}
                participants = store._read_participants_unlocked()
            except (OSError, ValueError, store.SeatActWithoutReceipt) as exc:
                allowed = {'session_ref_mismatch', 'agy_route_unreceipted',
                           'agy_initial_declaration_not_installed', 'grounding_record_missing',
                           'grounding_record_invalid', 'grounding_active_seat_required',
                           'agy_grounding_files_missing_or_unsafe',
                           'agy_route_history_requires_explicit_declaration',
                           'agy_conversation_id_missing_or_invalid'}
                reason = str(exc) if str(exc) in allowed else 'agy_declaration_failed_inspect_receipts'
                return {'accepted':False, 'reason':reason}
        route = _route(participants, actor, session_ref)
        if agy_invocation is not None:
            if (type(agy_invocation) is not int or agy_invocation < 0 or via != 'hook'
                    or route is None or route.get('kind') != 'agy-desktop'):
                return {'accepted':False,'reason':'session_ref_mismatch'}
        expected_route = (participants.get(actor) or {}).get('wake_route')
        if session_ref is not None and route is None:
            if isinstance(session_ref, dict) and set(session_ref.keys()) == {'conversation_id'}:
                return {'accepted': False, 'reason': 'session_ref_mismatch'}
        session_ref_observed = route['session_ref'] if route else None
        inbox = None
        def save(messages):
            nonlocal inbox
            if agy_invocation is not None and not messages:
                return
            inbox = save_batch(str(requested_home), messages)
            if agy_invocation is not None:
                agy_recovery.retain(requested_home,messages,inbox)
        messages = store.drain_inbox(actor, before_commit=save,
                                     fetch_metadata=({'via': 'hook', 'session_ref': session_ref_observed}
                                                     if via == 'hook' else None))
        result = {'messages': messages, 'inbox_path': inbox}
        if agy_invocation is None and via == 'hook' and store.normalize_family(
                (participants.get(actor) or {}).get('family')) == 'codex':
            import seat_grounding
            result['route_bound'] = route is not None
            result['neutral_grounding'] = seat_grounding.is_neutral(
                seat_grounding.current(actor, required=False))
        if neutral_grounding:
            result['grounding_notice'] = 'ORCH neutral grounding: no expectations adopted; nothing is compared.\n'
        if declaration is not None:
            result['declaration'] = declaration
        if agy_invocation is not None:
            result['recovery_notice']=agy_recovery.notice(requested_home)
            # Delivery-observation rows describe nonempty committed fetches.
            # An empty authenticated invocation gets its seat-act below.
            if messages:
                receipts._append({'kind':'agy-hook-observation','seat':actor,
                                  'session_ref':session_ref,'invocation_num':agy_invocation,
                                  'msg-ids':[m['id'] for m in messages],
                                  'event-id':'hook-'+uuid.uuid4().hex,'ts':store.now_iso()})
        if facts is not None:
            try:
                harness_facts.append_act(actor, 'hook-fetch' if via == 'hook' else 'inbox', facts)
                result['harness_reported'] = True
            except Exception:
                # Mail is already durable and consumed. Optional telemetry must
                # not turn successful delivery into a retry that finds no mail.
                result['harness_reported'] = False
        elif agy_invocation is not None and not messages:
            # CLI inbox records this activity even when there is no mail. The
            # AGY CLI entry point excludes a second generic activity append.
            try:
                with receipts._nudge_lock():
                    receipts._append({'kind': 'seat-act', 'seat': actor,
                                      'command': 'hook-fetch', 'ts': store.now_iso()})
                result['activity_reported'] = True
            except Exception:
                # Cursor refresh already happened, as on the CLI path. Report
                # missing observation without recasting it as failed delivery.
                result['activity_reported'] = False
        return result
    return store.authenticated_registry_act(presented_token, apply, expected_actor=expected_actor)
