"""Read-only digest defaults; local overrides live in store/digest_config.json.

Context windows: Anthropic model overview, consulted 2026-09-22. Exact keys
only: no guesses from model prefixes, aliases, or an unmeasured harness.
"""
MODEL_WINDOWS = {
    'claude-fable-5-1': 1_000_000,
    'claude-opus-5': 1_000_000,
    'claude-sonnet-5': 1_000_000,
    'claude-haiku-4-5-20251001': 200_000,
}
POINTER_WINDOW_SECONDS = 720
