"""Shared durable AGY intent records; no desktop adapter or native operation.

Core recall recovery must remain available in CLI-only installations. These
record primitives are also the optional bridge's writer/reader implementation.
"""
import json
import math
import os
from pathlib import Path
import re
import stat
import tempfile

import store

SCHEMA = 'orch.agy-bridge.v1'
EVENT = re.compile(r'evt-[0-9a-f]{32}', re.ASCII)
MAX_RECORD = 16384


def root():
    return store.STORE_DIR / 'agy-outbox'


def safe_path(path):
    path = Path(path)
    if not path.is_absolute() or path.resolve() != path:
        raise ValueError('noncanonical bridge path')
    return path


def read_json(path, *, missing=None, limit=MAX_RECORD):
    path = safe_path(path)
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except FileNotFoundError:
        return missing
    with os.fdopen(fd, 'rb') as f:
        if not stat.S_ISREG(os.fstat(f.fileno()).st_mode):
            raise ValueError('bridge file is not regular')
        data = f.read(limit + 1)
    if len(data) > limit:
        raise ValueError('bridge record too large')
    value = json.loads(data)
    if not isinstance(value, dict):
        raise ValueError('bridge record must be an object')
    return value


def atomic_json(path, value):
    path = safe_path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, name = tempfile.mkstemp(prefix='.agy-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(value, f, sort_keys=True, ensure_ascii=True)
            f.write('\n')
            f.flush()
            os.fsync(f.fileno())
        os.replace(name, path)
        store._fsync_dir(path.parent)
    finally:
        Path(name).unlink(missing_ok=True)


def record_path(event_id, suffix):
    if not isinstance(event_id, str) or EVENT.fullmatch(event_id) is None:
        raise ValueError('invalid bridge event id')
    return root() / 'intents' / (event_id + '.' + suffix + '.json')


def new_record(row, suffix, **extra):
    return {'schema': SCHEMA, 'kind': suffix, 'terminal_at': row.get('terminal_at'),
            **{k: row[k] for k in ('seat', 'event_id', 'pre_id', 'bridge_id', 'generation', 'operation', 'conversation_id', 'workspace_uri', 'project_id')},
            **extra}



def withdraw_recalled(pre, epoch):
    """Under nudge.lock, cancel an existing unclaimed intent; never native input.

    A missing intent is normal historical state. A present malformed or
    misbound intent remains a strict materialization failure; no guessed row
    is written. A claim slot is never overwritten or treated as unclaimed.
    """
    eid = pre['event-id']
    row = read_json(record_path(eid, 'intent'))
    if row is None:
        return
    expected = {'schema': SCHEMA, 'kind': 'intent', 'event_id': eid,
                'pre_id': pre.get('pre-id'), 'seat': pre['target seat'],
                'generation': pre.get('generation'), 'operation': 'deliver',
                'pointer': 'mail: ' + pre['msg-id']}
    if any(row.get(k) != v for k, v in expected.items()):
        raise ValueError('recall intent binding mismatch')
    if any(not isinstance(row.get(k), str) or not row[k]
           for k in ('bridge_id', 'conversation_id', 'workspace_uri', 'project_id')):
        raise ValueError('recall intent identity incomplete')
    if (type(row.get('created_at')) not in (int, float)
            or not math.isfinite(row['created_at']) or epoch < row['created_at']):
        raise ValueError('recall intent time mismatch')
    if os.path.lexists(record_path(eid, 'claim')):
        return  # Even torn claim evidence precludes a new unclaimed action.
    prior = read_json(record_path(eid, 'withdrawn'))
    record = new_record(row, 'withdrawn', reason='recalled', epoch=epoch)
    if prior is not None:
        if any(prior.get(k) != v for k, v in new_record(row, 'withdrawn').items()):
            raise ValueError('recall withdrawal binding mismatch')
        return
    atomic_json(record_path(eid, 'withdrawn'), record)
