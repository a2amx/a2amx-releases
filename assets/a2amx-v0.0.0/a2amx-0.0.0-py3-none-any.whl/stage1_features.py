"""Named refusals for execution surfaces not offered by the public profile."""
from __future__ import annotations

from importlib import metadata
from pathlib import Path
import tomllib

FEATURES = frozenset({"principal_credentials", "terminal_agents", "codex_desktop", "sdk_adapters"})


class NotOffered(ValueError):
    pass


def _public():
    try:
        import product_identity
    except ModuleNotFoundError as exc:
        if exc.name != "product_identity":
            raise
        # Compatibility for the pre-profile private source/wheel on this review
        # base. A public project without its profile is never treated as private.
        here = Path(__file__).resolve()
        try:
            project = tomllib.loads((here.parent / "pyproject.toml").read_text())["project"]
            if project.get("name") == "psqr-agentic-hub":
                return False
        except (OSError, ValueError, KeyError):
            pass
        try:
            dist = metadata.distribution("psqr-agentic-hub")
            if Path(dist.locate_file("stage1_features.py")).resolve() == here and "stage1_features.py" in {str(p) for p in dist.files or ()}:
                return False
        except metadata.PackageNotFoundError:
            pass
        raise NotOffered("product_configuration_unavailable") from None
    return product_identity.load().is_public


def require_private(feature):
    if feature not in FEATURES:
        raise ValueError("unknown_private_feature")
    if _public():
        raise NotOffered("feature_not_offered:" + feature)
