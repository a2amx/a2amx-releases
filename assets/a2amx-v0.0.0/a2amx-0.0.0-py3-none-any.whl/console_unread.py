"""D-CON-14 slice 1: a read-only, body-free unread snapshot and two filters."""
from collections import Counter
from html import escape


def summary(rows):
    """Count the very rows rendered below the summary, in the same group order."""
    counts = Counter((row['recipient'], row['sender']) for row in rows)
    return [{'recipient': recipient, 'sender': sender, 'count': count}
            for (recipient, sender), count in sorted(counts.items())]


def render(ledger):
    """Render already-sanitized ledger rows; filters never request or consume mail."""
    rows, cutover = ledger["rows"], ledger["cutover"]
    overdue_rows = [{**row, 'sender': row.get('sender', 'Unknown')} for row in ledger.get('accepted_no_fetch', [])]
    hook_rows = [{**row, 'sender': row.get('sender', 'Unknown')}
                 for row in ledger.get('hook_deliveries', [])]

    def text(value):
        return escape(str(value), quote=True)

    def attrs(row):
        return (f'data-recipient="{text(row["recipient"])}" '
                f'data-sender="{text(row["sender"])}"')

    def options(key):
        return ''.join(f'<option value="{text(value)}">{text(value)}</option>'
                       for value in sorted({row[key] for row in [*rows, *hook_rows, *overdue_rows]}))

    def age(seconds):
        if seconds is None:
            return 'Unknown'
        if seconds < 60:
            return f'{seconds}s'
        if seconds < 3600:
            return f'{seconds // 60}m'
        if seconds < 86400:
            return f'{seconds // 3600}h {(seconds % 3600) // 60}m'
        return f'{seconds // 86400}d {(seconds % 86400) // 3600}h'

    groups = ''.join(
        f'<tr {attrs(row)}><th scope="row">{text(row["recipient"])}</th>'
        f'<td>{text(row["sender"])}</td><td class="number">{row["count"]}</td></tr>'
        for row in summary(rows))
    messages = ''.join(
        f'<tr {attrs(row)}><th scope="row">{text(row["recipient"])}</th>'
        f'<td>{text(row["sender"])}</td><td><code>{text(row["id"])}</code></td>'
        f'<td><time>{text(row["ts"])}</time></td>'
        f'<td>{age(row["age_seconds"])}</td><td>—</td></tr>' for row in rows)
    boundary = (f'unread since {text(cutover)}: the receipts cutover' if cutover is not None
                else 'Receipts cutover not recorded; unread ledger unavailable.')
    hooked = ''.join('<tr '+attrs(row)+'><td>'+text(row['recipient'])+'</td><td>'+text(row['sender'])+'</td><td><code>'+text(row['id'])+
        '</code></td><td>'+('delivered to the turn, no act of the seat observed'
        if row['state']=='hook_fetched_no_seat_act' else 'delivered to the turn; later seat act observed')+
        '</td></tr>' for row in hook_rows)
    overdue = ''.join('<tr '+attrs(row)+'><td>'+text(row['recipient'])+'</td><td><code>'+text(row['id'])+
        '</code></td><td>accepted, no fetch</td><td>'+age(row['age_seconds'])+'</td><td>'+
        text(ledger.get('accepted_no_fetch_counts',{}).get(row['recipient'],0))+'</td></tr>' for row in overdue_rows)
    issues = ledger.get('quarantine_incomplete', [])
    incomplete = ('<aside role="status"><h2>Incomplete quarantine items</h2>'
        '<p>These items remain blocked. Independent unread rows are shown below.</p><ul>' +
        ''.join('<li><code>'+text(row['id'])+'</code>: '+text(row['reason'])+'</li>' for row in issues) +
        '</ul></aside>') if issues else ''
    import product_identity
    page = _PAGE.replace('<!--PRODUCT-->', text(product_identity.load().display_name))
    return page.replace('<!--QUARANTINE-->', incomplete).replace('<!--OVERDUE-->', overdue).replace('<!--HOOKED-->', hooked).replace('<!--CUTOVER-->', boundary).replace(
        '<!--RECIPIENTS-->', options('recipient')).replace(
        '<!--SENDERS-->', options('sender')).replace('<!--SUMMARY-->', groups).replace(
        '<!--MESSAGES-->', messages)


_PAGE = '''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Unread ledger · <!--PRODUCT--></title>
<style>
:root { color-scheme: light dark; font: 15px/1.5 system-ui, sans-serif; }
body { margin: 0; background: #101820; color: #e9edf1; }
main { max-width: 1120px; margin: auto; padding: 40px 24px; }
.eyebrow { color: #8cbfc3; font-size: 12px; letter-spacing: .12em; text-transform: uppercase; }
h1 { font-size: 34px; letter-spacing: -.04em; margin: 6px 0; }
h2 { font-size: 19px; margin: 30px 0 12px; }
p { color: #b2c0ca; margin: 8px 0; }
.filters { display: flex; flex-wrap: wrap; gap: 18px; margin: 24px 0 14px; }
label { display: grid; gap: 6px; flex: 1; min-width: 180px; max-width: 330px; }
select { font: inherit; color: inherit; background: #1b2834; border: 1px solid #526571; border-radius: 6px; padding: 10px; width: 100%; }
select:focus-visible { outline: 2px solid #8ad2d5; outline-offset: 3px; }
.table { overflow-x: auto; border: 1px solid #344754; border-radius: 8px; }
table { border-collapse: collapse; width: 100%; text-align: left; }
th,td { padding: 12px 16px; border-bottom: 1px solid #2b3d49; vertical-align: top; }
thead { background: #1b2834; color: #acbdc9; font-size: 12px; }
tbody th { font-weight: 550; }
tbody tr:last-child > * { border-bottom: 0; }
.number { text-align: right; font-variant-numeric: tabular-nums; }
code,time { font-size: 12px; white-space: nowrap; }
#visible-count { color: #d5e6e6; }
#recipient-counts { font-size: 13px; }
[hidden] { display: none !important; }
@media(max-width: 560px) { main { padding: 24px 16px; } h1 { font-size: 28px; } th,td { padding: 10px 12px; } }
</style></head><body><main>
<div class="eyebrow"><!--PRODUCT--> · Observation</div><h1>Unread ledger</h1>
<p>Messages awaiting a fetch receipt, grouped by recipient and sender.</p>
<p id="cutover"><!--CUTOVER--></p>
<p>This is a snapshot. Viewing or filtering it does not mark mail as read.</p>
<!--QUARANTINE-->
<div class="filters">
<label for="recipient">Recipient<select id="recipient"><option value="">All recipients</option><!--RECIPIENTS--></select></label>
<label for="sender">Sender<select id="sender"><option value="">All senders</option><!--SENDERS--></select></label>
</div>
<p id="visible-count" role="status" aria-live="polite"></p><p id="recipient-counts"></p>
<h2>Unread counts</h2>
<div class="table"><table id="summary"><caption hidden>Unread count for each recipient and sender</caption>
<thead><tr><th scope="col">Recipient</th><th scope="col">Sender</th><th scope="col" class="number">Count</th></tr></thead>
<tbody><!--SUMMARY--></tbody></table></div>
<h2>Messages</h2><p>subject column follows D-CON-11</p>
<div class="table"><table id="messages"><caption hidden>Unread messages, oldest first within each recipient and sender</caption>
<thead><tr><th scope="col">Recipient</th><th scope="col">Sender</th><th scope="col">Message ID</th><th scope="col">Sent</th><th scope="col">Age</th><th scope="col">RE:</th></tr></thead>
<tbody><!--MESSAGES--></tbody></table></div>
<p id="empty" hidden>No unread messages match these filters.</p>
<noscript><p>Enable JavaScript to filter this snapshot. All unread rows are shown above.</p></noscript>
<h2>Accepted, no fetch</h2><p>Accepted pointers still unfetched after twelve minutes. Counts are current per-seat observations; no new wake is sent by this view.</p>
<div class="table"><table><thead><tr><th>Recipient</th><th>Message</th><th>Observation</th><th>Age since acceptance</th><th>Seat count</th></tr></thead><tbody><!--OVERDUE--></tbody></table></div>
<h2>Hook deliveries</h2><p>Fetched by the hook; subsequent seat activity is observed separately.</p>
<div class="table"><table><thead><tr><th>Recipient</th><th>Sender</th><th>Message</th><th>Observation</th></tr></thead>
<tbody><!--HOOKED--></tbody></table></div></main><script>
const recipient = document.getElementById('recipient');
const sender = document.getElementById('sender');
function filter() {
  for (const row of document.querySelectorAll('tbody tr')) {
    row.hidden = (recipient.value !== '' && row.dataset.recipient !== recipient.value)
      || (sender.value !== '' && row.dataset.sender !== sender.value);
  }
  const visible = [...document.querySelectorAll('#messages tbody tr')].filter(row => !row.hidden);
  const counts = new Map();
  for (const row of visible) counts.set(row.dataset.recipient, (counts.get(row.dataset.recipient) || 0) + 1);
  document.getElementById('visible-count').textContent = `${visible.length} unread recipient/message pairs`;
  document.getElementById('recipient-counts').textContent = [...counts].map(([name, count]) => `${name}: ${count}`).join(' · ');
  document.getElementById('empty').hidden = visible.length !== 0;
}
recipient.addEventListener('change', filter);
sender.addEventListener('change', filter);
filter();
</script></body></html>'''
