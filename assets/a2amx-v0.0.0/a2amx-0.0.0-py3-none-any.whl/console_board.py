"""R2 §7: obligations plus spine from one read snapshot; never seal or edit."""
import copy
from datetime import datetime, timezone
import os
from pathlib import Path
import re
import threading

from console_files import digest, directory, manifest, read

OBLIGATIONS = 'OBLIGATIONS_01.md'
SPINE = os.environ.get('PSQR_CONSOLE_SPINE_NAME', 'FINDINGS_STATUS.md')
if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*\.md', SPINE) or SPINE == OBLIGATIONS:
    raise ValueError('PSQR_CONSOLE_SPINE_NAME must be a distinct Markdown basename')
MEMBERS = (OBLIGATIONS, SPINE)


def _cells(line):
    return [cell.strip().replace(r'\|', '|') for cell in re.split(r'(?<!\\)\|', line.strip())[1:-1]]


def obligations(text):
    header = ['#', 'Who owes', 'What', 'To whom', 'Since', 'Trigger', 'Cites']
    found = False
    rows = []
    for line in text.splitlines():
        if not line.startswith('|'):
            continue
        cells = _cells(line)
        if cells == header:
            found = True
            continue
        if not found or all(re.fullmatch(r':?-+:?', cell) for cell in cells):
            continue
        if len(cells) != len(header) or not cells[0]:
            raise ValueError('incomplete obligations table row')
        rid, owner, what, recipient, since, trigger, cites = cells
        current, *history = re.split(r'\bWas:', what, maxsplit=1)
        match = re.match(r'^\s*\*{0,2}(OPEN|CLOSED|HELD|DONE|DELIVERED|PENDING|STOP|BLOCKED)\b', current)
        rows.append({'id': rid, 'owner': owner, 'current': current.strip(),
                     'status': match[1] if match else 'unclassified',
                     'history': history[0].strip() if history else '', 'original': what,
                     'recipient': recipient, 'since': since, 'trigger': trigger, 'cites': cites,
                     'message_refs': list(dict.fromkeys(re.findall(r'\bmsg-[0-9a-f]{10}\b', cites + ' ' + what)))})
    if not found:
        raise ValueError('obligations table header missing')
    if len({r['id'] for r in rows}) != len(rows):
        raise ValueError('duplicate obligations row id')
    return rows


class Board:
    def __init__(self, root=None, sealed_root=None):
        configured_root = root if root is not None else os.environ.get('PSQR_CONSOLE_REGISTERS_DIR')
        self.root = Path(configured_root) if configured_root else None
        configured = sealed_root or os.environ.get('PSQR_CONSOLE_SEALED_DIR')
        self.sealed_root = Path(configured) if configured else None
        self._sealed = None
        self._lock = threading.Lock()

    def _read(self, root):
        with directory(root) as fd:
            # Even an unsealed view needs both files. No partial/zero board.
            data = {name: read(fd, name) for name in MEMBERS}
            pin, checks, sealed = None, {}, False
            seal_error = None
            try:
                seal = read(fd, 'SHA256SUMS', limit=1024 * 1024)
                pin = digest(seal)
                claimed = manifest(seal)
                if any(name not in claimed for name in MEMBERS):
                    raise ValueError('displayed member missing from manifest')
                checks = {name: {'claimed': claimed[name], 'measured': digest(data[name]),
                                 'matches': claimed[name] == digest(data[name])} for name in MEMBERS}
                sealed = all(row['matches'] for row in checks.values())
                label = 'sealed / displayed members verified' if sealed else 'unsealed / changed since manifest'
            except FileNotFoundError:
                label = 'unsealed / manifest missing'
                seal_error = 'Manifest missing; both live members are displayed unsealed.'
            except (OSError, ValueError, UnicodeError):
                label = 'unsealed / manifest verification failed'
                seal_error = 'Manifest invalid, unreadable or missing a displayed member.'
            texts = {name: data[name].decode('utf-8') for name in MEMBERS}
            return {'source': str(root), 'read_at': datetime.now(timezone.utc).isoformat(),
                    'manifest_sha256': pin, 'verification': label, 'verified': sealed, 'seal_error': seal_error,
                    'members': checks, 'content_hashes': {name: digest(value) for name, value in data.items()},
                    'rows': obligations(texts[OBLIGATIONS]), 'register_text': texts[OBLIGATIONS],
                    'spine': texts[SPINE], 'spine_name': SPINE}

    def snapshot(self, *, view='live', owner='', status='', trigger='', registered_seats=()):
        if view not in {'live', 'sealed'}:
            raise ValueError('board view must be live or sealed')
        # Cache only already-verified bytes in memory, not a write to registers.
        # An optional operator-provided immutable sealed root survives restarts.
        with self._lock:
            if self._sealed is None and self.sealed_root:
                try:
                    candidate = self._read(self.sealed_root)
                    if candidate['verified']:
                        self._sealed = candidate
                except (OSError, ValueError, UnicodeError):
                    pass
            live, error = None, None
            try:
                if self.root is None:
                    raise ValueError('registers not configured')
                live = self._read(self.root)
                if live['verified']:
                    self._sealed = copy.deepcopy(live)
            except (OSError, ValueError, UnicodeError):
                error = ('Registers unavailable: set PSQR_CONSOLE_REGISTERS_DIR.' if self.root is None else
                         'Register read failed or incomplete; this is not a zero-obligation board.')
            selected = live if view == 'live' else self._sealed
            if selected is None:
                return {'status': 'error', 'error': error if view == 'live' else 'No verified sealed snapshot is available.',
                        'view': view, 'sealed_available': self._sealed is not None, 'live_error': error}
            selected = copy.deepcopy(selected)
        all_rows = selected['rows']
        registered = set(registered_seats)
        # Match whole seat names, never fragments of another ID. Preserve
        # legacy exact-cell choices and the literal register/sealed bytes.
        owner_pattern = None
        if owner in registered:
            flags = re.IGNORECASE if sum(name.casefold() == owner.casefold() for name in registered) == 1 else 0
            owner_pattern = re.compile(r'(?<![\w-])' + re.escape(owner) + r'(?![\w-])', flags)
        selected['rows'] = [r for r in all_rows if (not owner or r['owner'] == owner
                            or (owner_pattern is not None and owner_pattern.search(r['owner'])))
                            and (not status or r['status'] == status)
                            and (not trigger or r['trigger'] == trigger)]
        return {**selected, 'status': 'ok', 'view': view, 'sealed_available': self._sealed is not None,
                'live_error': error, 'total': len(all_rows), 'matched': len(selected['rows']),
                'options': {key: sorted({r[key] for r in all_rows} | (registered if key == 'owner' else set()))
                            for key in ('owner', 'status', 'trigger')},
                'selection': {'owner': owner, 'status': status, 'trigger': trigger},
                'index_notice': 'This board is an index. Authenticated store messages govern when it lags. Compare cited messages; no status is rewritten.'}
