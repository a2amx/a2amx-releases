"""The obligations journal, slices 1 to 3 (ORCH_SPEC_01 addendum, section OBL, draft 9 as adopted).

Obligations are events in an append-only store journal, ``obligations.jsonl`` in the store directory:
a separate artifact, never edited, corrections being new events (D-OBL-2). This module is its one
append path and its replay; slice 2 adds the read of the replay (``show``) and the one repair the
journal admits (``repair_torn_tail``), which ``orch obligations`` exposes. Slice 3 adds D-OBL-5's time
checks at admission (a store message as evidence carries its own recorded time, found by id through a
bounded read of the message log), and D-OBL-5's clocks, series and quantiles and D-OBL-6's projections as
functions of the replay (``clock``, ``Estimates``).

**Inert.** Nothing here runs unless ``ORCH_OBLIGATIONS_ENABLED`` is ``1``, and the switch-on is the
principal's. Off, the journal does not exist, every append is refused with a structured reason before
anything is opened or created, and no other store behaviour changes.

**Admission.** ``append`` authenticates the presented seat credential through the store's registry act,
reads the writer's registry role there, and then, under the journal's own exclusive lock, replays the
journal, applies the checks and appends. A refused append changes nothing. The checks apply in this
order, and the first that fails refuses the append:

- ``switch``: the journal is enabled;
- ``writer``: D-OBL-2b. Slice 1 admits one writer, the seat that currently holds the ``chief_of_staff``
  registry role, for the judgment events of D-OBL-2's table. The deriver's class (an event carrying
  ``rule``, ``derived_from`` or ``actor: deriver``, and the deriver-only types, transitions, evidence and
  sources) and the principal's class are refused with a structured reason; their slices come later;
- ``form``: a closed schema per event type: required fields, their shapes, no field outside the type's
  row, and none of the fields the store assigns (``ts``, ``actor``) or reserves (``chain``);
- then D-OBL-2a's rows in its order: ``duplicate``, ``identity_created``, ``identity_referenced``,
  ``state``, ``edge_proposal``, ``confirmation``, ``withdrawal``.

**The line.** The store adds ``ts`` (its record time) and ``actor`` (the authenticated writer) and writes
the event as one RFC 8785 canonical line, then fsyncs it. The field ``chain`` is reserved for the
record-integrity addendum (D-OBL-11) and is neither written nor admitted here. A journal whose last line
is not terminated, or with a line that is not a canonical event, refuses every append until it is
repaired: an unreadable line is never read as absent.

**Projection.** Nodes and edges are replays (D-OBL-3, D-OBL-4). ``edge_status`` and ``derived_state``
compute D-OBL-3's satisfaction table and its derived ``waiting`` and ``runnable`` states; nothing derived
is stored. ``show`` returns the replay with them, to the Chief of Staff and the principal only.

**Repair.** ``repair_torn_tail`` is the operator act for a torn tail, by the Chief of Staff or the
principal: it removes only the bytes after the last newline, after writing a receipt for them, and never
a complete line. A healthy journal is left as it is, and a journal with a complete line that does not
replay is refused, with nothing removed.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import stat

import store

ENABLE_ENV = 'ORCH_OBLIGATIONS_ENABLED'
FILE_NAME = 'obligations.jsonl'

#: D-OBL-3: each kind and its family.
FAMILIES = {
    'work': ('commission', 'build', 'frame', 'report'),
    'review': ('review', 'check', 'fold'),
    'human': ('human_act', 'adoption', 'gate', 'merge', 'landing'),
    'external': ('external',),
    'other': ('other',),
}
FAMILY_OF = {kind: family for family, kinds in FAMILIES.items() for kind in kinds}
STATES = ('open', 'delivered', 'parked', 'answered', 'closed', 'declined', 'superseded')
TERMINAL = frozenset({'closed', 'declined', 'superseded'})
#: D-OBL-3's transition table. ``open -> answered`` is for a ``human_act`` item only.
TRANSITIONS = {
    'open': frozenset({'delivered', 'closed', 'declined', 'superseded', 'parked', 'answered'}),
    'delivered': frozenset({'open', 'closed', 'superseded', 'parked'}),
    'parked': frozenset({'open', 'declined', 'superseded'}),
    'answered': frozenset({'closed', 'superseded'}),
    'closed': frozenset(), 'declined': frozenset(), 'superseded': frozenset(),
}
EDGE_TYPES = frozenset({'needs', 'needs_act', 'needs_external'})
#: `until` for slice 1. `fit` is met by verdicts and green checks, which the deriver records (D-OBL-13).
UNTIL = frozenset({'closed', 'delivered'})
#: D-OBL-2b: `source: protocol` is the deriver's only.
CHIEF_SOURCES = frozenset({'commission', 'cos', 'report', 'inferred'})
#: D-OBL-2b: evidence of type `finding` is the deriver's only.
CHIEF_EVIDENCE = frozenset({'msg', 'pr', 'register', 'receipt', 'register_ref', 'promise'})

#: D-OBL-2's table: each event type, its required fields and its optional ones, beyond `id` and `event`.
SCHEMA = {
    'obligation.opened': ({'obl_id', 'owner', 'owed_to', 'what', 'kind', 'origin', 'opened_at'}, {'legacy'}),
    'obligation.reworded': ({'obl_id', 'what', 'reason'}, set()),
    'obligation.reassigned': ({'obl_id', 'owner', 'reason'}, set()),
    'obligation.state': ({'obl_id', 'from', 'to', 'at', 'at_ref', 'reason', 'evidence'},
                         {'by', 'principal_record'}),
    'obligation.evidence': ({'obl_id', 'type', 'ref'}, set()),
    'dependency.proposed': ({'dep_id', 'from', 'to', 'type', 'until', 'source', 'evidence'}, set()),
    'dependency.confirmed': ({'dep_ids', 'batch_digest', 'principal_record'}, set()),
    'dependency.withdrawn': ({'dep_id', 'reason'}, set()),
    'obligation.flagged': ({'flag_id', 'subject', 'flag', 'read_at', 'journal_cut', 'basis', 'snapshot'}, set()),
    'obligation.flag_cleared': ({'flag_id', 'read_at', 'journal_cut', 'reason'}, set()),
}
#: D-OBL-2b's other classes, each refused in slice 1 with its own reason.
PRINCIPAL_TYPES = frozenset({'principal.seen', 'principal.dismissed'})
DERIVER_TYPES = frozenset({'report.filed', 'obligation.run'})
LATER_CHIEF_TYPES = frozenset({'report.resolved', 'defect.linked'})
DERIVER_MARKS = ('rule', 'derived_from')
STORE_ASSIGNED = ('ts', 'actor')
RESERVED = ('chain',)

_ID = re.compile(r'[A-Za-z0-9][A-Za-z0-9._:-]{0,127}')
_NAME = re.compile(r'[A-Za-z0-9][A-Za-z0-9._-]{0,63}')
_MSG = re.compile(r'msg-[0-9a-f]{10}')
_SHA256 = re.compile(r'[0-9a-f]{64}')
_PR = re.compile(r'[A-Za-z0-9._/-]{1,200}#[0-9]{1,9}@[0-9a-f]{7,40}')
_PINNED = re.compile(r'.{1,512}@[0-9a-f]{64}', re.S)
TEXT_BOUND = 4000
SHORT_BOUND = 512


class ObligationRefused(ValueError):
    """An append refused before anything was written. `check` names the row that refused it."""

    def __init__(self, check: str, reason: str, detail: str = ''):
        self.check, self.reason, self.detail = check, reason, detail
        super().__init__(f'{check}: {reason}' + (f' ({detail})' if detail else ''))

    def as_dict(self) -> dict:
        return {'error': 'obligation_refused', 'check': self.check, 'reason': self.reason,
                'detail': self.detail}


def enabled() -> bool:
    return os.environ.get(ENABLE_ENV) == '1'


def require_enabled() -> None:
    """The switch, the first check of every act: refused before anything is opened or created."""
    if not enabled():
        _refuse('switch', 'obligations_disabled',
                f'{ENABLE_ENV} is not 1: the journal does not exist and no event is admitted')


def path() -> Path:
    return store.STORE_DIR / FILE_NAME


def canonical(value) -> bytes:
    import rfc8785
    return rfc8785.dumps(value)


# ---- the replay -----------------------------------------------------------------------------------

class Journal:
    """The journal replayed in order: its events and the indexes the checks and projections read."""

    def __init__(self, events=()):
        self.events: list[dict] = []
        self.by_id: dict[str, dict] = {}
        self.obligations: dict[str, dict] = {}
        self.dependencies: dict[str, dict] = {}
        self.flags: dict[str, dict] = {}
        self.legacy_keys: set = set()
        for event in events:
            self.apply(event)

    def is_created(self, created_id) -> bool:
        """Whether an event already created this id, in constant time (CodeRabbit 4199971578)."""
        return (created_id in self.obligations or created_id in self.dependencies
                or created_id in self.flags)

    def apply(self, event: dict) -> None:
        """Fold one admitted event into the indexes."""
        self.events.append(event)
        self.by_id[event['id']] = event
        kind = event['event']
        if kind == 'obligation.opened':
            self.obligations[event['obl_id']] = {
                'state': 'open', 'kind': event['kind'], 'owner': event['owner'], 'what': event['what'],
                'opened': event, 'opened_at': event['opened_at'], 'transitions': []}
            if event.get('legacy') is not None:
                self.legacy_keys.add(legacy_key(event['legacy']))
        elif kind == 'obligation.reworded':
            self.obligations[event['obl_id']]['what'] = event['what']
        elif kind == 'obligation.reassigned':
            self.obligations[event['obl_id']]['owner'] = event['owner']
        elif kind == 'obligation.state':
            node = self.obligations[event['obl_id']]
            node['state'] = event['to']
            node['transitions'].append({'from': event['from'], 'to': event['to'], 'at': event['at']})
        elif kind == 'dependency.proposed':
            self.dependencies[event['dep_id']] = {
                'from': event['from'], 'to': event['to'], 'type': event['type'],
                'until': event['until'], 'source': event['source'], 'status': 'proposed', 'proposed': event}
        elif kind == 'dependency.confirmed':
            # D-OBL-5: a decision about the graph takes effect for the clocks at its own record time.
            for dep_id in event['dep_ids']:
                self.dependencies[dep_id]['status'] = 'confirmed'
                self.dependencies[dep_id]['confirmed_ts'] = event.get('ts')
                self.dependencies[dep_id]['confirmed_seq'] = len(self.events) - 1   # its place in the journal
        elif kind == 'dependency.withdrawn':
            self.dependencies[event['dep_id']]['status'] = 'withdrawn'
            self.dependencies[event['dep_id']]['withdrawn_ts'] = event.get('ts')
        elif kind == 'obligation.flagged':
            self.flags[event['flag_id']] = {'subject': event['subject'], 'flag': event['flag'], 'cleared': False}
        elif kind == 'obligation.flag_cleared':
            self.flags[event['flag_id']]['cleared'] = True


def legacy_key(legacy: dict):
    """D-OBL-10's import key."""
    return (legacy['row_id'], legacy['part'])


def parse(data: bytes) -> Journal:
    """Replay raw journal bytes. A torn last line or a line that is not a canonical event refuses."""
    if data and not data.endswith(b'\n'):
        raise ObligationRefused('journal', 'journal_torn_tail',
                                'the last line is not terminated; repair before any append')
    journal = Journal()
    for number, line in enumerate(data.split(b'\n')[:-1] if data else [], start=1):
        # A line nested deeper than the parser or the canonicalizer can follow is unreadable, and
        # refuses like any other: it never escapes as RecursionError (LSK-OJS2-2).
        try:
            event = json.loads(line)
            canonical_line = canonical(event) if isinstance(event, dict) else None
        except (ValueError, RecursionError):
            raise ObligationRefused('journal', 'journal_unreadable', f'line {number}') from None
        if canonical_line != line:
            raise ObligationRefused('journal', 'journal_noncanonical_line', f'line {number}')
        _replay_one(event, journal, number)
    return journal


def _replay_one(event: dict, journal: 'Journal', number: int) -> None:
    """Admit one stored line to the replay only if it is an event of this table and every check
    holds against the lines before it; otherwise refuse, never fold it away (LSK-OJS-2)."""
    try:
        _envelope(event)
        _intrinsic(event, stored=True)
        if event['id'] in journal.by_id:
            _refuse('duplicate', 'id_repeated_in_journal', event['id'])
        for check in CHECKS:
            check(event, journal)
        journal.apply(event)
    except ObligationRefused as refused:
        raise ObligationRefused('journal', 'journal_invalid_record',
                                f'line {number}: {refused.check}: {refused.reason}') from None
    except (KeyError, TypeError, ValueError, AttributeError):
        raise ObligationRefused('journal', 'journal_invalid_record', f'line {number}') from None


@contextmanager
def _locked(*, create: bool):
    """The journal file under an exclusive lock: the one serialization point of every append."""
    target = path()
    if not create and not target.exists():
        yield None
        return
    store._private_directory(target.parent)
    flags = os.O_RDWR | os.O_APPEND | os.O_NOFOLLOW | (os.O_CREAT if create else 0)
    fd = os.open(target, flags, 0o600)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise ObligationRefused('journal', 'journal_not_regular')
        os.fchmod(fd, 0o600)
        fcntl.flock(fd, fcntl.LOCK_EX)
        try:
            yield fd
        finally:
            fcntl.flock(fd, fcntl.LOCK_UN)
    finally:
        os.close(fd)


def _sync_directory(directory: Path) -> None:
    """Make a new file's directory entry durable: fsync the directory itself.

    A store directory reached through a symlink is followed, as the store's own directory sync
    does; the journal file itself is still opened without following one (Bugbot 4200038810)."""
    fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _read_all(fd) -> bytes:
    size = os.fstat(fd).st_size
    chunks, offset = [], 0
    while offset < size:
        chunk = os.pread(fd, size - offset, offset)
        if not chunk:
            break
        chunks.append(chunk)
        offset += len(chunk)
    return b''.join(chunks)


def load() -> Journal:
    """The journal as it stands; an empty replay when the journal does not exist."""
    with _locked(create=False) as fd:
        return Journal() if fd is None else parse(_read_all(fd))


# ---- D-OBL-3 and D-OBL-4c, as pure functions ------------------------------------------------------

def transition_allowed(kind: str, current: str, to: str) -> bool:
    """D-OBL-3's table; `open -> answered` only for a `human_act` obligation."""
    if current == 'open' and to == 'answered':
        return kind == 'human_act'
    return to in TRANSITIONS.get(current, frozenset())


def satisfaction(predecessor_state: str, until: str) -> str:
    """D-OBL-3's satisfaction table: `satisfied`, `unsatisfied` or `broken`."""
    if predecessor_state in ('declined', 'superseded'):
        return 'broken'
    if predecessor_state == 'closed':
        return 'satisfied'
    if predecessor_state == 'delivered' and until == 'delivered':
        return 'satisfied'
    return 'unsatisfied'


def edge_status(dep_id: str, journal: Journal) -> str:
    dep = journal.dependencies[dep_id]
    return satisfaction(journal.obligations[dep['from']]['state'], dep['until'])


def derived_state(obl_id: str, journal: Journal):
    """`waiting` or `runnable` for an open obligation, else None. Only confirmed edges count (D-OBL-4a)."""
    if journal.obligations[obl_id]['state'] != 'open':
        return None
    for dep_id, dep in journal.dependencies.items():
        if dep['to'] == obl_id and dep['status'] == 'confirmed' and edge_status(dep_id, journal) != 'satisfied':
            return 'waiting'
    return 'runnable'


def batch_digest(dep_ids, journal: Journal) -> str:
    """D-OBL-2a: sha256 of the RFC 8785 list of the batch's proposals, as stored, sorted by `dep_id`."""
    proposals = sorted((journal.dependencies[d]['proposed'] for d in dep_ids), key=lambda e: e['dep_id'])
    return hashlib.sha256(canonical(proposals)).hexdigest()


def _has_cycle(edges) -> bool:
    graph: dict[str, list[str]] = {}
    for start, end in edges:
        graph.setdefault(start, []).append(end)
    state: dict[str, int] = {}
    for root in list(graph):
        if state.get(root):
            continue
        stack = [(root, iter(graph.get(root, ())))]
        state[root] = 1
        while stack:
            node, children = stack[-1]
            child = next(children, None)
            if child is None:
                state[node] = 2
                stack.pop()
            elif state.get(child) == 1:
                return True
            elif not state.get(child):
                state[child] = 1
                stack.append((child, iter(graph.get(child, ()))))
    return False


# ---- the checks -----------------------------------------------------------------------------------

def _refuse(check, reason, detail=''):
    raise ObligationRefused(check, reason, detail)


def _current_chief(actor_id: str, participants: dict) -> bool:
    row = participants.get(actor_id, {})
    return (row.get('role') == 'chief_of_staff' and row.get('kind') == 'agent'
            and not row.get('retired_at') and not row.get('parked_at'))


def _envelope(event) -> None:
    if not isinstance(event, dict):
        _refuse('form', 'event_not_an_object')
    if not isinstance(event.get('event'), str):
        _refuse('form', 'event_type_missing')


def _writer(event: dict, actor_id: str, participants: dict) -> None:
    """D-OBL-2b for slice 1: the current Chief of Staff, for the judgment events of D-OBL-2's table."""
    kind = event['event']
    if kind in PRINCIPAL_TYPES:
        _refuse('writer', 'principal_class_not_in_slice_1',
                f'{kind} is the principal console session\'s, admitted in a later slice')
    if (kind in DERIVER_TYPES or any(mark in event for mark in DERIVER_MARKS)
            or event.get('actor') == 'deriver'):
        _refuse('writer', 'deriver_class_not_in_slice_1',
                'no credential writes as the deriver; its rule table is a later slice')
    if not _current_chief(actor_id, participants):
        _refuse('writer', 'writer_not_current_chief_of_staff',
                f'{actor_id} does not hold the chief_of_staff registry role')
    if kind == 'obligation.state':
        if event.get('to') == 'answered' or (event.get('from') == 'answered' and event.get('to') == 'closed'):
            _refuse('writer', 'transition_is_the_derivers',
                    'an item\'s move to answered (R8) and from answered to closed (R3) are the deriver\'s only')
    nested = event.get('evidence') if kind in ('obligation.state', 'dependency.proposed') else None
    if ((kind == 'obligation.evidence' and event.get('type') == 'finding')
            or (isinstance(nested, list) and any(isinstance(item, dict) and item.get('type') == 'finding'
                                                 for item in nested))):
        _refuse('writer', 'evidence_is_the_derivers', 'evidence of type finding is the deriver\'s only')
    if kind == 'dependency.proposed' and event.get('source') == 'protocol':
        _refuse('writer', 'source_is_the_derivers', 'source: protocol is the deriver\'s only')


def _text(value, bound, field, *, allow_empty=False) -> None:
    if not isinstance(value, str) or (not value.strip() and not allow_empty) or len(value) > bound:
        _refuse('form', 'field_invalid', field)


def _one_of(value, allowed, field) -> bool:
    """Whether a field holds one of a fixed set of words; any other value, of any type, is not."""
    return isinstance(value, str) and value in allowed


def _token(value, field, pattern=_ID) -> None:
    if not isinstance(value, str) or pattern.fullmatch(value) is None:
        _refuse('form', 'field_invalid', field)


def _timestamp(value, field, *, nullable) -> None:
    if value is None and nullable:
        return
    try:
        if not isinstance(value, str) or len(value) > 64 or datetime.fromisoformat(value).tzinfo is None:
            raise ValueError
    except ValueError:
        _refuse('form', 'field_invalid', field)


def _principal_record(value, field) -> None:
    """D-OBL-4c: a sealed principal record by path and sha256; never a draft, never a message id."""
    if not isinstance(value, dict) or set(value) != {'path', 'sha256'}:
        _refuse('form', 'principal_record_invalid', f'{field}: {{path, sha256}} required')
    _text(value['path'], SHORT_BOUND, f'{field}.path')
    name = Path(value['path']).name
    if not name.endswith('.md') or 'PROPOSED' in name:
        _refuse('form', 'principal_record_invalid', f'{field}.path: a sealed .md record, never a draft')
    _token(value['sha256'], f'{field}.sha256', _SHA256)


def _principal_record_named(value, field, participants) -> None:
    """The record is named for the current principal: its id in upper case, then `_` (registry)."""
    prefixes = tuple(owner.upper() + '_' for owner in principal_owners(participants))
    if not (prefixes and Path(value['path']).name.startswith(prefixes)):
        _refuse('form', 'principal_record_invalid', f'{field}.path: a record named for the principal')


def principal_owners(participants: dict) -> set:
    """The principal as an owner: the lower-case id of the current holder of `human_authority`.

    D-OBL-3 writes it as the principal's own name in lower case; reading the holder from the registry
    keeps any estate's principal, and no one else, in that position (D-OBL-18).
    """
    return {pid.lower() for pid, row in participants.items()
            if row.get('role') == 'human_authority' and not row.get('retired_at')}


def _party_shape(value, field) -> None:
    """D-OBL-3's owner, by form alone: a name, or `external:<name>`."""
    if isinstance(value, str) and value.startswith('external:'):
        _token(value[len('external:'):], field, _NAME)
    elif not isinstance(value, str) or _NAME.fullmatch(value) is None:
        _refuse('form', 'party_invalid', f'{field}: a registered seat, the principal, or external:<name>')


def _party_known(value, field, participants) -> None:
    """D-OBL-3: exactly one of a registered seat, the principal, or `external:<name>` (registry)."""
    if value.startswith('external:') or value in principal_owners(participants):
        return
    if participants.get(value, {}).get('kind') != 'agent':
        _refuse('form', 'party_invalid', f'{field}: a registered seat, the principal, or external:<name>')


def _evidence_item(value, field) -> None:
    if not isinstance(value, dict) or set(value) != {'type', 'ref'}:
        _refuse('form', 'field_invalid', f'{field}: {{type, ref}} required')
    kind, ref = value['type'], value['ref']
    if not _one_of(kind, CHIEF_EVIDENCE, field):
        _refuse('form', 'field_invalid', f'{field}.type')
    if kind == 'msg':
        _token(ref, f'{field}.ref', _MSG)
    elif kind == 'pr':
        _token(ref, f'{field}.ref', _PR)
    elif kind in ('register', 'receipt'):
        _token(ref, f'{field}.ref', _PINNED)
    elif kind == 'register_ref':
        if not isinstance(ref, dict) or set(ref) != {'ref', 'status'}:
            _refuse('form', 'field_invalid', f'{field}.ref: {{ref, status}} required')
        _text(ref['ref'], SHORT_BOUND, f'{field}.ref.ref')
        _text(ref['status'], SHORT_BOUND, f'{field}.ref.status')
    else:  # promise (D-OBL-5)
        if not isinstance(ref, dict) or set(ref) != {'party', 'date', 'tz', 'stated_at', 'ref'}:
            _refuse('form', 'field_invalid', f'{field}.ref: {{party, date, tz, stated_at, ref}} required')
        for name in ('party', 'date', 'tz', 'ref'):
            _text(ref[name], SHORT_BOUND, f'{field}.ref.{name}')
        _timestamp(ref['stated_at'], f'{field}.ref.stated_at', nullable=False)


def _evidence_list(value, field) -> None:
    if not isinstance(value, list) or len(value) > 64:
        _refuse('form', 'field_invalid', field)
    for index, item in enumerate(value):
        _evidence_item(item, f'{field}[{index}]')


def _origin(value) -> None:
    """The store message or principal record that created the obligation (D-OBL-12)."""
    if isinstance(value, str):
        _token(value, 'origin', _MSG)
    else:
        _principal_record(value, 'origin')


def _legacy(value) -> None:
    """D-OBL-10: the register cut, the row as written, its part, and its seven cells verbatim."""
    if not isinstance(value, dict) or set(value) != {'register', 'row_id', 'part', 'cells'}:
        _refuse('form', 'field_invalid', 'legacy: {register, row_id, part, cells} required')
    register = value['register']
    if not isinstance(register, dict) or set(register) != {'path', 'sha256'}:
        _refuse('form', 'field_invalid', 'legacy.register: {path, sha256} required')
    _text(register['path'], SHORT_BOUND, 'legacy.register.path')
    _token(register['sha256'], 'legacy.register.sha256', _SHA256)
    _text(value['row_id'], 32, 'legacy.row_id')
    _text(value['part'], 32, 'legacy.part')
    cells = value['cells']
    if not isinstance(cells, list) or len(cells) != 7 or not all(isinstance(c, str) and len(c) <= 20000
                                                                  for c in cells):
        _refuse('form', 'field_invalid', 'legacy.cells: the seven cells verbatim')


def _intrinsic(event: dict, *, stored: bool = False) -> None:
    """The closed schema of D-OBL-2's table, by form alone: no registry read (LSK-OJS-3).

    The same check reads a stored line on replay (`stored=True`), where the store's own `ts` and
    `actor` are required, and the deriver's marks are admitted only on a line the deriver wrote
    (LSK-OJS-2). A replayed line is never re-authorized against today's registry.
    """
    kind = event['event']
    if kind in LATER_CHIEF_TYPES:
        _refuse('form', 'event_type_not_in_slice_1', kind)
    if kind not in SCHEMA:
        _refuse('form', 'unknown_event_type', kind)
    marks = set()
    if stored:
        for name in STORE_ASSIGNED:
            if name not in event:
                _refuse('form', 'field_missing', name)
        _timestamp(event['ts'], 'ts', nullable=False)
        _token(event['actor'], 'actor', _NAME)
        if event['actor'] == 'deriver':
            marks = {mark for mark in DERIVER_MARKS if mark in event}
            for mark in marks:
                _text(event[mark], SHORT_BOUND, mark)
    else:
        for name in STORE_ASSIGNED:
            if name in event:
                _refuse('form', 'store_assigned_field', name)
    for name in RESERVED:
        if name in event:
            _refuse('form', 'reserved_field', f'{name} is reserved for the record-integrity addendum (D-OBL-11)')
    required, optional = SCHEMA[kind]
    fields = set(event) - {'id', 'event'} - (set(STORE_ASSIGNED) | marks if stored else set())
    if required - fields:
        _refuse('form', 'field_missing', ', '.join(sorted(required - fields)))
    if fields - required - optional:
        _refuse('form', 'field_not_allowed', ', '.join(sorted(fields - required - optional)))
    _token(event.get('id'), 'id')
    if kind == 'obligation.opened':
        _token(event['obl_id'], 'obl_id')
        _party_shape(event['owner'], 'owner')
        _party_shape(event['owed_to'], 'owed_to')
        _text(event['what'], TEXT_BOUND, 'what')
        if not _one_of(event['kind'], FAMILY_OF, 'kind'):
            _refuse('form', 'field_invalid', 'kind')
        _origin(event['origin'])
        _timestamp(event['opened_at'], 'opened_at', nullable=True)
        if 'legacy' in event:
            _legacy(event['legacy'])
    elif kind == 'obligation.reworded':
        _token(event['obl_id'], 'obl_id')
        _text(event['what'], TEXT_BOUND, 'what')
        _text(event['reason'], TEXT_BOUND, 'reason')
    elif kind == 'obligation.reassigned':
        _token(event['obl_id'], 'obl_id')
        _party_shape(event['owner'], 'owner')
        _text(event['reason'], TEXT_BOUND, 'reason')
    elif kind == 'obligation.state':
        _token(event['obl_id'], 'obl_id')
        for name in ('from', 'to'):
            if not _one_of(event[name], STATES, name):
                _refuse('form', 'field_invalid', name)
        _timestamp(event['at'], 'at', nullable=True)
        if event['at_ref'] is not None:
            _text(event['at_ref'], SHORT_BOUND, 'at_ref')
        _text(event['reason'], TEXT_BOUND, 'reason')
        _evidence_list(event['evidence'], 'evidence')
        if 'by' in event:
            _token(event['by'], 'by')
        if 'principal_record' in event:
            _principal_record(event['principal_record'], 'principal_record')
    elif kind == 'obligation.evidence':
        _token(event['obl_id'], 'obl_id')
        _evidence_item({'type': event['type'], 'ref': event['ref']}, 'evidence')
    elif kind == 'dependency.proposed':
        for name in ('dep_id', 'from', 'to'):
            _token(event[name], name)
        if not _one_of(event['type'], EDGE_TYPES, 'type'):
            _refuse('form', 'field_invalid', 'type')
        if not _one_of(event['until'], UNTIL, 'until'):
            _refuse('form', 'until_not_in_slice_1' if event['until'] == 'fit' else 'field_invalid', 'until')
        if not _one_of(event['source'], CHIEF_SOURCES, 'source'):
            _refuse('form', 'field_invalid', 'source')
        _evidence_list(event['evidence'], 'evidence')
    elif kind == 'dependency.confirmed':
        dep_ids = event['dep_ids']
        if not isinstance(dep_ids, list) or not dep_ids or len(dep_ids) > 1000:
            _refuse('form', 'field_invalid', 'dep_ids')
        for dep_id in dep_ids:
            _token(dep_id, 'dep_ids')
        if len(set(dep_ids)) != len(dep_ids):
            _refuse('form', 'field_invalid', 'dep_ids: each once')
        _token(event['batch_digest'], 'batch_digest', _SHA256)
        _principal_record(event['principal_record'], 'principal_record')
    elif kind == 'dependency.withdrawn':
        _token(event['dep_id'], 'dep_id')
        _text(event['reason'], TEXT_BOUND, 'reason')
    elif kind == 'obligation.flagged':
        for name in ('flag_id', 'subject'):
            _token(event[name], name)
        _token(event['flag'], 'flag', _NAME)
        _timestamp(event['read_at'], 'read_at', nullable=False)
        if type(event['journal_cut']) is not int or event['journal_cut'] < 0:
            _refuse('form', 'field_invalid', 'journal_cut')
        _text(event['basis'], TEXT_BOUND, 'basis')
        if not isinstance(event['snapshot'], dict):
            _refuse('form', 'field_invalid', 'snapshot')
    elif kind == 'obligation.flag_cleared':
        _token(event['flag_id'], 'flag_id')
        _timestamp(event['read_at'], 'read_at', nullable=False)
        if type(event['journal_cut']) is not int or event['journal_cut'] < 0:
            _refuse('form', 'field_invalid', 'journal_cut')
        _text(event['reason'], TEXT_BOUND, 'reason')
    try:
        canonical(event)
    except Exception:
        _refuse('form', 'not_canonicalizable', 'the event has no RFC 8785 form')


def _contextual(event: dict, participants: dict) -> None:
    """The checks that read the registry: who an owner is, whom a principal record is named for.

    They run after Duplicate, so an identical retry returns its first result whatever the registry
    says now (LSK-OJS-3), and never on replay, which does not re-authorize history.
    """
    kind = event['event']
    if kind == 'obligation.opened':
        _party_known(event['owner'], 'owner', participants)
        _party_known(event['owed_to'], 'owed_to', participants)
        if isinstance(event['origin'], dict):
            _principal_record_named(event['origin'], 'origin', participants)
    elif kind == 'obligation.reassigned':
        _party_known(event['owner'], 'owner', participants)
    elif kind in ('obligation.state', 'dependency.confirmed') and 'principal_record' in event:
        _principal_record_named(event['principal_record'], 'principal_record', participants)


def _snapshot(event):
    """A private, deep copy of the caller's event, taken once: the event checked is the event stored
    (LSK-OJS-1). A value with no RFC 8785 form is refused here, before anything else reads it."""
    try:
        return json.loads(canonical(event))
    except Exception:
        _refuse('form', 'not_canonicalizable', 'the event has no RFC 8785 form')


def _content(event: dict) -> bytes:
    """What a redelivery must repeat: the event without the fields the store assigns."""
    return canonical({k: v for k, v in event.items() if k not in STORE_ASSIGNED})


def _duplicate(event: dict, journal: Journal):
    first = journal.by_id.get(event['id'])
    if first is None:
        return None
    if _content(first) != _content(event):
        _refuse('duplicate', 'id_reused_with_different_content', event['id'])
    return first


def _identity_created(event: dict, journal: Journal) -> None:
    """Three events create an id, and it must be fresh; so must a legacy import key (D-OBL-10)."""
    field = {'obligation.opened': 'obl_id', 'dependency.proposed': 'dep_id',
             'obligation.flagged': 'flag_id'}.get(event['event'])
    if field is None:
        return
    if journal.is_created(event[field]):
        _refuse('identity_created', 'id_not_fresh', f'{field} {event[field]}')
    if field == 'obl_id' and 'legacy' in event and legacy_key(event['legacy']) in journal.legacy_keys:
        _refuse('identity_created', 'legacy_key_already_imported', repr(legacy_key(event['legacy'])))


def _identity_referenced(event: dict, journal: Journal) -> None:
    kind = event['event']
    if kind in ('obligation.reworded', 'obligation.reassigned', 'obligation.state', 'obligation.evidence'):
        if event['obl_id'] not in journal.obligations:
            _refuse('identity_referenced', 'unknown_obl_id', event['obl_id'])
        if kind == 'obligation.state' and 'by' in event and event['by'] not in journal.obligations:
            _refuse('identity_referenced', 'unknown_obl_id', f'by {event["by"]}')
    elif kind == 'dependency.confirmed':
        unknown = [d for d in event['dep_ids'] if d not in journal.dependencies]
        if unknown:
            _refuse('identity_referenced', 'unknown_dep_id', ', '.join(unknown))
    elif kind == 'dependency.withdrawn':
        if event['dep_id'] not in journal.dependencies:
            _refuse('identity_referenced', 'unknown_dep_id', event['dep_id'])
    elif kind == 'obligation.flag_cleared':
        if event['flag_id'] not in journal.flags:
            _refuse('identity_referenced', 'unknown_flag_id', event['flag_id'])
    elif kind == 'obligation.flagged':
        if event['subject'] not in journal.obligations and event['subject'] not in journal.dependencies:
            _refuse('identity_referenced', 'unknown_subject', event['subject'])


def _state(event: dict, journal: Journal) -> None:
    """Compare-and-swap on D-OBL-3's table; parking and resuming carry a principal record (D-OBL-4c)."""
    if event['event'] != 'obligation.state':
        return
    node = journal.obligations[event['obl_id']]
    if event['from'] != node['state']:
        _refuse('state', 'from_is_not_current', f'current state is {node["state"]}')
    if not transition_allowed(node['kind'], event['from'], event['to']):
        _refuse('state', 'transition_not_in_table', f'{event["from"]} -> {event["to"]} for kind {node["kind"]}')
    if 'parked' in (event['from'], event['to']) and 'principal_record' not in event:
        _refuse('state', 'parking_needs_principal_record')
    if event['to'] == 'superseded':
        if 'by' not in event:
            _refuse('state', 'superseded_needs_by')
        if event['by'] == event['obl_id']:
            _refuse('state', 'superseded_by_itself')


def _edge_proposal(event: dict, journal: Journal) -> None:
    if event['event'] != 'dependency.proposed':
        return
    for end in ('from', 'to'):
        if event[end] not in journal.obligations:
            _refuse('edge_proposal', 'unknown_endpoint', f'{end} {event[end]}')
    if event['from'] == event['to']:
        _refuse('edge_proposal', 'endpoints_equal')
    if journal.obligations[event['to']]['state'] in TERMINAL:
        _refuse('edge_proposal', 'successor_terminal', event['to'])


def _confirmation(event: dict, journal: Journal) -> None:
    """The whole batch or nothing: proposed edges, the digest of their proposals, an acyclic result."""
    if event['event'] != 'dependency.confirmed':
        return
    for dep_id in event['dep_ids']:
        status = journal.dependencies[dep_id]['status']
        if status != 'proposed':
            _refuse('confirmation', 'edge_not_proposed', f'{dep_id} is {status}; the whole batch is refused')
    expected = batch_digest(event['dep_ids'], journal)
    if event['batch_digest'] != expected:
        _refuse('confirmation', 'batch_digest_mismatch', 'the whole batch is refused')
    edges = [(d['from'], d['to']) for d in journal.dependencies.values() if d['status'] == 'confirmed']
    edges += [(journal.dependencies[d]['from'], journal.dependencies[d]['to']) for d in event['dep_ids']]
    if _has_cycle(edges):
        _refuse('confirmation', 'cycle', 'the confirmed graph plus the batch has a cycle; the whole batch is refused')


def _withdrawal(event: dict, journal: Journal) -> None:
    if event['event'] != 'dependency.withdrawn':
        return
    if journal.dependencies[event['dep_id']]['status'] == 'withdrawn':
        _refuse('withdrawal', 'already_withdrawn', event['dep_id'])


CHECKS = (_identity_created, _identity_referenced, _state, _edge_proposal, _confirmation, _withdrawal)


# ---- the one append path --------------------------------------------------------------------------

def _write_line(fd, stored: dict) -> None:
    """Write one canonical line and make it durable, or leave the journal exactly as it was."""
    line = canonical(stored) + b'\n'
    before = os.fstat(fd).st_size
    try:
        written = 0
        while written < len(line):
            written += os.write(fd, line[written:])
        os.fsync(fd)
        if before == 0:
            # The journal's first line: its directory entry must survive a crash too (CodeRabbit
            # 4199252533). A journal emptied by a failed first write counts as first again.
            _sync_directory(path().parent)
    except BaseException as failure:
        # The lock is held and nothing after `before` was ever acknowledged: remove this call's
        # own partial bytes, so a failed write cannot leave a torn tail behind. If that fails too, the
        # event's outcome is uncertain, and the note says so (LSK-OJS-5).
        try:
            os.ftruncate(fd, before)
            os.fsync(fd)
        except OSError as rollback:
            failure.add_note(
                f'journal rollback to {before} bytes failed ({rollback.strerror}): this event\'s outcome is '
                'uncertain. If its whole line is in the journal, a redelivery of the same id and content '
                'returns it as stored; if only part is, every append refuses the torn tail until it is repaired.')
        raise


def append(event, *, presented_token) -> dict:
    """Admit one event through the store's authenticated API, or refuse it with nothing written.

    Returns ``{'event': <the stored event>, 'duplicate': <bool>}``; a redelivered event returns the
    first result and writes nothing.
    """
    require_enabled()
    event = _snapshot(event)
    _envelope(event)

    def act(actor_id):
        participants = store._read_participants_unlocked()
        _writer(event, actor_id, participants)
        _intrinsic(event)
        # Appends are serialized by the registry act; the journal's own lock orders them with
        # readers. A missing journal replays as empty and is created only when an event is admitted,
        # so a refused append leaves no file behind.
        with _locked(create=False) as fd:
            journal = Journal() if fd is None else parse(_read_all(fd))
            first = _duplicate(event, journal)
            if first is not None:
                return {'event': first, 'duplicate': True}
            _contextual(event, participants)
            for check in CHECKS:
                check(event, journal)
            _times(event)  # D-OBL-5: a store message as evidence exists and its time is the event's (slice 3)
            stored = {**event, 'ts': store.now_iso(), 'actor': actor_id}
            if fd is None:
                with _locked(create=True) as new_fd:
                    _write_line(new_fd, stored)
            else:
                _write_line(fd, stored)
            return {'event': stored, 'duplicate': False}

    try:
        return store.authenticated_registry_act(presented_token, act)
    except store.RegistryMutationRefused as exc:
        raise ObligationRefused('writer', exc.reason, 'the credential did not authenticate') from None


# ---- slice 2: the read and the repair -------------------------------------------------------------

def _chief_or_principal(actor_id: str, participants: dict, check: str) -> None:
    """The journal's readers and its repairer: the current Chief of Staff or the principal (D-OBL-15).

    Both are read from the registry at the act, as the writer is; a seat that no longer holds the
    role is refused.
    """
    row = participants.get(actor_id, {})
    principal = row.get('role') == 'human_authority' and not row.get('retired_at')
    if not (_current_chief(actor_id, participants) or principal):
        _refuse(check, f'{check}_not_chief_of_staff_or_principal',
                f'{actor_id} holds neither the chief_of_staff nor the human_authority registry role')


def _authenticated(presented_token, check: str, act):
    """Run `act(actor_id)` inside the store's authenticated registry act, for the two roles only."""
    def guarded(actor_id):
        _chief_or_principal(actor_id, store._read_participants_unlocked(), check)
        return act(actor_id)
    try:
        return store.authenticated_registry_act(presented_token, guarded)
    except store.RegistryMutationRefused as exc:
        raise ObligationRefused(check, exc.reason, 'the credential did not authenticate') from None


def _cut(data: bytes) -> dict:
    """The journal bytes a result was computed from: their length, digest and complete lines."""
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'lines': data.count(b'\n')}


def view(journal: Journal) -> dict:
    """The replay as D-OBL-3 and D-OBL-4 project it: obligations with their derived states, edges with
    their status and satisfaction, and flags, each in journal order. Nothing here is stored."""
    obligations = []
    for obl_id, node in journal.obligations.items():
        opened = node['opened']
        obligations.append({
            'obl_id': obl_id, 'kind': node['kind'], 'family': FAMILY_OF[node['kind']],
            'owner': node['owner'], 'owed_to': opened['owed_to'], 'what': node['what'],
            'origin': opened['origin'], 'opened_at': opened['opened_at'], 'legacy': 'legacy' in opened,
            'state': node['state'], 'derived_state': derived_state(obl_id, journal)})
    edges = [{'dep_id': dep_id, 'from': dep['from'], 'to': dep['to'], 'type': dep['type'],
              'until': dep['until'], 'source': dep['source'], 'status': dep['status'],
              'satisfaction': edge_status(dep_id, journal)}
             for dep_id, dep in journal.dependencies.items()]
    flags = [{'flag_id': flag_id, 'subject': flag['subject'], 'flag': flag['flag'], 'cleared': flag['cleared']}
             for flag_id, flag in journal.flags.items()]
    return {'obligations': obligations, 'edges': edges, 'flags': flags}


def show(*, presented_token) -> dict:
    """The replay, for the current Chief of Staff and the principal only; a damaged journal refuses.

    Reading never creates the journal: a missing one is an empty replay.
    """
    require_enabled()

    def act(_actor_id):
        with _locked(create=False) as fd:
            data = b'' if fd is None else _read_all(fd)
        return {'active': True, 'journal': _cut(data), **view(parse(data))}

    return _authenticated(presented_token, 'reader', act)


def repair_torn_tail(*, presented_token) -> dict:
    """Remove a torn tail, the bytes after the last newline, and nothing else.

    The operator act of slice 2, by the current Chief of Staff or the principal, under the same locks
    as an append. Every complete line must replay first: a complete line that does not refuses the
    repair, and nothing is removed. A journal with no torn tail, or none at all, is left exactly as it
    is and no receipt is written. Otherwise the receipt (the bytes before and after, and the length and
    digest of the bytes removed) is written to the store's ledger before the bytes are removed, so no
    removal is ever unrecorded. The removed bytes are a write that was never acknowledged (LSK-OJS-5):
    they are not kept, and the writer's redelivery is how such an event enters.
    """
    require_enabled()

    def act(actor_id):
        with _locked(create=False) as fd:
            if fd is None:
                return {'repaired': False, 'journal': None}
            data = _read_all(fd)
            boundary = data.rfind(b'\n') + 1
            kept, tail = data[:boundary], data[boundary:]
            try:
                parse(kept)
            except ObligationRefused as damaged:
                _refuse('repair', 'complete_line_damaged',
                        f'{damaged.reason} ({damaged.detail}): only a torn tail is repaired; nothing removed')
            if not tail:
                return {'repaired': False, 'journal': _cut(data)}
            payload = {'mutation': 'obligations_torn_tail_removed', 'journal': FILE_NAME,
                       'before': _cut(data), 'after': _cut(kept),
                       'removed': {'bytes': len(tail), 'sha256': hashlib.sha256(tail).hexdigest()}}
            receipt = store._emit_seat_receipt(actor_id, payload)
            # The removal and its durability are reported apart (LSK-OJS2-1): a failed truncate removed
            # nothing; a failed sync after it leaves the tail removed but not known to be durable.
            try:
                os.ftruncate(fd, boundary)
            except OSError as failure:
                failure.outcome = {'receipt': receipt['id'], 'tail_removed': False}
                failure.add_note(f'receipt {receipt["id"]} was written but the torn tail was not removed; '
                                 'the journal still refuses every append; repair-tail again')
                raise
            try:
                os.fsync(fd)
            except OSError as failure:
                failure.outcome = {'receipt': receipt['id'], 'tail_removed': True, 'journal_synced': False}
                failure.add_note(f'receipt {receipt["id"]} was written and the torn tail was removed, but the '
                                 'journal sync failed, so the removal is not known to be durable. Appends are '
                                 'admitted again; the next one that is admitted syncs the journal. If the tail '
                                 'comes back after a crash, every append refuses it and repair-tail removes it again.')
                raise
            return {'repaired': True, 'receipt': receipt['id'], **payload}

    return _authenticated(presented_token, 'operator', act)


# ---- slice 3: the message lookup, the time checks, the clocks and the estimates (D-OBL-5, D-OBL-6) ------

MESSAGE_INDEX_DIR = 'obligations.msgindex'
WINDOW_SECONDS = 90 * 24 * 3600
MIN_SAMPLES = 5
_READ_CHUNK = 1 << 20
_HEAD_BYTES = 4096
_ROW = re.compile(rb'(msg-[0-9a-f]{10}) (0|[1-9][0-9]{0,17}) ([1-9][0-9]{0,17})')


def _index_dir() -> Path:
    return store.STORE_DIR / MESSAGE_INDEX_DIR


def _pread(fd, length: int, offset: int) -> bytes:
    """Every read of the store's message log goes through here, so a test can bound it."""
    return os.pread(fd, length, offset)


_CHECKPOINT_FIELDS = {'dev', 'ino', 'offset', 'head_sha256'}
_SHA256 = re.compile(r'[0-9a-f]{64}')


def _read_checkpoint(directory: Path):
    """The checkpoint, or None when it is missing or not of its own shape: an object of exactly its four fields,
    the file identity and offset non-negative integers (never booleans) and the head a SHA-256 in hex. A None
    makes the next catch-up build the index again from the log (LSK-OJS3-1)."""
    try:
        checkpoint = json.loads((directory / 'checkpoint.json').read_text())
    except (OSError, ValueError):
        return None
    if not isinstance(checkpoint, dict) or set(checkpoint) != _CHECKPOINT_FIELDS:
        return None
    if any(type(checkpoint[field]) is not int or checkpoint[field] < 0 for field in ('dev', 'ino', 'offset')):
        return None
    if not isinstance(checkpoint['head_sha256'], str) or not _SHA256.fullmatch(checkpoint['head_sha256']):
        return None
    return checkpoint


def _write_all(fd, data: bytes) -> None:
    """Write all of `data`: os.write may write less than it was given."""
    view = memoryview(data)
    while view:
        written = os.write(fd, view)
        if written <= 0:
            raise OSError('the message index took no bytes')
        view = view[written:]


def _write_checkpoint(directory: Path, checkpoint: dict) -> None:
    tmp = directory / 'checkpoint.json.tmp'
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW, 0o600)
    try:
        _write_all(fd, json.dumps(checkpoint, sort_keys=True).encode())
        os.fsync(fd)
    finally:
        os.close(fd)
    os.replace(tmp, directory / 'checkpoint.json')
    _sync_index_directory(directory)


def _sync_index_directory(directory: Path) -> None:
    """The index's own directory sync, apart from the journal's (`_sync_directory`)."""
    fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _catch_up(directory: Path, log_fd) -> None:
    """Index the log lines appended since the checkpoint: `<id> <offset> <length>` in the shard named by
    the id's first two hex digits. A log replaced since the checkpoint (another inode, a shorter file or a
    different head) is indexed again from its start. Only complete lines are read; a partial last line
    waits for the next lookup.

    The shards are written before the checkpoint. A write cut short by a crash leaves an unterminated row,
    and its records are indexed again past the old checkpoint; the next row joins it into one that is not
    `<id> <offset> <length>`, which a lookup finds and answers by building the index again."""
    info = os.fstat(log_fd)
    checkpoint = _read_checkpoint(directory)
    offset = 0
    if checkpoint is not None and checkpoint['dev'] == info.st_dev and checkpoint['ino'] == info.st_ino \
            and checkpoint['offset'] <= info.st_size:
        head = _pread(log_fd, min(_HEAD_BYTES, checkpoint['offset']), 0)
        if hashlib.sha256(head).hexdigest() == checkpoint['head_sha256']:
            offset = checkpoint['offset']
    if offset == 0:
        for shard in directory.glob('*.idx'):
            shard.unlink()
    shards: dict[str, list[str]] = {}
    pending = b''
    position = offset
    while position < info.st_size:
        chunk = _pread(log_fd, min(_READ_CHUNK, info.st_size - position), position)
        if not chunk:
            break
        data = pending + chunk
        start = position - len(pending)
        position += len(chunk)
        lines = data.split(b'\n')
        pending = lines.pop()
        for line in lines:
            length = len(line) + 1
            try:
                record = json.loads(line)
            except ValueError:
                record = None
            if isinstance(record, dict) and isinstance(record.get('id'), str) and _MSG.fullmatch(record['id']):
                shards.setdefault(record['id'][4:6], []).append(f'{record["id"]} {start} {length}\n')
            start += length
    indexed = position - len(pending)
    for name, lines in shards.items():
        fd = os.open(directory / f'{name}.idx', os.O_WRONLY | os.O_CREAT | os.O_APPEND | os.O_NOFOLLOW, 0o600)
        try:
            _write_all(fd, ''.join(lines).encode())
            os.fsync(fd)
        finally:
            os.close(fd)
    if indexed != offset or checkpoint is None:
        _write_checkpoint(directory, {'dev': info.st_dev, 'ino': info.st_ino, 'offset': indexed,
                                      'head_sha256': hashlib.sha256(_pread(log_fd, min(_HEAD_BYTES, indexed), 0)).hexdigest()})


def _find(directory: Path, log_fd, msg_id: str):
    """(the record, or None; whether the index is damaged). Damaged: a row of the shard is not
    `<id> <offset> <length>` with a final newline, or a row for `msg_id` reaches past the log, does not start
    a log line, or does not lead to a record with that id.

    A span that starts a log line and parses as one JSON object is that line's whole record: an object's prefix
    is never a whole object, and a span running past the line's end is not one object. So an object nested
    inside another message is never taken for the message (LSK-OJS3-2)."""
    try:
        rows = (directory / f'{msg_id[4:6]}.idx').read_bytes().split(b'\n')
    except FileNotFoundError:
        return None, False
    if rows.pop():
        return None, True
    for row in rows:
        match = _ROW.fullmatch(row)
        if match is None:
            return None, True
        if match.group(1).decode() != msg_id:
            continue
        offset, length = int(match.group(2)), int(match.group(3))
        if offset + length > os.fstat(log_fd).st_size:
            return None, True
        before = 1 if offset else 0                    # the byte before the span, read with it in one read
        raw = _pread(log_fd, length + before, offset - before)
        if before and raw[:1] != b'\n':
            return None, True
        try:
            record = json.loads(raw[before:])
        except ValueError:
            return None, True
        if not isinstance(record, dict) or record.get('id') != msg_id:
            return None, True
        return record, False
    return None, False


def lookup_message(msg_id: str):
    """The store message `msg_id` as recorded in the log, or None: found through the index, read by its
    own offset and length, and checked to carry that id. After the index is current, a lookup reads the
    log's new tail and the one record, never the whole log."""
    target = store.LOG_FILE
    if not _MSG.fullmatch(msg_id) or not target.exists():
        return None
    directory = _index_dir()
    store._private_directory(directory)
    lock = os.open(directory / 'lock', os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    try:
        fcntl.flock(lock, fcntl.LOCK_EX)
        log_fd = os.open(target, os.O_RDONLY)
        try:
            _catch_up(directory, log_fd)
            record, damaged = _find(directory, log_fd, msg_id)
            if damaged:
                # The index is derived: one that fails its own reading is discarded and built again, once.
                (directory / 'checkpoint.json').unlink(missing_ok=True)
                _catch_up(directory, log_fd)
                record, _ = _find(directory, log_fd, msg_id)
            return record
        finally:
            os.close(log_fd)
    finally:
        fcntl.flock(lock, fcntl.LOCK_UN)
        os.close(lock)


def _instant(value):
    """An ISO timestamp as seconds since the epoch, or None for an unknown time."""
    if value is None:
        return None
    return datetime.fromisoformat(value).timestamp()


def _message_time(msg_id: str, claimed, field: str, reference: str) -> None:
    record = lookup_message(msg_id)
    if record is None:
        _refuse('time', f'{reference}_message_unknown', msg_id)
    recorded = record.get('ts')
    try:
        same = claimed is not None and isinstance(recorded, str) and _instant(claimed) == _instant(recorded)
    except ValueError:
        same = False
    if not same:
        _refuse('time', f'{field}_is_not_the_message_time', f'{msg_id} was recorded at {recorded}')


def _times(event: dict) -> None:
    """D-OBL-5's admission checks: when a transition's evidence (`at_ref`) or an obligation's `origin` is a
    store message, the message exists and `at` (or `opened_at`) is its recorded time, the same instant.
    Other evidence is the Chief of Staff's attestation, and a null time is an unknown one. Never on replay."""
    kind = event['event']
    if kind == 'obligation.state' and isinstance(event['at_ref'], str) and _MSG.fullmatch(event['at_ref']):
        _message_time(event['at_ref'], event['at'], 'at', 'at_ref')
    elif kind == 'obligation.opened' and isinstance(event['origin'], str):
        _message_time(event['origin'], event['opened_at'], 'opened_at', 'origin')


def _satisfaction_points(dep: dict, journal: Journal):
    """The predecessor's changes of satisfaction for this edge, in journal order, as (instant, satisfied),
    and whether one of them has an unknown time. Broken counts as not satisfied (D-OBL-5)."""
    points, current, unknown = [], False, False
    for transition in journal.obligations[dep['from']]['transitions']:
        satisfied = satisfaction(transition['to'], dep['until']) == 'satisfied'
        if satisfied != current:
            if transition['at'] is None:
                unknown = True
            else:
                points.append((_instant(transition['at']), satisfied))
            current = satisfied
    return points, unknown


def _satisfied_at(points, instant) -> bool:
    value = False
    for when, satisfied in points:
        if when <= instant:
            value = satisfied
    return value


def clock(obl_id: str, journal: Journal, instant: float):
    """D-OBL-5's clock of one obligation at an instant, by replay: {'waiting': bool, 'since': instant},
    where `since` is `R` (runnable since) or the start of the current wait; None when unknown.

    The timeline starts at `opened_at`. An incoming edge counts from its confirmation's `ts` to its
    withdrawal's `ts`. The obligation waits while some counting edge is unsatisfied or broken. An edge
    confirmed after the instant does not count at it, so its predecessor's times cannot make it unknown."""
    start = _instant(journal.obligations[obl_id]['opened_at'])
    if start is None:
        return None
    edges, changes = [], {start}
    for dep in journal.dependencies.values():
        if dep['to'] != obl_id or dep.get('confirmed_ts') is None:
            continue
        begin = _instant(dep['confirmed_ts'])
        if begin > instant:
            continue
        points, unknown = _satisfaction_points(dep, journal)
        if unknown:
            return None
        end = _instant(dep['withdrawn_ts']) if dep.get('withdrawn_ts') else float('inf')
        edges.append((begin, end, points))
        changes.update({begin, end, *(when for when, _ in points)})

    def waiting(at):
        return any(begin <= at < end and not _satisfied_at(points, at) for begin, end, points in edges)

    since, state = start, waiting(start)
    for at in sorted(c for c in changes if start < c <= instant):
        now = waiting(at)
        if now != state:
            since, state = at, now
    return {'waiting': state, 'since': since}


def _end_of(node: dict, to: str):
    """The `at` of the last transition into `to`, or None."""
    for transition in reversed(node['transitions']):
        if transition['to'] == to:
            return transition['at']
    return None


def _satisfied_since(node: dict, until: str):
    """When the obligation last came to meet `until`, as an instant: the start of its final run of
    satisfying states (D-OBL-3). None when it does not meet `until` now, or that move's time is unknown."""
    current, since = False, None
    for transition in node['transitions']:
        satisfied = satisfaction(transition['to'], until) == 'satisfied'
        if satisfied and not current:
            since = transition['at']
        current = satisfied
    return _instant(since) if current else None


def _fraction_floor(p, n: int) -> int:
    from fractions import Fraction
    return min(int(Fraction(str(p)) * n), n - 1)


def nearest_rank(samples, p):
    """D-OBL-5: the sorted sample at 0-based position floor(p × n), capped at n − 1."""
    ordered = sorted(samples)
    return ordered[_fraction_floor(p, len(ordered))]


class Estimates:
    """D-OBL-5's series and quantiles and D-OBL-6's projections, for one journal at one read time `T`.

    Times are seconds since the epoch; durations are seconds. Nothing here is stored."""

    PHASE_END = {'deliver': 'delivered', 'close': 'closed'}
    UNTIL_PHASE = {'delivered': 'deliver', 'closed': 'close'}

    def __init__(self, journal: Journal, read_time: float):
        self.journal, self.T = journal, read_time
        self.window = (read_time - WINDOW_SECONDS, read_time)
        self._series: dict = {}
        self._finish: dict = {}     # (obligation, phase, p, kind) -> its finish, kept for this journal and read time

    def series(self, kind: str, phase: str) -> list:
        """Samples `R → end` for obligations of `kind` closed in the window, each with an exact `R` and end."""
        key = (kind, phase)
        if key not in self._series:
            samples = []
            for obl_id, node in self.journal.obligations.items():
                if node['kind'] != kind or node['state'] != 'closed':
                    continue
                closed = _instant(_end_of(node, 'closed'))
                if closed is None or not self.window[0] <= closed <= self.window[1]:
                    continue
                end = _instant(_end_of(node, self.PHASE_END[phase]))
                if end is None:
                    continue
                state = clock(obl_id, self.journal, end)
                if state is None or state['waiting']:
                    continue
                samples.append(end - state['since'])
            self._series[key] = samples
        return self._series[key]

    def _basis(self, scope: str, phase: str, n: int) -> str:
        frm, to = (datetime.fromtimestamp(t, timezone.utc).date().isoformat() for t in self.window)
        return f'history:{scope}:{phase}, n={n}, window={frm}–{to}'

    def quantile(self, kind: str, phase: str, p):
        """Q_p(kind, phase): the kind's own series with 5 or more samples, else its family's, else unknown.
        Returns (seconds or None, basis)."""
        own = self.series(kind, phase)
        if len(own) >= MIN_SAMPLES:
            return nearest_rank(own, p), self._basis(kind, phase, len(own))
        family = FAMILY_OF[kind]
        pooled = [x for member in FAMILIES[family] for x in self.series(member, phase)]
        if len(pooled) >= MIN_SAMPLES:
            return nearest_rank(pooled, p), self._basis(family, phase, len(pooled))
        return None, self._basis(family, phase, len(pooled))

    def finish(self, obl_id: str, phase: str, p, *, kind=None):
        """D-OBL-6's F_p,phase(o) at the read time, or None when unknown (never zero).

        Each (obligation, phase, p, kind) is computed once per `Estimates` and kept, so a predecessor shared by
        many paths costs one computation. The walk keeps its own stack rather than recursing, so no chain is too
        long to answer (CodeRabbit 4205375411). An obligation met again while its own finish is still being
        computed lies on a cycle, which admission refuses; it is answered from what is known, so unknown."""
        goal = (obl_id, phase, p, kind)
        stack, joins = [goal], {}
        while stack:
            key = stack[-1]
            if key in self._finish:
                stack.pop()
                continue
            if key not in joins:
                step = self._finish_step(*key)
                if not isinstance(step, tuple):
                    self._finish[key] = step
                    stack.pop()
                    continue
                joins[key] = step
                missing = [need for need in step[1] if need not in self._finish]
                if missing:
                    stack.extend(missing)
                    continue
            q, needs = joins.pop(key)
            whens = [self._finish.get(need) for need in needs]
            self._finish[key] = None if not whens or None in whens else max(whens) + q
            stack.pop()
        return self._finish[goal]

    def _finish_step(self, obl_id: str, phase: str, p, kind):
        """One obligation's finish when it needs no predecessor's: a time, or None when unknown. When it waits:
        (Q_p, the keys of its confirmed predecessors' finishes), which `finish` joins as the latest plus Q_p."""
        node = self.journal.obligations[obl_id]
        if node['state'] == 'parked' or node['state'] in ('declined', 'superseded'):
            return None
        if satisfaction(node['state'], self.PHASE_END[phase]) == 'satisfied':
            # The phase is reached: its actual time, the start of the final satisfying run (or unknown).
            return _satisfied_since(node, self.PHASE_END[phase])
        kind = kind or node['kind']
        q, _ = self.quantile(kind, phase, p)
        floor, _ = self.quantile(kind, phase, 0.2)
        state = clock(obl_id, self.journal, self.T)
        if q is None or floor is None or state is None:
            return None
        if not state['waiting']:
            return self.T + max(q - (self.T - state['since']), floor)
        # A broken edge's predecessor is declined or superseded, whose finish is unknown.
        return q, [self._edge_key(dep, p) for dep in self.journal.dependencies.values()
                   if dep['to'] == obl_id and dep['status'] == 'confirmed']

    def _edge_key(self, dep: dict, p):
        """The finish an edge waits for: its predecessor's, to the edge's `until`, through `human_act`'s series
        for a `needs_act` edge."""
        return dep['from'], self.UNTIL_PHASE[dep['until']], p, 'human_act' if dep['type'] == 'needs_act' else None

    def _edge_finish(self, dep: dict, p):
        """F_p,until(a) for an edge's predecessor a: its actual satisfying time once satisfied, else its projection."""
        obl_id, phase, p, kind = self._edge_key(dep, p)
        return self.finish(obl_id, phase, p, kind=kind)

    def time_to_complete(self, dep_id: str, p):
        """An edge's estimated time to complete: F_p,until(a) − T if unsatisfied, 0 if satisfied, else None
        (a broken edge's predecessor has an unknown finish)."""
        dep = self.journal.dependencies[dep_id]
        if satisfaction(self.journal.obligations[dep['from']]['state'], dep['until']) == 'satisfied':
            return 0.0
        when = self._edge_finish(dep, p)
        return None if when is None else when - self.T

    def longest_chain(self, target: str, p):
        """The chain of confirmed edges with the latest satisfying time or projected finish into `target`,
        oldest first: (list of obligation ids, finish of target or None). An unknown on the way ends the walk
        there and makes the chain's finish unknown, even where the target's own finish is known.
        A tie goes to the edge confirmed first in the journal, and within one batch to the one proposed first."""
        chain, current, unknown = [target], target, False
        while True:
            best, best_when = None, None
            incoming = [dep for dep in self.journal.dependencies.values()
                        if dep['to'] == current and dep['status'] == 'confirmed']
            for dep in sorted(incoming, key=lambda dep: dep['confirmed_seq']):
                when = self._edge_finish(dep, p)
                if when is None:
                    best, unknown = dep['from'], True
                    break
                if best_when is None or when > best_when:
                    best, best_when = dep['from'], when
            if best is None:
                break
            if best in chain:
                unknown = True                       # a cycle, which admission refuses: the walk ends, unknown
                break
            chain.insert(0, best)
            if unknown:
                break
            current = best
        return chain, (None if unknown else self.finish(target, 'close', p))
