"""Read-only console projections; receipt absence is never delivery evidence."""
from __future__ import annotations

import hashlib
import json
import dialogue
import console_attention
import panel
import receipts
import store
from console_observation import observe



def harness_snapshot(participants):
    """Value and provenance from one receipt snapshot; leave client-pinned code intact.

    Same qualification as harness_facts.snapshot (asserted by parity tests). The
    console-only provenance is not a new report field or client hook contract.
    """
    from harness_facts import validate
    allowed = {seat for seat, row in participants.items()
               if store.has_mailbox(row) and not store.inactive_participant(row)}
    values, sources = {}, {}
    for position, row in enumerate(receipts.rows()):
        if (row.get("kind") != "seat-act" or not isinstance(row.get("seat"), str)
                or row["seat"] not in allowed
                or row.get("command") not in {"inbox", "hook-fetch"} or "harness" not in row):
            continue
        try:
            value = validate(row["harness"])
        except ValueError:
            continue
        values[row["seat"]] = value
        sources[row["seat"]] = {"source": "authenticated seat-act receipt",
            "receipt_position": position, "command": row["command"],
            "recorded_at": row.get("ts"), "seat": row["seat"]}
    return values, sources


def panel_snapshot():
    registry = store.load_participants()
    journal = receipts.rows()

    def web_liveness(seat, participants, measured_at):
        # The web's observation vocabulary is has-session + capture-pane only.
        # Inject the probe into the shared panel producer, not its CLI probe
        # (display-message/pane PID). Headers and roster use this same snapshot.
        result = observe(seat, participants, lines=30)
        return {"value": result["liveness"], "source": panel.RUNTIME_VERIFIED,
                "measured_at": result["measured_at"],
                "detail": "registered has-session AND capture-pane"}

    snapshot = panel.build(participants=registry, liveness_probe=web_liveness)
    # The CLI retains its retirement count; neither inactive tier appears in UI state.
    snapshot.pop("retired_count", None)
    for row in snapshot["seats"]:
        participant = registry[row["seat"]["value"]]
        row["channel"] = {"value": participant.get("channel"), "source": panel.DECLARED}
        row["label"] = {"value": participant.get("label") or row["seat"]["value"],
                        "source": panel.DECLARED}
        row["role"] = {"value": participant.get("role"), "source": panel.DECLARED}
        row["home"] = {"value": participant.get("provisioned_home") or participant.get("workspace_dir"),
                       "source": panel.DECLARED, "detail": "registered home or declared workspace; no filesystem lookup"}
        route = participant.get("wake_route")
        declared = None
        generation = console_attention.route_generation(route)
        if generation:
            kind = route.get("kind")
            binding = route.get("session_ref")
            ref = (binding.get("conversation_id") if kind == "codex-ipc" and isinstance(binding, dict)
                   else binding if kind == "inapp-socket" and isinstance(binding, str) else None)
            declared = {"kind": kind, "thread_ref": ref,
                        "generation": generation,
                        "declared_at": route.get("declared_at")}
        row["declared_route"] = {"value": declared, "source": panel.DECLARED,
                                 "detail": "stored declaration fingerprint; no route probe"}
        row["attention"] = console_attention.project(row["seat"]["value"], participant, row, journal)
    return snapshot


def unread_snapshot():
    """Active console projection only; the underlying unread ledger is unchanged."""
    registry = store.load_participants()
    ledger = dict(store.unread_ledger())
    for key in ("rows", "hook_deliveries", "accepted_no_fetch"):
        if key in ledger:
            ledger[key] = [row for row in ledger[key]
                           if store.has_mailbox(registry.get(row.get("recipient"), {}))
                           and not any(store.inactive_participant(registry.get(row.get(field), {}))
                                      for field in ("recipient", "sender"))]
    if "accepted_no_fetch_counts" in ledger:
        from collections import Counter
        ledger["accepted_no_fetch_counts"] = dict(Counter(row["recipient"]
            for row in ledger.get("accepted_no_fetch", [])))
    return ledger


def delivery_projection(messages, *, journal=None, registry=None):
    """Project one journal snapshot, respecting committed FETCHED transactions.

    Read-only: never recover/materialize a transaction from an HTTP read. A
    coalesced message has no synthetic POKED row. Pre-only and failed attempts
    remain visible even when a later successful retry or fetch exists.
    """
    journal = receipts.rows() if journal is None else journal
    registry = store.load_participants() if registry is None else registry
    committed = {r.get("txn-id") for r in journal
                 if r.get("kind") == "delivery-transaction" and r.get("phase") == "commit"}
    committed -= {r.get("txn-id") for r in journal
                  if r.get("kind") == "delivery-transaction" and r.get("phase") == "abort"}
    import recall
    recalled = recall.graph(journal)
    fetched_positions = {position for position, _ in store.valid_fetched_deliveries(journal)}
    transitions, outstanding = {}, {}
    posts = {r.get("event-id"): r for r in journal
             if r.get("kind") == "nudge" and r.get("phase") == "post"}
    reconciled = {r.get('event-id'): r for r in journal
                  if r.get('kind') == 'recall-reconciliation'}
    attempts = {}
    for position, row in enumerate(journal):
        if row.get("kind") == "delivery":
            if row.get("txn-id") is not None and row["txn-id"] not in committed:
                continue
            if (row.get("event") == "FETCHED" and row.get("txn-id") is not None
                    and position not in fetched_positions):
                continue
            seat, mid = row.get("seat"), row.get("msg-id")
            transitions.setdefault((mid, seat), []).append(row)
            if row.get("event") == "POKED":
                outstanding[seat] = mid
            elif row.get("event") == "FETCHED" and outstanding.get(seat) == mid:
                outstanding.pop(seat, None)
        elif row.get("kind") == "nudge" and row.get("phase") == "pre":
            post = posts.get(row.get("event-id"))
            settlement = reconciled.get(row.get('event-id'))
            outcome = "UNKNOWN" if post is None else (
                "SUCCESS" if post.get("result") == "success" else "FAILED")
            if (settlement or post or {}).get('result') == 'recalled':
                outcome = 'RECALLED'
            attempts.setdefault((row.get("msg-id"), row.get("target seat")), []).append(
                {"event_id": row.get("event-id"), "outcome": outcome, "pre": row, "post": post,
                 **({'reconciliation': settlement} if settlement else {})})
    result = {}
    for message in messages:
        mid = message.get("id")
        targets = message.get("recipients", message.get("to", []))
        if not isinstance(targets, list):
            targets = []
        projected = []
        for seat in dict.fromkeys(t for t in targets if dialogue._explicit_identity(t)):
            events = transitions.get((mid, seat), [])
            nudges = attempts.get((mid, seat), [])
            queued = next((r for r in events if r.get("event") == "QUEUED"), None)
            channel = ("tmux" if nudges or any(r.get("event") == "POKED" for r in events)
                       else (queued or {}).get("adapter") or registry.get(seat, {}).get("channel"))
            status = events[-1].get("event") if events else None
            # A retry outcome cannot erase an evidenced poke or fetch.
            # Failure/uncertainty remains visible on its individual attempt.
            if status not in {"POKED", "FETCHED"} and nudges and nudges[-1]["outcome"] != "SUCCESS":
                status = nudges[-1]["outcome"]
            behind = outstanding.get(seat)
            if mid in recalled:
                status = 'RECALLED' if recalled[mid]['kind'] == 'recall' else 'WITHDRAWN'
            if behind in recalled:
                behind = None
            projected.append({"seat": seat, "channel": channel, "status": status,
                "events": events, "attempts": nudges,
                "pending_behind": behind if channel == "tmux" and status == "QUEUED"
                    and not nudges and behind and behind != mid else None})
        result[mid] = projected
    return result
