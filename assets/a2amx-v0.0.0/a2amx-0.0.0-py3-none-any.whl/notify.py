"""Per-channel notification adapters.

The store delivers (inbox append); these only *alert* a subscriber that mail
is waiting. All of them are best-effort and disposable — losing a nudge never
loses a message.
"""

from __future__ import annotations

import os
import subprocess
from typing import Any, Dict

from tmux_bridge import (
    registered_pane_ready,
    registered_session_exists,
    send_registered_prompt,
)

# macOS notifications are SILENT by default (the operator, 2026-06-17 — the per-message
# sound was noise under heavy hub traffic). Restore a sound by setting
# PSQR_NOTIFY_SOUND to a System Sounds name (e.g. "Ping", "Glass", "Submarine").
NOTIFY_SOUND = os.environ.get("PSQR_NOTIFY_SOUND") or None


def macos_notify(title: str, body: str, *, sound: str | None = NOTIFY_SOUND) -> bool:
    """Post a macOS notification via osascript. Returns False on failure."""
    def esc(s: str) -> str:
        return s.replace("\\", "\\\\").replace('"', '\\"')
    script = f'display notification "{esc(body[:200])}" with title "{esc(title[:80])}"'
    if sound:
        script += f' sound name "{esc(sound)}"'
    try:
        proc = subprocess.run(["osascript", "-e", script],
                              capture_output=True, text=True, timeout=10, check=False)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False
    return proc.returncode == 0


def one_line(text: str, limit: int = 80) -> str:
    import re
    flat = re.sub(r"\s+", " ", text).strip()
    return flat if len(flat) <= limit else flat[: limit - 1] + "…"


def compose_nudge(msg_id: str) -> str:
    """Return the sole Phase-A poke grammar, with no content or commands."""
    return f"mail: {msg_id}"


def registered_tmux_nudge(seat: str, participants: Dict[str, Dict[str, Any]],
                          nudge: str) -> tuple[bool, str]:
    """Send the Phase-A pointer through the seat's registered private server."""
    if any(control in nudge for control in ("\r", "\n")) \
            or not nudge.startswith("mail: ") or nudge == "mail: ":
        return False, "invalid_nudge_grammar"
    if not registered_session_exists(seat, participants):
        return False, "session_not_found"
    if not registered_pane_ready(seat, participants):
        return False, "pane_not_ready"
    # Recheck at the final adapter boundary as well as in daemon dispatch.
    # Unknown retains the existing readiness policy; no inferred readiness.
    from pane_state_adapter import observe
    from pane_state import input_allowed
    if not input_allowed(observe(seat, participants)):
        return False, "pane_input_withheld"
    result = send_registered_prompt(seat, participants, nudge,
        before_write=lambda: input_allowed(observe(seat, participants)))
    return result.ok, result.stderr or ""
