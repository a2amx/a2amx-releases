"""Provisioner-owned origin enrollment inside one D-SW-15 launch act.

This is a local trusted-launcher seam, not a host/HTTP operation. It accepts an
actual Popen and its private pipes, never a caller's JSON assertion of PID or
public key. The installed qualification resolver defaults to no qualifications;
no live profile can silently fall back to own-seat-token origin authentication.
No vendor process is started here. The existing authorized launcher owns spawn,
cleanup and the child's descriptor/environment configuration.
"""
from __future__ import annotations

import os
import re
from pathlib import Path
import secrets
import selectors
import stat
import subprocess
import time

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

import launched_origin as origin
import launched_protocol as wire
import launched_storage as files
import receipts
import store

PREPARED_FIELDS = frozenset({"seat", "canonical_home", "binding", "qualified_host_program_pin",
    "adapter_pin", "identity_sha256", "grounding_sha256", "supervisor_control_ref",
    "origin_qualification_ref", "configuration_sha256"})
PROCESS_FIELDS = frozenset({"pid", "birth", "owner_uid", "boot_incarnation", "command_sha256",
                            "program_sha256", "configuration_sha256"})
BOOTSTRAP_DOMAIN = "orch-launched-host-bootstrap/v1"


def no_qualification(_reference):
    return None


def canonical_path(value):
    wire.text(value, 4096)
    path = Path(value)
    if (not path.is_absolute() or str(path) != value or path.resolve() != path
            or any(ord(c) < 32 for c in value)):
        raise wire.Refused("binding_mismatch")
    return path


def validate_prepared(value):
    value = wire.decode(wire.canonical(value))
    wire.exact(value, PREPARED_FIELDS)
    wire.text(value["seat"])
    wire.binding(value["binding"])
    canonical_path(value["canonical_home"])
    canonical_path(value["supervisor_control_ref"])
    wire.text(value["origin_qualification_ref"])
    for name in ("qualified_host_program_pin", "adapter_pin", "identity_sha256",
                 "grounding_sha256", "configuration_sha256"):
        wire.digest(value[name])
    return value


class Enrollment:
    """Trusted core owner configuration; callbacks are never deserialized.

    `qualification` resolves an installed, independently approved exact profile,
    including host program/configuration/tool-isolation pins. `observe` queries
    the OS, not host-provided metadata. A missing resolver/observer is unavailable.
    SDK fixtures may supply their own explicit disposable qualification; that is
    no qualification of vendor execution or hostile same-UID isolation.
    """

    def __init__(self, *, qualification=no_qualification, observe=None, clock=time.time):
        self.qualification, self.observe, self.clock = qualification, observe, clock
        self.incarnation = "launch-owner-" + secrets.token_hex(16)
        self._active = set()
        self._completion_children = {}

    def _profile(self, prepared):
        profile = self.qualification(prepared["origin_qualification_ref"])
        fields = {"adapter_kind", "qualified_host_program_pin", "configuration_sha256",
                  "adapter_pin", "grounding_sha256", "identity_sha256"}
        if (type(profile) is not dict or self.observe is None
                or profile.get("origin_isolation") != "qualified"
                or any(profile.get(k) != (prepared["binding"][k] if k == "adapter_kind" else prepared[k])
                       for k in fields)):
            raise wire.Refused("origin_unqualified", "unavailable")
        return profile

    def _registry(self, prepared):
        row = store._read_participants_unlocked().get(prepared["seat"])
        if (not row or row.get("kind") != "agent" or store.inactive_participant(row)
                or store.normalize_family(row.get("family")) != prepared["binding"]["adapter_kind"]
                or str(store.seat_home(prepared["seat"], override=row.get("workspace_dir")).resolve())
                != prepared["canonical_home"]):
            raise wire.Refused("binding_mismatch")
        return row

    def prepare(self, value, *, presented_token):
        prepared = validate_prepared(value)
        def apply(actor):
            launch_ref = "launch-" + secrets.token_hex(16)
            bootstrap = {"domain": BOOTSTRAP_DOMAIN, "launch_receipt_ref": launch_ref,
                         "prepared_sha256": wire.fingerprint(prepared),
                         "nonce": origin.encode(secrets.token_bytes(32)),
                         "expires_at": self.clock() + 30, "core_incarnation": self.incarnation}
            pre = {"kind": "seat_lifecycle", "act": "launch", "phase": "pre",
                   "event-id": launch_ref, "seat": prepared["seat"], "requester": actor,
                   "credential_class": "provisioner", "adapter_pin": prepared["adapter_pin"],
                   "prepared_sha256": bootstrap["prepared_sha256"], "epoch": self.clock(), "ts": store.now_iso()}
            history = [r for r in receipts.strict_rows() if r.get("kind") == "seat_lifecycle"
                       and r.get("seat") == prepared["seat"]]
            receipts.append_durable(pre)
            try:
                row = self._registry(prepared)
                self._profile(prepared)
                if row.get("wake_route") is not None or row.get("hosting_kind") == "tmux-hosted":
                    raise wire.Refused("launch_conflict")
                completed = {r["event-id"]: r for r in history if r.get("phase") == "post"}
                for entry in history:
                    if entry.get("phase") != "pre" or entry.get("act") != "launch":
                        continue
                    post = completed.get(entry["event-id"])
                    if post is None:
                        # A recognized prepare whose private admission was never
                        # published could not return a bootstrap capability.
                        # Recover that gap only; an existing admission may have
                        # reached its launcher and still requires reconciliation.
                        if (entry.get("credential_class") == "provisioner"
                                and isinstance(entry.get("prepared_sha256"), str)
                                and re.fullmatch(r'[0-9a-f]{64}', entry['prepared_sha256'])
                                and re.fullmatch(r'launch-[0-9a-f]{32}', entry['event-id'])
                                and files.read("launch", entry["event-id"]) is None):
                            receipts.append_durable({**entry, "phase": "post", "result": "refused",
                                "reason": "prepare_not_published", "reconciled_by": actor,
                                "epoch": self.clock(), "ts": store.now_iso()})
                            continue
                        raise wire.Refused("launch_conflict")
                    if post.get("result") == "uncertain":
                        raise wire.Refused("launch_conflict")
                    if post.get("cleanup_required"):
                        child = self._completion_children.get(entry["event-id"])
                        if (child is not None and child.poll() is None) or self.observe is None:
                            raise wire.Refused("launch_conflict")
                        # Refused enrollment is not proof that a child died.
                        # Do not authorize a replacement until absence is known.
                        try:
                            observation = self.observe(post["pid"])
                        except wire.Refused:
                            raise  # Already typed; the outer handler receipts it.
                        except (OSError, ValueError):
                            # Undecidable absence blocks replacement, but must
                            # not strand this new prepare without its post.
                            raise wire.Refused("launch_conflict") from None
                        if observation is not None:
                            raise wire.Refused("launch_conflict")
                        self._completion_children.pop(entry["event-id"], None)
                    if post.get("result") == "done" and not any(
                            r.get("act") == "stop" and r.get("phase") == "post" and r.get("result") == "done"
                            and r.get("origin_ref") == (post.get("origin") or {}).get("origin_ref") for r in history):
                        raise wire.Refused("launch_conflict")
                    if (post.get("origin") or {}).get("binding", {}).get("host_generation") == prepared["binding"]["host_generation"]:
                        raise wire.Refused("launch_conflict")
                files.create("launch", launch_ref, {"prepared": prepared, "bootstrap": bootstrap,
                    "requester": actor, "completion_id": None})
            except Exception as exc:
                # This method has not returned its private bootstrap capability
                # and never spawns. Even a create error after replacement cannot
                # be treated as a successful prepare. Preserve a fixed reason.
                reason = exc.code if isinstance(exc, wire.Refused) else "prepare_failed"
                receipts.append_durable({**pre, "phase": "post", "result": "refused", "reason": reason,
                                         "epoch": self.clock(), "ts": store.now_iso()})
                raise
            return {"launch_receipt_ref": launch_ref, "bootstrap": bootstrap}
        return store.authenticated_registry_act(presented_token, apply, provisioning=True)

    def _observe(self, child, prepared):
        if type(child) is not subprocess.Popen or child.poll() is not None:
            raise wire.Refused("no_process")
        observed = self.observe(child.pid)
        wire.exact(observed, PROCESS_FIELDS)
        if (type(observed["pid"]) is not int or observed["pid"] != child.pid
                or type(observed["owner_uid"]) is not int or observed["owner_uid"] != os.getuid()):
            raise wire.Refused("owner_mismatch")
        wire.text(observed["birth"])
        wire.text(observed["boot_incarnation"])
        wire.digest(observed["command_sha256"])
        if (observed["program_sha256"] != prepared["qualified_host_program_pin"]
                or observed["configuration_sha256"] != prepared["configuration_sha256"]):
            raise wire.Refused("owner_mismatch")
        profile = self._profile(prepared)
        if observed["command_sha256"] != profile.get("command_sha256"):
            raise wire.Refused("owner_mismatch")
        return observed

    @staticmethod
    def _bootstrap(child, challenge):
        # Dedicated setup pipes are surrendered after the one frame. No vendor
        # output/transcript parsing and no generic send-message interface.
        for stream in (child.stdin, child.stdout):
            if stream is None or not stat.S_ISFIFO(os.fstat(stream.fileno()).st_mode):
                raise wire.Refused("owner_unresolved")
        child.stdin.write(wire.canonical(challenge) + b"\n")
        child.stdin.flush()
        deadline = time.monotonic() + 5
        data = bytearray()
        with selectors.DefaultSelector() as selector:
            selector.register(child.stdout, selectors.EVENT_READ)
            while b"\n" not in data and len(data) <= 4096:
                remaining = deadline - time.monotonic()
                if remaining <= 0 or not selector.select(remaining):
                    raise wire.Refused("owner_unresolved")
                chunk = os.read(child.stdout.fileno(), 4097 - len(data))
                if not chunk:
                    raise wire.Refused("no_process")
                data.extend(chunk)
        if len(data) > 4096 or not data.endswith(b"\n") or data.count(b"\n") != 1:
            raise wire.Refused("origin_invalid")
        response = wire.decode(bytes(data))
        wire.exact(response, {"public_key", "signature"})
        key = origin.decode(response["public_key"], 32)
        signature = origin.decode(response["signature"], 64)
        signed = {**challenge, "public_key": response["public_key"]}
        try:
            Ed25519PublicKey.from_public_bytes(key).verify(signature, wire.canonical(signed))
        except InvalidSignature:
            raise wire.Refused("origin_invalid") from None
        return response["public_key"]

    def complete(self, launch_ref, child, *, presented_token):
        wire.text(launch_ref)
        completion_id = "completion-" + secrets.token_hex(16)
        value = prepared = challenge = observed = None
        owned = False

        def preflight():
            self._registry(prepared)
            self._profile(prepared)
            if self.clock() >= challenge["expires_at"]:
                raise wire.Refused("launch_expired")
            return self._observe(child, prepared)

        def reserve(actor):
            nonlocal value, prepared, challenge, owned
            current = files.read("launch", launch_ref)
            if (not current or current.get("bootstrap", {}).get("core_incarnation") != self.incarnation
                    or current.get("completion_id") is not None):
                raise wire.Refused("launch_conflict")
            if current.get("requester") != actor:
                raise wire.Refused("credential_scope")
            if type(child) is not subprocess.Popen:
                raise wire.Refused("owner_unresolved")
            journal = receipts.strict_rows()
            rows = [r for r in journal if r.get("kind") == "seat_lifecycle" and r.get("event-id") == launch_ref]
            if (len(rows) != 1 or rows[0].get("phase") != "pre"
                    or rows[0].get("requester") != actor
                    or rows[0].get("prepared_sha256") != wire.fingerprint(current["prepared"])):
                raise wire.Refused("launch_conflict")
            value = {**current, "completion_id": completion_id}
            prepared, challenge = value["prepared"], value["bootstrap"]
            files.write("launch", launch_ref, value)
            owned = True
            self._completion_children[launch_ref] = child
            # Reservation precedes fallible admission checks. Only this owner
            # may close the attempt and its dedicated pipes on their failure.
            return preflight()

        def commit(actor):
            if (actor != value["requester"] or preflight() != observed
                    or files.read("launch", launch_ref) != value):
                raise wire.Refused("owner_mismatch")
            if any(r.get("event-id") == launch_ref and r.get("phase") == "post"
                   for r in receipts.strict_rows()):
                raise wire.Refused("launch_conflict")
            row = self._registry(prepared)
            if row.get("wake_route") is not None:
                raise wire.Refused("launch_conflict")
            record = {**prepared, **observed, "origin_ref": "origin-" + secrets.token_hex(16),
                      "public_key": public_key, "launch_receipt_ref": launch_ref,
                      "core_incarnation": self.incarnation, "state": "enrolled"}
            receipts.append_durable({"kind": "seat_lifecycle", "act": "launch", "phase": "post",
                "event-id": launch_ref, "seat": prepared["seat"], "requester": actor,
                "credential_class": "provisioner", "result": "done", "reason": "ok",
                "pid": observed["pid"], "birth": observed["birth"], "adapter_pin": prepared["adapter_pin"],
                "origin": record, "epoch": self.clock(), "ts": store.now_iso()})
            self._active.add(record["origin_ref"])
            self._completion_children.pop(launch_ref, None)
            return record
        try:
            observed = store.authenticated_registry_act(presented_token, reserve, provisioning=True)
            public_key = self._bootstrap(child, challenge)
            return store.authenticated_registry_act(presented_token, commit, provisioning=True)
        except (wire.Refused, store.RegistryMutationRefused, OSError, ValueError) as exc:
            if owned:
                def failure():
                    # A lost write, foreign request or concurrent completion
                    # cannot overwrite another owner's metadata or receipt.
                    if files.read("launch", launch_ref) != value:
                        return
                    rows = receipts.strict_rows()
                    if any(r.get("event-id") == launch_ref and r.get("phase") == "post" for r in rows):
                        return
                    code = exc.code if isinstance(exc, wire.Refused) else (
                        "credential_invalid" if isinstance(exc, store.RegistryMutationRefused) else "launch_failed")
                    receipts.append_durable({"kind": "seat_lifecycle", "act": "launch", "phase": "post",
                        "event-id": launch_ref, "seat": prepared["seat"], "requester": value["requester"],
                        "credential_class": "provisioner", "result": "refused", "reason": code,
                        "pid": child.pid, "birth": (observed or {}).get("birth"),
                        "cleanup_required": child.poll() is None, "adapter_pin": prepared["adapter_pin"],
                        "epoch": self.clock(), "ts": store.now_iso()})
                    if child.poll() is not None:
                        self._completion_children.pop(launch_ref, None)
                store._registry_locked(failure)
            raise
        finally:
            if owned:
                for stream in (child.stdin, child.stdout):
                    if stream is not None:
                        stream.close()

    def _enrolled_record(self, seat, requested_binding, *, journal=None):
        journal = receipts.strict_rows() if journal is None else journal
        rows = [r for r in journal if r.get("kind") == "seat_lifecycle" and r.get("seat") == seat]
        origins = [r["origin"] for r in rows if r.get("phase") == "post" and r.get("result") == "done"
                   and isinstance(r.get("origin"), dict)]
        if not origins:
            raise wire.Refused("origin_unqualified", "unavailable")
        record = origins[-1]
        if record.get("binding") != requested_binding:
            raise wire.Refused("binding_mismatch")
        return record, rows

    def current(self, seat, requested_binding):
        record, rows = self._enrolled_record(seat, requested_binding)
        if record.get("core_incarnation") != self.incarnation:
            raise wire.Refused("binding_mismatch")
        if (record.get("origin_ref") not in self._active or any(
                r.get("act") == "stop" and r.get("origin_ref") == record["origin_ref"] for r in rows)):
            raise wire.Refused("origin_unqualified", "unavailable")
        prepared = {k: record[k] for k in PREPARED_FIELDS}
        self._registry(prepared)
        self._profile(prepared)
        observed = self.observe(record["pid"])
        if observed is None:
            raise wire.Refused("no_process")
        if any(observed.get(k) != record[k] for k in PROCESS_FIELDS):
            raise wire.Refused("owner_mismatch")
        return record

    def prepare_stop(self, seat, requested_binding, *, presented_token):
        """Revoke admission before the existing launcher stops the process.

        This performs no kill. An open stop receipt makes current() unavailable.
        The completion is done only once OS observation establishes absence.
        """
        wire.text(seat); wire.binding(requested_binding)
        def apply(actor):
            record, history = self._enrolled_record(seat, requested_binding)
            # Retirement binds retained authenticated enrollment, not a live
            # origin admission. This also permits an already-crashed host.
            for prior in reversed(history):
                if prior.get("act") == "stop" and prior.get("origin_ref") == record["origin_ref"]:
                    if prior.get("requester") != actor:
                        raise wire.Refused("credential_scope")
                    if prior.get("phase") == "pre" or prior.get("result") == "done":
                        return {"stop_receipt_ref": prior["event-id"]}
                    break
            ref = "stop-" + secrets.token_hex(16)
            row = {"kind": "seat_lifecycle", "act": "stop", "phase": "pre", "event-id": ref,
                   "seat": seat, "requester": actor, "credential_class": "provisioner",
                   "origin_ref": record["origin_ref"], "binding": requested_binding,
                   "pid": record["pid"], "birth": record["birth"], "process": {k:record[k] for k in PROCESS_FIELDS},
                   "adapter_pin": record["adapter_pin"],
                   "epoch": self.clock(), "ts": store.now_iso()}
            receipts.append_durable(row)
            return {"stop_receipt_ref": ref}
        return store.authenticated_registry_act(presented_token, apply, provisioning=True)

    def complete_stop(self, stop_ref, *, presented_token):
        wire.text(stop_ref)
        def apply(actor):
            matches = [r for r in receipts.strict_rows() if r.get("kind") == "seat_lifecycle"
                       and r.get("act") == "stop" and r.get("event-id") == stop_ref]
            if not matches or matches[0].get("requester") != actor or matches[0].get("phase") != "pre":
                raise wire.Refused("launch_conflict")
            if len(matches) > 1:
                if matches[-1].get("phase") != "post":
                    raise wire.Refused("persistence_unknown", "unknown")
                return {"result": matches[-1]["result"], "reason": matches[-1]["reason"]}
            pre = matches[0]
            result, reason = "uncertain", "owner_unresolved"
            try:
                if self.observe is None:
                    raise wire.Refused("owner_unresolved")
                observed = self.observe(pre["pid"])
                if observed is None:
                    result, reason = "done", "ok"
                else:
                    wire.exact(observed, PROCESS_FIELDS)
                    if observed != pre.get("process"):
                        reason = "owner_mismatch"
            except (wire.Refused, OSError, ValueError):
                pass
            if result == "done":
                from launched_gateway import _retiring
                parts = store._read_participants_unlocked()
                row = parts.get(pre["seat"]) or {}
                route = row.get("wake_route")
                if route and route.get("binding") == pre["binding"]:
                    candidate = {**parts, pre["seat"]: {**row, "wake_route": None}}
                    with _retiring(pre["seat"]):
                        store._write_participants_unlocked(candidate)
            receipts.append_durable({**pre, "phase": "post", "result": result, "reason": reason,
                                     "epoch": self.clock(), "ts": store.now_iso()})
            return {"result": result, "reason": reason}
        return store.authenticated_registry_act(presented_token, apply, provisioning=True)
