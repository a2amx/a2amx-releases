"""Closed launched-seat gateway v1 wire contract; no store or native effects.

HOST_METHODS.json in LAUNCHED_SEAT_CORE_GATEWAY_01 defines the business
envelopes. Authentication and origin proofs travel in separate private frames.
JCS is supplied by a pinned implementation, not json.dumps(sort_keys=True).
"""
from __future__ import annotations

import hashlib
import json
import math
import re

import rfc8785

PROTOCOL = "launched-seat-core-gateway"
VERSION = 1
MAX_FRAME_BYTES = 65536
PROTECTED = frozenset({"host.route.declare", "host.intent.verify", "host.mail.fetch",
                       "host.event.pointer", "host.event.arrival"})
V2 = frozenset({"host.execution.record", "host.decision.await"})
METHOD_FIELDS = {
    "host.capabilities": frozenset(),
    "host.authenticate": frozenset(),
    "host.route.declare": frozenset({"declaration_id", "binding", "ref",
        "identity_sha256", "adapter_pin", "expected_route_generation"}),
    "host.intent.verify": frozenset({"binding", "route_generation", "delivery"}),
    "host.mail.fetch": frozenset({"binding", "route_generation", "verification_ref"}),
    "host.fetch.proof": frozenset({"binding", "route_generation", "intent_id", "pre_receipt_ref"}),
    "host.event.pointer": frozenset({"binding", "route_generation", "verification_ref", "event"}),
    "host.event.arrival": frozenset({"binding", "route_generation", "admission_id", "event"}),
    "host.status": frozenset({"binding", "declaration_id"}),
}
REASONS = frozenset({
    "ok", "invalid_request", "protocol_unsupported", "method_unsupported",
    "requires_O9_v2", "credential_invalid", "credential_scope", "binding_mismatch",
    "origin_unqualified", "origin_required", "origin_invalid", "origin_expired",
    "origin_replayed", "origin_capacity", "declaration_conflict", "stale_generation",
    "intent_mismatch", "intent_expired", "intent_withdrawn", "claim_conflict",
    "result_conflict", "event_conflict", "fetch_unknown", "persistence_unknown",
    "owner_mismatch", "owner_unresolved", "no_process", "seat_busy",
    "fetch_pending", "fetch_committed", "delivery_uncertain", "launch_conflict",
    "launch_unqualified", "launch_expired", "launch_failed", "qualification_invalid",
    "live_unqualified", "gateway_unavailable", "acceptance_unresolved",
})


class Refused(ValueError):
    """Only fixed public reasons; never interpolate input or an exception."""

    def __init__(self, code="invalid_request", status="refused"):
        if code not in REASONS or status not in {"refused", "unavailable", "unknown"}:
            raise ValueError("invalid gateway error")
        self.code, self.status = code, status
        super().__init__(code)


def exact(value, fields):
    if type(value) is not dict or set(value) != set(fields):
        raise Refused()
    return value


def text(value, limit=128):
    try:
        valid = type(value) is str and 0 < len(value.encode("utf-8")) <= limit
    except UnicodeError:
        valid = False
    if not valid:
        raise Refused()
    return value


def digest(value):
    if type(value) is not str or re.fullmatch(r"[a-f0-9]{64}", value) is None:
        raise Refused()
    return value


def timestamp(value):
    if type(value) not in {int, float}:
        raise Refused()
    try:
        if not math.isfinite(value):
            raise Refused()
    except (OverflowError, ValueError):
        raise Refused() from None
    return value


def binding(value):
    exact(value, {"session_ref", "adapter_kind", "host_generation"})
    for item in value.values():
        text(item)
    # Future adapters require producer qualification; strings are opaque here.
    return value


def pointer(value):
    if type(value) is not str or re.fullmatch(r"mail: msg-[a-f0-9]{10}", value) is None:
        raise Refused()
    return value


def _tree(value, depth=0):
    if depth > 16:
        raise Refused()
    if type(value) is dict:
        for key, item in value.items():
            text(key, MAX_FRAME_BYTES)
            _tree(item, depth + 1)
    elif type(value) is list:
        for item in value:
            _tree(item, depth + 1)
    elif type(value) is str:
        try:
            value.encode("utf-8")
        except UnicodeError:
            raise Refused() from None
    elif value is not None and type(value) is not bool:
        timestamp(value)


def canonical(value):
    _tree(value)
    try:
        data = rfc8785.dumps(value)
    except (ValueError, TypeError, OverflowError):
        raise Refused() from None
    if len(data) > MAX_FRAME_BYTES:
        raise Refused()
    return data


def fingerprint(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise Refused()
        result[key] = value
    return result


def decode(data):
    if type(data) is not bytes or len(data) > MAX_FRAME_BYTES:
        raise Refused()
    def invalid(_):
        raise Refused()
    try:
        value = json.loads(data.decode("utf-8"), object_pairs_hook=_pairs,
                           parse_constant=invalid)
        canonical(value)
        return value
    except (UnicodeError, ValueError, RecursionError):
        raise Refused() from None


def request(value):
    """Validate and detach from caller-owned mutable data before authentication."""
    value = decode(canonical(value)) if type(value) is dict else decode(value)
    exact(value, {"protocol", "version", "call_id", "method", "params"})
    if value["protocol"] != PROTOCOL or type(value["version"]) is not int or value["version"] != VERSION:
        raise Refused("protocol_unsupported", "unavailable")
    text(value["call_id"])
    method, params = value["method"], value["params"]
    text(method)
    if method in V2:
        raise Refused("requires_O9_v2", "unavailable")
    if method not in METHOD_FIELDS:
        raise Refused("method_unsupported", "unavailable")
    exact(params, METHOD_FIELDS[method])
    for key, item in params.items():
        if key == "binding":
            binding(item)
        elif key in {"identity_sha256", "adapter_pin"}:
            digest(item)
        elif key == "ref":
            text(item, 4096)
        elif key not in {"event", "delivery"}:
            if item is None and (key == "expected_route_generation" or
                                 method == "host.status" and key == "declaration_id"):
                continue
            text(item)
    if method == "host.intent.verify":
        delivery = exact(params["delivery"], {"intent_id", "claim_ref", "pre_receipt_ref", "pointer", "not_after"})
        for key in ("intent_id", "claim_ref", "pre_receipt_ref"):
            text(delivery[key])
        pointer(delivery["pointer"])
        timestamp(delivery["not_after"])
    if method == "host.event.pointer":
        event = exact(params["event"], {"event", "pointer", "session_ref", "session_id"})
        if event["event"] != "UserPromptSubmit":
            raise Refused()
        pointer(event["pointer"])
        text(event["session_ref"])
        text(event["session_id"])
        if event["session_ref"] != params["binding"]["session_ref"]:
            raise Refused("binding_mismatch")
    if method == "host.event.arrival":
        event = exact(params["event"], {"event", "channel", "text_sha256"})
        if event["event"] != "prompt_arrived" or event["channel"] != "attach":
            raise Refused()
        digest(event["text_sha256"])
    return value


def response(call_id, *, result=None, error=None):
    # A malformed/unrecoverable call id is deliberately not echoed.
    try:
        text(call_id)
    except Refused:
        call_id = None
    if error is not None and not isinstance(error, Refused):
        raise ValueError("unclassified gateway error")
    return {"protocol": PROTOCOL, "version": VERSION, "call_id": call_id,
            "status": "ok" if error is None else error.status,
            "result": result if error is None else None,
            "error": None if error is None else {"code": error.code, "retryable": False}}
