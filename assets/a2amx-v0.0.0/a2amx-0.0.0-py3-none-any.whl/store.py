"""PSQR orchestrator message store.

Append-only JSONL files under a single store directory. Every write holds an
exclusive flock for the duration of the append and fsyncs before releasing, so
concurrent writers (CLI, daemon, server threadpool) interleave at line
granularity. Readers tolerate a torn final line (no trailing newline) by
skipping it — the next reader pass picks it up once the newline lands.

Layout (see docs/DELIVERY_V2_DESIGN.md):
    store/log.jsonl              global append-only message history
    store/inbox/<P>.jsonl        per-subscriber inbox (append = watcher wake)
    store/cursor/<P>.json        consumed byte offset into the inbox
    store/participants.json      registry (atomic replace under flock)
    store/tasks.jsonl            task event log; board state derived by replay
    store/drop/<P>/*.txt         file-reply drop (for agents that can write
                                 files but not run shells, e.g. Gemini auto_edit)
"""

from __future__ import annotations

import stage1_features

import fcntl
import hashlib
import hmac
import inspect
import json
import os
import re
import secrets
import shlex
import stat
import threading
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional

import constitution   # leaf module (no store/ledger import) — governance knob source
import product_identity
from identity_resolution import label_index, resolve_id_or_label

SCRIPT_DIR = Path(__file__).resolve().parent

# --- active-store binding (ORCH_SPEC_01 D-STO-1; Phase 0 W0.1 / W0.2) ------------------
#
# ONE authoritative locator at a fixed absolute path OUTSIDE every repository and every
# shell environment: ``~/.orch/active_store`` (mode 0600). Line 1 is the absolute store
# directory; line 2 is the ``#registered <ISO-ts> by <participant> from <sha256 of
# log.jsonl> prepare <ledger id of the store_registration_prepared row>`` comment that
# ``orch store register`` writes — the prepare id is the one field that ties the locator
# to a SINGLE registration sequence (ts, registrant and hash all repeat when an unchanged
# store is re-registered within the same second). ``resolve_store_dir()`` is the
# ONLY way any process learns its store — CLI, daemon, server, watchers, notify, delivery,
# tests. There is NO checkout default: the former ``SCRIPT_DIR / "store"`` fallback routed
# an ordinary CLI call into a frozen checkout and wrote a live message there (META_HARNESS
# candidate MH-CANDIDATE-ORCH-STORE-PATH, ``store.py:39``); it is DELETED, not guarded.
# ``PSQR_STORE_DIR`` survives only as an explicit override that MUST EQUAL the locator — a
# mismatch refuses, naming both; it never substitutes for the locator. An absent or invalid
# locator refuses: non-zero exit, no write anywhere, one diagnostic naming the locator path
# and the registration command.

LOCATOR_RELPATH = Path(product_identity.load().home_directory) / "active_store"
#: Line 2 of the locator, exactly as ``register_store`` writes it. The trailing prepare id
#: is the ledger id of the ``store_registration_prepared`` row of the sequence that
#: committed this binding (``ledger.new_event_id`` mints it BEFORE the temp locator is
#: written, so the id is fsynced into the very file the commit renames into place).
LOCATOR_COMMENT_RE = re.compile(
    r"#registered (?P<ts>\S+) by (?P<registrant>\S+) from (?P<sha256>[0-9a-f]{64}) "
    r"prepare (?P<prepare_id>evt_[0-9A-HJKMNP-TV-Z]{26})")
STORE_ENV_OVERRIDE = "PSQR_STORE_DIR"
REGISTER_COMMAND = product_identity.command()+" --as <you> store register <absolute-store-dir>"
CANDIDATES_COMMAND = product_identity.command()+" store candidates"
#: Refusal exit status. 78 is sysexits' EX_CONFIG ("something was found in an unconfigured
#: or misconfigured state") and collides with no status the CLI already uses (0/1/2/3), so
#: a watcher loop can never mistake a refusal for its heartbeat (2) or a burn-guard trip (3).
STORE_UNBOUND_EXIT = getattr(os, "EX_CONFIG", 78)


class StoreUnbound(RuntimeError):
    """No active store is bound: the locator is absent/invalid, or PSQR_STORE_DIR names a
    different directory. ``str(exc)`` is the ONE diagnostic every entry point prints."""
    exit_code = STORE_UNBOUND_EXIT


class StoreRegisteredWithoutReceipt(RuntimeError):
    """The registration COMMITTED (the locator visibly names the store) but the completion
    receipt could not be appended to the store's ledger. This is NOT a refusal: the binding
    is in effect. ``str(exc)`` says so and names the recovery — re-run the registration,
    which writes a fresh prepare/receipt pair linked to this one (``recovers_prepared_id``).
    Exit status 74 (sysexits EX_IOERR), distinct from a refusal (78) and from success (0)."""
    exit_code = getattr(os, "EX_IOERR", 74)

    def __init__(self, *, store_dir: Path, locator: Path, prepared_id: str, error: str,
                 registrant: str, durability_error: Optional[str] = None):
        self.store_dir, self.locator, self.prepared_id = store_dir, locator, prepared_id
        self.error, self.registrant = error, registrant
        self.durability_error = durability_error
        # Durability is never claimed here (reviewer-P0-3): no receipt records the directory
        # fsync, and when that fsync itself failed the commit is visible but NOT proven to
        # survive a crash.
        durability = (f"durability across a crash: NOT proven — the locator directory fsync "
                      f"FAILED ({durability_error}) and no receipt records it"
                      if durability_error is not None else
                      "durability across a crash: unreceipted — the directory fsync succeeded "
                      "in this process, but no receipt records it; treat it as unproven")
        super().__init__(
            f"registered {store_dir} — the locator {locator} IS committed and in effect, but "
            f"the completion receipt is MISSING: the append to {store_dir}/ledger.jsonl failed "
            f"({error}). Prepared row {prepared_id} has no receipt. {durability}.\n"
            f"  recovery: {product_identity.command()} --as {registrant} store register {store_dir}   (writes a fresh "
            f"prepare/receipt pair that names this prepare as recovered, and retries the fsync)")


class RegistrationBusy(ValueError):
    """Another registration (or a starting daemon) holds the locator-level exclusion. A
    REFUSAL — nothing was written — so a concurrent registration never races the one in
    flight and never reports a success the locator does not hold (reviewer-P0-4)."""


def locator_path() -> Path:
    """The locator's fixed path under the CURRENT home directory. Evaluated per call, not
    at import, so a process whose HOME is redirected (tests, the isolated reviewer
    launcher) reads that home's locator and never a cached one."""
    return Path.home() / LOCATOR_RELPATH


#: The locator-level exclusion (reviewer-P0-4): an flock on this file, beside the locator.
REGISTRATION_LOCK_NAME = "active_store.lock"


def registration_lock_path() -> Path:
    return locator_path().with_name(REGISTRATION_LOCK_NAME)


@contextmanager
def registration_exclusion(*, wait: bool = False) -> Iterator[Path]:
    """ONE writer at the locator at a time (reviewer-P0-4): an ``flock`` on
    ``~/.orch/active_store.lock`` (0600), released when the block exits or the holder dies.
    ``register_store`` holds it across its WHOLE sequence — current-locator read,
    live-daemon check, prepare, commit, parent-dir fsync, completion receipt — so two
    registrations can never both read the same binding and both report success; the
    delivery daemon holds it while it re-reads the locator and takes ``daemon.lock``, so it
    can neither enter on a binding that is being superseded nor slip in between a
    registration's live-daemon check and its commit. ``wait=False`` REFUSES at once
    (RegistrationBusy): a registration is a deliberate act and never queues behind an
    unknown writer. ``wait=True`` blocks — the daemon, which re-verifies afterwards."""
    lock_path = registration_lock_path()
    lock_path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    fd = os.open(lock_path, os.O_RDWR | os.O_CREAT, 0o600)
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | (0 if wait else fcntl.LOCK_NB))
        except BlockingIOError:
            raise RegistrationBusy(
                f"another registration (or a starting daemon) holds {lock_path} — refusing "
                f"to race it: nothing was written; retry once it has finished") from None
        yield lock_path
    finally:
        os.close(fd)                                 # releases the flock


def _unbound(problem: str, *, locator: Path) -> StoreUnbound:
    return StoreUnbound(
        f"{product_identity.command()}: no active store is bound — refusing to run.\n"
        f"  locator : {locator} ({problem})\n"
        f"  register: {REGISTER_COMMAND}\n"
        f"  preflight (measures every candidate, chooses none): {CANDIDATES_COMMAND}")


def read_locator(locator: Optional[Path] = None) -> tuple[Path, str]:
    """Parse the locator STRICTLY: a regular 0600 file whose first line is an absolute
    path naming an existing directory that contains ``log.jsonl``. Returns
    ``(store_dir, registration_comment)`` or raises StoreUnbound naming exactly what is
    wrong. Reads only; never writes."""
    loc = locator if locator is not None else locator_path()
    try:
        st = loc.lstat()
    except FileNotFoundError:
        raise _unbound("absent", locator=loc) from None
    except OSError as exc:
        raise _unbound(f"unreadable: {exc.strerror}", locator=loc) from None
    if stat.S_ISLNK(st.st_mode) or not stat.S_ISREG(st.st_mode):
        raise _unbound("not a regular file", locator=loc)
    if stat.S_IMODE(st.st_mode) != 0o600:
        # exactly 0600 (W0.1), not merely "no group/other bits": 0400 and 0700 are refused too
        raise _unbound(f"mode {stat.S_IMODE(st.st_mode):04o} is not exactly 0600 — repair with: "
                       f"chmod 600 {loc}", locator=loc)
    try:
        lines = loc.read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeDecodeError) as exc:
        raise _unbound(f"unreadable: {exc}", locator=loc) from None
    if not lines or not lines[0].strip():
        raise _unbound("empty", locator=loc)
    raw = lines[0].strip()
    if not os.path.isabs(raw):
        raise _unbound(f"line 1 is not an absolute path: {raw!r}", locator=loc)
    store_dir = Path(os.path.normpath(raw))
    if not store_dir.is_dir():
        raise _unbound(f"names {store_dir}, which is not a directory", locator=loc)
    if not (store_dir / "log.jsonl").is_file():
        raise _unbound(f"names {store_dir}, which has no log.jsonl", locator=loc)
    comment = lines[1].strip() if len(lines) > 1 else ""
    return store_dir, comment


def _same_dir(a: Path, b: Path) -> bool:
    """Directory identity, symlink-insensitive (macOS mkdtemp answers /var/… for
    /private/var/…) — the ONLY comparison the override and the lock are held to."""
    try:
        return a.resolve() == b.resolve()
    except OSError:
        return False


def resolve_store_dir() -> Path:
    """THE resolver — the one code path that turns "which store?" into a directory.

    locator → must exist, parse to an absolute path, and name a directory containing
    ``log.jsonl``, else StoreUnbound. ``PSQR_STORE_DIR``, when set, must name the SAME
    directory, else StoreUnbound naming both. Reads only; never writes; never guesses."""
    loc = locator_path()
    store_dir, _ = read_locator(loc)
    override = product_identity.inherited_setting(STORE_ENV_OVERRIDE)
    if override is not None:
        wanted = Path(os.path.normpath(os.path.expanduser(override.strip()))) \
            if override.strip() else None
        if wanted is None or not wanted.is_absolute() or not _same_dir(wanted, store_dir):
            if product_identity.is_public():
                raise StoreUnbound(
                    f"{product_identity.command()}: installation configuration does not match the registered store; refusing to run.\n"
                    f"  locator: {loc} -> {store_dir}")
            raise StoreUnbound(
                f"orch: {STORE_ENV_OVERRIDE} does not match the registered active store — "
                "refusing to run.\n"
                f"  locator : {loc} -> {store_dir}\n"
                f"  env     : {STORE_ENV_OVERRIDE}={override!r}\n"
                f"  the env var never substitutes for the locator: unset it, set it to "
                f"{store_dir}, or re-register with: {REGISTER_COMMAND}")
    return store_dir


class UnboundStoreDir:
    """Stands in for STORE_DIR when no store is bound. Path-shaped enough that module-level
    derivations (``STORE_DIR / "x"``) import cleanly — and NOTHING else: every
    filesystem-facing use (``str()``, ``os.fspath()``, ``.exists()``, ``.open()``,
    ``.mkdir()``, truthiness, formatting, …) raises the captured StoreUnbound. A process
    that slips past its entry-point check therefore cannot read, write, or even NAME a
    directory — the refusal is structural, not a convention."""
    __slots__ = ("_reason", "_tail")

    def __init__(self, reason: StoreUnbound, tail: tuple[str, ...] = ()):
        object.__setattr__(self, "_reason", reason)
        object.__setattr__(self, "_tail", tail)

    def __truediv__(self, other: Any) -> "UnboundStoreDir":
        return UnboundStoreDir(self._reason, self._tail + (str(other),))

    def __repr__(self) -> str:
        return "<UnboundStoreDir " + "/".join(("<unbound>",) + self._tail) + ">"

    def __str__(self) -> str:
        raise self._reason

    def __format__(self, spec: str) -> str:
        raise self._reason

    def __fspath__(self) -> str:
        raise self._reason

    def __bytes__(self) -> bytes:
        raise self._reason

    def __bool__(self) -> bool:
        raise self._reason

    def __eq__(self, other: Any) -> bool:
        return self is other

    def __hash__(self) -> int:
        return id(self)

    def __getattr__(self, name: str) -> Any:
        raise self._reason


def _bind_store_dir() -> "Path | UnboundStoreDir":
    try:
        return resolve_store_dir()
    except StoreUnbound as exc:
        return UnboundStoreDir(exc)


STORE_DIR = _bind_store_dir()


def require_bound_store() -> Path:
    """Fail fast at an entry point: the bound store, or the StoreUnbound captured at import.
    Not a resolver — it re-reads nothing; the binding is the import-time result of
    ``resolve_store_dir()`` and every module-level path derives from it."""
    if isinstance(STORE_DIR, UnboundStoreDir):
        raise STORE_DIR._reason
    return STORE_DIR


LOG_FILE = STORE_DIR / "log.jsonl"
INBOX_DIR = STORE_DIR / "inbox"
CURSOR_DIR = STORE_DIR / "cursor"
TASKS_FILE = STORE_DIR / "tasks.jsonl"
PARTICIPANTS_FILE = STORE_DIR / "participants.json"
REGISTRY_LOCK = STORE_DIR / ".registry.lock"
LEGACY_ROLE_PENDING = STORE_DIR / ".legacy_role_normalisation.pending.json"
REGISTRY_PARK_PENDING = STORE_DIR / ".registry_parking.pending.json"
REGISTRY_ROLE_PENDING = STORE_DIR / ".registry_role.pending.json"
RUNTIME_LAUNCH_FENCE_LOCK = STORE_DIR / ".runtime_launch_fence.lock"

# Cross-process launch-identity fence.  Lock order is deliberately fixed:
# RUNTIME_LAUNCH_FENCE_LOCK -> TOKENS_LOCK -> REGISTRY_LOCK (or the independent
# runtime_registry.RUNTIME_LOCK). Authenticated provisioning holds this order
# through its effect. No writer may acquire the fence while holding a registry
# lock without already owning the fence. The RLock/thread-local pair makes nested
# participant reads/seeding safe in one process while still excluding sibling
# server threads; flock provides the process boundary.
_runtime_launch_fence_mutex = threading.RLock()
_runtime_launch_fence_local = threading.local()
_token_mutex = threading.RLock()
_token_local = threading.local()
_registry_actor_local = threading.local()

VALID_CHANNELS = {"tmux", "watch", "pull", "notify"}

# The operator — exempt from the burn guard, and the recipient of its alerts.
OWNER = product_identity.inherited_setting("PSQR_OWNER") or "local-operator"


class OperatorIdentityError(ValueError):
    exit_code = 78


def operator_identity():
    """Resolve an existing human without inventing an inbox after an upgrade."""
    parts = load_participants()
    humans = {pid for pid, row in parts.items()
              if row.get('kind') == 'human' and row.get('role') in {None, 'human_authority'}
              and not row.get('retired_at') and not row.get('parked_at')}
    explicit = product_identity.inherited_setting('PSQR_OWNER')
    if explicit:
        if explicit in humans:
            return explicit
        raise OperatorIdentityError(product_identity.diagnostic(
            'PSQR_OWNER must name a registered active human authority',
            'the configured operator is not a registered active human authority'))
    if 'local-operator' in humans:
        return 'local-operator'
    if len(humans) == 1:
        return next(iter(humans))
    raise OperatorIdentityError(product_identity.diagnostic(
        'operator identity is ambiguous or absent; set PSQR_OWNER explicitly',
        'the installation has no unambiguous operator identity'))

# --- burn guard: hub-layer runaway-loop / storm caps (execution-plan v2 P0/P1) ---
# Enforced HERE, at the send chokepoint every CLI and API message funnels through
# — NOT via the trace ledger. The capture spike confirmed foreign CLIs may never
# expose tool-calls to the ledger, so a ledger-dependent guard would be blind
# exactly where a runaway loop hides. This is what would have stopped the Gemma
# broadcast-loop. Set a cap to 0 to disable it. Caps are read at import: changing
# the env requires a process restart (server/daemon) to take effect (reviewer PR#12 LOW).
BURN_MAX_CONSECUTIVE = int(os.environ.get("PSQR_BURN_MAX_CONSECUTIVE",
                                          str(constitution.value("burn_guard.max_consecutive", 8))))
BURN_MAX_PER_WINDOW = int(os.environ.get("PSQR_BURN_MAX_PER_WINDOW",
                                         str(constitution.value("burn_guard.max_per_window", 20))))
BURN_WINDOW_SEC = int(os.environ.get("PSQR_BURN_WINDOW_SEC", "60"))


class BurnGuardTripped(Exception):
    """Raised by send() when a sender exceeds the hub-layer storm/loop caps."""


class TypedAckRefused(ValueError):
    """CLI admission refusal from the existing typed-ack-solicited vet row."""


class RecipientPolicyError(KeyError):
    """Typed refusal for disallowed or changed recipient addressing."""

    def __init__(self, reason: str, target: str):
        self.reason = reason
        self.target = target
        self.detail = {
            "error": "recipient_policy_refusal",
            "reason": reason,
            "target": target,
            "remedy": ("retry the send to resolve and validate the current Chief of Staff"
                       if reason == "system_notice_routing_changed" else
                       "ask the Chief of Staff" if reason == "seat_parked" else
                       "choose an active seat; retired identities cannot receive new mail"
                       if reason == "seat_retired" else "use an explicit comma-separated participant list"),
        }
        super().__init__(target)

    def __str__(self) -> str:
        return json.dumps(self.detail, sort_keys=True)


class UnreadMailRefused(ValueError):
    """Authenticated agent send refused before any message or receipt is stored."""

    def __init__(self, seat: str, unread: list[dict], *, token_path: Path):
        import shlex
        oldest = min(unread, key=lambda row: (
            datetime.fromisoformat(row["ts"]).timestamp(), row["id"]))
        self.detail = {
            "error": "unread_mail_refusal", "seat": seat, "count": len(unread),
            "oldest_id": oldest["id"],
            "fetch_command": product_identity.diagnostic("~/agents/_bin/orch-read", product_identity.command("read"))+" --token-file "
                + shlex.quote(str(token_path)) + " " + shlex.quote(seat),
        }
        super().__init__(json.dumps(self.detail, sort_keys=True))

class UnreadStateBusy(ValueError):
    """Refuse without a write when a fresh unread observation cannot be obtained."""

    def __init__(self, seat: str):
        self.detail = {
            "error": "unread_state_busy", "seat": seat,
            "remedy": "mail state changed during three checks; fetch and retry the send",
        }
        super().__init__(json.dumps(self.detail, sort_keys=True))


# --- post-send hooks (Stage 0 trace ledger, see ledger.py) ---
# A bare list so store's *module load* never imports ledger (avoids a store<->ledger circular
# import). ledger.install() appends a mirror hook here. Each hook runs right after the canonical
# log append (pre-fanout) and MUST NOT break delivery — send() swallows any hook exception.
_post_send_hooks = []

# Hooks are process-local, but store.send() is called from EVERY process (server, the
# bin/orch CLI, daemons). Relying on one entry point to `import ledger` would silently drop
# that process's traffic from the ledger. So send() self-activates the built-in mirror once
# per process via a lazy, guarded import — cross-process capture with no circular import at
# module load, and a ledger problem can never break the message bus.
_hooks_bootstrapped = False
_hooks_bootstrap_failed = False
_hooks_bootstrap_lock = threading.Lock()


def _bootstrap_hooks() -> None:
    global _hooks_bootstrapped, _hooks_bootstrap_failed
    if _hooks_bootstrapped:              # fast path once initialized — no lock per send
        return
    with _hooks_bootstrap_lock:
        if _hooks_bootstrapped:          # double-check under the lock
            return
        try:
            import ledger  # noqa: F401 — ledger.install() registers its mirror into _post_send_hooks
        except Exception:
            _hooks_bootstrap_failed = True
        else:
            _hooks_bootstrap_failed = False
        # Flip the flag only AFTER the import finished (Bugbot #40: setting it first let a
        # concurrent send observe bootstrapped=True while _post_send_hooks was still empty
        # and skip the mirror for that message permanently — server sends run on a
        # threadpool). A failed import still sets it: no retry on every send. NOTE:
        # ledger's module body must never call send() — it only defines + install()s —
        # or this bootstrap would self-deadlock.
        _hooks_bootstrapped = True


def _record_trace_mirror_loss(msg, phase):
    """Record a failed mirror attempt, not a claim that no mirror bytes landed."""
    try:
        import receipts
        # A single diagnostic row uses the journal's append lock. Do not take
        # the nudge fence from inside a canonical message append.
        receipts._append({'kind': 'trace-mirror-loss', 'phase': phase,
                          'msg-id': msg.get('id'), 'outcome': 'unconfirmed',
                          'ts': now_iso()})
    except Exception:
        # A broken diagnostic sink cannot turn canonical delivery into failure.
        # Keep exception text (which may contain message data) out of stderr.
        try:
            os.write(2, b'trace_mirror_loss_receipt_unavailable\n')
        except OSError:
            pass


def trace_mirror_loss_counts():
    """Count retained loss signals; absence never proves mirror completeness."""
    import receipts
    counts = {'ledger_import': 0, 'hook': 0, 'unknown': 0}
    for row in receipts.rows():
        if isinstance(row, dict) and row.get('kind') == 'trace-mirror-loss':
            phase = row.get('phase')
            counts[phase if phase in ('ledger_import', 'hook') else 'unknown'] += 1
    return {**counts, 'total': sum(counts.values())}


def _run_post_send_hooks(msg: Dict[str, Any], *, authenticated_actor: str | None = None) -> None:
    """Dispatch the post-send hooks (e.g. the trace-ledger mirror) for a fully-formed
    message record. Bootstraps the mirror first (so every sending process mirrors) and
    isolates each hook so a hook failure can never break message delivery. Called for
    EVERY message that lands in the log — normal sends AND direct-append paths like the
    burn-guard alert — so the ledger stays complete."""
    _bootstrap_hooks()
    if _hooks_bootstrap_failed:
        _record_trace_mirror_loss(msg, 'ledger_import')
    for _hook in _post_send_hooks:
        try:
            try:
                parameters = inspect.signature(_hook).parameters.values()
                accepts_actor = any(
                    p.name == "authenticated_actor" or p.kind == p.VAR_KEYWORD
                    for p in parameters
                )
            except (TypeError, ValueError):
                accepts_actor = False
            if accepts_actor:
                _hook(msg, authenticated_actor=authenticated_actor)
            else:
                # Legacy observational hooks see the canonical row but cannot
                # influence authenticated ledger attribution.
                _hook(msg)
        except Exception:
            _record_trace_mirror_loss(msg, 'hook')

# Participant ids map 1:1 to inbox/cursor filenames — a strict charset (no
# lossy stripping) prevents distinct ids colliding on the same file.
PARTICIPANT_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,31}$")

# Presence heartbeat (PSQ-251): a per-participant file whose MTIME is "last seen". Used by
# OUT-OF-PROCESS channels (the SDK-channel runner) so the hub can show them online without any
# auth/network — the web UI's own presence is in-process; this covers everyone else. Ephemeral
# by nature (a stale file just reads as offline), so it lives beside the store, not in the log.
PRESENCE_DIR = STORE_DIR / "presence"


def mark_present(pid: str) -> None:
    """Heartbeat ``pid`` now (touch its presence file). No-op on a malformed id or any FS error
    — presence is best-effort and must never break the caller's loop."""
    if not PARTICIPANT_ID_RE.match(pid or ""):
        return
    try:
        PRESENCE_DIR.mkdir(parents=True, exist_ok=True)
        (PRESENCE_DIR / pid).touch()
    except OSError:
        pass


def presence_age(pid: str) -> Optional[float]:
    """Seconds since ``pid``'s last heartbeat, or None if never seen / unreadable."""
    if not PARTICIPANT_ID_RE.match(pid or ""):
        return None
    try:
        return time.time() - (PRESENCE_DIR / pid).stat().st_mtime
    except OSError:
        return None


def clear_present(pid: str) -> None:
    """Drop ``pid``'s heartbeat so it shows offline immediately (clean shutdown)."""
    if not PARTICIPANT_ID_RE.match(pid or ""):
        return
    try:
        (PRESENCE_DIR / pid).unlink()
    except OSError:
        pass

# A fresh registry has the local operator and no pre-seeded agent identities.
DEFAULT_PARTICIPANTS: Dict[str, Dict[str, Any]] = {
    OWNER: {"kind": "human", "family": None, "channel": "notify"},
}


def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:10]}"


def _private_directory(path: Path) -> None:
    """Create missing components privately, without changing existing directories."""
    try:
        path.mkdir(mode=0o700)
    except FileNotFoundError:
        _private_directory(path.parent)
        _private_directory(path)
    except FileExistsError:
        if not path.is_dir():
            raise
    else:
        # mkdir's mode is reduced by umask; restore owner access even under 0777.
        path.chmod(0o700)


def ensure_store() -> None:
    for d in (STORE_DIR, INBOX_DIR, CURSOR_DIR):
        _private_directory(d)


# --- low-level JSONL ---

def _open_private_journal(path: Path):
    """Open a regular private append target for generic and fenced writers."""
    _private_directory(path.parent)
    fd = os.open(path, os.O_WRONLY | os.O_APPEND | os.O_CREAT | os.O_NONBLOCK
                 | os.O_NOFOLLOW, 0o600)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise ValueError('journal_not_regular')
        os.fchmod(fd, 0o600)
        f = os.fdopen(fd, 'a', encoding='utf-8')
    except BaseException:
        os.close(fd)
        raise
    return f


def append_jsonl(path: Path, record: Dict[str, Any]) -> None:
    with _open_private_journal(path) as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            _append_jsonl_to_locked_file(f, record)
        finally:
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)


def _append_jsonl_to_locked_file(target, record: Dict[str, Any]) -> None:
    """Append and fsync one JSONL record while the caller holds its write fence."""
    target.write(json.dumps(record, ensure_ascii=False) + "\n")
    target.flush()
    os.fsync(target.fileno())


READ_BATCH_BYTES = 4 * 1024 * 1024


def read_jsonl(path: Path, offset: int = 0,
               max_bytes: int = READ_BATCH_BYTES) -> tuple[List[Dict[str, Any]], int]:
    """Read complete records past byte `offset`, at most max_bytes per call.
    Returns (records, new_offset); callers loop until the offset stops moving.

    A final line without a trailing newline is a write in flight (or the
    batch cut) — it is not consumed and not counted into new_offset.
    """
    from console_read_cache import batch as console_batch
    cached = console_batch(path, offset, max_bytes)
    if cached is not None:
        return cached
    if not path.exists():
        return [], offset
    records: List[Dict[str, Any]] = []
    with path.open("rb") as f:
        f.seek(offset)
        data = f.read(max_bytes)
        # A single record larger than max_bytes has no newline in the batch;
        # without this, new_offset == offset and every caller replays the
        # same position forever. Grow until the record's newline (or EOF —
        # a torn in-flight giant, left unconsumed like any torn tail).
        while len(data) >= max_bytes and b"\n" not in data:
            more = f.read(max_bytes)
            if not more:
                return [], offset
            data += more
    pos = offset
    for raw in data.split(b"\n")[:-1]:  # only newline-terminated lines
        pos += len(raw) + 1
        raw = raw.strip()
        if not raw:
            continue
        try:
            record = json.loads(raw)
        except (json.JSONDecodeError, UnicodeDecodeError):
            # Skip rather than wedge the reader. UnicodeDecodeError happens when a
            # byte offset (e.g. tail_jsonl's size-TAIL_READ_BYTES seek) lands inside
            # a multibyte UTF-8 char, so the torn leading line starts mid-character
            # — the same torn-tail case we already tolerate, just at the head. One
            # such line otherwise crashed every reader (status/inbox/await/server).
            continue
        if isinstance(record, dict):
            records.append(record)
    return records, pos


TAIL_READ_BYTES = 512 * 1024


def tail_jsonl(path: Path, n: int) -> List[Dict[str, Any]]:
    """Last n records, reading at most TAIL_READ_BYTES from the file end
    (the log grows forever; UI/status views must not load all of it)."""
    if not path.exists():
        return []
    size = path.stat().st_size
    start = max(0, size - TAIL_READ_BYTES)
    records, _ = read_jsonl(path, start)
    if start > 0 and records:
        records = records[1:]  # first record may be torn by the byte cut
    return records[-n:]


# --- registry ---

class RegistryMutationRefused(ValueError):
    """An authenticated registry/provisioning act was refused before mutation."""

    def __init__(self, reason: str, detail: str):
        self.reason = reason
        super().__init__(f"{detail} (reason={reason})")


SELF_SERVICE_PARTICIPANT_FIELDS = frozenset({
    "label", "channel", "hand_raised", "hand_message", "last_update", "wake_route",
})
TMUX_HOSTING_FIELDS = frozenset({
    "hosting_kind", "tmux_socket", "tmux_session", "session_ref",
})


def _require_current_provisioner(actor, participants, *, target=None, act=None):
    """Current-row rights, with only the commissioned roleless self-repair exception."""
    pid = actor.get("participant_id") if actor else None
    row = participants.get(pid)
    current = (row or {}).get("role")
    if current in PROVISIONING_ROLES:
        return
    if (row is not None and current is None and target == pid
            and act in {"seat_invite", "legacy_role_normalisation"}
            and _default_role(row.get("kind"), row.get("family")) == "human_authority"
            and getattr(_token_local, "depth", 0)
            and getattr(_registry_actor_local, "lock_depth", 0)):
        credential = getattr(_registry_actor_local, "credential", None)
        live, _ = (_verdict_unlocked(credential, _read_tokens_unlocked())
                   if credential else (None, "no_token"))
        if (live is not None and live.get("id") == actor.get("id")
                and live.get("participant_id") == pid and live.get("scope") == SEAT_SCOPE
                and live.get("role") == "human_authority"):
            return True
    reason = ("provisioning_auth_stale_role" if actor and
              actor.get("role") in PROVISIONING_ROLES else "not_a_provisioner")
    raise RegistryMutationRefused(
        reason, f"{pid!r} has current registry role {current!r}; provisioning requires "
        f"{' / '.join(sorted(PROVISIONING_ROLES))}")


def _check_registry_change(before, after, *, writer=None):
    """The single check shared by every participant-file writer (PRC-5)."""
    # PRN-HF-6: unrelated legacy rows are not rewritten by this act. The
    # invariant applies to new/changed surviving rows, not the whole registry.
    _require_registry_roles({pid: row for pid, row in after.items()
                             if pid not in before or row != before[pid]})
    if REGISTRY_ROLE_PENDING.exists() and not getattr(_registry_actor_local, "setting_role", False):
        raise RegistryMutationRefused("registry_role_pending",
                                      "retry the original registry set-role to complete its receipt")
    if REGISTRY_PARK_PENDING.exists() and not getattr(_registry_actor_local, "parking", False):
        raise RegistryMutationRefused("parking_pending", "retry the original registry park/unpark to complete its receipt")
    normalising = getattr(_registry_actor_local, "legacy_normalisation", False)
    if normalising:
        expected, changed = _derived_legacy_roles(before, targets=normalising)
        if (writer == "governance" and changed and after == expected
                and getattr(_registry_actor_local, "lock_depth", 0)):
            return
        raise RegistryMutationRefused("legacy_role_normalisation_scope",
                                      "normalisation may only derive missing roles")
    if LEGACY_ROLE_PENDING.exists():
        raise RegistryMutationRefused("legacy_role_normalisation_pending",
                                      "retry registry normalise-roles --apply to complete the receipt")
    if any(old.get("role") is None and old != after.get(pid)
           for pid, old in before.items()):
        raise RegistryMutationRefused("legacy_role_normalisation_required",
                                      "only registry normalise-roles may change a roleless legacy row")
    credential = getattr(_registry_actor_local, "credential", None)
    actor = None
    invite = None
    why = 'no_token'
    if credential and getattr(_token_local, 'depth', 0) \
            and getattr(_registry_actor_local, 'lock_depth', 0):
        tokens = _read_tokens_unlocked()
        actor, why = _verdict_unlocked(credential, tokens)
        if actor is None and getattr(_registry_actor_local, 'invite_grant', False):
            invite = next((rec for rec in _token_records(tokens) if rec.get('kind') == 'invite'
                           and _token_matches(credential, rec)), None)
            now_ts = datetime.now(timezone.utc).timestamp()
            generations = _credentials_on(tokens)
            if invite and not invite.get('revoked') and not invite.get('used') \
                    and not _token_expired(invite, now_ts, tokens=tokens) \
                    and (not generations or _generation_current(
                        invite, tokens, invite.get('allowed_participant_id'))):
                issuer = tokens.get(invite.get('provisioner_session_id')) or {}
                if issuer.get('kind') == 'session' and issuer.get('status') == 'active' \
                        and not issuer.get('revoked') and not _token_expired(issuer, now_ts, tokens=tokens) \
                        and (not generations or _generation_current(
                            issuer, tokens, issuer.get('participant_id'))):
                    actor = issuer
    for pid in before.keys() | after.keys():
        old, new = before.get(pid), after.get(pid)
        if old == new:
            continue
        if any(((key in (old or {})) != (key in (new or {})))
               or (old or {}).get(key) != (new or {}).get(key)
               for key in ("parked_at", "parked_by")) and not getattr(
                   _registry_actor_local, "parking", False):
            raise RegistryMutationRefused("parking_fields_read_only",
                                          "only registry park/unpark may change parking fields")
        if any((old or {}).get(key) != (new or {}).get(key)
               for key in ("retired_at", "retired_by")) and not getattr(
                   _registry_actor_local, "retirement", False):
            raise RegistryMutationRefused("retirement_fields_read_only",
                                          "only registry retire may set retirement fields; no unretire")
        changed = ({key for key in old.keys() | new.keys() if old.get(key) != new.get(key)}
                   if old is not None and new is not None else None)
        if changed is not None and changed <= EXECUTION_PARTICIPANT_FIELDS | {"last_update"}:
            continue
        if actor is None:
            raise RegistryMutationRefused(f"registry_auth_{why}",
                                          "participant mutation requires an authenticated actor")
        if (old or {}).get('inapp_hookset') != (new or {}).get('inapp_hookset'):
            from desktop_support import require
            check_hookset_change = require('inapp_hookset').check_registry_change
            check_hookset_change(pid, actor, before, after)
        if new is not None and (old or {}).get("wake_route") != new.get("wake_route"):
            from wake_route import check_registry_change
            check_registry_change(pid, actor, before, after)
        if invite is not None:
            created = getattr(_registry_actor_local, 'invite_created', {})
            allowed = pid == invite.get('allowed_participant_id')
            if old is None:
                expected = _participant_record(pid, kind='human', family=None, channel='pull')
                allowed = allowed and new is not None and \
                    {k: v for k, v in new.items() if k != 'last_update'} == \
                    {k: v for k, v in expected.items() if k != 'last_update'}
            elif new is None:
                # Only undo a creation this authenticated grant just approved in
                # this transaction. An invite cannot delete a pre-existing row.
                allowed = allowed and created.get(pid) == old
            else:
                allowed = allowed and changed <= {'label', 'channel', 'last_update'}
            if not allowed:
                raise RegistryMutationRefused('invite_grant_scope', 'invite cannot authorize this mutation')
            _require_current_provisioner(actor, before)
            if old is None:
                created[pid] = dict(new)
            continue
        if pid == actor["participant_id"] and changed is not None \
                and changed <= SELF_SERVICE_PARTICIPANT_FIELDS:
            continue
        # An explicit self join to pull may only clear its obsolete tmux
        # declaration. It does not grant general ownership of hosting fields.
        if pid == actor["participant_id"] and changed is not None \
                and getattr(_registry_actor_local, "join_pull", None) == pid \
                and old.get("hosting_kind") in (None, "tmux-hosted") \
                and new.get("channel") == "pull" \
                and changed <= SELF_SERVICE_PARTICIPANT_FIELDS | TMUX_HOSTING_FIELDS \
                and all(new.get(key) is None for key in TMUX_HOSTING_FIELDS):
            continue
        _require_current_provisioner(actor, before)
    # CREDENTIALS_01 D-CRED-1: once the credentials migration has run, the role human_authority
    # goes only on an identity of kind human, and any other grant is refused with a receipt. Only
    # rows this write creates or changes are judged (PRN-HF-6); an existing row is the migration's.
    granted = sorted(pid for pid, new in after.items()
                     if new is not None and new != before.get(pid)
                     and new.get("role") == "human_authority" and new.get("kind") != "human")
    if granted and _credentials_on(_read_tokens_unlocked()):
        _record_seat_lifecycle_event({
            "kind": "registry-role-refused", "reason": "principal_role_requires_human",
            "seats": [{"seat": pid, "role": "human_authority", "seat_kind": after[pid].get("kind")}
                      for pid in granted],
            "actor": actor["participant_id"] if actor else None,
            "ts": datetime.now(timezone.utc).isoformat()})
        raise RegistryMutationRefused("principal_role_requires_human",
                                      "the role human_authority is granted only to an identity of kind human: "
                                      + ", ".join(granted))


def _require_registry_roles(parts):
    missing = sorted(pid for pid, row in parts.items() if not row.get("role"))
    if missing:
        raise RegistryMutationRefused("registry_row_without_role",
                                      f"registry rows require a role: {', '.join(missing)}")


@contextmanager
def _registry_actor(actor, credential, *, invite_grant=False):
    previous = getattr(_registry_actor_local, "actor", None)
    old_credential = getattr(_registry_actor_local, "credential", None)
    old_grant = getattr(_registry_actor_local, "invite_grant", False)
    old_created = getattr(_registry_actor_local, "invite_created", None)
    _registry_actor_local.actor = actor
    _registry_actor_local.credential = credential
    _registry_actor_local.invite_grant = invite_grant
    _registry_actor_local.invite_created = {}
    try:
        yield
    finally:
        _registry_actor_local.actor = previous
        _registry_actor_local.credential = old_credential
        _registry_actor_local.invite_grant = old_grant
        _registry_actor_local.invite_created = old_created


def authenticated_registry_act(presented_token, action, *, provisioning=False,
                               expected_actor=None, provisioning_target=None):
    """Authenticate and hold the launch fence, token and registry locks through an act.

    Demotion/revocation serialize with the act. The callback receives the derived
    identity, never a caller-asserted role. This is a mistake-proofing boundary,
    not isolation from arbitrary Python or same-UID filesystem access.
    """
    def apply():
        actor, why = _verdict_unlocked(presented_token, _read_tokens_unlocked()) \
            if presented_token else (None, "no_token")
        if actor is None:
            raise RegistryMutationRefused(f"registry_auth_{why}", "invalid actor credential")
        if expected_actor is not None and actor["participant_id"] != expected_actor:
            raise RegistryMutationRefused("registry_auth_wrong_actor", "actor differs from credential")
        with _registry_actor(actor, presented_token):
            if provisioning:
                _require_current_provisioner(actor, _read_participants_unlocked(),
                                            target=provisioning_target,
                                            act="seat_invite" if provisioning_target is not None else None)
            return action(actor["participant_id"])
    return _tokens_locked(lambda: _registry_locked(apply))

@contextmanager
def runtime_launch_fence():
    """Fence participant/catalog mutation against check->spawn/ACTIVE."""
    with _runtime_launch_fence_mutex:
        depth = getattr(_runtime_launch_fence_local, "depth", 0)
        if depth:
            _runtime_launch_fence_local.depth = depth + 1
            try:
                yield
            finally:
                _runtime_launch_fence_local.depth = depth
            return
        ensure_store()
        with RUNTIME_LAUNCH_FENCE_LOCK.open("a") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            _runtime_launch_fence_local.depth = 1
            try:
                yield
            finally:
                _runtime_launch_fence_local.depth = 0
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def _registry_locked(fn):
    """Run fn() under launch-fence -> participant-registry lock order."""
    ensure_store()
    with runtime_launch_fence():
        if getattr(_registry_actor_local, "lock_depth", 0):
            return fn()
        with REGISTRY_LOCK.open("a") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            _registry_actor_local.lock_depth = 1
            try:
                return fn()
            finally:
                _registry_actor_local.lock_depth = 0
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def load_participants() -> Dict[str, Dict[str, Any]]:
    """Pure registry view: agent defaults are in memory; humans remain as stored.

    No writer lock, pending-receipt recovery or governance act belongs on a read.
    """
    parts = _read_participants_unlocked()
    for row in parts.values():
        if row.get("kind") == "agent" and row.get("role") is None:
            row.update(role=_default_role(row.get("kind"), row.get("family")),
                       role_source="derived")
    return parts


def _derived_legacy_roles(parts, *, targets=None):
    """Build the exact delta allowed only by the explicit normalisation act."""
    result = {pid: dict(row) for pid, row in parts.items()}
    changed = []
    for pid, row in sorted(result.items()):
        if row.get("role") is None and (targets is None or pid in targets):
            role = _default_role(row.get("kind"), row.get("family"))
            changed.append({
                "participant_id": pid, "kind": row.get("kind"),
                "before": dict(row),
                "derivation_inputs": {"kind": row.get("kind"), "family": row.get("family")},
                "proposed_role": role, "role_source": "derived",
                "approval": ("REQUIRES_PRINCIPAL_APPROVAL" if row.get("kind") == "human"
                             else "PROVISIONER"),
            })
            row.update(role=role, role_source="derived")
    return result, changed


def _registry_bytes(parts):
    return json.dumps(parts, indent=2, ensure_ascii=False).encode("utf-8")


def _role_normalisation_plan():
    # Strict parse: an unreadable registry must not become a plan over seed rows.
    source = PARTICIPANTS_FILE.read_bytes()
    parts = json.loads(source)
    normalized, rows = _derived_legacy_roles(parts)
    plan = {"schema_version": 1, "rows": rows,
            "registry_before_sha256": hashlib.sha256(source).hexdigest(),
            "registry_after_sha256": hashlib.sha256(
                _registry_bytes(normalized) if rows else source).hexdigest()}
    plan["plan_sha256"] = hashlib.sha256(
        json.dumps(plan, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return plan, normalized


class LegacyRoleNormalisationIncomplete(RuntimeError):
    """An explicit act has a pending write/receipt; reads never recover it."""
    exit_code = getattr(os, "EX_IOERR", 74)


def _normalisation_receipt_exists(event_id):
    offset = 0
    while True:
        events, end = read_jsonl(STORE_DIR / "ledger.jsonl", offset)
        if any(event.get("id") == event_id for event in events):
            return True
        if end == offset:
            return False
        offset = end


def _repair_normalisation_receipt_tail():
    """Scoped repair of an unterminated JSONL tail under its lock.

    CodeRabbit 3992654633: otherwise a good retry can join a torn append and
    disappear with it on read. A complete JSON object only needs its newline;
    an invalid fragment is discarded. Complete lines and the shared append
    primitive are untouched. A read gates removal of the pending record.
    """
    path = STORE_DIR / "ledger.jsonl"
    with path.open("a+b") as stream:
        fcntl.flock(stream.fileno(), fcntl.LOCK_EX)
        try:
            stream.seek(0, os.SEEK_END)
            end = stream.tell()
            if end:
                stream.seek(end - 1)
                if stream.read(1) != b"\n":
                    position, boundary = end, 0
                    while position:
                        start = max(0, position - 65536)
                        stream.seek(start)
                        block = stream.read(position - start)
                        last = block.rfind(b"\n")
                        if last >= 0:
                            boundary = start + last + 1
                            break
                        position = start
                    stream.seek(boundary)
                    try:
                        complete = isinstance(json.loads(stream.read()), dict)
                    except (ValueError, UnicodeDecodeError):
                        complete = False
                    if complete:
                        stream.write(b"\n")
                    else:
                        stream.truncate(boundary)
                    stream.flush()
                    os.fsync(stream.fileno())
        finally:
            fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def normalise_registry_roles(*, apply=False, plan_sha256=None, presented_token=None,
                             approved_by_principal=None, approved_by_principal_sha256=None):
    """Plan without effects; explicitly apply a digest under authenticated governance.

    The digest binds the complete before-state and proposed delta. Approval is an
    attributed register id and content hash supplied with apply, not a
    caller-asserted role. The invoker verifies the record; this function binds
    that evidence in its receipt, without treating it as a new authority source.
    Pending recovery requires the same live invoker, plan and approval binding.
    A predecessor pending record without the content-hash field completes only
    with its original reference-only binding; recovery never invents a past hash.
    """
    if not apply:
        if LEGACY_ROLE_PENDING.exists():
            pending = json.loads(LEGACY_ROLE_PENDING.read_text())
            return {**pending["plan"], "state": "receipt_pending",
                    "current_registry_sha256": hashlib.sha256(PARTICIPANTS_FILE.read_bytes()).hexdigest()}
        return {**_role_normalisation_plan()[0], "state": "plan"}
    if approved_by_principal is not None and (
            not isinstance(approved_by_principal, str) or not approved_by_principal.strip()
            or approved_by_principal != approved_by_principal.strip()
            or any(ch.isspace() for ch in approved_by_principal)):
        raise ValueError("approved-by-principal requires a clean register record id")
    if approved_by_principal is not None and approved_by_principal_sha256 is not None:
        if (not isinstance(approved_by_principal_sha256, str)
                or not re.fullmatch(r"[0-9a-fA-F]{64}", approved_by_principal_sha256)):
            raise ValueError("approved-by-principal requires its record content SHA-256")
        approved_by_principal_sha256 = approved_by_principal_sha256.lower()
    elif approved_by_principal is None and approved_by_principal_sha256 is not None:
        raise ValueError("approval content SHA-256 requires approved-by-principal record id")

    def transact(identity):
        import ledger
        actor = _registry_actor_local.actor
        if actor.get("scope") != SEAT_SCOPE or actor.get("role") not in PROVISIONING_ROLES:
            raise RegistryMutationRefused("not_a_provisioner", "normalisation requires a live provisioning seat credential")
        registry = _read_participants_unlocked()
        self_repair = bool(_require_current_provisioner(
            actor, registry, target=identity, act="legacy_role_normalisation"))
        pending = json.loads(LEGACY_ROLE_PENDING.read_text()) if LEGACY_ROLE_PENDING.exists() else None
        # DJK-A2-3: finish an already-issued predecessor act, never create a new
        # reference-only approval. Inspect this format under the authenticated
        # registry act, and preserve the original plan/invoker/event below.
        # The explicit marker is written atomically by new authenticated acts.
        # It detects loss of only the hash field; it is not an authenticity seal.
        # Unmarked historical states remain ambiguous if multiple fields were
        # removed or a pre-marker writer's hash was lost. Deployment excludes
        # pre-marker hash-bound state under the recorded CoS ruling.
        if pending is not None and "pending_format" in pending:
            if (pending["pending_format"] != "approval-content-sha256/v1"
                    or "approved_by_principal_sha256" not in pending):
                raise RegistryMutationRefused(
                    "registry_pending_format_invalid", "pending approval binding is incomplete or unsupported")
        if (pending is not None and "pending_format" not in pending
                and "approved_by_principal_sha256" in pending):
            raise RegistryMutationRefused(
                "registry_pending_format_invalid", "unmarked hash-bound pending record cannot be recovered")
        legacy_pending = (pending is not None and "pending_format" not in pending
                          and "approved_by_principal_sha256" not in pending)
        if approved_by_principal is not None and approved_by_principal_sha256 is None and not legacy_pending:
            raise ValueError("approved-by-principal requires its record content SHA-256")
        plan, normalized = ((pending["plan"], None) if pending else _role_normalisation_plan())
        if not plan_sha256 or plan_sha256 != plan["plan_sha256"]:
            raise RegistryMutationRefused("registry_plan_changed", "plan digest does not match; inspect a fresh plan")
        if any(row["kind"] == "human" for row in plan["rows"]) \
                and actor["role"] != "human_authority" and not approved_by_principal:
            raise RegistryMutationRefused("principal_approval_required", "human rows require a principal approval record")
        if self_repair and any(row["participant_id"] != identity for row in plan["rows"]):
            raise RegistryMutationRefused("principal_self_repair_scope", "a roleless principal may normalise only its own row")
        invoker = {"actor_id": identity, "role": actor["role"], "token_id": actor["id"]}
        if pending:
            if (pending["invoker"] != invoker
                    or pending["approved_by_principal"] != approved_by_principal
                    or pending.get("approved_by_principal_sha256") != approved_by_principal_sha256):
                raise RegistryMutationRefused("registry_recovery_invoker_changed", "retry with the original invoker and approval reference")
        elif not plan["rows"]:
            return {**plan, "state": "unchanged"}
        try:
            if pending is None:
                pending = {"pending_format": "approval-content-sha256/v1",
                           "plan": plan, "event_id": ledger.new_event_id(), "invoker": invoker,
                           "approved_by_principal": approved_by_principal,
                           "approved_by_principal_sha256": approved_by_principal_sha256,
                           "self_repair_event_id": ledger.new_event_id() if self_repair else None}
                tmp = LEGACY_ROLE_PENDING.with_suffix(".tmp")
                with tmp.open("w", encoding="utf-8") as stream:
                    os.chmod(tmp, 0o600)
                    json.dump(pending, stream)
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(tmp, LEGACY_ROLE_PENDING)
            # DJK-A2-4: a prior replace may have succeeded while its directory
            # fsync failed. Re-establish publication durability on explicit
            # authenticated retry before any registry or receipt mutation.
            _fsync_dir(STORE_DIR)
            approval_binding = {"approved_by_principal": pending["approved_by_principal"]}
            if "approved_by_principal_sha256" in pending:
                approval_binding["approved_by_principal_sha256"] = pending["approved_by_principal_sha256"]
            current = hashlib.sha256(PARTICIPANTS_FILE.read_bytes()).hexdigest()
            if current not in {plan["registry_before_sha256"], plan["registry_after_sha256"]}:
                raise RuntimeError("pending normalisation source changed; refusing to overwrite")
            if current == plan["registry_before_sha256"]:
                fresh, normalized = _role_normalisation_plan()
                if fresh != plan:
                    raise RuntimeError("pending normalisation plan changed")
                _registry_actor_local.legacy_normalisation = {row["participant_id"] for row in plan["rows"]}
                try:
                    _write_participants_unlocked(normalized, writer="governance")
                    _fsync_dir(STORE_DIR)
                finally:
                    _registry_actor_local.legacy_normalisation = False
            if hashlib.sha256(PARTICIPANTS_FILE.read_bytes()).hexdigest() != plan["registry_after_sha256"]:
                raise RuntimeError("normalisation registry fingerprint mismatch")
            receipts = [(pending["event_id"], {
                "mutation": "legacy_role_normalisation", "writer": "governance", **plan,
                "invoker": invoker, **approval_binding,
                "self_repair_receipt_id": pending["self_repair_event_id"],
            })]
            if pending["self_repair_event_id"]:
                receipts.append((pending["self_repair_event_id"], {
                    "mutation": "principal_self_repair", "seat": identity,
                    "act": "legacy_role_normalisation", "token_id": actor["id"],
                    "normalised_rows": [identity], "plan_sha256": plan["plan_sha256"],
                    "normalisation_receipt_id": pending["event_id"],
                }))
            for event_id, payload in receipts:
                _repair_normalisation_receipt_tail()
                if not _normalisation_receipt_exists(event_id):
                    ledger.emit("harness_mutation", actor_id=identity, role=actor["role"],
                                payload=payload, event_id=event_id, ledger_file=STORE_DIR / "ledger.jsonl")
                    _repair_normalisation_receipt_tail()
                if not _normalisation_receipt_exists(event_id):
                    raise RuntimeError("normalisation receipt is not readable; retry the explicit act")
            LEGACY_ROLE_PENDING.unlink()
            _fsync_dir(STORE_DIR)
            return {**plan, "state": "complete", "receipt_id": pending["event_id"],
                    "invoker": invoker, **approval_binding}
        except (OSError, ValueError, RuntimeError) as exc:
            raise LegacyRoleNormalisationIncomplete(
                f"legacy role normalisation incomplete ({exc}); registry may already be updated; "
                "retry registry normalise-roles --apply with the same digest, invoker and approval") from exc

    return authenticated_registry_act(presented_token, transact)


def _read_participants_unlocked() -> Dict[str, Dict[str, Any]]:
    try:
        with PARTICIPANTS_FILE.open("r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, FileNotFoundError):
        return _seed_participants()


def _seed_participants() -> Dict[str, Dict[str, Any]]:
    parts = {}
    for pid, cfg in DEFAULT_PARTICIPANTS.items():
        parts[pid] = _participant_record(pid, **cfg)
    return parts


# Participant harness roles (META_HARNESS_PLAN Stage 1) — the closed vocabulary the ledger
# envelope and harness/policy speak. Distinct from token roles (VALID_ROLES: operator/guest,
# an auth concept): this is the participant's FUNCTION in the governed loop. Defaulted from
# kind/family at record creation; ledger.role_for prefers this explicit field over inference.
PARTICIPANT_ROLES = frozenset({
    "chief_of_staff", "coder", "reviewer", "system_governor", "human_authority"})

# ORCH_SPEC_01 D-PANEL-2: participants.json is one artifact with two write
# authorities.  Keep these sets at the registry seam so callers cannot smuggle
# a rights-bearing declaration through a daemon/probe update (or assert runtime
# state through provisioning).  Fields not listed here retain their existing
# registrar ownership until a later specification assigns them.
GOVERNANCE_PARTICIPANT_FIELDS = frozenset({
    "id", "kind", "family", "role_source", "channel", "tmux_session",
    "role", "token_validity", "token_valid", "signing_key", "signing_key_id",
    "hosting_kind", "tmux_socket", "workspace_dir", "config_dir", "session_ref",
    "history_limit", "panel_poll_interval",
})
EXECUTION_PARTICIPANT_FIELDS = frozenset({
    "liveness", "adapter_probe_state", "last_successful_wake", "pending_count",
    "measured_at",
})
PARTICIPANT_WRITERS = frozenset({"governance", "execution"})
PROVISIONAL_PANEL_POLL_INTERVAL_SECONDS = 10

# Family -> default harness role. An agent of UNKNOWN family defaults to reviewer — the
# least-privileged agent role under harness/policy (reviewers cannot write); defaulting to
# coder would silently grant sandbox-edit to any newly spawned family.
FAMILY_DEFAULT_ROLE = {"claude": "coder", "gemini": "reviewer", "codex": "reviewer"}


def _default_role(kind: str, family: str | None) -> str:
    if kind == "human":
        return "human_authority"
    if kind == "system":
        return "system_governor"
    return FAMILY_DEFAULT_ROLE.get(normalize_family(family) or "", "reviewer")


def _participant_record(pid: str, *, kind: str, family: str | None, channel: str,
                        tmux_session: str | None = None, label: str | None = None,
                        role: str | None = None) -> Dict[str, Any]:
    role_value = role or _default_role(kind, family)
    return {
        "id": pid,
        "label": label or pid,
        "kind": kind,
        "family": family,
        "role": role_value,
        # Keep provenance durable. Without this field a materialized family
        # default is indistinguishable from a role somebody deliberately set,
        # so a derived writable role can be mistaken for assigned authority.
        "role_source": "explicit" if role is not None else "derived",
        "channel": channel,
        "tmux_session": tmux_session,
        "hand_raised": False,
        "hand_message": "",
        # Provisioning must not claim observations.  A daemon/adapter probe is
        # the first writer and supplies measured_at with the observation.
        "liveness": None,
        "adapter_probe_state": None,
        "last_successful_wake": None,
        "pending_count": None,
        "measured_at": None,
        "hosting_kind": None,
        "tmux_socket": None,
        "workspace_dir": None,
        "config_dir": None,
        "session_ref": None,
        "history_limit": None,
        # Phase A DP-5 provisional governance declaration.  Materialize it in
        # every production registry row so the panel never invents a fallback.
        "panel_poll_interval": PROVISIONAL_PANEL_POLL_INTERVAL_SECONDS,
        "last_update": now_iso(),
    }


def _write_participants_unlocked(parts: Dict[str, Dict[str, Any]], *, writer=None) -> None:
    before = _read_participants_unlocked()
    _check_registry_change(before, parts, writer=writer)
    _establish_generations(before, parts)
    ensure_store()
    tmp = PARTICIPANTS_FILE.with_suffix(".json.tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(parts, f, indent=2, ensure_ascii=False)
        f.flush()
        os.fsync(f.fileno())
    os.chmod(tmp, 0o600)  # registry is sensitive — owner-only (reviewer/reviewer MED)
    os.replace(tmp, PARTICIPANTS_FILE)


def _upsert_participant_unlocked(pid: str, *, create_only: bool = False,
                                 writer: str = "governance",
                                 **fields: Any) -> Dict[str, Any]:
    """Create-or-update a participant. CALLER MUST ALREADY HOLD REGISTRY_LOCK.

    Factored out of update_participant so claim_invite can do create + token
    write + rollback inside ONE continuous registry-lock hold (Bugbot PR#20 MED:
    no early lock release between create and commit). Same registrar rules
    (PARTNERS.md Birth §1): no retired ids, no label/id collisions, no postfixed
    runtime variants. create_only raises if the id already exists.
    """
    if writer not in PARTICIPANT_WRITERS:
        raise ValueError(f"participant writer must be one of {sorted(PARTICIPANT_WRITERS)}")
    field_names = set(fields)
    forbidden = (field_names - EXECUTION_PARTICIPANT_FIELDS
                 if writer == "execution"
                 else field_names & EXECUTION_PARTICIPANT_FIELDS)
    if forbidden:
        owner = "governance" if writer == "execution" else "execution"
        raise ValueError(
            f"{writer} participant writer cannot write {owner}-owned field(s): "
            f"{', '.join(sorted(forbidden))}")
    if writer == "execution" and field_names & EXECUTION_PARTICIPANT_FIELDS:
        measured_at = fields.get("measured_at")
        if not isinstance(measured_at, str) or not measured_at.strip():
            raise ValueError("execution probe writes require a non-empty measured_at timestamp")
        try:
            parsed_measured_at = datetime.fromisoformat(measured_at)
        except ValueError as exc:
            raise ValueError("execution probe measured_at must be an ISO-8601 timestamp") from exc
        if parsed_measured_at.tzinfo is None or parsed_measured_at.utcoffset() is None:
            raise ValueError("execution probe measured_at timestamp must include a timezone")

    if not PARTICIPANT_ID_RE.match(pid):
        raise ValueError(
            f"invalid participant id {pid!r}: must match {PARTICIPANT_ID_RE.pattern}")
    aliases = load_aliases()
    if pid in aliases:
        raise ValueError(
            f"'{pid}' is a retired identity — its successor is '{aliases[pid]['successor']}'")
    parts = _read_participants_unlocked()
    if writer == "execution" and pid not in parts:
        raise ValueError("execution participant writer cannot create a participant")
    if create_only and pid in parts:
        raise ValueError(f"participant id {pid!r} already exists")
    if pid not in parts:  # creation: enforce uniqueness + anti-variant
        taken = {}
        for other, p in parts.items():
            taken[other.lower()] = other
            taken[(p.get("label") or other).lower()] = other
        new_label = (fields.get("label") or pid).lower()
        if pid.lower() in taken:
            raise ValueError(f"id '{pid}' collides with existing partner "
                             f"'{taken[pid.lower()]}'")
        if new_label != pid.lower() and new_label in taken:
            raise ValueError(f"label '{fields.get('label')}' collides with "
                             f"existing partner '{taken[new_label]}'")
        base = pid.split("-")[0].lower()
        if base != pid.lower() and base in taken:
            raise ValueError(
                f"'{pid}' looks like a runtime variant of partner "
                f"'{taken[base]}' — runtime tags are session labels, "
                f"never hub identities")
    existing = parts.get(pid)
    prev_identity = (existing.get("kind"), normalize_family(existing.get("family"))) if existing else None
    rec = existing or _participant_record(
        pid,
        kind=fields.get("kind", "agent"),
        family=fields.get("family"),
        channel=fields.get("channel", "pull"),
    )
    if "role_source" in fields:
        raise ValueError("role_source is derived by the registry and cannot be caller-supplied")
    for k, v in fields.items():
        rec[k] = v
    if existing is None and rec.get("role") is None:
        rec["role"] = _default_role(rec.get("kind"), rec.get("family"))
    if "role" in fields:
        rec["role_source"] = "explicit" if fields["role"] is not None else "derived"
    # A RECLASSIFIED participant must not keep a stale privilege (Bugbot #40): if kind/family
    # actually changed and this call did not explicitly re-grant a role, re-derive it from the
    # NEW identity — else an ex-Claude agent moved to a reviewer family keeps role=coder, a
    # writer privilege its family no longer warrants. Updates that don't touch the identity
    # (or that pass the same kind/family) leave an explicit role untouched.
    if prev_identity is not None and "role" not in fields \
            and (rec.get("kind"), normalize_family(rec.get("family"))) != prev_identity:
        rec["role"] = _default_role(rec.get("kind") or "human", rec.get("family"))
        rec["role_source"] = "derived"
    # Preserve absent provenance on legacy rows during metadata/probe writes.
    # Readers classify absence as derived; only creation, reclassification or
    # an explicit role update above records provenance. A probe cannot add it.
    rec["last_update"] = now_iso()
    if rec.get("channel") not in VALID_CHANNELS:
        raise ValueError(f"channel must be one of {sorted(VALID_CHANNELS)}")
    # Legacy absence is readable, never writable. Creation derives a role above.
    _require_registry_roles({pid: rec})
    if rec.get("role") is not None and rec["role"] not in PARTICIPANT_ROLES:
        raise ValueError(f"role must be one of {sorted(PARTICIPANT_ROLES)}")
    if "role_source" in rec and rec["role_source"] not in ("explicit", "derived"):
        raise ValueError("role_source must be explicit or derived")
    parts[pid] = rec
    _write_participants_unlocked(parts)
    return rec


def _remove_participant_unlocked(pid: str) -> None:
    """Delete a participant. CALLER MUST ALREADY HOLD REGISTRY_LOCK. Used by
    claim_invite's rollback so the undo runs in the same hold as the create."""
    parts = _read_participants_unlocked()
    if pid in parts:
        del parts[pid]
        _write_participants_unlocked(parts)


def update_participant(pid: str, *, create_only: bool = False,
                       presented_token: str | None = None,
                       **fields: Any) -> Dict[str, Any]:
    """Create-or-update a participant atomically (check-and-write under one
    REGISTRY_LOCK hold) through the governance/provisioning writer. Returns the
    record. Runtime probes must use update_participant_probe()."""
    return authenticated_registry_act(
        presented_token, lambda actor: _upsert_participant_unlocked(
            pid, create_only=create_only, writer="governance", **fields))


def join_participant(pid: str, *, presented_token=None, **metadata):
    """Join without regranting rights; explicit pull joins clear old tmux hosting."""
    if set(metadata) - {"kind", "family", "channel", "tmux_session"}:
        raise ValueError("join accepts identity and channel metadata only")
    if metadata.get("channel") == "pull" and metadata.get("tmux_session") is not None:
        raise ValueError("cannot combine channel pull with a tmux session")

    def apply(actor):
        participants = _read_participants_unlocked()
        old = participants.get(pid)
        if (old or {}).get("retired_at"):
            raise RegistryMutationRefused("seat_retired", f"{pid!r} is retired; its identity cannot be reused")
        if (old or {}).get("parked_at"):
            raise RegistryMutationRefused("seat_parked", f"{pid!r} is parked; ask the Chief of Staff")
        if pid != actor or old is None:
            _require_current_provisioner(_registry_actor_local.actor, participants)
        elif any(key in metadata and metadata[key] != old.get(key)
                 for key in ("kind", "family")):
            raise RegistryMutationRefused("self_service_rights_change",
                                          "self-service join cannot reclassify a seat")
        if metadata.get("channel") == "pull" \
                and (old or {}).get("hosting_kind") in (None, "tmux-hosted"):
            fields = {**metadata, **dict.fromkeys(TMUX_HOSTING_FIELDS)}
            previous = getattr(_registry_actor_local, "join_pull", None)
            _registry_actor_local.join_pull = pid
            try:
                return _upsert_participant_unlocked(pid, **fields)
            finally:
                _registry_actor_local.join_pull = previous
        return _upsert_participant_unlocked(pid, **metadata)
    return authenticated_registry_act(presented_token, apply)


def _record_seat_retirement(seat, row):
    """Complete one receipt, including a retry after a committed row or torn append.

    The row's immutable attribution is the recovery intent. Reads never recover it.
    Caller holds the token/registry transaction; the receipt append has its own lock.
    """
    event = {"kind": "seat-retire", "actor": row["retired_by"],
             "seat": seat, "ts": row["retired_at"]}
    _record_seat_lifecycle_event(event)


def _record_seat_lifecycle_event(event):
    """Append one durable lifecycle receipt, repairing only an interrupted tail."""
    import receipts
    with receipts.path().open("a+", encoding="utf-8") as target:
        fcntl.flock(target.fileno(), fcntl.LOCK_EX)
        try:
            target.seek(0)
            content = target.read()
            if content and not content.endswith("\n"):
                # Bound an interrupted tail before retrying; never rewrite history.
                target.write("\n")
                target.flush()
                os.fsync(target.fileno())
            # Rows end at "\n" alone, the only terminator the writer emits. str.splitlines() also
            # breaks a row at U+2028, U+2029 or U+0085, which ensure_ascii=False leaves raw, so a
            # stored receipt carrying one never matched and a retry appended it a second time.
            for line in content.split("\n"):
                try:
                    if json.loads(line) == event:
                        return
                except json.JSONDecodeError:
                    continue
            _append_jsonl_to_locked_file(target, event)
        finally:
            fcntl.flock(target.fileno(), fcntl.LOCK_UN)


def retire_participant(seat: str, *, presented_token=None):
    """Retire without deleting an identity, through the authenticated registry writer."""
    def apply(actor):
        parts = _read_participants_unlocked()
        row = parts.get(seat)
        if row is None:
            raise RegistryMutationRefused("unknown_seat", f"unknown seat {seat!r}")
        if seat == DAEMON_SEAT or row.get("kind") == "system":
            raise RegistryMutationRefused("protected_system_seat", f"{seat!r} is a protected system seat")
        if row.get("role") == "human_authority" or (row.get("kind") == "human" and row.get("role") is None):
            raise RegistryMutationRefused("protected_principal", f"{seat!r} is a protected principal")
        already = bool(row.get("retired_at"))
        if not already:
            now = datetime.now(timezone.utc).timestamp()
            tokens = _read_tokens_unlocked()
            live = any(
                rec.get("kind") in {"invite", "session"} and not rec.get("revoked")
                and not rec.get("used") and not _token_expired(rec, now, tokens=tokens)
                and (rec.get("participant_id") == seat or rec.get("allowed_participant_id") == seat)
                for rec in _token_records(tokens))
            if live:
                raise RegistryMutationRefused("seat_has_live_token",
                    f"{seat!r} has a live token; run {product_identity.command()} token revoke {seat} first")
            row.update(retired_at=datetime.now(timezone.utc).isoformat(), retired_by=actor)
            _registry_actor_local.retirement = True
            try:
                _write_participants_unlocked(parts)
            finally:
                _registry_actor_local.retirement = False
        try:
            _record_seat_retirement(seat, row)
        except OSError as exc:
            raise SeatActWithoutReceipt("registry retire", seat,
                f"retirement committed; retry {product_identity.command()} registry retire {seat} to complete its receipt: {exc}") from exc
        return {"seat": seat, "already_retired": already,
                "retired_at": row["retired_at"], "retired_by": row["retired_by"]}
    return authenticated_registry_act(presented_token, apply, provisioning=True)


def inactive_participant(row):
    """Whether a registry identity is absent from the active operating views."""
    return bool(row.get("retired_at") or row.get("parked_at"))


def registry_roles():
    """List stored roles, including legacy nulls, without auth or recovery effects."""
    return [{"seat": seat, "role": row.get("role"), "role_source": row.get("role_source"),
             "state": "retired" if row.get("retired_at") else
                      "parked" if row.get("parked_at") else "current"}
            for seat, row in sorted(_read_participants_unlocked().items())]


class RegistryRoleIncomplete(RuntimeError):
    """A role intent exists; its registry write or receipt may need recovery."""


def set_participant_role(seat, role, *, presented_token=None,
                         approved_by_principal=None, approved_by_principal_sha256=None):
    """Explicit, receipted role assignment under the provisioning locks.

    As with normalise-roles, the invoker verifies the CoS-landed approval record;
    the store binds its id and content hash, not a new authority source. Recovery
    requires the same credential and approval pair. No token is ever changed.
    """
    if role not in PARTICIPANT_ROLES:
        raise ValueError(f"role must be one of {', '.join(sorted(PARTICIPANT_ROLES))}")
    if approved_by_principal is not None and (
            not isinstance(approved_by_principal, str) or not approved_by_principal.strip()
            or any(ch.isspace() for ch in approved_by_principal)):
        raise ValueError("approved-by-principal requires a clean register record id")
    if (approved_by_principal is None) != (approved_by_principal_sha256 is None):
        raise ValueError("approval requires both a register record id and its content SHA-256")
    if approved_by_principal_sha256 is not None:
        if (not isinstance(approved_by_principal_sha256, str)
                or not re.fullmatch(r"[0-9a-fA-F]{64}", approved_by_principal_sha256)):
            raise ValueError("approved-by-principal requires its record content SHA-256")
        approved_by_principal_sha256 = approved_by_principal_sha256.lower()

    def apply(identity):
        actor = _registry_actor_local.actor
        if actor.get("scope") != SEAT_SCOPE or actor.get("role") not in PROVISIONING_ROLES:
            raise RegistryMutationRefused("not_a_provisioner", "set-role requires a live provisioning seat credential")
        parts = _read_participants_unlocked()
        row = parts.get(seat)
        if row is None:
            raise RegistryMutationRefused("unknown_seat", f"unknown seat {seat!r}")
        binding = {"seat": seat, "new_role": role, "actor": identity,
                   "actor_token_id": actor["id"],
                   "approved_by_principal": approved_by_principal,
                   "approved_by_principal_sha256": approved_by_principal_sha256}
        pending = None
        if REGISTRY_ROLE_PENDING.exists():
            try:
                pending = json.loads(REGISTRY_ROLE_PENDING.read_text())
                if (not isinstance(pending, dict) or pending.get("format") != "registry-role/v1"
                        or not all(isinstance(pending.get(k), dict) for k in ("before", "after", "event"))):
                    raise ValueError("unsupported pending record")
                event = pending["event"]
                if (not (binding.keys() | {"kind", "old_role", "ts"}) <= event.keys()
                        or event["kind"] != "registry-role"
                        or event["old_role"] != pending["before"].get("role")
                        or event["new_role"] not in PARTICIPANT_ROLES
                        or pending["after"] != {**pending["before"], "role": event["new_role"],
                                                "role_source": "explicit"}):
                    raise ValueError("inconsistent pending role change")
            except (ValueError, OSError) as exc:
                raise RegistryMutationRefused("registry_role_pending_invalid",
                    "role intent unreadable; operator repair required") from exc
            if any(pending["event"].get(k) != v for k, v in binding.items()):
                raise RegistryMutationRefused("registry_role_pending_mismatch",
                    "retry the original registry set-role with the same credential and approval record/hash")
            if row not in (pending["before"], pending["after"]):
                raise RegistryMutationRefused("registry_role_pending_changed",
                                             "pending role row changed; refusing to overwrite")
        old_role = pending["before"].get("role") if pending else row.get("role")
        if (old_role in PROVISIONING_ROLES or role in PROVISIONING_ROLES) and not approved_by_principal:
            raise RegistryMutationRefused("principal_approval_required",
                "changing a privileged role requires --approved-by-principal and --approved-by-principal-sha256")
        now = datetime.now(timezone.utc).timestamp()
        tokens = _read_tokens_unlocked()
        if any(rec.get("kind") in {"invite", "session"} and not rec.get("revoked")
               and not rec.get("used") and not _token_expired(rec, now, tokens=tokens)
               and (rec.get("participant_id") == seat or rec.get("allowed_participant_id") == seat)
               and rec.get("role") != role for rec in _token_records(tokens)):
            raise RegistryMutationRefused("seat_has_live_token",
                f"{seat!r} has a live token with a different role; run {product_identity.command()} token revoke {seat} first")
        if pending is None:
            if row.get("role") == role and row.get("role_source") == "explicit":
                return {"seat": seat, "role": role, "changed": False}
            after = {**row, "role": role, "role_source": "explicit"}
            _check_registry_change(parts, {**parts, seat: after}, writer="governance")
            pending = {"format": "registry-role/v1", "before": row, "after": after,
                       "event": {"kind": "registry-role", **binding, "old_role": old_role,
                                 "ts": datetime.now(timezone.utc).isoformat()}}
        try:
            if not REGISTRY_ROLE_PENDING.exists():
                tmp = REGISTRY_ROLE_PENDING.with_suffix(".tmp")
                with tmp.open("w", encoding="utf-8") as stream:
                    os.chmod(tmp, 0o600)
                    json.dump(pending, stream)
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(tmp, REGISTRY_ROLE_PENDING)
            _fsync_dir(STORE_DIR)
            if row != pending["after"]:
                parts[seat] = pending["after"]
                _registry_actor_local.setting_role = True
                try:
                    _write_participants_unlocked(parts, writer="governance")
                    _fsync_dir(STORE_DIR)
                finally:
                    _registry_actor_local.setting_role = False
            _record_seat_lifecycle_event(pending["event"])
            REGISTRY_ROLE_PENDING.unlink()
        except OSError as exc:
            raise RegistryRoleIncomplete(
                f"registry set-role {seat}: role change may be committed; retry the same command "
                f"with the original credential and approval record/hash to complete its receipt: {exc}") from exc
        try:
            _fsync_dir(STORE_DIR)
        except OSError as exc:
            raise SeatActCleanupUnconfirmed("registry set-role", seat, str(exc)) from exc
        return {"seat": seat, "role": role, "changed": True, "receipt": pending["event"]}

    return authenticated_registry_act(presented_token, apply, provisioning=True)


def _change_parking(seat, *, parked, channel=None, presented_token=None):
    """One explicit, recoverable lifecycle act; reads never complete a pending act."""
    if channel is not None and (parked or channel not in {"pull", "tmux"}):
        raise ValueError("unpark channel must be pull or tmux")
    command = "park" if parked else "unpark"

    def apply(actor):
        parts = _read_participants_unlocked()
        row = parts.get(seat)
        strict = _credentials_on(_read_tokens_unlocked())
        pending = _parking_intent(strict=strict)
        if pending is not None:
            if (pending["seat"] != seat or pending["command"] != command
                    or pending["channel"] != channel or pending["event"].get("actor") != actor):
                raise RegistryMutationRefused("parking_pending", "retry the original registry park/unpark with its original actor and channel")
            if row not in (pending["before"], pending["after"]):
                raise RegistryMutationRefused("parking_pending_changed", "pending parking row changed; refusing to overwrite")
        else:
            if row is None:
                raise RegistryMutationRefused("unknown_seat", f"unknown seat {seat!r}")
            if seat == DAEMON_SEAT or row.get("kind") == "system":
                raise RegistryMutationRefused("protected_system_seat", f"{seat!r} is a protected system seat")
            if row.get("role") == "human_authority" or (row.get("kind") == "human" and row.get("role") is None):
                raise RegistryMutationRefused("protected_principal", f"{seat!r} is a protected principal")
            if row.get("retired_at"):
                raise RegistryMutationRefused("seat_retired", f"{seat!r} is retired; its identity cannot be restored")
            if parked and row.get("parked_at"):
                return {"seat": seat, "already_parked": True, "parked_at": row["parked_at"],
                        "parked_by": row.get("parked_by"), "channel": row.get("channel")}
            if not parked and not row.get("parked_at"):
                raise RegistryMutationRefused("seat_not_parked", f"{seat!r} is not parked")
            revoke = None
            if parked:
                now = datetime.now(timezone.utc).timestamp()
                tokens = _read_tokens_unlocked()
                live = sorted(tid for tid, rec in _token_items(tokens)
                              if rec.get("kind") in {"invite", "session"} and not rec.get("revoked")
                              and not rec.get("used") and not _token_expired(rec, now, tokens=tokens)
                              and (rec.get("participant_id") == seat or rec.get("allowed_participant_id") == seat))
                if _credentials_on(tokens):
                    if seat == actor:
                        # DJK-CREDA-1: the act would revoke the very credential that authorizes it,
                        # and then could neither finish nor be retried. Before the migration a seat
                        # could not park itself either (its own token is live); that stays so.
                        raise RegistryMutationRefused(
                            "self_park_refused",
                            f"{seat!r} cannot park itself; another provisioner parks it")
                    # CREDENTIALS_01 D-CRED-1: parking is one governed act that revokes the
                    # seat's live sessions and open invites, then marks the row.
                    revoke = live
                elif live:
                    raise RegistryMutationRefused("seat_has_live_token",
                        f"{seat!r} has a live token; run {product_identity.command()} token revoke {seat} first")
            after = dict(row)
            event = {"kind": "seat-" + command, "actor": actor, "seat": seat,
                     "ts": datetime.now(timezone.utc).isoformat()}
            if parked:
                after.update(parked_at=event["ts"], parked_by=actor)
            else:
                after.pop("parked_at", None)
                after.pop("parked_by", None)
                if channel is not None:
                    after["channel"] = channel
                event.update(parked_at=row["parked_at"], channel=after.get("channel"))
            if revoke is not None:
                event["revoked"] = revoke
            pending = {"format": "registry-parking/v1", "seat": seat, "command": command,
                       "channel": channel, "before": row, "after": after, "event": event}
            if revoke is not None:
                pending["revoke"] = revoke
            # Validate every shared writer invariant before publishing an intent.
            _registry_actor_local.parking = True
            try:
                _check_registry_change(parts, {**parts, seat: after}, writer="governance")
            finally:
                _registry_actor_local.parking = False
        try:
            if not REGISTRY_PARK_PENDING.exists():
                tmp = REGISTRY_PARK_PENDING.with_suffix(".tmp")
                with tmp.open("w", encoding="utf-8") as stream:
                    os.chmod(tmp, 0o600)
                    json.dump(pending, stream)
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(tmp, REGISTRY_PARK_PENDING)
            _fsync_dir(STORE_DIR)
            if strict and pending.get("revoke"):
                # One token-table write revokes every credential the intent names; a retry
                # revokes only what is still unrevoked, so it completes the same set.
                tokens = _read_tokens_unlocked()
                unrevoked = [tid for tid in pending["revoke"]
                             if isinstance(tokens.get(tid), dict) and not tokens[tid].get("revoked")]
                if unrevoked:
                    stamp = now_iso()
                    for tid in unrevoked:
                        tokens[tid].update(revoked=True, revoked_at=stamp, revocation_reason="parked")
                    _write_tokens_unlocked(tokens)
            if row != pending["after"]:
                parts[seat] = pending["after"]
                _registry_actor_local.parking = True
                try:
                    _write_participants_unlocked(parts, writer="governance")
                    _fsync_dir(STORE_DIR)
                finally:
                    _registry_actor_local.parking = False
            _record_seat_lifecycle_event(pending["event"])
            REGISTRY_PARK_PENDING.unlink()
        except OSError as exc:
            raise SeatActWithoutReceipt("registry " + command, seat,
                f"parking act may be committed; retry {product_identity.command()} registry {command} {seat} "
                f"with the original actor and channel to complete its receipt: {exc}") from exc
        # DJK-RPK-1: unlink completed and the receipt is present. A failure here
        # cannot honestly promise that retrying unpark completes a missing receipt.
        try:
            _fsync_dir(STORE_DIR)
        except OSError as exc:
            raise SeatActCleanupUnconfirmed("registry " + command, seat, str(exc)) from exc
        return {"seat": seat, "already_parked": False,
                "parked_at": pending["after"].get("parked_at"),
                "parked_by": pending["after"].get("parked_by"),
                "channel": pending["after"].get("channel")}

    return authenticated_registry_act(presented_token, apply, provisioning=True)


def park_participant(seat: str, *, presented_token=None):
    """Pause an identity after its credentials have been revoked."""
    return _change_parking(seat, parked=True, presented_token=presented_token)


def unpark_participant(seat: str, *, channel=None, presented_token=None):
    """Resume an identity; fresh credentials and runtime provisioning are separate."""
    return _change_parking(seat, parked=False, channel=channel, presented_token=presented_token)


def update_participant_probe(pid: str, *, measured_at: str,
                             **fields: Any) -> Dict[str, Any]:
    """Write execution-owned participant facts from a daemon/adapter probe."""
    return _registry_locked(
        lambda: _upsert_participant_unlocked(
            pid, writer="execution", measured_at=measured_at, **fields))


SEAT_DECLARATION_FIELDS = frozenset({
    "hosting_kind", "tmux_socket", "workspace_dir", "config_dir",
    "session_ref", "history_limit",
})


def provision_seat_declaration(actor: str, seat: str, *, presented_token=None,
                               **declarations: Any) -> Dict[str, Any]:
    """Apply one explicit, failure-aware governance declaration and receipt."""
    if set(declarations) != SEAT_DECLARATION_FIELDS:
        missing = sorted(SEAT_DECLARATION_FIELDS - set(declarations))
        extra = sorted(set(declarations) - SEAT_DECLARATION_FIELDS)
        raise ValueError(f"seat declaration fields invalid; missing={missing}, extra={extra}")
    if declarations["hosting_kind"] != "tmux-hosted":
        raise ValueError("seat declaration hosting_kind must be tmux-hosted")
    history_limit = declarations["history_limit"]
    if isinstance(history_limit, bool) or not isinstance(history_limit, int) or history_limit <= 0:
        raise ValueError("seat declaration history_limit must be a positive integer")
    for field in ("workspace_dir", "config_dir"):
        value = declarations[field]
        path = Path(value) if isinstance(value, str) else Path("")
        if not isinstance(value, str) or not value.strip() or not path.is_absolute() \
                or path.is_symlink() or not path.is_dir():
            raise ValueError(f"seat declaration {field} must be an existing absolute non-symlink directory")
    session_ref = declarations["session_ref"]
    if not isinstance(session_ref, str) or not session_ref.strip() or session_ref != session_ref.strip():
        raise ValueError("seat declaration session_ref must be a clean non-empty string")

    def apply():
        participants = _read_participants_unlocked()
        existing = participants.get(seat)
        if not isinstance(existing, dict):
            raise ValueError(f"seat {seat!r} is not registered")
        candidate = {name: dict(row) if isinstance(row, dict) else row
                     for name, row in participants.items()}
        candidate[seat].update(declarations)
        from seat_socket import registered_session, registered_socket
        registered_socket(seat, candidate)
        registered_session(candidate[seat])
        backfilled = []
        for name, row in candidate.items():
            if isinstance(row, dict) and row.get("panel_poll_interval") is None:
                row["panel_poll_interval"] = PROVISIONAL_PANEL_POLL_INTERVAL_SECONDS
                backfilled.append(name)
        changed = candidate != participants
        payload = {
            "act": "seat_declare", "seat": seat,
            "fields": sorted(SEAT_DECLARATION_FIELDS), "changed": changed,
            "panel_poll_backfilled": sorted(backfilled),
        }
        if changed:
            _write_participants_unlocked(candidate)
        return candidate[seat], changed, payload

    # Match the merged A.4 provisioning shape: commit the governed state under
    # its owner lock, then emit the ordinary harness-mutation receipt.  A
    # receipt failure is reported as an already-committed act, never as a
    # refused declaration and never by changing the shared JSONL primitive.
    participant, changed, payload = authenticated_registry_act(
        presented_token, lambda identity: apply(), provisioning=True, expected_actor=actor)
    try:
        receipt = _emit_seat_receipt(actor, payload)
    except Exception as exc:
        raise SeatActWithoutReceipt("seat_declare", seat, str(exc)) from exc
    return {"participant": participant, "changed": changed, "receipt": receipt}


def remove_participant(pid: str, *, presented_token=None) -> bool:
    def apply():
        parts = _read_participants_unlocked()
        if pid not in parts:
            return False
        del parts[pid]
        _write_participants_unlocked(parts)
        return True
    return authenticated_registry_act(presented_token, lambda actor: apply(), provisioning=True)


# --- messages ---

def _safe_pid(pid: str) -> str:
    if not PARTICIPANT_ID_RE.match(pid):
        raise ValueError(f"invalid participant id {pid!r}")
    return pid


def inbox_path(pid: str) -> Path:
    return INBOX_DIR / f"{_safe_pid(pid)}.jsonl"


def cursor_path(pid: str) -> Path:
    return CURSOR_DIR / f"{_safe_pid(pid)}.json"


def has_mailbox(participant: Dict[str, Any]) -> bool:
    """Humans are authorities/conversation participants, never mailbox seats."""
    return participant.get("kind") != "human" and participant.get("role") != "human_authority"


def mailbox_targets(message):
    """Accepted delivery intent, distinct from conversation addressing.

    Send and routed-notice writers freeze this subset under the registry fence. Legacy
    rows retain their recorded recipients: historical eligibility cannot be
    reconstructed from today's registry or a missing QUEUED receipt.
    """
    recipients = message.get("recipients", [])
    targets = message.get("mailbox_recipients", recipients)
    if not isinstance(recipients, list) or not isinstance(targets, list):
        return []
    return list(dict.fromkeys(pid for pid in targets
                              if isinstance(pid, str) and pid and pid in recipients))


def _active_chiefs(participants):
    return [pid for pid, row in participants.items()
            if row.get("kind") == "agent" and row.get("role") == "chief_of_staff"
            and not inactive_participant(row)]


def chief_of_staff_recipients(participants):
    """Return the unique current agent CoS, or no actionable recipient."""
    chiefs = _active_chiefs(participants)
    return chiefs if len(chiefs) == 1 else []


def human_notification_channel(participant):
    """Whether an active human authority accepts native notifications."""
    return (participant.get("kind") == "human"
            and participant.get("role") in {None, "human_authority"}
            and participant.get("channel") == "notify"
            and not inactive_participant(participant))


def _vacancy_notify_recipients(participants):
    if _active_chiefs(participants):
        return []  # Ambiguous ownership is not a vacancy.
    return [pid for pid, row in participants.items() if human_notification_channel(row)]


def _system_notice_routes(targets, participants):
    """Snapshot each explicit target's route, before recipient deduplication."""
    active = _active_chiefs(participants)
    chiefs = tuple(active) if len(active) == 1 else ()
    # With no chief, retain the human's canonical addressing (not a mailbox).
    # Notification targets are recorded separately at acceptance.
    return tuple((target, (target,) if has_mailbox(participants.get(target, {})) or not active else chiefs)
                 for target in targets)


def system_notice_recipients(targets, participants):
    """Route human-directed System notices to the unique current agent CoS.

    A vacancy retains human addressing for the log and notification channel;
    ambiguous role ownership has no actionable route. Humans never gain mailboxes.
    """
    return list(dict.fromkeys(pid for _, route in _system_notice_routes(targets, participants)
                              for pid in route))


def obsolete_human_notice(message, participants):
    """Hide retained human-only System notices without rewriting audit history."""
    if (isinstance(message.get("mailbox_recipients"), list)
            or message.get("human_notify_recipients")):
        # Accepted modern notices (including vacancy/log-only notices) are
        # current history, not the obsolete unclassified human mailbox rows.
        return False
    targets = message.get("recipients", message.get("to", []))
    return (message.get("from") in {"System", DAEMON_SEAT}
            and message.get("kind") == "system"
            and isinstance(targets, list) and bool(targets)
            and all(isinstance(pid, str) and not has_mailbox(participants.get(pid, {}))
                    for pid in targets))


def get_cursor(pid: str) -> int:
    if not has_mailbox(load_participants().get(pid, {})):
        return 0
    path = cursor_path(pid)
    if not path.exists():
        return 0
    try:
        state = json.loads(path.read_text())
    except (json.JSONDecodeError, OSError, UnicodeError):
        return 0
    if not isinstance(state, dict):
        return 0
    offset = state.get("offset", 0)
    return offset if type(offset) is int and offset >= 0 else 0


SDK_INBOX_FENCE_VERSION = 1


def set_cursor(pid: str, offset: int, *,
               sdk_fence_version: int | None = None) -> None:
    if type(offset) is not int or offset < 0:
        raise ValueError("invalid inbox cursor offset")
    if not has_mailbox(load_participants().get(pid, {})):
        return
    ensure_store()
    path = cursor_path(pid)
    if sdk_fence_version is None and path.exists():
        try:
            existing = json.loads(path.read_text())
        except (json.JSONDecodeError, OSError, UnicodeError):
            existing = None
        if isinstance(existing, dict) and "sdk_fence_version" in existing:
            marker = existing["sdk_fence_version"]
            if type(marker) is int and marker == SDK_INBOX_FENCE_VERSION:
                sdk_fence_version = marker
    tmp = path.with_suffix(".json.tmp")
    state = {"offset": offset, "updated_at": now_iso()}
    if sdk_fence_version is not None:
        if type(sdk_fence_version) is not int \
                or sdk_fence_version != SDK_INBOX_FENCE_VERSION:
            raise ValueError("invalid SDK inbox fence version")
        state["sdk_fence_version"] = sdk_fence_version
    with tmp.open("w") as f:
        f.write(json.dumps(state))
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def establish_sdk_inbox_fence(pid: str) -> bool:
    """Atomically establish the first SDK activation at the inbox tail.

    A generic cursor can predate SDK activation, so cursor-file existence is
    not the discriminator. A valid in-record marker means restart and preserves
    its offset. A missing marker means first activation and moves to the current
    tail. Malformed marked state refuses before any vendor-capable drain.
    """
    if not has_mailbox(load_participants().get(pid, {})):
        raise ValueError("human participants have no inbox")
    ensure_store()
    path = cursor_path(pid)
    lock_target = path.with_suffix(".lock")
    with lock_target.open("a") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        try:
            if path.exists():
                try:
                    state = json.loads(path.read_text())
                except (json.JSONDecodeError, OSError, UnicodeError) as error:
                    raise RuntimeError(
                        f"invalid SDK inbox cursor state: {error}") from error
                if not isinstance(state, dict):
                    raise RuntimeError("invalid SDK inbox cursor state")
                if "sdk_fence_version" in state:
                    marker = state["sdk_fence_version"]
                    offset = state.get("offset")
                    if type(marker) is not int \
                            or marker != SDK_INBOX_FENCE_VERSION \
                            or type(offset) is not int or offset < 0:
                        raise RuntimeError("invalid SDK inbox fence state")
                    return False
            inbox = inbox_path(pid)
            with inbox.open("a+b") as inbox_file:
                fcntl.flock(inbox_file.fileno(), fcntl.LOCK_EX)
                try:
                    set_cursor(
                        pid, os.fstat(inbox_file.fileno()).st_size,
                        sdk_fence_version=SDK_INBOX_FENCE_VERSION)
                finally:
                    fcntl.flock(inbox_file.fileno(), fcntl.LOCK_UN)
            return True
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


SEEN_IDS_KEEP = 500


def _seen_path(pid: str) -> Path:
    return CURSOR_DIR / f"{_safe_pid(pid)}.seen.json"


def _read_seen_ids(pid: str) -> List[str]:
    """Return only the non-authoritative seen-state shape we can trust.

    Missing, unreadable, undecodable, unparsable, or malformed state recovers
    as empty. At worst that permits a duplicate to surface; it must never brick
    a drain or advance the cursor and then lose the drained messages.
    """
    try:
        state = json.loads(_seen_path(pid).read_text())
    except (json.JSONDecodeError, OSError, UnicodeError):
        return []
    if not isinstance(state, list) \
            or any(type(message_id) is not str for message_id in state):
        return []
    return state


def _load_seen(pid: str) -> set:
    return set(_read_seen_ids(pid))


def _save_seen(pid: str, new_ids: List[str]) -> None:
    """Append consumed ids, keeping the most recent SEEN_IDS_KEEP.
    Called under the drain cursor lock."""
    existing = _read_seen_ids(pid)
    existing.extend(new_ids)
    path = _seen_path(pid)
    tmp = path.with_suffix(".json.tmp")
    with tmp.open("w") as f:
        f.write(json.dumps(existing[-SEEN_IDS_KEEP:]))
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


# --- identities: aliases (tombstones) and labels ---

ALIASES_FILE = STORE_DIR / "aliases.json"


def load_aliases() -> Dict[str, Dict[str, Any]]:
    """Retired identities: {old_id: {successor, retired_at}}. Sends to a
    retired id REFUSE with a pointer (never silent forwarding) — the operator's
    cutover directive 2026-06-12."""
    try:
        return json.loads(ALIASES_FILE.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def _save_aliases(aliases: Dict[str, Dict[str, Any]]) -> None:
    ensure_store()
    tmp = ALIASES_FILE.with_suffix(".json.tmp")
    with tmp.open("w") as f:
        json.dump(aliases, f, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, ALIASES_FILE)


def retire_identity(old_id: str, successor_id: str, *, presented_token=None) -> Dict[str, Any]:
    """Hard-retire old_id in favor of successor_id (which must exist).

    Ordering per directive: retire FIRST (alias entry up → new sends refuse),
    THEN forward the unread backlog to the successor's inbox (their watcher
    wakes), then delete the old inbox/cursor files. log.jsonl is never
    rewritten — history keeps the old name; views render via the alias table.
    Returns {forwarded: n}.
    """
    if not PARTICIPANT_ID_RE.match(successor_id):
        raise ValueError(f"invalid successor id {successor_id!r}")

    def apply():
        parts = _read_participants_unlocked()
        if successor_id not in parts:
            # Succession bypasses the registrar's collision check against the
            # predecessor (whose label is typically already the new name):
            # clone the old record under the new id, atomically with the
            # retirement, so there is no window where both identities accept.
            if old_id not in parts:
                raise ValueError(
                    f"successor '{successor_id}' does not exist and there is "
                    f"no '{old_id}' record to inherit from")
            src = parts[old_id]
            parts[successor_id] = {**src, "id": successor_id,
                                   "label": successor_id,
                                   "last_update": now_iso()}
            if src.get('inapp_hookset') is not None:
                # Qualification and its route belong to the predecessor's
                # identity/home/token. A successor must provision and declare.
                parts[successor_id].pop('inapp_hookset', None)
                parts[successor_id].pop('wake_route', None)
        aliases = load_aliases()
        aliases[old_id] = {"successor": successor_id, "retired_at": now_iso()}
        if old_id in parts:
            del parts[old_id]
        # Check the registry invariant before the migration's first side effect.
        previous = getattr(_registry_actor_local, 'hookset_retiring', None)
        _registry_actor_local.hookset_retiring = old_id
        try:
            _check_registry_change(_read_participants_unlocked(), parts)
            _save_aliases(aliases)            # 1. retire: sends now refuse
            _write_participants_unlocked(parts)
        finally:
            _registry_actor_local.hookset_retiring = previous
    authenticated_registry_act(presented_token, lambda actor: apply(), provisioning=True)

    forwarded = 0
    try:
        backlog = drain_inbox(old_id)     # 2. unread only; read history is in the log
    except ValueError:
        backlog = []
    for m in backlog:
        append_jsonl(inbox_path(successor_id), m)
        forwarded += 1
    for path in (inbox_path(old_id), cursor_path(old_id), _seen_path(old_id),
                 cursor_path(old_id).with_suffix(".lock")):
        try:
            path.unlink()                 # 3. old files go; log keeps history
        except FileNotFoundError:
            pass
    return {"forwarded": forwarded}


def display_name(pid: str) -> str:
    """'reviewer (then agent)'-style rendering input: maps a historical id to
    its current successor label where one exists."""
    aliases = load_aliases()
    if pid in aliases:
        succ = aliases[pid]["successor"]
        return f"{succ} (then {pid})"
    return pid


def resolve_recipients(to: List[str], sender: str, *, participants=None, aliases=None) -> List[str]:
    """Resolve explicit participant ids/labels to participant ids.

    Retired ids refuse with their successor; labels resolve when unique.
    Broadcast aliases and room-like targets are typed refusals. Returns
    recipients excluding the sender.
    """
    parts = load_participants() if participants is None else participants
    aliases = load_aliases() if aliases is None else aliases
    labels = label_index(parts)
    wanted = [t.strip() for t in to if t.strip()]
    if not wanted:
        # FAIL LOUD on an empty/blank recipient list — never silently fan out to
        # nobody, and (crucially) callers must not paper this over with a
        # default-to-everyone (reviewer/Operator: a malformed send silently
        # broadcasting is a spam + spoofing footgun).
        raise KeyError("no recipients — give one or more explicit participant names")
    for target in wanted:
        if target.lower() in ("all", "everybody", "everyone"):
            raise RecipientPolicyError("broadcast_alias_retired", target)
        if target.startswith("#"):
            raise RecipientPolicyError("room_transport_retired", target)
    resolved: List[str] = []
    for t in wanted:
        if t in aliases and t not in parts:
            succ = aliases[t]["successor"]
            raise KeyError(f"'{t}' is retired — use '{succ}'")
        found = resolve_id_or_label(t, parts, labels=labels)
        if found:
            for seat in found:
                if parts[seat].get("retired_at"):
                    raise RecipientPolicyError("seat_retired", seat)
                if parts[seat].get("parked_at"):
                    raise RecipientPolicyError("seat_parked", seat)
            resolved.extend(found)
        else:
            raise KeyError(f"unknown participant(s): {t}")
    out = list(dict.fromkeys(t for t in resolved if t != sender))
    if not out:
        # MH-012: the emptiness guard above only covers a blank INPUT list;
        # self-exclusion can empty a NON-blank list here — a self-only send where
        # every resolved target is the sender. Fail loud rather than let store.send
        # persist a to=[] record delivered to nobody.
        raise KeyError("no recipients after excluding yourself — you cannot address only yourself")
    return out


def _ts_or(m: Dict[str, Any], default: float) -> float:
    """Epoch seconds of a record's ts, or `default` if missing/unparseable
    (undatable rows are treated as 'now' so they are never silently dropped)."""
    try:
        return datetime.fromisoformat(m["ts"]).astimezone(timezone.utc).timestamp()
    except (ValueError, KeyError, TypeError):
        return default


def _read_from_to_eof(offset: int) -> List[Dict[str, Any]]:
    """All records from byte `offset` through EOF. read_jsonl caps each call at
    READ_BATCH_BYTES, so we loop until the offset stops advancing — otherwise a
    window larger than one batch would read only a middle segment (reviewer PR#12
    HIGH: the newest rows near EOF would be silently dropped)."""
    recs: List[Dict[str, Any]] = []
    off = offset
    while True:
        batch, new_off = read_log(off)
        if new_off == off:
            break
        recs.extend(batch)
        off = new_off
    return recs


def read_log_to_eof(offset: int = 0) -> List[Dict[str, Any]]:
    """Return every canonical log record from ``offset`` through physical EOF."""
    import recall
    edges = recall.graph()
    return [recall.project(row, edges=edges) for row in _read_from_to_eof(offset)]


def read_log(offset: int = 0) -> tuple[List[Dict[str, Any]], int]:
    """Read legacy-prefix and envelope-v1 records through one surface.

    A.8 keeps both segments in ``log.jsonl``: the M1 ledger receipt pins the
    legacy prefix by byte length and hash, while M2 appends additive records.
    Canonical bytes remain intact; admitted recalls add a derived read status.
    """
    import recall
    rows, end = read_jsonl(LOG_FILE, offset)
    edges = recall.graph()
    return [recall.project(row, edges=edges) for row in rows], end


def _records_in_window(window_sec: int, now_ts: float) -> List[Dict[str, Any]]:
    """All log records whose ts is within the last `window_sec`.

    Scans the tail in GROWING chunks, reading each chunk THROUGH EOF, until the
    earliest record read is older than the cutoff (or we reach file start). A
    fixed-size tail is wrong (reviewer PR#12 HIGH): on a busy channel other rows
    push a sender's own recent rows out of a small tail, so it could exceed the
    cap inside the window yet read as under it — evaded exactly where it matters.
    Reading through EOF on each chunk keeps the result traffic- and size-independent."""
    if not LOG_FILE.exists():
        return []
    cutoff = now_ts - window_sec
    size = LOG_FILE.stat().st_size
    chunk = TAIL_READ_BYTES
    while True:
        start = max(0, size - chunk)
        recs = _read_from_to_eof(start)
        if start > 0 and recs:
            recs = recs[1:]  # first record may be torn by the byte cut
        if start == 0 or (recs and _ts_or(recs[0], now_ts) < cutoff):
            return [m for m in recs if _ts_or(m, now_ts) >= cutoff]
        chunk *= 2  # window not yet covered — read further back


def _burn_guard_check(sender: str, recipients) -> None:
    """Stop a runaway message storm/loop at the hub layer before it fans out.

    Trips when an *agent* emits too many *consecutive* messages to the same recipient set with no other
    (non-system) participant speaking in between — the Gemma broadcast-loop shape
    — or too many messages in a rolling time window. Humans (incl. the operator)
    and system messages are exempt: people don't loop, and the operator must never
    be throttled out of intervening. Raises BurnGuardTripped; the send is not made.

    SCOPE (reviewer PR#12 HIGH): this guards ACCIDENTAL runaway loops, the case it
    was built for. It is NOT an adversarial control under today's unauthenticated
    local CLI identity — an agent with shell access could evade it by sending
    `--as the operator` (inherit the human exemption), by `orch join <self> --kind human`
    (self-reclassification), or starve a peer by sending `--as <peer>`. Closing
    those requires authenticated identity = #19. Until then the guard's promise is
    "a polite agent that loops is stopped", not "a hostile agent is contained".
    """
    if BURN_MAX_CONSECUTIVE <= 0 and BURN_MAX_PER_WINDOW <= 0:
        return  # disabled
    # Agents only. NOTE: an unregistered/misregistered sender is exempt (kind is
    # not "agent") — an accepted boundary for the registered-agent scope; #19's
    # authenticated identity is the real closure (reviewer PR#12 MED).
    if load_participants().get(sender, {}).get("kind") != "agent":
        return

    # consecutive run: trailing messages from this sender; system notices are
    # transparent, anyone else breaks the run. Adjacency lives at the very tail,
    # so a bounded read is correct here (interleaving breaks the run by definition).
    if BURN_MAX_CONSECUTIVE > 0:
        consec = 0
        recipient_set = frozenset(recipients)
        for m in reversed(tail_jsonl(LOG_FILE, BURN_MAX_CONSECUTIVE + 2)):
            frm = m.get("from")
            if frm == sender:
                if frozenset(m.get("recipients", m.get("to", []))) != recipient_set:
                    break
                consec += 1
            elif frm in (None, "System"):
                continue
            else:
                break
        if consec >= BURN_MAX_CONSECUTIVE:
            raise BurnGuardTripped(
                f"{consec} consecutive messages to the same recipients with no one else speaking "
                f"(cap {BURN_MAX_CONSECUTIVE}) — halted to prevent a runaway loop. "
                f"Operator can release it with: {product_identity.command()} interrupt {sender}")

    # rate: sender's messages within the rolling window (traffic-independent count)
    if BURN_MAX_PER_WINDOW > 0:
        now_ts = datetime.now(timezone.utc).timestamp()
        count = sum(1 for m in _records_in_window(BURN_WINDOW_SEC, now_ts)
                    if m.get("from") == sender)
        if count >= BURN_MAX_PER_WINDOW:
            raise BurnGuardTripped(
                f"{count} messages in {BURN_WINDOW_SEC}s (cap {BURN_MAX_PER_WINDOW}) "
                f"— halted to prevent a storm. Operator: {product_identity.command()} interrupt {sender}")


def _message_envelope_v1(text: str, envelope: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Return the additive v1 envelope shared by every post-cutover append."""
    value = dict(envelope or {})
    if value.get("v", 1) != 1:
        raise ValueError("unsupported message envelope version; expected v=1")
    value["v"] = 1
    value.setdefault("re", "")
    value.setdefault("authority", "FYI")
    value.setdefault("confirm", False)
    value.setdefault("triage", "engage")
    value.setdefault("bluf", text[:280])
    return value


def _prepare_message_record(record: Dict[str, Any],
                            envelope: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Own the schema for every new canonical message-log record."""
    prepared = dict(record)
    prepared["envelope"] = _message_envelope_v1(str(prepared.get("text", "")), envelope)
    prepared["vet"] = dict(prepared.get("vet") or {})
    return prepared


def _append_message_log(record: Dict[str, Any]) -> None:
    """Atomically pin M1 and append one prepared M2 record behind one fence."""
    if "envelope" not in record or "vet" not in record:
        raise ValueError("post-cutover message append requires envelope and vet")
    import ledger
    with _open_private_journal(LOG_FILE) as log_file:
        fcntl.flock(log_file.fileno(), fcntl.LOCK_EX)
        try:
            ledger.ensure_legacy_log_segment()
            _append_jsonl_to_locked_file(log_file, record)
        finally:
            fcntl.flock(log_file.fileno(), fcntl.LOCK_UN)


class _UnreadStateMoved(Exception):
    """Retry an optimistic unread observation outside the delivery fence."""


def _unread_sources_stamp():
    """Constant-size identity/version stamp for the two append-only sources."""
    values = []
    for path in (LOG_FILE, STORE_DIR / "receipts.jsonl", STORE_DIR / "quarantine-dispositions"):
        try:
            value = path.stat()
            values.append((value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns))
        except FileNotFoundError:
            values.append(None)
    return tuple(values)


_UNREAD_DELTA_MAX_BYTES = 65536
# Existing activity, route and lifecycle observations do not commit a fetch.
# Keep this explicit: a future receipt kind must be classified before ignoring it.
_UNREAD_NEUTRAL_RECEIPT_KINDS = frozenset({
    "delivery", "nudge", "seat-act", "seat_event", "seat-event-refused",
    "wake-route", "wake_route_dead", "wake-submission", "seat-retire", "seat-park", "seat-unpark",
    "seat-home-bindings", "seat-provisioned", "machine-seat-rules", "seat-onboarding", "seat-help",
    "trace-mirror-loss", "seat-act-completion-failed", "claude-startup",
    "claude-route-hold", "claude-reconciliation",
    # The focus period (focus.py): policy, period and DEFERRED rows commit no fetch.
    "focus-policy", "focus-period", "delivery-disposition",
})


def _unread_delta_irrelevant(sender, before, after):
    """Prove a bounded append cannot alter this sender's unread projection.

    New addressed messages and all FETCHED/transaction rows require a replay:
    a transaction for another seat may establish or invalidate global cutover.
    Unknown, torn, replaced, truncated or oversized input also requires replay.
    """
    if before[2:] != after[2:]:
        return False  # An admitted release can make an old canonical row unread.
    for index, path in enumerate((LOG_FILE, STORE_DIR / "receipts.jsonl")):
        old, new = before[index], after[index]
        if old == new:
            continue
        if new is None or (old is not None and old[:2] != new[:2]):
            return False
        offset = old[2] if old is not None else 0
        delta = new[2] - offset
        if delta <= 0 or delta > _UNREAD_DELTA_MAX_BYTES:
            return False
        try:
            with path.open("rb") as source:
                if offset:
                    source.seek(offset - 1)
                    if source.read(1) != b"\n":
                        return False
                data = source.read(delta)
            if len(data) != delta or not data.endswith(b"\n"):
                return False
            for line in data.splitlines():
                row = json.loads(line)
                if not isinstance(row, dict):
                    return False
                if index == 0:
                    recipients = row.get("recipients")
                    if not isinstance(recipients, list) or sender in recipients:
                        return False
                elif (row.get("kind") == "delivery-transaction"
                      or row.get("event") == "FETCHED"
                      or row.get("kind") not in _UNREAD_NEUTRAL_RECEIPT_KINDS):
                    return False
        except (OSError, ValueError):
            return False
    return True


def _unread_exempt(sender, row):
    return (sender is None or row.get("kind") == "human"
            or (sender == DAEMON_SEAT and row.get("kind") == "system"))


def _prepare_unread_send(sender):
    """Replay outside registry/delivery locks; commit verifies source freshness."""
    row = load_participants().get(sender, {})
    if _unread_exempt(sender, row):
        return {"rows": None}
    before = _unread_sources_stamp()
    rows = [item for item in unread_ledger()["rows"] if item["recipient"] == sender]
    after = _unread_sources_stamp()
    return {"rows": rows, "stamp": after,
            "stable": before == after or _unread_delta_irrelevant(sender, before, after)}


def _check_unread_sender(sender, observation):
    """Use the current registry exemption and a fresh replay under the fence."""
    row = load_participants().get(sender, {})
    if _unread_exempt(sender, row):
        return
    current = _unread_sources_stamp()
    if (observation["rows"] is None or not observation["stable"]
            or (observation["stamp"] != current and not _unread_delta_irrelevant(
                sender, observation["stamp"], current))):
        raise _UnreadStateMoved()
    unread = observation["rows"]
    if unread:
        raise UnreadMailRefused(sender, unread, token_path=seat_token_path(
            sender, override=row.get("workspace_dir")))


def _append_chief_notice(record):
    """Resolve CoS addressing and canonically accept it under the registry fence.

    Record preparation, fan-out and hooks stay outside the fence. The accepted
    metadata lets daemon repair recover delivery without re-resolving history.
    """
    notice = _prepare_message_record(record)
    def accept_notice():
        parts = _read_participants_unlocked()
        chiefs = chief_of_staff_recipients(parts)
        notice.update(to=chiefs, recipients=chiefs, ts=now_iso())
        notice["mailbox_recipients"] = list(chiefs)
        notify = _vacancy_notify_recipients(parts)
        if notify:
            notice["human_notify_recipients"] = notify
        notice["meta"] = {**notice.get("meta", {}),
                          "notice_routing": "chief_of_staff" if chiefs else
                          "chief_of_staff missing or ambiguous"}
        # D-GOV-2 (f): the same commit protocol as a send, under the same lock
        # order: once a policy row exists the notice carries ``focus_commit`` and
        # its QUEUED and DEFERRED rows are written inside the nudge lock.
        import focus
        import receipts
        with receipts._nudge_lock():
            plan = focus.before_commit_unlocked(
                notice, None,
                [pid for pid in mailbox_targets(notice) if has_mailbox(parts.get(pid, {}))])
            _append_message_log(notice)
            if plan is not None:
                focus.after_commit_unlocked(notice, plan)
    _registry_locked(accept_notice)
    repair_fanout(notice)
    _run_post_send_hooks(notice, authenticated_actor="System")
    return notice


def _emit_burn_alert(sender: str, reason: str) -> None:
    """Alert the current Chief of Staff once per trip, with a cooldown.

    Appended directly (bypassing send/guard). Sender-scoped cooldown (reviewer
    PR#12 MED): suppress if we already alerted on this sender within the last
    BURN_WINDOW_SEC — checking only the immediately-prior row let any intervening
    message re-open the floodgate, so a still-blocked agent could drive an alert
    storm. Uses the same true time-window scan as the rate cap (not a bounded
    tail), so heavy traffic can't hide a recent prior alert."""
    now_ts = datetime.now(timezone.utc).timestamp()
    for m in _records_in_window(BURN_WINDOW_SEC, now_ts):
        if m.get("kind") == "system" and m.get("meta", {}).get("burn_guard") == sender:
            repair_fanout(m)  # heal a committed notice; never reopen FETCHED work
            return
    _append_chief_notice({
        "id": new_id("msg"), "ts": now_iso(), "from": "System",
        "kind": "system",
        "text": f"⚠ burn-guard halted {sender}: {reason}",
        "meta": {"burn_guard": sender},
    })


def _append_send_log(record, *, authenticated_actor, notice_routes=None, admitted=True):
    """Fence retirement, then unread/fetch state, through canonical acceptance.

    Lock order is registry then delivery, matching authenticated hook fetches.
    Full replay, validation and observer callbacks remain outside both fences.
    """
    import receipts
    def commit(observation):
        parts = _read_participants_unlocked()
        if notice_routes is not None:
            current_routes = _system_notice_routes([target for target, _ in notice_routes], parts)
            for (target, expected), (_, current) in zip(notice_routes, current_routes):
                if current != expected:
                    # Do not silently rewrite recipients after authentication,
                    # header comparison and vetting. A fresh send re-runs them.
                    raise RecipientPolicyError("system_notice_routing_changed", target)
            if any(not has_mailbox(parts.get(target, {})) for target, _ in notice_routes):
                notify = _vacancy_notify_recipients(parts)
                if notify:
                    # Store-owned field: neither caller metadata nor an
                    # asserted sender can enable native human notifications.
                    record["human_notify_recipients"] = notify
        for seat in record["recipients"]:
            if parts.get(seat, {}).get("retired_at"):
                raise RecipientPolicyError("seat_retired", seat)
            if parts.get(seat, {}).get("parked_at"):
                raise RecipientPolicyError("seat_parked", seat)
        record["mailbox_recipients"] = [pid for pid in record["recipients"]
                                         if has_mailbox(parts.get(pid, {}))]
        with receipts._nudge_lock():
            _check_unread_sender(authenticated_actor, observation)
            if (authenticated_actor is not None and record.get("from") == authenticated_actor
                    and record.get("kind") != "system"):
                _burn_guard_check(authenticated_actor, record["recipients"])
            # Timestamp canonical acceptance, not the earlier validation start:
            # a first FETCHED cutover during validation cannot hide this send.
            record["ts"] = now_iso()
            # D-GOV-2 (f): decided at the commit, under the commit's own lock, so a
            # declaration either precedes this message (deferred) or follows it.
            # Once a policy row exists the record itself carries the decision
            # (``focus_commit``), and QUEUED, DEFERRED and any pass-through end are
            # journaled inside this lock; a row that fails stays owed by the record.
            import focus
            plan = None
            if admitted and (record.get("vet") or {}).get("disposition") not in {"QUARANTINE", "DROP"}:
                author_role = ((parts.get(authenticated_actor) or {}).get("role")
                               if authenticated_actor is not None
                               and record.get("from") == authenticated_actor else None)
                plan = focus.before_commit_unlocked(
                    record, author_role,
                    [pid for pid in mailbox_targets(record) if has_mailbox(parts.get(pid, {}))])
            _append_message_log(record)
            if plan is None:
                return {}, None
            return focus.after_commit_unlocked(record, plan), plan["queued"]
    for _attempt in range(3):
        observation = _prepare_unread_send(authenticated_actor)
        try:
            return _registry_locked(lambda observation=observation: commit(observation))
        except _UnreadStateMoved:
            continue
        except BurnGuardTripped as exc:
            # Unread refusal takes precedence; alert outside both fences.
            _emit_burn_alert(authenticated_actor, str(exc))
            raise
    # Relevant, unknown or oversized appends may invalidate every observation.
    # Never replay under the shared fence or spin indefinitely under norms.lock.
    # QUEUED/DROPPED journal rows cannot create/clear unread pairs; relevant
    # deliveries and transactional FETCHED writers already hold nudge.lock.
    raise UnreadStateBusy(authenticated_actor)


def send(sender: str, to: List[str], text: str, *, kind: str = "message",
         reply_to: str | None = None, meta: Dict[str, Any] | None = None,
         envelope: Dict[str, Any] | None = None,
         cites: List[str] | None = None,
         supersedes: str | None = None,
         presented_token: str | None = None,
         authenticated_sender: str | None = None,
         validate_client_headers: bool = False,
         refuse_invalid_ack: bool = False) -> Dict[str, Any]:
    """Append a message to the global log and fan out to recipient inboxes.

    The inbox append is the durable delivery AND the watcher wake-up; the
    daemon only layers notifications on top. Returns the message record.
    CLI/HTTP opt into a final header check against the same snapshot used for
    recipient resolution, authority and advisory vetting. Other clients retain
    advisory-only prose checks. No registry lock spans validation or callbacks.
    The CLI also opts into refusing an invalid typed ack before append, using
    the existing vet row under the norms fence. Other callers retain stored
    vet dispositions; the receipted vetting kill-switch is unchanged.
    """
    ensure_store()
    # Phase A A.4 is an authentication boundary, not an A.2 content rule.  Resolve
    # the credential before consulting the receipted A.2 kill-switch so disabling
    # content vetting can never restore caller-asserted authorship.  On the normal
    # enabled path an invalid claim is still preserved as the existing canonical
    # DROPPED/unverified audit row; the disabled path has no vet row in which to
    # record that refusal, so it fails before any log, hook, receipt, or fan-out.
    principal, credential_reason = token_verdict(presented_token) \
        if presented_token else (None, "no_token")
    bound_sender = principal.get("participant_id") if principal is not None else None
    identity_error = None
    if principal is None:
        identity_error = credential_reason
    elif bound_sender != sender:
        identity_error = "token-bound seat does not match message sender"
    import norms
    norms_on = norms.enabled()
    if not norms_on and identity_error is not None:
        raise PermissionError(
            f"refusing to send: credential-derived sender identity failed "
            f"({identity_error})"
        )
    participants, retired = load_participants(), load_aliases()
    recipients = resolve_recipients(to, sender, participants=participants, aliases=retired)
    notice_routes = None
    if (identity_error is None and bound_sender == DAEMON_SEAT and kind == "system"
            and participants.get(bound_sender, {}).get("kind") == "system"):
        notice_routes = _system_notice_routes(recipients, participants)
        recipients = list(dict.fromkeys(pid for _, route in notice_routes for pid in route))
    if not recipients:
        # MH-012 fail-closed choke point: NO send path (CLI, interactive,
        # programmatic, web) may persist an empty-recipient record. resolve_recipients
        # already rejects a self-only explicit send; this catches any residual empty
        # (e.g. a broadcast/room resolving to nobody but the sender) so store.send is
        # the single boundary no caller can bypass.
        raise KeyError("refusing to send: recipient set is empty after resolution")
    if validate_client_headers:
        import message_headers
        comparison = message_headers.compare(text, envelope, sender, recipients, participants, retired)
        if comparison["verdict"] == "refused":
            raise message_headers.ClientHeaderRefused(comparison)
    # Compose-time expansion is now the only fan-out: every recorded target is
    # an explicit addressed seat, so the filtered watcher honestly wakes each.
    to_logged = recipients
    msg = _prepare_message_record({
        "id": new_id("msg"),
        "ts": now_iso(),
        "from": sender,
        "to": to_logged,
        "recipients": recipients,
        "kind": kind,
        "text": text,
    }, envelope)
    if reply_to:
        msg["reply_to"] = reply_to
    if meta:
        msg["meta"] = meta
    if cites is not None:
        msg["cites"] = list(cites)
    if supersedes is not None:
        msg["supersedes"] = supersedes

    # Phase A A.2/A.4 seam: identity is derived afresh from an existing A.4
    # credential on every send.  A caller-supplied name (including the retained,
    # inert ``authenticated_sender`` compatibility parameter) is never evidence
    # of identity.  Re-resolving here makes revocation effective at the production
    # boundary and leaves no generic self-binding/direct-call bypass.
    # Authority verification is deliberately OUTSIDE the execution-plane critical
    # section: authority.py owns the rights model and returns a typed disposition.
    blocked = None
    authority_verdict = None
    if norms_on:
        import authority
        pre_records = _read_from_to_eof(0)
        pre_by_id = {record.get("id"): record for record in pre_records if record.get("id")}
        authority_verdict = authority.verify(
            msg,
            participants=participants,
            superseded=pre_by_id.get(supersedes) if supersedes is not None else None,
        )
        lock_path = LOG_FILE.with_suffix(".norms.lock")
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        with lock_path.open("a") as _norms_lock:
            fcntl.flock(_norms_lock.fileno(), fcntl.LOCK_EX)
            try:
                import vetting
                records = _read_from_to_eof(0)
                records_by_id = {
                    record.get("id"): record for record in records if record.get("id")
                }
                checks = vetting.deliverability_checks(
                    msg,
                    participants=participants,
                    records_by_id=records_by_id,
                    authenticated_sender=bound_sender,
                )
                if refuse_invalid_ack and identity_error is None:
                    ack_failure = next((check for check in checks
                                        if check['row'] == 'typed-ack-solicited'
                                        and check['disposition'] == vetting.DROP), None)
                    if ack_failure is not None:
                        raise TypedAckRefused(ack_failure['reason'])
                # Compare against the caller's envelope before record defaults.
                checks.extend(vetting.prose_advisory_checks(
                    msg, envelope, participants=participants, retired=retired))
                checks.append(vetting.duplicate_delta_check(
                    msg,
                    _records_in_window(norms.DELTA_WINDOW_SEC, time.time()),
                    min_chars=norms.MIN_DELTA_CHARS,
                ))
                checks.append({
                    "row": authority_verdict["row"],
                    "result": authority_verdict["result"],
                    "disposition": authority_verdict["disposition"],
                    "reason": authority_verdict["basis"],
                })
                msg["vet"] = vetting.result(checks)
                if msg["vet"]["disposition"] in {vetting.QUARANTINE, vetting.DROP}:
                    blocked = {
                        "rule": next(
                            (check["row"] for check in checks
                             if check["disposition"] == msg["vet"]["disposition"]),
                            "vetting",
                        ),
                        "reason": msg["vet"]["reason"],
                        "disposition": msg["vet"]["disposition"],
                    }
                if msg["vet"]["disposition"] == vetting.QUARANTINE:
                    # Compatibility marker for pre-A.2 repair tooling; ``vet`` is
                    # the canonical disposition and the quarantine-list source.
                    msg["quarantined"] = {
                        "rule": blocked["rule"], "reason": blocked["reason"]
                    }
                focus_deferred, queued_at_commit = _append_send_log(
                    msg, authenticated_actor=bound_sender, notice_routes=notice_routes,
                    admitted=blocked is None)
            finally:
                fcntl.flock(_norms_lock.fileno(), fcntl.LOCK_UN)
    else:
        focus_deferred, queued_at_commit = _append_send_log(
            msg, authenticated_actor=bound_sender, notice_routes=notice_routes,
            admitted=blocked is None)
    _run_post_send_hooks(msg, authenticated_actor=bound_sender)
    if blocked is not None:
        norms.record_block(
            msg, blocked,
            authenticated_actor=bound_sender if identity_error is None else None,
        )
        if identity_error is None:
            # Only a credential-derived author may receive a refusal notice or
            # produce recipient delivery receipts.  An unverified/mismatched
            # claim remains solely as the canonical DROPPED audit row.
            notice = norms.rejection_record(msg, blocked, new_id, now_iso)
            current = load_participants()
            import receipts
            if not has_mailbox(current.get(bound_sender, {})):
                _append_chief_notice(notice)
            else:
                append_jsonl(inbox_path(bound_sender), notice)
            for pid in recipients:
                try:
                    receipts.journal(msg["id"], pid, "DROPPED", detail=blocked["reason"])
                except OSError:
                    pass
        return msg
    # A.3 QUEUED is now strictly behind gate PASS.  No non-PASS record can
    # enter the pending set or reach a recipient adapter.
    import receipts
    if queued_at_commit is None:
        current = load_participants()
        mailbox_recipients = [pid for pid in mailbox_targets(msg) if has_mailbox(current.get(pid, {}))]
        for pid in mailbox_recipients:
            try:
                receipts.journal(msg["id"], pid, "QUEUED")
            except OSError:
                pass  # evidence failure must not strand the canonical delivery
    else:
        mailbox_recipients = queued_at_commit  # D-GOV-2 (f): journaled at the commit
    for pid in mailbox_recipients:
        append_jsonl(inbox_path(pid), msg)
    if focus_deferred:
        import focus
        # §3.9: the sender learns, per focusing recipient, until when the wake waits.
        # A copy: the stored record and every inbox copy stay as admitted.
        msg = {**msg, "focus": {seat: {"period-id": start["period-id"],
                                       "until": focus._iso(start["end_epoch"])}
                                for seat, start in sorted(focus_deferred.items())}}
    return msg


def drain_inbox(pid: str, *, peek: bool = False, before_commit=None,
                fetch_metadata=None) -> List[Dict[str, Any]]:
    """Return unconsumed messages for pid; advance the cursor unless peeking.

    The whole get-read-set sequence holds a lock on the cursor file so two
    concurrent drains for the same participant can't double-consume or
    leapfrog each other's offsets.
    """
    if not has_mailbox(load_participants().get(pid, {})):
        return []
    ensure_store()
    lock_target = cursor_path(pid).with_suffix(".lock")
    with lock_target.open("a") as lock:
        if not peek:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        try:
            offset = get_cursor(pid)
            path = inbox_path(pid)
            # If the inbox was rotated/removed, don't read from a stale offset.
            size = path.stat().st_size if path.exists() else 0
            if offset > size:
                offset = 0
            records, new_offset = read_jsonl(path, offset)
            if before_commit is not None:
                while new_offset < size:
                    more, next_offset = read_jsonl(path, new_offset)
                    if next_offset == new_offset:
                        break
                    records.extend(more)
                    new_offset = next_offset
            # Dedupe by id, both within the batch and against recently
            # consumed ids (at-least-once appends: a repair copy can land
            # after the cursor passed the original — see repair_fanout).
            seen = _load_seen(pid) if not peek else set()
            unique = []
            new_ids = []
            for r in records:
                rid = r.get("id")
                if type(rid) is not str or not rid:
                    continue
                if rid in seen:
                    continue
                seen.add(rid)
                new_ids.append(rid)
                unique.append(r)
            import receipts
            import recall
            from contextlib import nullcontext
            with receipts._nudge_lock() if not peek else nullcontext():
                # Projection, durable hook file and FETCHED share the recall fence.
                edges = recall.graph()
                unique = [recall.project(row, edges=edges) for row in unique]
                if not peek:
                    if before_commit is not None:
                        before_commit(unique)
                    if new_ids:
                        receipts.mark_fetched_unlocked(new_ids, pid, adapter="inbox",
                                                       metadata=fetch_metadata)
                    set_cursor(pid, new_offset)
                    if new_ids:
                        _save_seen(pid, new_ids)
                return unique
        finally:
            if not peek:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def valid_fetched_deliveries(journal):
    """Yield (position, row) for valid transactional FETCHED evidence.

    Pure replay of supplied rows: no reads, writes, locks or recovery. The whole
    journal is checked before yielding, because a later abort or conflicting
    prepare invalidates even an earlier delivery. Positions identify individual
    materialisations without admitting another row for the same transaction.
    """
    transactions, deliveries = {}, []
    for position, row in enumerate(journal):
        txn = row.get("txn-id")
        if not isinstance(txn, str) or not txn:
            continue
        state = transactions.setdefault(txn, {"prepare": None, "committed": False,
                                               "invalid": False})
        if row.get("kind") == "delivery-transaction":
            phase = row.get("phase")
            if phase == "abort":
                state["invalid"] = True
            elif phase == "commit":
                if state["prepare"] is None:
                    state["invalid"] = True
                state["committed"] = True
            elif phase == "prepare":
                mids, seat = row.get("msg-ids"), row.get("seat")
                if (row.get("event") != "FETCHED" or not isinstance(seat, str) or not seat
                        or not isinstance(mids, list)
                        or not all(isinstance(mid, str) and mid for mid in mids)):
                    state["invalid"] = True
                    continue
                signature = (seat, frozenset(mids), row.get("adapter"))
                if state["prepare"] is not None and state["prepare"] != signature:
                    state["invalid"] = True
                state["prepare"] = signature
        elif (row.get("kind") == "delivery" and row.get("event") == "FETCHED"
                and state["committed"] and not state["invalid"]):
            seat, mids, adapter = state["prepare"]
            mid = row.get("msg-id")
            if (isinstance(mid, str) and mid in mids and row.get("seat") == seat
                    and row.get("adapter") == adapter):
                deliveries.append((txn, position, row))

    for txn, position, row in deliveries:
        if not transactions[txn]["invalid"]:
            yield position, row


def unread_ledger() -> Dict[str, Any]:
    """Observe unread pairs since the first valid transactional FETCHED receipt.

    Replay prepare → commit → delivery in journal order. Aborts and conflicting
    prepares invalidate the whole transaction, including earlier deliveries.
    The cutover is the timestamp of its first valid dated delivery in journal
    order. Without one, the boundary is unknown and no rows are actionable.
    Current human rows are excluded. No cursor, inbox, credential or repair
    path is consulted; retained historical human files remain untouched.
    """
    def records(path):
        offset = 0
        while True:
            batch, next_offset = read_jsonl(path, offset)
            yield from batch
            if next_offset == offset:
                return
            offset = next_offset

    def instant(ts):
        if not isinstance(ts, str):
            return None
        try:
            value = datetime.fromisoformat(ts)
            return value.timestamp() if value.tzinfo is not None else None
        except (ValueError, OverflowError, OSError):
            return None

    participants = load_participants()
    mailbox = lambda pid: has_mailbox(participants.get(pid, {}))
    fetched, cutover, cutover_instant = set(), None, None
    for _, row in valid_fetched_deliveries(records(STORE_DIR / "receipts.jsonl")):
        seat, mid, ts = row.get("seat"), row.get("msg-id"), row.get("ts")
        fetched.add((seat, mid))
        if cutover is None and (timestamp := instant(ts)) is not None:
            cutover, cutover_instant = ts, timestamp
    import wake_hook_observation
    overdue = [row for row in wake_hook_observation.accepted_without_fetch()
               if mailbox(row['recipient'])]
    overdue_counts = {}
    for row in overdue:
        overdue_counts[row['recipient']] = overdue_counts.get(row['recipient'], 0) + 1
    measured_at = datetime.now(timezone.utc).timestamp()
    import recall
    recall_edges = recall.graph()
    unread, seen, senders, incomplete = [], set(), {}, {}
    for message in records(LOG_FILE):
        mid, sender = message.get("id"), message.get("from")
        recipients = message.get("recipients")
        vet = message.get("vet")
        if (not isinstance(mid, str) or not mid or not isinstance(sender, str)
                or not isinstance(recipients, list)):
            continue
        if mid in recall_edges or message.get("kind") in {"recall", "withdraw"}:
            continue
        recipients = mailbox_targets(message)
        ts = message.get("ts")
        if isinstance(vet, dict) and vet.get("verdict") == "QUARANTINED":
            import quarantine
            disposition = quarantine.status(message)
            if disposition["state"] == "incomplete":
                incomplete[mid] = {"id": mid, **disposition}
            if disposition["blocked"]:
                continue
            # Receipt time is when this formerly withheld row became deliverable.
            # Keep the original canonical message timestamp untouched.
            ts = disposition["ts"]
            recipients = disposition["recipients"]
        elif delivery_blocked(message, recall_edges=recall_edges):
            continue
        senders[mid] = sender
        timestamp = instant(ts)
        # An undated message cannot be shown to be at or after the cutover.
        if cutover_instant is None or timestamp is None or timestamp < cutover_instant:
            continue
        age = max(0, int(measured_at - timestamp))
        for recipient in recipients:
            if (not isinstance(recipient, str) or not recipient or recipient == sender
                    or not mailbox(recipient)):
                continue
            pair = (recipient, mid)
            if pair in fetched or pair in seen:
                continue
            seen.add(pair)
            unread.append((timestamp, {"recipient": recipient, "sender": sender,
                "id": mid, "ts": ts, "age_seconds": age}))
    extra = ({'accepted_no_fetch': [
                {**row, 'sender': senders.get(row['id'], 'Unknown')} for row in overdue],
              'accepted_no_fetch_counts': overdue_counts} if overdue else {})
    if incomplete:
        extra["quarantine_incomplete"] = list(incomplete.values())
    if cutover is None:
        return {"cutover": None, "rows": [], **extra}
    unread.sort(key=lambda item: (item[1]["recipient"], item[1]["sender"],
                                  item[0], item[1]["id"]))
    return {"cutover": cutover, "rows": [row for _, row in unread], **extra,
            "hook_deliveries": [{**row, 'sender': senders.get(row['id'], 'Unknown')}
                                for row in wake_hook_observation.hook_deliveries()
                                if mailbox(row['recipient'])]}


def unread_count(pid: str) -> int:
    return sum(row.get("actionable") is not False for row in drain_inbox(pid, peek=True))


def await_inbox(pid: str, *, timeout: float | None = None,
                poll_interval: float = 0.2) -> List[Dict[str, Any]]:
    """Block until pid's inbox grows past its cursor; drain and return.

    One-shot: returns after the first batch. Callers re-arm by calling again
    (matches the verified agent file-watcher pattern, sub-second latency).
    """
    if not has_mailbox(load_participants().get(pid, {})):
        return []
    deadline = time.monotonic() + timeout if timeout else None
    path = inbox_path(pid)
    while True:
        offset = get_cursor(pid)
        size = path.stat().st_size if path.exists() else 0
        if size > offset:
            msgs = drain_inbox(pid)
            if msgs:
                return msgs
        if deadline and time.monotonic() > deadline:
            return []
        time.sleep(poll_interval)


def repair_fanout(msg: Dict[str, Any]) -> List[str]:
    """Ensure msg is present in every recipient inbox; append where missing.

    For canonical CoS System notices, also recover missing QUEUED evidence
    under the delivery fence. Their recorded recipient is never re-resolved;
    pending notices survive long downtime, and FETCHED work is never reopened.
    Covers the crash window in send() between the log append and the inbox
    loop. The daemon calls this for each message it processes (each message is
    checked once, shortly after creation). Ordinary messages retain a bounded
    tail scan; age-exempt CoS notices scan full inbox IDs to avoid duplicating
    a durable copy that later traffic has moved outside that tail.
    """
    repaired = []
    mid = msg.get("id", "")
    if not mid:
        return repaired
    if (msg.get("vet") or {}).get("verdict") == "QUARANTINED":
        import quarantine
        try:
            return quarantine.repair(msg)
        except quarantine.ItemRefused:
            return []
    if delivery_blocked(msg):
        # A non-PASS message was deliberately NOT fanned out. Its absence from
        # inboxes is intentional, not a crash-window gap — never repair it in.
        return repaired
    recoverable_notice = (msg.get("from") == "System" and msg.get("kind") == "system"
                          and (msg.get("meta") or {}).get("notice_routing") == "chief_of_staff")
    # Only repair recent ordinary messages: the tail presence-scan is bounded, so a
    # replayed delivery cursor over old history must not re-append copies
    # whose ids have scrolled past the scan window.
    try:
        age = (datetime.now(timezone.utc).astimezone()
               - datetime.fromisoformat(msg.get("ts", ""))).total_seconds()
    except ValueError:
        return repaired
    if age > 3600 and not recoverable_notice:
        return repaired
    needle = json.dumps(mid).encode()  # '"msg-..."' — matches the id field
    participants = load_participants()
    for pid in mailbox_targets(msg):
        if not has_mailbox(participants.get(pid, {})):
            continue
        def repair_one():
            if recoverable_notice:
                state = receipts._delivery_state(mid, pid)
                if state is None:
                    receipts.journal(mid, pid, "QUEUED")
                elif state not in {"QUEUED", "POKED"}:
                    return  # FETCHED (including committed batches) stays terminal
            path = inbox_path(pid)
            present = False
            if path.exists():
                size = path.stat().st_size
                with path.open("rb") as f:
                    if recoverable_notice:
                        for raw in f:
                            if not raw.endswith(b"\n"):
                                continue  # readers consume complete records only
                            try:
                                row = json.loads(raw)
                            except (json.JSONDecodeError, UnicodeDecodeError):
                                continue
                            if isinstance(row, dict) and row.get("id") == mid:
                                present = True
                                break
                    else:
                        f.seek(max(0, size - TAIL_READ_BYTES))
                        present = needle in f.read()
            if not present:
                append_jsonl(path, msg)
                repaired.append(pid)
        if recoverable_notice:
            import receipts
            # Serialize queue recovery and inbox repair with consumption. A
            # repair racing FETCHED cannot append a later QUEUED or inbox copy.
            with receipts._nudge_lock():
                repair_one()
        else:
            repair_one()
    return repaired


def delivery_blocked(message: Dict[str, Any], *, recall_edges=None) -> bool:
    """Keep the original vet result; a signed disposition alone releases quarantine."""
    import recall
    if message.get("kind") in {"recall", "withdraw"} or message.get("id") in (recall.graph() if recall_edges is None else recall_edges):
        return True
    verdict = (message.get("vet") or {}).get("verdict")
    if verdict == "DROPPED":
        return True
    if verdict == "QUARANTINED":
        import quarantine
        try:
            return not quarantine.released(message)
        except quarantine.ItemRefused:
            return True
    return bool(message.get("quarantined"))


# --- access tokens (#19): per-user, individually-revocable, hashed at rest ---
#
# Replaces the single shared guest token. Two kinds:
#   invite  — operator-issued for a named person; SINGLE-USE; the only way to
#             register a new identity (auth-gated registration).
#   session — minted when an invite is claimed; carries identity + role; durable;
#             individually revocable (operator kill-switch / logout).
# Tokens are stored as salted SHA-256 HASHES — the plaintext is shown once at
# creation and never persisted, so a leaked tokens.json exposes no usable token.
# See docs/DESIGN_AUTH_TOKENS.md. NOTE (#19 build, design under bench review):
# this is the store layer only; the server middleware / sender-binding / claim
# endpoint / UI are wired after the design review.

TOKENS_FILE = STORE_DIR / "tokens.json"
TOKENS_LOCK = STORE_DIR / ".tokens.lock"
VALID_ROLES = {"operator", "guest"}

# --- Phase A A.4: per-seat identity tokens on the agent send path -------------------------
# (ORCH_SPEC_01 D-IDT-1/-2/-3; ORCH_PHASE0A_PLAN_03 §4 A.4, §12.1.) The SAME machinery with one
# more scope. An invite of scope "seat" is bound to an EXISTING registry row (an agent seat,
# a human, or the daemon's system row) and is claimed by the seat itself, in its own
# workspace; the claim mints an ordinary session token whose participant_id IS the seat's
# identity on every hub-acting CLI command. Identity is DERIVED from the token, never
# asserted: --as / $ORCH_AGENT are inert for hub-acting commands. Rotation = re-invite +
# re-claim (a claim supersedes every earlier live session of that seat, as it always did);
# revocation on retirement = revoke_participant. The invite and the token travel by 0600
# files under the seat's private space ~/agents/<seat>/.orch/ (BRIEF C4) — never by argv,
# hub mail, or transcript (GA.10). Mistake-proofing grade only, by the operator's threat-model
# ruling (D-IDT-2): a same-UID process can read another seat's file; that is not the
# defect class this closes.
SEAT_SCOPE = "seat"
# Token-role vocabulary for seat invites = the registry's harness roles plus "daemon", the
# delivery daemon's system token (A.4 "registry role daemon"; consumed by A.3's nudge-requester
# allow-list). PARTICIPANT_ROLES itself is untouched — A.2b/A.8 own the registry vocabulary
# and its write-partition. The role on a seat token is checked against the registry row at
# issue time (a mismatch refuses), so the two can never disagree by accident.
DAEMON_TOKEN_ROLE = "daemon"
SEAT_TOKEN_ROLES = frozenset(PARTICIPANT_ROLES | {DAEMON_TOKEN_ROLE})
# Who may ISSUE and REVOKE seat tokens: the CoS and the principal (plan A.4 "create_invite
# (by CoS)"; §12.1 "issued by the CoS from the registry"). Checked on the issuer's own
# token role — a coder seat cannot invite or retire another seat by accident (CodeRabbit
# PR #222 Major). The first token of a store is the --bootstrap exception.
PROVISIONING_ROLES = frozenset({"chief_of_staff", "human_authority"})
DAEMON_SEAT = os.environ.get("PSQR_DAEMON_SEAT", "daemon")   # the daemon's registry id
TOKEN_ENV = "ORCH_TOKEN"              # the token value itself (a process that already holds it)
TOKEN_FILE_ENV = "ORCH_TOKEN_FILE"    # path of a 0600 token file
SEAT_PRIVATE_DIRNAME = ".orch"        # <seat home>/.orch/{invite,token}
# The asserted-identity bootstrap is ONE monotonic transition per store (reviewer
# DJK-A4-1): it is consumed by a marker record written in the same token-lock transaction
# as the first seat invite, and it never reopens — not on revocation, not on expiry, not
# when every live session is gone. A store that carries any seat credential at all
# (records from before the marker existed) is closed too.
BOOTSTRAP_MARKER_ID = "bootstrap"
SEAT_TOKEN_FILENAME = "token"
SEAT_INVITE_FILENAME = "invite"
INVITE_TTL_SEC = int(os.environ.get("PSQR_INVITE_TTL_SEC", str(24 * 3600)))  # 24h default
SESSION_TTL_SEC_DEFAULT = 30 * 24 * 3600  # 30d. Session lifetime, anchored at CLAIM (login),
                                    # not mint. RAISED FROM 6h BY the operator, 2026-07-30, explicitly
                                    # WITHOUT adversarial review, so a remote reviewer stays
                                    # logged in across days instead of re-requesting a token.
SESSION_TTL_SEC_MIN = 60            # governed floor: below it falls back to the default
SESSION_TTL_SEC_MAX = 30 * 24 * 3600  # 30d ceiling. RAISED FROM 24h BY the operator, 2026-07-30.
                                    # THE SUPERSEDED RATIONALE, kept rather than deleted because
                                    # it is still true and the trade was made knowingly (the operator,
                                    # 07-10): "a permanent stolen session is standing exposure;
                                    # N-hours-from-login bounds the blast radius." Bounded
                                    # exposure WAS the objective; 30d is a much weaker bound.
                                    # NOTE the mismatch this trades against: the 2026-07-29
                                    # trust reframe rests on LOCAL, no remote ports — and the
                                    # only consumer of this TTL is a REMOTE reviewer over a
                                    # public tunnel, which is the one path that premise does not
                                    # cover. Revocation (`orch` logout / kill-switch) is now the
                                    # primary control here, not expiry.


def _session_ttl_sec() -> int:
    """Session TTL from PSQR_SESSION_TTL_SEC, read at claim time (live-tunable,
    no restart). Malformed AND out-of-policy values fall back to the 6h default
    (reviewer #50 HIGH): zero/negative would mint immediately-dead sessions,
    huge positives defeat the bounded-exposure objective, and overflow-scale
    integers would 500 every claim at timestamp construction. The governed
    range is [SESSION_TTL_SEC_MIN, SESSION_TTL_SEC_MAX]; anything outside it —
    like anything unparseable — is the safe 6h. Rationale (the operator, 07-10): a
    permanent stolen session is standing exposure; N-hours-from-login bounds
    the blast radius."""
    try:
        ttl = int(os.environ["PSQR_SESSION_TTL_SEC"])
    except (KeyError, ValueError):
        return SESSION_TTL_SEC_DEFAULT
    if not (SESSION_TTL_SEC_MIN <= ttl <= SESSION_TTL_SEC_MAX):
        return SESSION_TTL_SEC_DEFAULT
    return ttl

# Z-merge approval tokens (META_HARNESS_PLAN Stage 1). A single-use bearer token that
# authorizes EXACTLY ONE merge, bound to a (repo, base_sha, head_sha) fingerprint. Short
# Legacy consumption remains fail-closed for existing records; minting is retired (Rule A).
APPROVAL_TTL_SEC = int(os.environ.get("PSQR_APPROVAL_TTL_SEC", str(3600)))  # 1h default


def _tokens_locked(fn):
    """Reentrant token transaction, ordered launch-fence → tokens → registry.

    The launch fence also precedes legacy callers' participant writes. Taking it
    here avoids an inversion when a launch checks credentials while fenced.
    """
    ensure_store()
    with runtime_launch_fence(), _token_mutex:
        if getattr(_token_local, "depth", 0):
            return fn()
        with TOKENS_LOCK.open("a") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            _token_local.depth = 1
            try:
                return fn()
            finally:
                _token_local.depth = 0
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def _token_records(tokens: Dict[str, Any]):
    """The token table's records. Once the credentials migration has run, the table also holds the
    generation entries, and any value that is not a record is skipped: a damaged one is no credential
    at all, never a reason to fail every other identity's check (DJK-CREDA-4). Before the migration
    the table is read exactly as before (DJK-CREDA-6)."""
    if not _credentials_on(tokens):
        return tokens.values()
    return (rec for rec in tokens.values() if isinstance(rec, dict))


def _token_items(tokens: Dict[str, Any]):
    """(id, record) pairs of the token table, on `_token_records`' terms."""
    if not _credentials_on(tokens):
        return tokens.items()
    return ((tid, rec) for tid, rec in tokens.items() if isinstance(rec, dict))


def _hash_token(token: str, salt: str) -> str:
    return hashlib.sha256(f"{salt}:{token}".encode()).hexdigest()


def _token_matches(presented: str, rec: Dict[str, Any]) -> bool:
    """Constant-time compare (reviewer PR#20): timing-safe even though these are
    high-entropy bearer tokens. Defensive (Bugbot PR#20 re-run MED): a record whose
    salt or token_sha256 is missing/null/non-string is treated as NO MATCH, never
    allowed to raise TypeError out of hmac.compare_digest — one malformed record
    must not abort resolve_token/claim_invite and wedge ALL token validation."""
    stored = rec.get("token_sha256")
    salt = rec.get("salt")
    if not isinstance(stored, str) or not isinstance(salt, str):
        return False
    return hmac.compare_digest(_hash_token(presented, salt), stored)


# --- CREDENTIALS_01 D-CRED-1 and D-CRED-1b: seat lifetimes and the credential generation -------
# Inert until the token table carries the marker the credentials migration (D-CRED-6) writes:
# without it every reader, issuer and governed act below behaves as before, byte for byte. A
# marker this reader cannot read refuses every presentation and claim; it is never read as absent.
CREDENTIALS_MARKER_ID = "credentials_01"
LIFETIME_UNTIL_REVOKED = "until_revoked"
GENERATION_KIND = "generation"
_SHA256_HEX = re.compile(r"[0-9a-f]{64}")


class CredentialsMarkerInvalid(RuntimeError):
    """The token table carries a credentials_01 marker of a shape this reader does not know."""


def credential_class(row: Dict[str, Any] | None) -> str | None:
    """D-CRED-1's two classes, from the identity's registry row at the moment of the check.

    Principal-class: role `human_authority` (read first) or kind `human`. Seat-class: kind
    `agent` or `system` with any other role. Anything else, a missing row included, is neither."""
    if not isinstance(row, dict):
        return None
    if row.get("role") == "human_authority" or row.get("kind") == "human":
        return "principal"
    if row.get("kind") in ("agent", "system"):
        return "seat"
    return None


def _credentials_on(tokens: Dict[str, Any]) -> bool:
    """Whether the credentials migration has run on this token table (D-CRED-6's marker)."""
    if CREDENTIALS_MARKER_ID not in tokens:
        return False
    marker = tokens[CREDENTIALS_MARKER_ID]
    if (isinstance(marker, dict) and marker.get("id") == CREDENTIALS_MARKER_ID
            and marker.get("kind") == "migration" and marker.get("state") == "done"
            and isinstance(marker.get("plan_sha256"), str)
            and _SHA256_HEX.fullmatch(marker["plan_sha256"])):
        return True
    raise CredentialsMarkerInvalid(
        f"the token table's {CREDENTIALS_MARKER_ID!r} marker is malformed; refusing every "
        "credential rather than reading it as absent (repair the table out of band)")


def _untimed_seat_session(rec: Dict[str, Any], registry: Dict[str, Dict[str, Any]] | None) -> bool:
    """D-CRED-1's one record that lives until an event: a seat-scoped session of a seat-class
    identity carrying the lifetime marker and no expires_at at all. Anything else that carries
    the marker is expired: absence never means forever, and contradiction never means forever."""
    if (rec.get("lifetime") != LIFETIME_UNTIL_REVOKED or "expires_at" in rec
            or rec.get("kind") != "session" or rec.get("scope") != SEAT_SCOPE):
        return False
    rows = registry if registry is not None else _read_participants_unlocked()
    return credential_class(rows.get(rec.get("participant_id"))) == "seat"


def _generation_entry(tokens: Dict[str, Any], pid: str | None) -> int | None:
    """The identity's credential generation (D-CRED-1b), or None if its entry is missing or malformed."""
    key = f"gen:{pid}"
    entry = tokens.get(key)
    if (isinstance(entry, dict) and entry.get("id") == key and entry.get("kind") == GENERATION_KIND
            and entry.get("participant_id") == pid and type(entry.get("generation")) is int
            and entry["generation"] >= 1):
        return entry["generation"]
    return None


def _generation_current(rec: Dict[str, Any], tokens: Dict[str, Any], pid: str | None) -> bool:
    """Whether a record carries its identity's current generation. Older, missing, malformed or
    newer is not current, and neither is any record of an identity whose entry is unreadable."""
    current = _generation_entry(tokens, pid)
    stamped = rec.get("generation")
    return current is not None and type(stamped) is int and stamped == current


def _issue_generation(tokens: Dict[str, Any], pid: str) -> int:
    """The generation to stamp on a record issued now. Every identity has its entry from the
    migration or from its registration (`_establish_generations`); issuing never creates one, so a
    missing or malformed entry is damage and refuses, never defaulted (DJK-CREDA-2)."""
    current = _generation_entry(tokens, pid)
    if current is None:
        raise RegistryMutationRefused("credential_generation_missing",
                                      f"{pid!r} has no readable credential generation; repair required")
    return current


def _establish_generations(before: Dict[str, Dict[str, Any]], after: Dict[str, Dict[str, Any]]) -> None:
    """D-CRED-1b at the identity-creation boundary: once the credentials migration has run, every row
    a registry write creates gets its generation entry, at 1, in the token table, written before the
    row. Creation is admitted only to an authenticated actor, whose check runs under the token lock.
    An entry already present is kept, never reset; one present but malformed refuses the creation."""
    created = sorted(pid for pid in after if pid not in before)
    if not created:
        return
    tokens = _read_tokens_unlocked()
    if not _credentials_on(tokens):
        return
    added = False
    for pid in created:
        key = f"gen:{pid}"
        if key in tokens:
            if _generation_entry(tokens, pid) is None:
                raise RegistryMutationRefused("credential_generation_missing",
                                              f"{pid!r} has a damaged credential generation; repair required")
            continue
        tokens[key] = {"id": key, "kind": GENERATION_KIND, "participant_id": pid, "generation": 1}
        added = True
    if added:
        _write_tokens_unlocked(tokens)


def _born_migrated_unlocked(tokens: Dict[str, Any], plan_sha256: str) -> None:
    """Stage 1's fresh store, born in the credential state D-CRED-6's migration ends in (B2,
    ruled by the engineering lead): the marker and generation 1 for every row the registry
    has, added to the same table write as the store's first token, the bootstrap invite.
    Only an empty token table: a store with any record has a history, and D-CRED-6's own
    migration is the act for it. CALLER HOLDS TOKENS_LOCK."""
    if not isinstance(plan_sha256, str) or not _SHA256_HEX.fullmatch(plan_sha256):
        raise ValueError("a fresh store's plan hash must be 64 lowercase hex characters")
    if tokens:
        raise RegistryMutationRefused(
            "store_has_history", "this store's token table is not empty, so it is not born "
            "migrated; the credentials migration (D-CRED-6) is the act for a store with a history")
    tokens[CREDENTIALS_MARKER_ID] = {
        "id": CREDENTIALS_MARKER_ID, "kind": "migration", "state": "done",
        "plan_sha256": plan_sha256, "fresh_store": True, "at": now_iso()}
    for pid in sorted(_read_participants_unlocked()):
        key = f"gen:{pid}"
        tokens[key] = {"id": key, "kind": GENERATION_KIND, "participant_id": pid, "generation": 1}


def _parking_intent(*, strict: bool) -> Dict[str, Any] | None:
    """The pending park/unpark intent, or None when there is none. The one reader that the act, its
    retry, and (once the credentials migration has run) every issue and claim share: an intent this
    reader cannot read refuses as `parking_pending_invalid`, never reads as "nothing pending"
    (DJK-CREDA-3). `strict` is whether the migration has run: only then does it also require a text
    seat, a park or unpark command and a well-formed revoke list; before it, it reads as it always
    has (DJK-CREDA-6)."""
    if not REGISTRY_PARK_PENDING.exists():
        return None
    try:
        pending = json.loads(REGISTRY_PARK_PENDING.read_text())
        if (not isinstance(pending, dict) or pending.get("format") != "registry-parking/v1"
                or not all(k in pending for k in ("seat", "command", "channel", "before", "after", "event"))
                or not isinstance(pending["event"], dict)):
            raise ValueError("unsupported pending record")
        # A migrated park intent names the credentials it revokes; one without that list would park
        # and revoke nothing (CodeRabbit 4201235094). An unpark intent revokes nothing and may omit it.
        if strict and (not isinstance(pending["seat"], str) or pending["command"] not in ("park", "unpark")
                       or (("revoke" in pending or pending["command"] == "park")
                           and not (isinstance(pending.get("revoke"), list)
                                    and all(isinstance(t, str) for t in pending["revoke"])))):
            raise ValueError("unsupported pending record")
    except (ValueError, OSError) as exc:
        raise RegistryMutationRefused("parking_pending_invalid",
                                      "parking intent unreadable; operator repair required") from exc
    return pending


def _park_pending_for(seat: str) -> bool:
    """Whether a park act of this seat is pending; while it is, no credential of the seat is issued
    or claimed, so the act revokes exactly the set its intent names."""
    pending = _parking_intent(strict=True)       # called only once the migration has run
    return pending is not None and pending["seat"] == seat and pending["command"] == "park"


def _token_expired(rec: Dict[str, Any], now_ts: float, *, tokens: Dict[str, Any] | None = None,
                   registry: Dict[str, Dict[str, Any]] | None = None) -> bool:
    """Generic expires_at check for ANY token record (invites, sessions,
    approvals). Fail CLOSED (Bugbot PR#20 MED): a missing or unparseable
    expires_at is treated as EXPIRED, never as a perpetual credential. A token
    the TTL check can't positively confirm is still valid must not be honored.
    (For sessions this deliberately kills pre-expiry-era records that were
    never stamped — a permanent session is exactly the exposure being closed.)

    CREDENTIALS_01 D-CRED-1: once the migration's marker exists, a record carrying the lifetime
    marker is judged by the lifetime table instead (`_untimed_seat_session`); before it, and for
    every record without the marker, this check is unchanged."""
    if "lifetime" in rec and _credentials_on(tokens if tokens is not None else _read_tokens_unlocked()):
        return not _untimed_seat_session(rec, registry)
    exp = rec.get("expires_at")
    if not exp:
        return True
    try:
        return now_ts > datetime.fromisoformat(exp).astimezone(timezone.utc).timestamp()
    except (ValueError, TypeError):
        return True


def _read_tokens_unlocked() -> Dict[str, Dict[str, Any]]:
    try:
        with TOKENS_FILE.open("r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}  # legitimately empty — no tokens minted yet
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        # Bugbot PR#20 HIGH: NEVER treat a CORRUPT secrets file as empty. A
        # reader that returned {} would let the very next _write_tokens_unlocked
        # persist {} and WIPE every invite + session. Fail loud instead; an
        # operator restores/repairs the file rather than losing all auth state.
        raise RuntimeError(
            f"tokens file {TOKENS_FILE} is corrupt ({e}); refusing to read it as "
            "empty (that would wipe all tokens on the next write)") from e


def _write_tokens_unlocked(tokens: Dict[str, Dict[str, Any]]) -> None:
    ensure_store()
    tmp = TOKENS_FILE.with_suffix(".json.tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(tokens, f, indent=2, ensure_ascii=False)
        f.flush()
        os.fsync(f.fileno())
    os.chmod(tmp, 0o600)  # tokens are secrets — owner-only
    os.replace(tmp, TOKENS_FILE)


def _seat_invite_role(participant_id: str, role: str | None) -> str:
    """Resolve and CHECK the role of a seat invite against the registry row it binds to
    (A.4 mistake-proofing; §12.1: the role is governance-owned, written at provisioning).
    The row must exist — a seat invite never creates identity. `daemon` is accepted only
    for a `system` row; any other role must equal the row's registry role when the row
    carries one (legacy rows without a role take the role given)."""
    if not PARTICIPANT_ID_RE.match(participant_id or ""):
        raise ValueError(f"invalid participant id {participant_id!r}")
    row = load_participants().get(participant_id)
    if row is None:
        raise ValueError(f"seat {participant_id!r} is not registered — a seat invite binds "
                         f"to an existing registry row and never creates one")
    if row.get("retired_at"):
        raise RegistryMutationRefused("seat_retired", f"{participant_id!r} is retired; no new credentials")
    if row.get("parked_at"):
        raise RegistryMutationRefused("seat_parked", f"{participant_id!r} is parked; ask the Chief of Staff")
    registry_role = row.get("role")
    if participant_id == DAEMON_SEAT:
        # THE daemon's row (and only it — reviewer DJK-A4-4): its token role IS `daemon`
        # (A.4), whatever harness role the registry derived for a system row; the row must
        # be kind `system`, the same fact delivery.daemon_identity checks.
        if row.get("kind") != "system":
            raise ValueError(f"the daemon row {DAEMON_SEAT!r} must be kind 'system', "
                             f"not {row.get('kind')!r}")
        if role not in (None, DAEMON_TOKEN_ROLE):
            raise ValueError(f"the daemon's token role is {DAEMON_TOKEN_ROLE!r}, not {role!r}")
        return DAEMON_TOKEN_ROLE
    if role is None:
        if not registry_role:
            raise ValueError(f"seat {participant_id!r} has no registry role; pass --role")
        role = registry_role
    if role not in SEAT_TOKEN_ROLES:
        raise ValueError(f"invalid seat token role {role!r} (one of {sorted(SEAT_TOKEN_ROLES)})")
    if role == DAEMON_TOKEN_ROLE:
        raise ValueError(f"role {DAEMON_TOKEN_ROLE!r} is only for the daemon row "
                         f"{DAEMON_SEAT!r}; {participant_id!r} is kind {row.get('kind')!r}")
    if registry_role and role != registry_role:
        raise ValueError(f"role {role!r} does not match the registry role {registry_role!r} "
                         f"of {participant_id!r} — the registry row is the governed value")
    if registry_role is None and row.get("kind") == "human" and role != "human_authority":
        raise ValueError("a roleless human self-invite requires role human_authority")
    return role


class BootstrapClosed(ValueError):
    """The asserted-identity bootstrap of this store is closed (reason in `.reason`:
    `consumed` — the marker exists; `seat_credentials_exist` — the store already carries
    seat credentials, live or not)."""

    def __init__(self, reason: str, marker: Dict[str, Any] | None = None):
        detail = (f"consumed at {marker.get('consumed_at')} by {marker.get('by')} for seat "
                  f"{marker.get('seat')}" if marker else "this store already carries seat credentials")
        super().__init__(f"bootstrap is closed — {detail}; it never reopens (present your own "
                         f"token; a store with no usable credential at all is repaired out of "
                         f"band, never by a second asserted bootstrap)")
        self.reason, self.marker = reason, marker


def _bootstrap_closed_unlocked(tokens: Dict[str, Dict[str, Any]]) -> tuple[str | None, Dict[str, Any] | None]:
    """(reason, marker) when the bootstrap is closed, (None, None) when it is still open.
    CALLER HOLDS TOKENS_LOCK. Monotonic: the marker is never removed, and ANY seat-scoped
    record — open, used, revoked, expired, live or dead — closes it as well."""
    marker = tokens.get(BOOTSTRAP_MARKER_ID)
    if isinstance(marker, dict) and marker.get("kind") == "bootstrap":
        return "consumed", marker
    if any(isinstance(rec, dict) and rec.get("scope") == SEAT_SCOPE for rec in tokens.values()):
        return "seat_credentials_exist", None
    return None, None


def bootstrap_state() -> Dict[str, Any]:
    """Read-only view for the CLI's early refusal: {"open": bool, "reason": ..., "marker":
    sanitized marker or None}. The DECISION is made again inside the issuing transaction
    (create_invite(bootstrap=True)) — this view never authorizes anything."""
    def _read():
        reason, marker = _bootstrap_closed_unlocked(_read_tokens_unlocked())
        return {"open": reason is None, "reason": reason, "marker": dict(marker) if marker else None}
    return _tokens_locked(_read)


def _check_seat_invite_issuer(actor, participant_id, participants, *, act=None):
    self_repair = _require_current_provisioner(actor, participants, target=participant_id, act=act)
    issuer_role = (participants.get(actor["participant_id"]) or {}).get("role")
    target = participants.get(participant_id) or {}
    # A roleless human is still protected by the principal issuer ceiling. This
    # is a restriction on inviting that identity, never a derived registry grant.
    principal_target = (target.get("role") == "human_authority" or
                        (target.get("role") is None and target.get("kind") == "human"))
    if principal_target and issuer_role != "human_authority" and not self_repair:
        raise RegistryMutationRefused("principal_invite_requires_principal",
                                      "a human_authority identity requires a human_authority issuer")
    return bool(self_repair)


def create_invite(participant_id: str, role: str | None = "guest",
                   ttl_sec: int = INVITE_TTL_SEC, *, scope: str | None = None,
                   invite_value: str | None = None, before_commit: Any = None,
                   after_commit: Any = None, progress: Dict[str, Any] | None = None,
                   bootstrap: bool = False, bootstrap_issuer: str | None = None,
                   presented_token=None,
                   born_migrated_plan_sha256: str | None = None) -> tuple[str, str]:
    """Operator action: mint a single-use, IDENTITY-BOUND invite (reviewer PR#20:
    the invite is *for a specific person*, not a free label — the claimant cannot
    pick an arbitrary id). Expires after ttl_sec. Returns (token_id, plaintext) —
    the plaintext is shown ONCE; only its salted hash is stored.

    scope="seat" (Phase A A.4): the invite binds to an EXISTING registry row of any kind
    (the owner included — the claim never creates or reuses a human row, so the reserved-id
    guard of the human path does not apply); the role is checked against that row; any
    earlier UNUSED seat invite for the same row is revoked in the same write, so a
    re-issue leaves no dangling live credential.

    Seat-scope serialization protocol (reviewer DJK-A4-1/-2): EVERYTHING that decides the
    invite happens inside one TOKENS_LOCK transaction — the bootstrap decision (and its
    marker, written in the same table write), the role revalidation against the registry
    row, the supersession of earlier open invites, `before_commit()` (the caller stages
    the plaintext; if it raises nothing is committed), the commit, and `after_commit()`
    (the caller places the visible file, so it follows commit order). `progress` is
    written from inside: `committing` before the write, `committed` + the sanitized
    `record` after."""
    if scope != SEAT_SCOPE:
        raise ValueError("seat invites only")
    if born_migrated_plan_sha256 is not None and not bootstrap:
        raise ValueError("only the bootstrap invite can be a fresh store's first token")
    if not PARTICIPANT_ID_RE.match(participant_id or ""):
        raise ValueError(f"invalid participant id {participant_id!r}")
    token = invite_value or secrets.token_urlsafe(24)
    salt = secrets.token_hex(8)
    tid = new_id("tok")
    expires_at = datetime.now(timezone.utc).astimezone()
    expires_at = (expires_at.fromtimestamp(expires_at.timestamp() + ttl_sec,
                  tz=expires_at.tzinfo)).isoformat(timespec="seconds")

    def _add():
        tokens = _read_tokens_unlocked()
        if bootstrap:
            why, marker = _bootstrap_closed_unlocked(tokens)
            if why is not None:
                raise BootstrapClosed(why, marker)
            if born_migrated_plan_sha256 is not None:
                _born_migrated_unlocked(tokens, born_migrated_plan_sha256)
        self_repair = False
        if not bootstrap:
            actor = getattr(_registry_actor_local, "actor", None)
            self_repair = _check_seat_invite_issuer(
                actor, participant_id, _read_participants_unlocked(), act="seat_invite")
        role_value = _seat_invite_role(participant_id, role)
        for rec in _token_records(tokens):
            if (rec.get("kind") == "invite" and rec.get("scope") == SEAT_SCOPE
                    and rec.get("allowed_participant_id") == participant_id
                    and not rec.get("used") and not rec.get("revoked")):
                rec["revoked"] = True
                rec["revoked_at"] = now_iso()
                rec["superseded_by"] = tid
        record = {
            "id": tid, "label": participant_id, "role": role_value, "kind": "invite",
            "salt": salt, "token_sha256": _hash_token(token, salt),
            "allowed_participant_id": participant_id, "participant_id": None,
            "used": False, "revoked": False,
            "created": now_iso(), "expires_at": expires_at,
        }
        actor = getattr(_registry_actor_local, "actor", None)
        if actor is not None:
            record["provisioner_session_id"] = actor["id"]
        record["scope"] = SEAT_SCOPE
        if _credentials_on(tokens):
            if _park_pending_for(participant_id):
                raise RegistryMutationRefused("parking_pending",
                                              f"{participant_id!r} is being parked; ask the Chief of Staff")
            record["generation"] = _issue_generation(tokens, participant_id)   # D-CRED-1b
        if bootstrap:
            record["bootstrap"] = True
            tokens[BOOTSTRAP_MARKER_ID] = {
                "id": BOOTSTRAP_MARKER_ID, "kind": "bootstrap", "consumed_at": now_iso(),
                "by": bootstrap_issuer, "seat": participant_id, "invite_id": tid,
            }
        if before_commit is not None:
            if progress is not None:
                progress["token_id"] = tid
            before_commit()           # stage the plaintext; a failure here commits nothing
        if progress is not None:
            progress["committing"] = True
        tokens[tid] = record
        _write_tokens_unlocked(tokens)
        if progress is not None:
            progress["committed"] = True
            progress["record"] = _sanitize_token_rec(dict(record))
        if self_repair:
            import ledger
            try:
                ledger.emit("harness_mutation", actor_id=actor["participant_id"], role=actor["role"],
                            payload={"mutation": "principal_self_repair", "seat": participant_id,
                                     "act": "seat_invite", "token_id": actor["id"],
                                     "invite_id": tid, "normalised_rows": []},
                            ledger_file=STORE_DIR / "ledger.jsonl")
            except Exception as exc:
                raise SeatActWithoutReceipt("invite", tid, str(exc)) from exc
        if after_commit is not None:
            after_commit()
        return tid

    if bootstrap:
        _tokens_locked(_add)
    else:
        authenticated_registry_act(presented_token, lambda actor: _add(), provisioning=True,
                                   expected_actor=bootstrap_issuer, provisioning_target=participant_id)
    return tid, token


LEGACY_SURFACE_MIGRATION_ID = "legacy_surface_migration"


def _legacy_placement_evidence(receipt, participant_id, registry):
    """DJK-PRB-1: a base repair left no new receipt; recover its final path
    from the original claim's recorded staging/probe paths, then verify bytes.
    A receipt always wins over the default home, even if its evidence is absent.
    """
    if receipt is None:
        path = str(seat_token_path(participant_id)) if participant_id in registry else None
        return path, "default_seat_home"
    if receipt.get("token_path"):
        return receipt["token_path"], "claim_receipt"
    probe = receipt.get("placement_probe") or {}
    final_path = (probe.get("final") or {}).get("path")
    if isinstance(final_path, str) and Path(final_path).is_absolute():
        return final_path, "claim_receipt:repair_destination"
    staged = receipt.get("staged_path")
    if (isinstance(staged, str) and Path(staged).is_absolute()
            and Path(staged).name.startswith(SEAT_TOKEN_FILENAME + ".next-")):
        return str(Path(staged).with_name(SEAT_TOKEN_FILENAME)), "claim_receipt:repair_destination"
    return None, "claim_receipt:no_destination"


def _migration_invoker(presented, tokens, registry):
    """PRN-PRB-4: attribution only; the migration stays a local filesystem act.
    A live legacy seat token can identify its holder before surface migration.
    No caller-supplied identity is accepted and no token value is returned.
    """
    if presented:
        now_ts = datetime.now(timezone.utc).timestamp()
        generations = _credentials_on(tokens)
        for rec in _token_records(tokens):
            if (rec.get("kind") == "session" and rec.get("scope") == SEAT_SCOPE
                    and rec.get("status") == "active" and not rec.get("revoked")
                    and not _token_expired(rec, now_ts, tokens=tokens, registry=registry)
                    and (not generations or _generation_current(rec, tokens, rec.get("participant_id")))
                    and rec.get("participant_id") in registry
                    and _token_matches(presented, rec)):
                return {"actor_id": rec["participant_id"], "actor_source": "seat_token",
                        "actor_token_id": rec["id"]}
        raise ValueError("presented migration credential cannot identify a live seat")
    import pwd
    import socket
    user = pwd.getpwuid(os.getuid()).pw_name
    host = socket.gethostname()
    return {"actor_id": f"os:{user}@{host}", "actor_source": "os_user_host"}


def migrate_legacy_surfaces(*, apply: bool = False, plan_sha256: str | None = None,
                            presented_token: str | None = None) -> Dict[str, Any]:
    """D-CON-5: explicit local migration, never invoked by serving or importing.

    First inspect the dry-run result; apply must name that plan's digest. The plan
    is remeasured under the token lock, including placed-file evidence. No effect
    precedes the principal guard. An atomic marker retains the receipt payload so
    an interrupted append can be retried without repeating any token transition.
    """
    import ledger

    def transact():
        tokens = _read_tokens_unlocked()
        events, offset = [], 0
        while True:
            batch, next_offset = read_jsonl(STORE_DIR / "ledger.jsonl", offset)
            events.extend(batch)
            if next_offset == offset:
                break
            offset = next_offset
        marker = tokens.get(LEGACY_SURFACE_MIGRATION_ID)
        if marker:
            if apply and not any(row.get("id") == marker["event_id"] for row in events):
                ledger.emit("harness_mutation", actor_id=marker["payload"]["actor_id"],
                            event_id=marker["event_id"], payload=marker["payload"],
                            ledger_file=STORE_DIR / "ledger.jsonl")
            return {"state": "complete", "plan_sha256": marker["plan_sha256"],
                    "records": marker["payload"]["records"],
                    "actor_id": marker["payload"]["actor_id"]}
        registry = load_participants()
        invoker = _migration_invoker(presented_token, tokens, registry)
        now_ts = datetime.now(timezone.utc).timestamp()
        changes = []
        survivors = set()
        claims = {}
        for event in events:
            payload = event.get("payload") or {}
            if payload.get("mutation") in {"seat_token_claimed", "seat_token_placed"}:
                claims[payload.get("token_id")] = payload
        for tid, rec in _token_items(tokens):
            if (rec.get("kind") != "session" or rec.get("status") != "active"
                    or rec.get("revoked") or _token_expired(rec, now_ts, tokens=tokens, registry=registry)):
                continue
            pid = rec.get("participant_id")
            if rec.get("surface") in {"terminal", "browser"}:
                if rec.get("surface") == "terminal" and pid in registry:
                    survivors.add(pid)
                continue
            item = {"token_id": tid, "participant_id": pid}
            if rec.get("scope") != SEAT_SCOPE:
                item.update(action="revoke", reason="legacy_surface_migration:legacy_invite",
                            evidence="non-seat-scoped legacy session")
            else:
                receipt = claims.get(tid)
                path, evidence = _legacy_placement_evidence(receipt, pid, registry)
                matched = False
                if path:
                    try:
                        plain = read_secret_file(Path(path))
                        matched = _token_matches(plain, rec)
                        plain = None
                    except (OSError, UnicodeError):
                        evidence += ":unreadable_or_absent"
                item.update(token_path=path, evidence=evidence, matched=matched)
                if matched and pid in registry:
                    item.update(action="stamp", surface="terminal")
                    survivors.add(pid)
                else:
                    item.update(action="revoke", reason="legacy_surface_migration:unplaced")
            changes.append(item)
        missing = sorted(pid for pid, row in registry.items()
                         if row.get("role") == "human_authority" and pid not in survivors)
        plan = {**invoker, "records": sorted(changes, key=lambda item: item["token_id"]),
                "principals_without_credentials": missing}
        # Full table and registry fingerprints prevent applying a stale plan.
        payload = json.dumps({"plan": plan, "tokens": tokens, "registry": registry}, sort_keys=True)
        digest = hashlib.sha256(payload.encode()).hexdigest()
        result = {**plan, "plan_sha256": digest, "state": "halted" if missing else "dry_run"}
        if not apply:
            return result
        if missing:
            raise ValueError("migration would leave human_authority without a live credential on the terminal surface: " + ", ".join(missing))
        if not plan_sha256 or not hmac.compare_digest(plan_sha256, digest):
            raise ValueError("migration requires the current dry-run plan_sha256")
        for item in changes:
            rec = tokens[item["token_id"]]
            if item["action"] == "stamp":
                rec["surface"] = "terminal"
            else:
                rec.update(revoked=True, revoked_at=now_iso(), revocation_reason=item["reason"])
        receipt_payload = {**invoker, "mutation": LEGACY_SURFACE_MIGRATION_ID,
                           "plan_sha256": digest, "records": plan["records"]}
        event_id = ledger.new_event_id()
        tokens[LEGACY_SURFACE_MIGRATION_ID] = {
            "kind": "migration", "id": LEGACY_SURFACE_MIGRATION_ID,
            "plan_sha256": digest, "event_id": event_id, "payload": receipt_payload}
        _write_tokens_unlocked(tokens)
        ledger.emit("harness_mutation", actor_id=invoker["actor_id"], payload=receipt_payload,
                    event_id=event_id, ledger_file=STORE_DIR / "ledger.jsonl")
        return {**result, "state": "complete"}

    return _tokens_locked(transact)


def _sanitize_token_rec(rec: Dict[str, Any]) -> Dict[str, Any]:
    """Strip secret material (the hash + its salt) from a token record before it
    leaves the store (Bugbot PR#20 LOW)."""
    return {k: v for k, v in rec.items() if k not in ("token_sha256", "salt")}


def resolve_token(presented: str) -> Dict[str, Any] | None:
    """Return the live record for a presented SESSION token, or None. Live iff it
    is a session, status 'active' (NOT a half-finished 'pending' claim — reviewer
    PR#20 HIGH), not revoked, AND its participant still exists. The returned record
    is SANITIZED (no hash/salt — Bugbot PR#20 LOW).

    The lookup runs under TOKENS_LOCK (Bugbot PR#20 re-run MED): every token mutation
    holds _tokens_locked, so the read takes it too — uniform locking, no lone unlocked
    reader, and the active/revoked decision serializes with concurrent
    revoke/claim writes instead of racing a stale snapshot. Raw registry membership
    is read under the same launch fence; authentication does not normalise roles.
    Residual: the inherent TOCTOU between resolve and the
    caller's use is unchanged — revocation is visible to the NEXT resolve, immediately."""
    return token_verdict(presented)[0]


def token_verdict(presented: str) -> tuple[Dict[str, Any] | None, str]:
    """resolve_token with the REASON a presentation fails (Phase A A.4 — `orch token status`
    and the CLI's refusal name it). Same lock, same decision: (sanitized live record, "ok")
    or (None, one of no_token · unknown_token · revoked · pending · expired ·
    unregistered_seat · retired_seat). Every failure branch is still None; nothing about a revoked or
    pending session is honored — only named."""
    if not presented:
        return None, "no_token"
    return _tokens_locked(lambda: _verdict_unlocked(presented, _read_tokens_unlocked()))


def _verdict_unlocked(presented: str, tokens: Dict[str, Dict[str, Any]]) -> tuple[Dict[str, Any] | None, str]:
    """token_verdict's decision over an already-read token table. CALLER HOLDS TOKENS_LOCK
    Membership is read without role normalisation: authentication is not a registry write."""
    now_ts = datetime.now(timezone.utc).timestamp()
    generations = _credentials_on(tokens)
    for rec in _token_records(tokens):
        if rec.get("kind") != "session" or not _token_matches(presented, rec):
            continue
        if rec.get("revoked"):
            return None, "revoked"
        # D-CRED-1b: once the migration has run, a session not of its identity's current
        # generation is refused as revoked (older, missing or malformed alike).
        if generations and not _generation_current(rec, tokens, rec.get("participant_id")):
            return None, "revoked"
        if rec.get("status") != "active":
            return None, "pending"
        # SESSION EXPIRY, enforced on every authenticated request
        # (the operator, 07-10): the matched session must be inside its
        # claim-anchored TTL. Fail-closed via _token_expired — a
        # session with no/garbled expires_at (incl. pre-expiry-era
        # records) is dead, not eternal. A seat session without a time
        # limit (CREDENTIALS_01 D-CRED-1) is judged there too.
        if _token_expired(rec, now_ts, tokens=tokens):
            return None, "expired"
        if rec.get("surface") not in {"terminal", "browser"}:
            return None, "missing_surface"
        row = _read_participants_unlocked().get(rec.get("participant_id"))
        if row is None:
            return None, "unregistered_seat"
        if row.get("retired_at"):
            return None, "retired_seat"
        if row.get("parked_at"):
            return None, "parked_seat"
        return _sanitize_token_rec(rec), "ok"
    return None, "unknown_token"


def _mint_session(tokens: Dict[str, Any], registry: Dict[str, Any], pid: str, *, role: str,
                  surface: str, sid: str, session: str, salt: str, from_invite: str | None,
                  issuer: str | None = None, now_ts: float | None = None) -> Dict[str, Any]:
    """A new session for *pid* on *surface*, superseding that surface's active session.

    One construction for every way in: a claimed invite, and the principal's password
    sign-in (CREDENTIALS_01 D-CRED-3: "a session exactly as a claimed invite does"), which
    alone names an ``issuer``. The caller holds the token and registry locks and commits.
    """
    now_ts = datetime.now(timezone.utc).timestamp() if now_ts is None else now_ts
    for rec in _token_records(tokens):
        if (rec.get("kind") == "session" and rec.get("participant_id") == pid
                and rec.get("status") == "active" and not rec.get("revoked")
                and rec.get("surface") == surface):
            rec.update(revoked=True, revoked_at=now_iso(), superseded_by=sid)
    expiry = datetime.fromtimestamp(now_ts + _session_ttl_sec(), tz=timezone.utc).isoformat(timespec="seconds")
    tokens[sid] = {
        "id": sid, "label": pid, "role": role, "kind": "session",
        "salt": salt, "token_sha256": _hash_token(session, salt),
        "participant_id": pid, "status": "active", "revoked": False,
        "created": now_iso(), "expires_at": expiry, "from_invite": from_invite,
        "surface": surface, "scope": SEAT_SCOPE,
    }
    if issuer is not None:
        tokens[sid]["issuer"] = issuer
    if _credentials_on(tokens):
        # D-CRED-1b: the generation current at issue. D-CRED-1 (and D-CON-6 as amended):
        # a seat-class identity's session carries the lifetime marker and no expiry.
        tokens[sid]["generation"] = _issue_generation(tokens, pid)
        if credential_class(registry[pid]) == "seat":
            del tokens[sid]["expires_at"]
            tokens[sid]["lifetime"] = LIFETIME_UNTIL_REVOKED
    return tokens[sid]


def claim_invite(invite_token: str, *, surface: str,
                 expected_participant: str | None = None,
                 session_value: str | None = None,
                 before_commit: Any = None, after_commit: Any = None,
                 progress: Dict[str, Any] | None = None) -> tuple[str, str]:
    """Claim a seat-scoped invite for an existing identity on an explicit surface.

    The caller supplies browser or terminal; scope is always seat. The launch
    fence, token lock and registry lock serialize validation, same-surface
    supersession, staging and the single token-table commit. No registry row is
    created. Placement runs before releasing the token lock. Progress separates
    a refused claim from an interrupted but committed one for the CLI repair.
    """
    if surface not in {"terminal", "browser"}:
        raise ValueError("invalid session surface")
    session = session_value or secrets.token_urlsafe(24)
    salt = secrets.token_hex(8)
    sid = new_id("tok")

    def _claim():
        now_ts = datetime.now(timezone.utc).timestamp()
        tokens = _read_tokens_unlocked()
        generations = _credentials_on(tokens)
        match = next((r for r in _token_records(tokens)
                      if r.get("kind") == "invite" and not r.get("revoked")
                      and _token_matches(invite_token, r)), None)
        if not match:
            raise ValueError("invite not found")
        if match.get("used"):
            raise ValueError("invite already used")
        if generations and not _generation_current(match, tokens, match.get("allowed_participant_id")):
            raise ValueError("invite revoked")     # D-CRED-1b: not of its identity's current generation
        if _token_expired(match, now_ts, tokens=tokens):
            raise ValueError("invite expired")
        if match.get("scope") != SEAT_SCOPE:
            raise ValueError("seat invites only")
        pid = match["allowed_participant_id"]
        if expected_participant is not None and pid != expected_participant:
            raise ValueError(f"invite is bound to {pid!r}, not {expected_participant!r}")

        def _seat_txn():
            registry = _read_participants_unlocked()
            if pid not in registry:
                raise ValueError(f"seat {pid!r} is not registered")
            if registry[pid].get("retired_at"):
                raise RegistryMutationRefused("seat_retired", f"{pid!r} is retired; invite claim refused")
            if registry[pid].get("parked_at"):
                raise RegistryMutationRefused("seat_parked", f"{pid!r} is parked; ask the Chief of Staff")
            if generations and _park_pending_for(pid):
                raise RegistryMutationRefused("parking_pending", f"{pid!r} is being parked; ask the Chief of Staff")
            if surface == "browser":
                issuer = tokens.get(match.get("provisioner_session_id"))
                if issuer is None:
                    raise ValueError("browser invite has no authenticated issuer")
                # R9 binds issuer authority to its current registry role, not
                # the issuing session's lifetime. The invite has its own TTL.
                _check_seat_invite_issuer(issuer, pid, registry)
            match.update(used=True, claimed_at=now_iso(), participant_id=pid)
            _mint_session(tokens, registry, pid, role=match["role"], surface=surface, sid=sid,
                          session=session, salt=salt, from_invite=match["id"], now_ts=now_ts)
            if before_commit is not None:
                if progress is not None:
                    progress["token_id"] = sid
                before_commit()
            if progress is not None:
                progress["committing"] = True
            _write_tokens_unlocked(tokens)
            if progress is not None:
                progress["committed"] = True
                progress["record"] = _sanitize_token_rec(dict(tokens[sid]))

        _registry_locked(_seat_txn)
        if after_commit is not None:
            after_commit()
        return pid

    return session, _tokens_locked(_claim)


def revoke_token(token_id: str, *, presented_token=None) -> bool:
    """Revoke a single invite or session by id. Returns True if found."""
    def _revoke():
        tokens = _read_tokens_unlocked()
        if token_id not in tokens:
            return False
        tokens[token_id]["revoked"] = True
        tokens[token_id]["revoked_at"] = now_iso()
        _write_tokens_unlocked(tokens)
        return True
    def authorized(actor):
        rec = getattr(_registry_actor_local, "actor")
        if rec["id"] != token_id:
            _require_current_provisioner(rec, _read_participants_unlocked())
        return _revoke()
    return authenticated_registry_act(presented_token, authorized)


def revoke_participant(participant_id: str, *, presented_token=None) -> int:
    """Operator: fully cut a user off — revoke ALL their live sessions AND any
    outstanding invites bound to that identity (reviewer PR#20 HIGH: revoking one
    token id is not enough; a user can hold several). Returns the count revoked."""
    def _revoke_all():
        tokens = _read_tokens_unlocked()
        generations = _credentials_on(tokens)
        n = 0
        for rec in _token_records(tokens):
            if rec.get("revoked"):
                continue
            if generations and rec.get("kind") == GENERATION_KIND:
                continue                  # the identity's generation entry is store state, not a credential
            bound = rec.get("participant_id") == participant_id \
                or rec.get("allowed_participant_id") == participant_id
            if bound:
                rec["revoked"] = True
                rec["revoked_at"] = now_iso()
                n += 1
        if n:
            _write_tokens_unlocked(tokens)
        return n
    return authenticated_registry_act(presented_token, lambda actor: _revoke_all(), provisioning=True)


def revoke_presented(presented: str) -> bool:
    """Logout: revoke ONLY the presenting session token (not the whole user)."""
    rec = resolve_token(presented)
    return revoke_token(rec["id"], presented_token=presented) if rec else False


def cancel_minted_approval(token_id: str, presented: str) -> bool:
    """Undo an approval mint using its own secret; never revoke a seat credential.

    The mint's receipt-failure rollback has no seat session. Possession of that
    exact approval is a bounded cancellation grant, with no provisioning rights.
    """
    def cancel():
        tokens = _read_tokens_unlocked()
        record = tokens.get(token_id) or {}
        if record.get("kind") != "approval" or not _token_matches(presented, record):
            return False
        record["revoked"] = True
        record["revoked_at"] = now_iso()
        _write_tokens_unlocked(tokens)
        return True
    return _tokens_locked(cancel)


def list_tokens() -> List[Dict[str, Any]]:
    """Sanitized token registry for the People UI — never exposes hashes/salts."""
    out = []
    tokens = _read_tokens_unlocked()
    generations = _credentials_on(tokens)
    for rec in tokens.values():
        if not isinstance(rec, dict) or rec.get("kind") == "bootstrap":
            continue                     # the bootstrap marker is store state, not a token
        if generations and (rec.get("kind") == GENERATION_KIND or rec.get("id") == CREDENTIALS_MARKER_ID):
            continue                     # so are the credentials migration's marker and generation entries
        out.append(_token_view(rec))
    return out


def _token_view(rec: Dict[str, Any]) -> Dict[str, Any]:
    """list_tokens' sanitized view of one record: ids, roles, timestamps; never hashes or salts."""
    return {k: rec.get(k) for k in (
        "id", "label", "role", "kind", "participant_id", "allowed_participant_id",
        "status", "used", "revoked", "created", "claimed_at", "expires_at",
        "revoked_at", "superseded_by", "scope", "from_invite", "surface")}


# --- Phase A A.4: seat token files, presentation, and receipted provisioning acts ---------

def seat_home(seat: str, override: str | os.PathLike | None = None) -> Path:
    """The seat's private workspace: ~/agents/<seat> (BRIEF C4; plan §11 "a seat is its
    home directory"), or an explicit override for a seat homed elsewhere."""
    # A provisioned canonical home is shared by invite, claim and generated rules.
    # Legacy rows retain their original default until the CoS imports a home map.
    registered = load_participants().get(seat, {}).get("provisioned_home")
    if registered:
        if override and Path(override).expanduser() != Path(registered):
            raise ValueError("seat-home override differs from the provisioned canonical home")
        return Path(registered)
    if override:
        return Path(override).expanduser()
    return Path.home() / "agents" / seat


def seat_token_path(seat: str, override: str | os.PathLike | None = None) -> Path:
    return seat_home(seat, override) / SEAT_PRIVATE_DIRNAME / SEAT_TOKEN_FILENAME


def seat_invite_path(seat: str, override: str | os.PathLike | None = None) -> Path:
    return seat_home(seat, override) / SEAT_PRIVATE_DIRNAME / SEAT_INVITE_FILENAME


def seat_launch_line(seat: str, command: str, *, home=None) -> str:
    """Run from the seat's own home with inherited credential selectors removed."""
    from launch_environment import seat_command
    return seat_command(command, seat_home(seat, home))


def write_secret_file(path: Path, secret: str) -> None:
    """Write a credential to `path` as a 0600 file inside a 0700 directory, atomically
    (0600 temp created O_EXCL, fsynced, renamed). Never logs or returns the value."""
    path = Path(path)
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(path.parent, 0o700)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(secret + "\n")
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def read_secret_file(path: Path) -> str:
    """Read a credential file, refusing one that is readable by group/other (the token
    would already be leaked — the repair is `chmod 600`, the same rule the Phase 0 locator
    has). Raises OSError (missing/unreadable) or PermissionError (mode)."""
    path = Path(path)
    mode = path.stat().st_mode & 0o777
    if mode & 0o077:
        raise PermissionError(f"{path} is mode {mode:04o}; a token file must be 0600 "
                              f"(repair: chmod 600 {path})")
    return path.read_text(encoding="utf-8").strip()


def find_presented_token(explicit_file: str | os.PathLike | None = None, *,
                         cwd: str | os.PathLike | None = None,
                         default_seat: str | None = None,
                         env: Dict[str, str] | None = None) -> Dict[str, Any]:
    """Locate the token a process presents. Order: an explicit file (--token-file), then
    $ORCH_TOKEN_FILE, then $ORCH_TOKEN (the value), then — for a CLI — the nearest
    `.orch/token` at or above the cwd (a seat acting from inside its own workspace,
    ~/agents/<seat>/), or — for the daemon — its own seat's token file.

    Returns {"token": str|None, "source": str, "looked": [str], "error": str|None}. A
    named file (flag or env) that is missing, unreadable, or loosely permissioned is an
    ERROR, not a fall-through: a misconfiguration must surface, never silently become
    "no token"."""
    env = os.environ if env is None else env
    looked: List[str] = []
    named = explicit_file or env.get(TOKEN_FILE_ENV)
    if named:
        origin = "--token-file" if explicit_file else f"${TOKEN_FILE_ENV}"
        looked.append(f"{origin}={named}")
        try:
            return {"token": read_secret_file(Path(named).expanduser()) or None,
                    "source": f"{origin} {named}", "looked": looked, "error": None}
        except OSError as exc:
            return {"token": None, "source": f"{origin} {named}", "looked": looked,
                    "error": f"{origin} {named}: {exc.strerror or exc}"}
    looked.append(f"${TOKEN_FILE_ENV} (unset)")
    value = env.get(TOKEN_ENV)
    if value:
        return {"token": value.strip() or None, "source": f"${TOKEN_ENV}", "looked": looked,
                "error": None}
    looked.append(f"${TOKEN_ENV} (unset)")
    candidates: List[Path] = []
    if default_seat is not None:
        candidates.append(seat_token_path(default_seat))
    else:
        here = Path(cwd or os.getcwd()).resolve()
        for d in (here, *here.parents):
            candidates.append(d / SEAT_PRIVATE_DIRNAME / SEAT_TOKEN_FILENAME)
    for cand in candidates:
        if cand.is_file():
            looked.append(str(cand))
            try:
                return {"token": read_secret_file(cand) or None, "source": str(cand),
                        "looked": looked, "error": None}
            except OSError as exc:
                return {"token": None, "source": str(cand), "looked": looked,
                        "error": f"{cand}: {exc.strerror or exc}"}
    if default_seat is not None:
        looked.append(f"{candidates[0]} (absent)")
    else:
        looked.append(f"{SEAT_PRIVATE_DIRNAME}/{SEAT_TOKEN_FILENAME} at or above {candidates[0].parent.parent} (absent)")
    return {"token": None, "source": "", "looked": looked, "error": None}


def token_seconds_remaining(rec: Dict[str, Any]) -> int | None:
    try:
        expiry = datetime.fromisoformat(rec["expires_at"])
        if expiry.tzinfo is None:
            return None
        return max(0, int(expiry.timestamp() - datetime.now(timezone.utc).timestamp()))
    except (KeyError, TypeError, ValueError):
        return None


def seat_token_records(seat: str) -> List[Dict[str, Any]]:
    """Sanitized invite + session records bound to `seat` (newest first) with a derived
    `state` — for `orch token status <seat>` and the A.7 panel's `token status` column.
    Ids, roles, timestamps: yes. Hashes, salts, values: never."""
    now_ts = datetime.now(timezone.utc).timestamp()
    tokens = _read_tokens_unlocked()
    generations = _credentials_on(tokens)
    out = []
    # The state is judged on the stored record: list_tokens' view fills an absent expires_at with
    # None and omits the lifetime marker, which would misjudge an untimed seat session (D-CRED-1).
    for raw in tokens.values():
        if not isinstance(raw, dict) or raw.get("kind") == "bootstrap":
            continue
        rec = _token_view(raw)
        bound = rec.get("participant_id") == seat or rec.get("allowed_participant_id") == seat
        if not bound or rec.get("kind") not in ("invite", "session"):
            continue
        if rec.get("revoked"):
            state = "revoked"
        elif rec["kind"] == "invite":
            state = "used" if rec.get("used") else ("expired" if _token_expired(raw, now_ts, tokens=tokens) else "open")
        elif rec.get("status") != "active":
            state = "pending"
        else:
            state = ("expired" if _token_expired(raw, now_ts, tokens=tokens) else
                     "missing_surface" if rec.get("surface") not in {"terminal", "browser"}
                     else "active")
        # D-CRED-1b: a record that would be live but is not of its identity's current generation
        # is shown as the gate treats it. Used, expired and revoked records were never stamped.
        if state in ("open", "active") and generations and not _generation_current(
                raw, tokens, rec.get("participant_id") or rec.get("allowed_participant_id")):
            state = "revoked"
        if generations and "lifetime" in raw:
            rec["lifetime"] = raw["lifetime"]
        out.append({**rec, "state": state, "expires_in_seconds": token_seconds_remaining(rec)})
    out.sort(key=lambda r: r.get("created") or "", reverse=True)
    return out


def _emit_seat_receipt(actor: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    import ledger  # ledger imports store; bind lazily (as register_store does)
    return ledger.emit("harness_mutation", actor_id=actor, payload=payload)


class SeatTokenNotPlaced(RuntimeError):
    """The claim is COMMITTED and receipted as not placed — invite consumed, the seat's
    earlier sessions superseded, the new session recorded — and its plaintext IS on disk
    at `staged`. Not a refusal: the caller names the staged file and the locked repair."""

    def __init__(self, seat: str, staged: Path, path: Path, error: str,
                 seat_home_override: Path | None = None):
        recovery = [product_identity.command(), "token", "place", seat]
        if seat_home_override is not None:
            recovery.extend(["--seat-home", str(seat_home_override)])
        recovery_command = shlex.join(recovery)
        super().__init__(f"token claimed for {seat} but not placed at {path} ({error}); "
                         f"the value is at {staged} — repair: {recovery_command} "
                         f"(places it only if that session is still the seat's live one; "
                         f"never move it by hand — a later claim may have superseded it)")
        self.seat, self.staged, self.path, self.error = seat, staged, path, error
        self.seat_home_override = seat_home_override
        self.recovery_argv = tuple(recovery)


class SeatInviteNotPlaced(RuntimeError):
    """The invite is COMMITTED (and receipted as not placed) and its plaintext IS on disk
    at `staged`; placement did not complete. Not a refusal: the seat claims it straight
    from the staged file — a claim consumes by value, so nothing can be clobbered."""

    def __init__(self, seat: str, token_id: str, staged: Path, path: Path, error: str,
                 seat_home_override: Path | None = None):
        recovery = [product_identity.command(), "token", "claim", seat]
        if seat_home_override is not None:
            recovery.extend(["--seat-home", str(seat_home_override)])
        recovery.extend(["--invite-file", str(staged)])
        recovery_command = shlex.join(recovery)
        super().__init__(f"invite {token_id} issued for {seat} but not placed at {path} "
                         f"({error}); the value is at {staged} — the seat claims it with: "
                         f"{recovery_command}")
        self.seat, self.token_id, self.staged, self.path, self.error = seat, token_id, staged, path, error
        self.seat_home_override = seat_home_override
        self.recovery_argv = tuple(recovery)


class SeatCredentialCommitIndeterminate(RuntimeError):
    """A staged seat credential exists but the token table could not be read after its
    write raised, so the attempt's commit state cannot be classified. The stage is kept
    and named; callers must never describe this as an ordinary refusal."""

    def __init__(self, act: str, seat: str, token_id: str | None, staged: Path,
                 write_error: BaseException, classification_error: BaseException):
        label = token_id or "UNKNOWN-ID"
        super().__init__(f"{act} {label} for {seat} has INDETERMINATE commit state: the "
                         f"token-table write raised {type(write_error).__name__}: {write_error}; "
                         f"the locked read-back also failed with "
                         f"{type(classification_error).__name__}: {classification_error}; "
                         f"the staged plaintext is preserved at {staged}")
        self.act, self.seat, self.token_id, self.staged = act, seat, token_id, staged
        self.write_error, self.classification_error = write_error, classification_error


class SeatCredentialPlacementIndeterminate(RuntimeError):
    """A committed credential's callback failed and the stage/final file probe could not
    establish exactly placed or not-placed. Both candidate paths and their observations
    are named without asserting that either absent path contains the credential."""

    def __init__(self, act: str, seat: str, token_id: str | None, staged: Path, path: Path,
                 callback_error: BaseException, probe: Dict[str, Any]):
        label = token_id or "UNKNOWN-ID"
        stage_state = probe["stage"]["state"]
        final_state = probe["final"]["state"]
        super().__init__(f"{act} {label} for {seat} is COMMITTED but placement is "
                         f"INDETERMINATE after {type(callback_error).__name__}: "
                         f"{callback_error}; stage candidate {staged} was {stage_state}; "
                         f"final candidate {path} was {final_state}")
        self.act, self.seat, self.token_id = act, seat, token_id
        self.staged, self.path = staged, path
        self.callback_error, self.probe = callback_error, probe


class SeatCredentialPlacedAfterCallbackError(RuntimeError):
    """The committed credential is durably at its final path, but an ordinary callback
    error occurred after placement. The CLI must not describe this as uncommitted."""

    def __init__(self, act: str, seat: str, token_id: str | None, path: Path,
                 callback_error: Exception):
        label = token_id or "UNKNOWN-ID"
        super().__init__(f"{act} {label} for {seat} is COMMITTED and placed at {path}, "
                         f"but its placement callback raised "
                         f"{type(callback_error).__name__}: {callback_error}")
        self.act, self.seat, self.token_id, self.path = act, seat, token_id, path
        self.callback_error = callback_error


class SeatCredentialPlacedAfterInterruption(KeyboardInterrupt):
    """A KeyboardInterrupt that retains its interruption semantics while carrying the
    committed/placed outcome needed for claim-source cleanup in the CLI."""

    def __init__(self, act: str, seat: str, token_id: str | None, path: Path,
                 interruption: KeyboardInterrupt):
        super().__init__(*interruption.args)
        self.act, self.seat, self.token_id, self.path = act, seat, token_id, path
        self.interruption = interruption


class SeatUncommittedStageNotRemoved(RuntimeError):
    """The attempt's record is absent, but its staged plaintext could not be removed.
    The commit state is known; the exceptional recovery surface names the retained file."""

    def __init__(self, act: str, seat: str, token_id: str | None, staged: Path,
                 write_error: BaseException, cleanup_error: BaseException):
        label = token_id or "UNKNOWN-ID"
        super().__init__(f"{act} {label} for {seat} was NOT COMMITTED after "
                         f"{type(write_error).__name__}: {write_error}, but its staged "
                         f"plaintext could not be removed ({type(cleanup_error).__name__}: "
                         f"{cleanup_error}); it is preserved at {staged}")
        self.act, self.seat, self.token_id, self.staged = act, seat, token_id, staged
        self.write_error, self.cleanup_error = write_error, cleanup_error


def _classify_staged_token_write_failure(*, act: str, seat: str, token_id: str | None,
                                         staged: Path, expected_kind: str,
                                         write_error: BaseException) -> Dict[str, Any] | None:
    """Classify a raised token-table write by re-reading its unique record under TOKENS_LOCK.

    A returned record means COMMITTED and the caller must receipt/report not-placed. None
    means NOT COMMITTED and this helper removed the attempt's stage while holding the lock.
    An unreadable/structurally unexpected table is indeterminate and preserves the named
    stage. Secret hash/salt fields never leave this helper.
    """
    if not token_id:
        raise SeatCredentialCommitIndeterminate(
            act, seat, token_id, staged, write_error,
            RuntimeError("the attempt did not expose its unique token id")) from write_error

    def _classify() -> Dict[str, Any] | None:
        tokens = _read_tokens_unlocked()
        record = tokens.get(token_id)
        if record is None:
            try:
                staged.unlink()
            except FileNotFoundError:
                pass
            except OSError as cleanup_error:
                raise SeatUncommittedStageNotRemoved(
                    act, seat, token_id, staged, write_error, cleanup_error) from write_error
            return None
        if not isinstance(record, dict) or record.get("kind") != expected_kind:
            raise RuntimeError(f"token id {token_id} resolved to an unexpected record")
        bound_seat = (record.get("allowed_participant_id") if expected_kind == "invite"
                      else record.get("participant_id"))
        if bound_seat != seat or record.get("scope") != SEAT_SCOPE:
            raise RuntimeError(f"token id {token_id} resolved to an unexpected seat/scope")
        return _sanitize_token_rec(dict(record))

    try:
        return _tokens_locked(_classify)
    except SeatUncommittedStageNotRemoved:
        raise
    except Exception as classification_error:
        raise SeatCredentialCommitIndeterminate(
            act, seat, token_id, staged, write_error, classification_error) from write_error


def _classify_credential_placement(*, staged: Path, path: Path,
                                   attempt_value: str,
                                   callback_recorded_placed: bool) -> Dict[str, Any]:
    """Probe this attempt's stage and final file under TOKENS_LOCK after a committed
    placement callback raises. Values never leave the helper.

    Exactly one final match with no stage is placed. A matching stage while the final is
    absent or holds an older/different credential is not placed. Unreadable state, a lost
    value, or duplicate copies is indeterminate. `callback_recorded_placed` records the
    callback phase fact but never overrides contradictory durable file state.
    """
    def _probe_one(candidate: Path) -> Dict[str, str]:
        try:
            value = read_secret_file(candidate)
        except FileNotFoundError:
            return {"path": str(candidate), "state": "absent"}
        except Exception as exc:
            return {"path": str(candidate), "state": "unreadable",
                    "error": f"{type(exc).__name__}: {exc}"}
        state = ("attempt" if secrets.compare_digest(
            value.encode("utf-8"), attempt_value.encode("utf-8")) else "other")
        return {"path": str(candidate), "state": state}

    def _classify() -> Dict[str, Any]:
        stage_probe = _probe_one(staged)
        final_probe = _probe_one(path)
        stage_state = stage_probe["state"]
        final_state = final_probe["state"]
        if callback_recorded_placed:
            state = ("placed" if final_state == "attempt" and stage_state == "absent"
                     else "indeterminate")
        elif final_state == "attempt" and stage_state == "absent":
            state = "placed"
        elif stage_state == "attempt" and final_state in ("absent", "other"):
            state = "not_placed"
        else:
            state = "indeterminate"
        return {"state": state, "stage": stage_probe, "final": final_probe,
                "callback_recorded_placed": bool(callback_recorded_placed)}

    return _tokens_locked(_classify)


class SeatActCleanupUnconfirmed(RuntimeError):
    """The act and receipt completed; final cleanup durability is unconfirmed."""

    def __init__(self, act: str, seat: str, error: str):
        super().__init__(f"{act} {seat}: act and receipt completed; cleanup durability unconfirmed: {error}")
        self.act, self.seat, self.error = act, seat, error


class SeatActWithoutReceipt(RuntimeError):
    """The provisioning act is committed but its ledger receipt failed. Not a refusal:
    the caller reports the known placement state and any recovery."""

    def __init__(self, act: str, token_id: str, error: str):
        super().__init__(f"{act} {token_id} is done but its ledger receipt failed: {error}")
        self.act, self.token_id, self.error = act, token_id, error


def issue_seat_invite(seat: str, *, issuer: str, auth: str, role: str | None = None,
                      seat_home_override: str | os.PathLike | None = None,
                      ttl_sec: int = INVITE_TTL_SEC, bootstrap: bool = False,
                      presented_token=None,
                      born_migrated_plan_sha256: str | None = None) -> Dict[str, Any]:
    """`orch invite <seat>`: mint a seat-scoped invite (create_invite, scope "seat"), place
    its plaintext at <seat home>/.orch/invite (0600) for the seat to claim, and receipt the
    act in the ledger (token id, seat, role, issuer, how the issuer was identified). The
    plaintext is never returned to the caller.

    Failure-atomic (reviewer DJK-A4-2), the claim's protocol: the plaintext is staged at a
    name unique to this attempt INSIDE the issuing transaction (before the commit — a
    failed write refuses with nothing committed and any earlier open invite untouched),
    then the visible `invite` file is placed inside the same lock hold right after the
    commit, so the file follows commit order across concurrent issuers. If that callback
    raises, the stage and final file are compared with this attempt's value under the token
    lock: placed, not-placed, or indeterminate is receipted before the corresponding outcome
    propagates. `bootstrap=True` makes the bootstrap decision and its marker part of the
    same transaction."""
    path = seat_invite_path(seat, seat_home_override)
    staged = path.with_name(f"{path.name}.next-{os.getpid()}-{secrets.token_hex(4)}")
    secret = [secrets.token_urlsafe(24)]     # cleared the moment the transaction is over
    placement: Dict[str, Any] = {}
    progress: Dict[str, Any] = {}
    deferred_callback_error: BaseException | None = None
    placement_indeterminate: SeatCredentialPlacementIndeterminate | None = None

    def stage() -> None:
        write_secret_file(staged, secret[0])
        progress["staged"] = True

    def place() -> None:
        os.replace(staged, path)
        progress["placed"] = True

    try:
        tid, _ = create_invite(seat, role, ttl_sec, scope=SEAT_SCOPE, invite_value=secret[0],
                               before_commit=stage, after_commit=place, progress=progress,
                               bootstrap=bootstrap, bootstrap_issuer=issuer,
                               born_migrated_plan_sha256=born_migrated_plan_sha256,
                               presented_token=presented_token)
    except BaseException as exc:
        if progress.get("staged") and not progress.get("committing"):
            secret.clear()
            try:
                staged.unlink()       # this attempt's file only; nothing was committed
            except OSError as cleanup_error:
                raise SeatUncommittedStageNotRemoved(
                    "invite", seat, progress.get("token_id"), staged,
                    exc, cleanup_error) from exc
            raise
        if progress.get("staged") and progress.get("committed"):
            tid = str(progress["token_id"])
            try:
                probe = _classify_credential_placement(
                    staged=staged, path=path, attempt_value=secret[0],
                    callback_recorded_placed=bool(progress.get("placed")))
            finally:
                secret.clear()
            deferred_callback_error = exc
            placement.update({"state": probe["state"], "probe": probe,
                              "callback_error": f"{type(exc).__name__}: {exc}"})
            if probe["state"] == "not_placed":
                placement["error"] = (f"post-commit placement raised "
                                      f"{type(exc).__name__}: {exc}")
            elif probe["state"] == "indeterminate":
                placement_indeterminate = SeatCredentialPlacementIndeterminate(
                    "invite", seat, progress.get("token_id"), staged, path, exc, probe)
        elif progress.get("staged") and progress.get("committing"):
            secret.clear()
            rec = _classify_staged_token_write_failure(
                act="invite", seat=seat, token_id=progress.get("token_id"), staged=staged,
                expected_kind="invite", write_error=exc)
            if rec is None:
                raise
            tid = str(progress["token_id"])
            progress["record"] = rec
            deferred_callback_error = exc
            placement["state"] = "not_placed"
            placement["error"] = (f"token-table write raised after the invite record landed: "
                                  f"{type(exc).__name__}: {exc}")
        else:
            secret.clear()
            raise
    secret.clear()
    rec = progress.get("record") or {}
    placement_state = placement.get("state", "placed" if progress.get("placed") else "indeterminate")
    placed = placement_state == "placed"
    stage_probe = (placement.get("probe") or {}).get("stage") or {}
    payload = {"mutation": "seat_invite_issued", "seat": seat, "role": rec.get("role"),
               "token_id": tid, "issuer": issuer, "issuer_auth": auth,
               "bootstrap": bool(bootstrap),
               "placed": placed if placement_state != "indeterminate" else None,
               "placement_state": placement_state,
               "invite_path": str(path) if placed else None,
               "staged_path": (str(staged) if placement_state == "not_placed"
                               or (placement_state == "indeterminate"
                                   and stage_probe.get("state") != "absent") else None),
               "placement_error": placement.get("error"),
               "callback_error": placement.get("callback_error"),
               "placement_probe": placement.get("probe"),
               "expires_at": rec.get("expires_at")}
    try:
        _emit_seat_receipt(issuer, payload)
    except KeyboardInterrupt as exc:
        if placed:
            raise SeatCredentialPlacedAfterInterruption(
                "invite", seat, tid, path, exc) from exc
        raise
    except Exception as exc:
        if placement_state == "placed":
            where = ""
        elif placement_state == "not_placed":
            where = f" (and not placed: the value is at {staged})"
        else:
            probe = placement.get("probe") or {"stage": {"state": "unknown"},
                                                "final": {"state": "unknown"}}
            where = (f" (and placement is indeterminate: stage {staged} was "
                     f"{probe['stage']['state']}; final {path} was {probe['final']['state']})")
        raise SeatActWithoutReceipt("invite", tid, f"{exc}{where}") from exc
    if placement_indeterminate is not None:
        raise placement_indeterminate from deferred_callback_error
    if not placed:
        override = path.parent.parent if seat_home_override else None
        raise SeatInviteNotPlaced(
            seat, tid, staged, path, placement["error"], override) from deferred_callback_error
    if deferred_callback_error is not None:
        if isinstance(deferred_callback_error, KeyboardInterrupt):
            raise SeatCredentialPlacedAfterInterruption(
                "invite", seat, tid, path, deferred_callback_error) from deferred_callback_error
        if isinstance(deferred_callback_error, Exception):
            raise SeatCredentialPlacedAfterCallbackError(
                "invite", seat, tid, path, deferred_callback_error) from deferred_callback_error
        raise deferred_callback_error
    return {"token_id": tid, "seat": seat, "role": rec.get("role"), "path": path,
            "expires_at": rec.get("expires_at"), "bootstrap": bool(bootstrap)}


def claim_seat_token(seat: str, invite_plain: str, *,
                     seat_home_override: str | os.PathLike | None = None) -> Dict[str, Any]:
    # Placement and its evidence must be visible together to the surface migration.
    # Without this outer hold an override claim could be placed but not yet receipted
    # when the migration classifies it using only the default path.
    return _tokens_locked(lambda: _claim_seat_token_locked(
        seat, invite_plain, seat_home_override=seat_home_override))


def _claim_seat_token_locked(seat: str, invite_plain: str, *,
                     seat_home_override: str | os.PathLike | None = None) -> Dict[str, Any]:
    """`orch token claim <seat>`: redeem the seat's invite (claim_invite, bound-id checked),
    place the session token at <seat home>/.orch/token (0600), and receipt the act as the
    seat. A raised post-commit callback is classified from the attempt's stage/final files
    before its plaintext is cleared. Returns ids and paths only — never the token."""
    return _place_session_locked(
        seat, lambda **kw: claim_invite(invite_plain, expected_participant=seat,
                                        surface="terminal", **kw),
        act="claim", seat_home_override=seat_home_override)


def login_seat_token(seat: str, password: str, *,
                     seat_home_override: str | os.PathLike | None = None) -> Dict[str, Any]:
    """`orch login`: the principal's password sign-in on the terminal (CREDENTIALS_01 D-CRED-3).

    Phase one (every precondition, the throttle's admission and the hash) runs outside
    the token lock; phase two re-reads under the locks and mints, then the session is
    placed and receipted exactly as a claim's, the receipt naming ``password`` as issuer.
    """
    stage1_features.require_private('principal_credentials')
    import principal_password
    verified = principal_password.check(seat, password, surface="terminal", local=True)
    return _tokens_locked(lambda: _place_session_locked(
        seat, lambda **kw: principal_password.mint(verified, surface="terminal", **kw),
        act="login", issuer="password", seat_home_override=seat_home_override))


def _place_session_locked(seat: str, mint: Any, *, act: str, issuer: str | None = None,
                          seat_home_override: str | os.PathLike | None = None) -> Dict[str, Any]:
    """Mint a terminal session through *mint* and place it at <seat home>/.orch/token (0600).

    *mint* takes the claim's keyword callbacks (session_value, before_commit, after_commit,
    progress) and returns (session, pid). The receipt is the claim's; a sign-in's adds
    ``issuer`` and ``surface``."""
    path = seat_token_path(seat, seat_home_override)
    # A staging name UNIQUE to this attempt (Bugbot PR #222 round 3): a retry or a second
    # claim never overwrites or unlinks another attempt's file — in particular never the
    # only plaintext of a session that committed but was not renamed (SeatTokenNotPlaced).
    staged = path.with_name(f"{path.name}.next-{os.getpid()}-{secrets.token_hex(4)}")
    secret = [secrets.token_urlsafe(24)]     # cleared the moment the transaction is over
    # Order (Bugbot High + CodeRabbit Major, PR #222 round 2; reviewer DJK-A4-3): the
    # plaintext reaches disk BEFORE anything is committed, and it does so INSIDE the
    # claim's lock hold (`before_commit`), after the invite is validated — so no staged file
    # of an in-progress claim is ever visible to the repair, which takes the same lock. A
    # failed staging write refuses with nothing committed: the invite is untouched, the
    # seat's current token stays live. The rename over the seat's token file happens in
    # the same lock hold right after the commit, so placement follows commit order.
    placement: Dict[str, Any] = {}
    progress: Dict[str, Any] = {}
    deferred_callback_error: BaseException | None = None
    placement_indeterminate: SeatCredentialPlacementIndeterminate | None = None

    def stage() -> None:
        write_secret_file(staged, secret[0])
        progress["staged"] = True

    def place() -> None:
        os.replace(staged, path)
        progress["placed"] = True

    try:
        _, pid = mint(session_value=secret[0], before_commit=stage, after_commit=place,
                      progress=progress)
    except BaseException as exc:
        # Unlink THIS attempt's file only when the claim provably never reached its commit.
        # Interrupted at or after the token-table write (`committing`), the session may be
        # live and this file its only plaintext: keep it — `orch token place <seat>` is the
        # locked repair (CodeRabbit PR #222 round 4).
        if progress.get("staged") and not progress.get("committing"):
            secret.clear()
            try:
                staged.unlink()
            except OSError as cleanup_error:
                raise SeatUncommittedStageNotRemoved(
                    act, seat, progress.get("token_id"), staged,
                    exc, cleanup_error) from exc
            raise
        if progress.get("staged") and progress.get("committed"):
            pid = seat
            try:
                probe = _classify_credential_placement(
                    staged=staged, path=path, attempt_value=secret[0],
                    callback_recorded_placed=bool(progress.get("placed")))
            finally:
                secret.clear()
            deferred_callback_error = exc
            placement.update({"state": probe["state"], "probe": probe,
                              "callback_error": f"{type(exc).__name__}: {exc}"})
            if probe["state"] == "not_placed":
                placement["error"] = (f"post-commit placement raised "
                                      f"{type(exc).__name__}: {exc}")
            elif probe["state"] == "indeterminate":
                placement_indeterminate = SeatCredentialPlacementIndeterminate(
                    act, seat, progress.get("token_id"), staged, path, exc, probe)
        elif progress.get("staged") and progress.get("committing"):
            secret.clear()
            rec = _classify_staged_token_write_failure(
                act=act, seat=seat, token_id=progress.get("token_id"), staged=staged,
                expected_kind="session", write_error=exc)
            if rec is None:
                raise
            pid = seat
            progress["record"] = rec
            deferred_callback_error = exc
            placement["state"] = "not_placed"
            placement["error"] = (f"token-table write raised after the session record landed: "
                                  f"{type(exc).__name__}: {exc}")
        else:
            secret.clear()
            raise
    secret.clear()
    rec = progress.get("record") or {}   # captured inside the transaction, never re-read
    placement_state = placement.get("state", "placed" if progress.get("placed") else "indeterminate")
    placed = placement_state == "placed"
    stage_probe = (placement.get("probe") or {}).get("stage") or {}
    payload = {"mutation": "seat_token_claimed", "seat": pid, "role": rec.get("role"),
               "token_id": rec.get("id"), "from_invite": rec.get("from_invite"),
               "token_path": str(path) if placed else None,
               "placed": placed if placement_state != "indeterminate" else None,
               "placement_state": placement_state,
               "staged_path": (str(staged) if placement_state == "not_placed"
                               or (placement_state == "indeterminate"
                                   and stage_probe.get("state") != "absent") else None),
               "placement_error": placement.get("error"),
               "callback_error": placement.get("callback_error"),
               "placement_probe": placement.get("probe"),
               "expires_at": rec.get("expires_at")}
    if "lifetime" in rec:
        payload["lifetime"] = rec["lifetime"]   # D-CRED-1: an untimed seat session says so
    if issuer is not None:
        payload.update(issuer=issuer, surface="terminal")   # D-CRED-3: the sign-in's receipt
    try:
        _emit_seat_receipt(pid, payload)
    except KeyboardInterrupt as exc:
        if placed:
            raise SeatCredentialPlacedAfterInterruption(
                act, seat, rec.get("id"), path, exc) from exc
        raise
    except Exception as exc:
        if placement_state == "placed":
            where = ""
        elif placement_state == "not_placed":
            where = f" (and not placed: the value is at {staged})"
        else:
            probe = placement.get("probe") or {"stage": {"state": "unknown"},
                                                "final": {"state": "unknown"}}
            where = (f" (and placement is indeterminate: stage {staged} was "
                     f"{probe['stage']['state']}; final {path} was {probe['final']['state']})")
        raise SeatActWithoutReceipt(act, str(rec.get("id")), f"{exc}{where}") from exc
    if placement_indeterminate is not None:
        raise placement_indeterminate from deferred_callback_error
    if not placed:
        override = path.parent.parent if seat_home_override else None
        raise SeatTokenNotPlaced(
            pid, staged, path, placement["error"], override) from deferred_callback_error
    if deferred_callback_error is not None:
        if isinstance(deferred_callback_error, KeyboardInterrupt):
            raise SeatCredentialPlacedAfterInterruption(
                act, seat, rec.get("id"), path,
                deferred_callback_error) from deferred_callback_error
        if isinstance(deferred_callback_error, Exception):
            raise SeatCredentialPlacedAfterCallbackError(
                act, seat, rec.get("id"), path,
                deferred_callback_error) from deferred_callback_error
        raise deferred_callback_error
    return {"token_id": rec.get("id"), "seat": pid, "role": rec.get("role"), "path": path,
            "expires_at": rec.get("expires_at")}


def place_staged_token(seat: str, *, seat_home_override: str | os.PathLike | None = None) -> Dict[str, Any]:
    """`orch token place <seat>`: the LOCKED repair for a claim that committed but was not
    placed (SeatTokenNotPlaced, or an interrupted claim). Under TOKENS_LOCK: every staged
    file of the seat (`<seat home>/.orch/token.next-*`) is read; the one whose value is the
    seat's LIVE session (active, unrevoked, unexpired, bound to this seat) is renamed over
    `token`; every other staged file is a dead credential (superseded, revoked, expired, or
    unknown to this store) and is removed. Nothing is ever placed blindly: if no staged
    file holds a live session, the seat's current token file is left untouched and
    ValueError names what was removed."""
    path = seat_token_path(seat, seat_home_override)

    def _repair():
        # Enumerated UNDER the lock (reviewer DJK-A4-3): a claim stages its file inside its
        # own lock hold, so every file seen here belongs to a finished attempt — committed
        # (live or superseded) or died before its commit (unknown to the store) — never to
        # a claim in progress.
        candidates = sorted(path.parent.glob(f"{path.name}.next-*")) if path.parent.is_dir() else []
        if not candidates:
            raise ValueError(f"no staged token file for {seat!r} under {path.parent}")
        tokens = _read_tokens_unlocked()
        live: Path | None = None
        live_rec: Dict[str, Any] | None = None
        dead: List[str] = []
        for cand in candidates:
            try:
                value = read_secret_file(cand)
            except OSError:
                dead.append(cand.name)
                continue
            rec, _ = _verdict_unlocked(value, tokens)
            if rec is not None and rec.get("participant_id") == seat and live is None:
                live, live_rec = cand, rec
            else:
                dead.append(cand.name)
        for name in dead:
            try:
                (path.parent / name).unlink()
            except OSError:
                pass
        if live is None:
            raise ValueError(f"no staged file of {seat!r} holds a live session — nothing placed; "
                             f"removed {len(dead)} dead staged file(s): {', '.join(dead) or '-'}; "
                             f"{path} is untouched. Claim again from a fresh invite.")
        os.replace(live, path)
        os.chmod(path, 0o600)
        try:
            _emit_seat_receipt(seat, {"mutation": "seat_token_placed", "seat": seat,
                                     "token_id": live_rec["id"], "token_path": str(path),
                                     "placed": True})
        except Exception as exc:
            raise SeatActWithoutReceipt("place", live_rec["id"], str(exc)) from exc
        return {"placed": path, "token_id": live_rec.get("id"), "role": live_rec.get("role"),
                "expires_at": live_rec.get("expires_at"), "removed": dead}

    return _tokens_locked(_repair)


def retire_seat_tokens(seat: str, *, actor: str, auth: str, presented_token=None) -> int:
    """`orch token revoke <seat>`: revoke every live token bound to the seat (sessions and
    open invites — revoke_participant) and receipt the count. The gate refuses the seat's
    next presentation immediately (D-IDT-3)."""
    n = authenticated_registry_act(
        presented_token, lambda identity: revoke_participant(seat, presented_token=presented_token),
        provisioning=True, expected_actor=actor)
    payload = {"mutation": "seat_tokens_revoked", "seat": seat, "revoked": n,
               "actor": actor, "actor_auth": auth}
    try:
        _emit_seat_receipt(actor, payload)
    except Exception as exc:
        raise SeatActWithoutReceipt("revoke", seat, f"{exc}") from exc
    return n


# --- Z-merge approval tokens (the merge gate; META_HARNESS_PLAN Stage 1) ---
# policy.classify() routes git_merge/git_push to FULL_ACCESS → escalate. The escalation is
# resolved by a single-use, fingerprint-bound approval token minted by the OWNER. Reuses the
# same salted-hash + flock-serialized store as invites/sessions. NOTE the trust split: this
# module MINTS and CONSUMES the token; the ledger only records the human_approval *receipt*
# (harness/zgate.py). Authorization is the token, never the ledger.

def approval_fingerprint(repo: str, base_sha: str, head_sha: str) -> Dict[str, str]:
    """The normalized identity of a single merge. A token authorizes this exact triple and
    no other — a different head (new commits) or a moved base (someone pushed to the target
    after minting) is a different fingerprint, so the stale approval no longer resolves and
    the merge re-escalates."""
    parts = {"repo": repo, "base_sha": base_sha, "head_sha": head_sha}
    for k, v in parts.items():
        if not isinstance(v, str) or not v.strip():
            raise ValueError(f"approval fingerprint needs a non-empty {k}")
    return {k: v.strip() for k, v in parts.items()}


def _fingerprint_key(fp: Dict[str, str]) -> str:
    """Stable key for a fingerprint (unit-separated — the fields can't contain \\x1f)."""
    return "\x1f".join((fp["repo"], fp["base_sha"], fp["head_sha"]))


def mint_approval_token(repo: str, base_sha: str, head_sha: str, *, auth_source: str,
                        ttl_sec: int = APPROVAL_TTL_SEC) -> tuple[str, str, Dict[str, str]]:
    """Retired compatibility seam; cannot mint or touch the token store.

    Kept callable so old adapters refuse explicitly and GC-7's effect trap still
    tests this boundary. Rule A supersedes operator/UI-string mint authority.
    """
    raise PermissionError("merge approval mint retired: GC-7 removed the mint seam; use the principal Z / CoS exact-head gate")


def _match_live_approval(tokens: Dict[str, Dict[str, Any]], presented: str,
                         key: str, now_ts: float) -> Dict[str, Any] | None:
    """The ONE matching rule for approval tokens (shared by resolve + peek): live,
    fingerprint-bound, secret-matched, not expired. Returns the record or None."""
    for rec in _token_records(tokens):
        if rec.get("kind") != "approval" or rec.get("revoked") or rec.get("used"):
            continue
        if rec.get("fingerprint_key") != key:
            continue                     # wrong merge — leave the token for its real one
        if not _token_matches(presented, rec):
            continue
        if _token_expired(rec, now_ts, tokens=tokens):  # generic expires_at check, fail-closed
            return None
        return rec
    return None


def peek_approval_token(presented: str, repo: str, base_sha: str, head_sha: str) -> bool:
    """NON-CONSUMING validity check for an approval token.

    Used by the action seam when a pre-merge hook is installed in the target repo
    (Bugbot #40 High: seam-consume + hook-consume double-burned one authorization —
    the seam VERIFIES here, and the hook, the last checkpoint git actually runs,
    performs the single consume). Same matching rule as resolve, zero writes."""
    if not presented:
        return False
    fp = approval_fingerprint(repo, base_sha, head_sha)
    key = _fingerprint_key(fp)

    def _peek():
        now_ts = datetime.now(timezone.utc).timestamp()
        return _match_live_approval(_read_tokens_unlocked(), presented, key, now_ts) is not None

    return _tokens_locked(_peek)


def approval_recently_consumed(presented: str, repo: str, base_sha: str, head_sha: str,
                               *, within_sec: int = 120) -> bool:
    """GRACE check for the pre-merge hook: the governed seam ALWAYS consumes the token
    pre-effect, so when git then fires OUR hook at commit time the token is already used.
    The hook honors a token consumed for EXACTLY this fingerprint within ``within_sec``
    seconds — the same authorization covering the same merge, burned once (Bugbot #40
    High: deferring consumption to the hook let fast-forward merges — which never fire
    pre-merge-commit — skip consumption entirely, making one mint reusable).

    Never consumes or writes. Residual (documented): replaying the SAME token on an
    identical (repo, base, head) inside the window would pass the hook — after a real
    merge the base moves, so that requires a deliberate branch reset within seconds."""
    if not presented:
        return False
    fp = approval_fingerprint(repo, base_sha, head_sha)
    key = _fingerprint_key(fp)

    def _check():
        now_ts = datetime.now(timezone.utc).timestamp()
        for rec in _token_records(_read_tokens_unlocked()):
            if rec.get("kind") != "approval" or not rec.get("used"):
                continue
            if rec.get("fingerprint_key") != key or not _token_matches(presented, rec):
                continue
            if rec.get("consumed_via") != "seam":
                return False   # grace covers ONLY a seam-consume; a hook-consume replay must fail
            try:
                consumed = datetime.fromisoformat(rec.get("consumed_at", "")).timestamp()
            except (TypeError, ValueError):
                return False               # unparseable state — fail closed
            return (now_ts - consumed) <= within_sec
        return False

    return _tokens_locked(_check)


def resolve_approval_token(presented: str, repo: str, base_sha: str,
                           head_sha: str, *, via: str = "unspecified") -> Dict[str, Any] | None:
    """Atomic CHECK-AND-CONSUME at merge time. Returns the sanitized token record iff a live
    approval token matches BOTH the presented secret AND this exact merge fingerprint —
    and, in the same critical section, marks it used (single-use). Returns None on any miss
    WITHOUT consuming anything, so a wrong-fingerprint attempt never burns a token valid for
    its real merge.

    Concurrency: the whole find-validate-consume runs under one _tokens_locked hold, so two
    simultaneous resolves of one token serialize — the first marks it used, the second sees
    used → None. Exactly one merge is ever authorized. Expiry fails CLOSED (_token_expired).
    """
    if not presented:
        return None
    fp = approval_fingerprint(repo, base_sha, head_sha)
    key = _fingerprint_key(fp)

    def _consume():
        now_ts = datetime.now(timezone.utc).timestamp()
        tokens = _read_tokens_unlocked()
        rec = _match_live_approval(tokens, presented, key, now_ts)
        if rec is None:
            return None
        rec["used"] = True
        rec["consumed_at"] = now_iso()
        rec["consumed_via"] = via     # "seam" | "hook" | … — the hook's grace honors ONLY
        _write_tokens_unlocked(tokens)  # seam-consumes (a hook-consume must never re-grace)
        return _sanitize_token_rec(rec)

    return _tokens_locked(_consume)


# --- tasks ---

def task_event(event: str, *, task_id: str | None = None, actor: str = "",
               **fields: Any) -> Dict[str, Any]:
    rec = {"id": new_id("evt"), "ts": now_iso(), "event": event,
           "task_id": task_id or new_id("task"), "actor": actor, **fields}
    append_jsonl(TASKS_FILE, rec)
    return rec


def task_board() -> List[Dict[str, Any]]:
    """Replay tasks.jsonl into current board state, oldest first."""
    events, _ = read_jsonl(TASKS_FILE)
    board: Dict[str, Dict[str, Any]] = {}
    for e in events:
        tid = e.get("task_id")
        if not tid:
            continue
        t = board.setdefault(tid, {"id": tid, "title": "", "assignee": None,
                                   "status": "open", "created_by": "",
                                   "created_at": e.get("ts", ""), "notes": []})
        ev = e.get("event")
        if ev == "created":
            t["title"] = e.get("title", t["title"])
            t["created_by"] = e.get("actor", "")
            t["assignee"] = e.get("assignee", t["assignee"])
        elif ev == "assigned":
            t["assignee"] = e.get("assignee")
            t["status"] = "open" if t["status"] == "done" else t["status"]
        elif ev == "done":
            t["status"] = "done"
        elif ev == "reopened":
            t["status"] = "open"
        elif ev == "comment":
            t["notes"].append({"by": e.get("actor", ""), "ts": e.get("ts", ""),
                               "text": e.get("text", "")})
    return sorted(board.values(), key=lambda t: t["created_at"])


# --- handoff files (delivery TO agents that read files but can't run orch) ---

HANDOFF_DIR = STORE_DIR / "handoff"


def handoff_dir(pid: str) -> Path:
    d = HANDOFF_DIR / _safe_pid(pid)
    d.mkdir(parents=True, exist_ok=True)
    return d


def normalize_family(value: Any) -> Optional[str]:
    """The canonical vendor family, lowercased, or None.

    CLOSED: an unrecognised family normalizes to None rather than passing
    through, so a typo can never be mistaken for a vendor. Callers decide what
    None means for them — it is a real state (humans have no vendor family)
    and not only an error.

    Single source of truth on purpose. The roster stores family in whatever
    case a seat was registered with.
    EVERY comparison must normalize on read; an exact-case `==` against this
    field is a latent bug even when it happens to be right today.
    """
    if not isinstance(value, str):
        return None
    return {"claude": "claude", "codex": "codex", "gemini": "gemini"}.get(
        value.strip().lower())


def reads_files(participant: Dict[str, Any]) -> bool:
    """True for agents whose consumption mechanism is reading files rather
    than running `orch inbox` (no shell — e.g. Gemini in auto_edit).

    Was `family == "Gemini"`, an exact-case match. It happened to be correct
    only because all three Gemini seats were registered capitalized: a seat
    stored as "gemini" would have been told to run `orch inbox` with no shell
    to run it in, and its mail would have gone quietly undelivered.
    """
    reads = participant.get("reads")
    if reads is not None:
        return reads == "file"
    return normalize_family(participant.get("family")) == "gemini"


def write_handoff(pid: str) -> tuple[Path | None, List[Dict[str, Any]]]:
    """Drain pid's unread into a formatted handoff file; advance the cursor.

    This IS consumption for file-read agents: the cursor moves when the
    handoff is written (the file + durable log both persist, so nothing is
    lost if the agent never reads it — the next doctor run shows the file).
    Returns (path, messages); (None, []) when there was nothing unread.
    """
    msgs = drain_inbox(pid)
    if not msgs:
        return None, []
    ts = datetime.now(timezone.utc).astimezone().strftime("%Y%m%dT%H%M%S")
    path = handoff_dir(pid) / f"{ts}_{len(msgs)}msgs.md"
    lines = [f"# {product_identity.load().display_name} mail for {pid} — {len(msgs)} message(s)",
             f"Written {now_iso()}. Reply through the authenticated {product_identity.command()} CLI. "
             "Mail is discussion/review only.", ""]
    for m in msgs:
        lines.append(f"## [{m.get('ts', '')}] from {m.get('from', '?')} "
                     f"to {', '.join(m.get('to', []))}  ({m.get('id', '')})")
        lines.append(m.get("text", ""))
        lines.append("")
    tmp = path.with_suffix(".md.tmp")
    tmp.write_text("\n".join(lines), encoding="utf-8")
    os.chmod(tmp, 0o600)  # handoff carries mail — owner-only (reviewer/reviewer MED)
    os.replace(tmp, path)  # readers never see a partial handoff
    return path, msgs


# --- legacy migration ---

def migrate_legacy(legacy_path: Path, *, channel_owner: str | None = None) -> int:
    """Import broadcasts/channel messages from a v1 orchestration.json.

    Appends to log.jsonl only (history — no inbox fan-out, no notification).
    Returns the number of records imported. Idempotent via meta.legacy_id.
    """
    if not legacy_path.exists():
        return 0
    try:
        legacy = json.loads(legacy_path.read_text())
    except json.JSONDecodeError:
        return 0
    if legacy.get('channel_messages') and (not isinstance(channel_owner, str)
            or not channel_owner.strip() or channel_owner != channel_owner.strip()
            or len(channel_owner) > 128 or any(ord(c) < 32 for c in channel_owner)):
        raise ValueError('legacy channel history requires an explicit --legacy-owner; no attribution was guessed')
    existing, _ = read_log()
    seen_legacy = {m.get("meta", {}).get("legacy_id") for m in existing if m.get("meta")}
    count = 0
    entries: List[tuple[str, str, str, str]] = []  # (ts, sender, text, legacy_id)
    for b in legacy.get("broadcasts", []):
        entries.append((b.get("timestamp", ""), b.get("participant_id") or b.get("agent", "unknown"),
                        b.get("message", ""), b.get("id", "")))
    for m in legacy.get("channel_messages", []):
        entries.append((m.get("created_at", ""), channel_owner, m.get("text", ""), m.get("id", "")))
    for r in legacy.get("channel_replies", []):
        entries.append((r.get("created_at", ""), r.get("participant_id", "unknown"),
                        r.get("text", ""), r.get("id", "")))
    ensure_store()
    for ts, sender, text, legacy_id in sorted(entries, key=lambda e: e[0]):
        if not text or (legacy_id and legacy_id in seen_legacy):
            continue
        record = _prepare_message_record({
            "id": new_id("msg"), "ts": ts or now_iso(), "from": sender,
            "to": ["all"], "recipients": [], "kind": "legacy", "text": text,
            "meta": {"legacy_id": legacy_id},
        })
        _append_message_log(record)
        count += 1
    return count


# --- registration act + candidate measurement (Phase 0 W0.2) --------------------------

def measure_store(path: Path) -> Dict[str, Any]:
    """Read-only measurement of one candidate store directory: complete-line count,
    newest ``msg-id``, log mtime, SHA-256 of ``log.jsonl``. Never writes, never chooses."""
    path = Path(path)
    log = path / "log.jsonl"
    out: Dict[str, Any] = {"path": str(path), "exists": log.is_file()}
    if not out["exists"]:
        return out
    digest = hashlib.sha256()
    lines = 0
    try:
        with log.open("rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                digest.update(chunk)
                lines += chunk.count(b"\n")
        newest = tail_jsonl(log, 1)
        st = log.stat()
    except OSError as exc:
        # one unreadable candidate (foreign owner, stale mount) is a finding about THAT
        # row, never a reason to abort the measurement of the others
        out["error"] = f"unreadable: {exc.strerror or exc}"
        return out
    out.update({
        "lines": lines,
        "newest_msg_id": newest[0].get("id") if newest else None,
        "mtime": datetime.fromtimestamp(st.st_mtime, timezone.utc).astimezone()
                         .isoformat(timespec="seconds"),
        "size": st.st_size,
        "sha256": digest.hexdigest(),
    })
    return out


_SCAN_MAX_DEPTH = 3


def store_candidates(paths: Iterable[Any] = (), *, scan: Iterable[Any] = ()) -> List[Dict[str, Any]]:
    """Every KNOWN candidate store, measured side by side — the locator's target, any
    ``PSQR_STORE_DIR`` in scope, this checkout's own ``store/`` and ``store.bak-*/``
    siblings (the frozen-checkout hazard class: measured, never selected), any ``scan``
    roots (directories containing ``log.jsonl``, depth-limited), and explicit ``paths``.
    Each row carries its ``sources``. Chooses nothing: choosing is a decision (DP-1)."""
    found: Dict[str, Dict[str, Any]] = {}

    def add(candidate: Path, source: str) -> None:
        candidate = Path(candidate)
        try:
            key = str(candidate.resolve())
        except OSError:
            key = str(candidate)
        row = found.get(key)
        if row is None:
            row = measure_store(candidate)
            row["sources"] = []
            if row.get("exists"):
                try:
                    row["registration"] = registration_state(candidate)
                except (OSError, ValueError, TypeError) as exc:
                    # a foreign or damaged ledger is a finding about THIS row, never an
                    # abort of the measurement of the others
                    row["registration"] = {"state": "unknown",
                                           "note": f"ledger unreadable: {exc}"}
            found[key] = row
        if source not in row["sources"]:
            row["sources"].append(source)

    try:
        add(read_locator()[0], "locator")
    except StoreUnbound:
        pass
    env = product_identity.inherited_setting(STORE_ENV_OVERRIDE)
    if env:
        add(Path(os.path.expanduser(env)), product_identity.diagnostic(
            "env:" + STORE_ENV_OVERRIDE, 'installation configuration'))
    checkout = SCRIPT_DIR / "store"          # the deleted default — MEASURED, never resolved
    if checkout.is_dir():
        add(checkout, "checkout")
    for bak in sorted(SCRIPT_DIR.glob("store.bak-*")):
        if bak.is_dir():
            add(bak, "checkout-backup")
    for root in scan:
        root = Path(os.path.expanduser(str(root)))
        if not root.is_dir():
            continue
        base_depth = len(root.parts)
        for dirpath, dirnames, filenames in os.walk(root):
            depth = len(Path(dirpath).parts) - base_depth
            if depth >= _SCAN_MAX_DEPTH:
                dirnames[:] = []
            dirnames[:] = [d for d in dirnames if not d.startswith(".")]
            if "log.jsonl" in filenames:
                add(Path(dirpath), f"scan:{root}")
    for p in paths:
        add(Path(os.path.expanduser(str(p))), "arg")
    return list(found.values())


def parse_daemon_lock(raw: str) -> Optional[Dict[str, Any]]:
    """The delivery daemon's lock content: JSON ``{"pid", "proc_birth", "store_dir", ...}``
    since Phase 0, or the legacy bare pid. None when it is neither. ONE reader for every
    consumer — ``orch status``/``doctor``/``down`` and the registration act — so they
    cannot drift apart."""
    text = raw.strip()
    if not text:
        return None
    if text.startswith("{"):
        try:
            rec = json.loads(text)
        except json.JSONDecodeError:
            return None
        if not isinstance(rec, dict) or not isinstance(rec.get("pid"), int) \
                or isinstance(rec.get("pid"), bool) or rec["pid"] <= 0:
            return None
        return rec
    try:
        pid = int(text)
    except ValueError:
        return None
    return {"pid": pid} if pid > 0 else None


def daemon_lock_is_held(lock_path: Path, *, observe: bool = False) -> bool:
    """Read lease state; health observers never acquire a competing flock.

    The default retains the registration/teardown probe. Unavailable read-only
    observation raises OSError, so heartbeat reports unknown rather than down.
    """
    with lock_path.open("r") as f:
        if observe:
            from service_lifecycle import Refused, observed_flock
            try:
                return observed_flock(f.fileno())
            except Refused as exc:
                raise OSError('read-only daemon lock observation unavailable') from exc
        try:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return True
        fcntl.flock(f.fileno(), fcntl.LOCK_UN)
        return False


def daemon_lock_holder(store_dir: Path) -> Optional[Dict[str, Any]]:
    """Read-only: is ``<store_dir>/daemon.lock`` LIVE-held? ``{"pid", "lock"}`` when a live
    process holds the flock (``pid`` None when the content is unparseable — the flock,
    not the text, is the proof); None when there is no lock or nobody holds it (a dead
    pid, or a pid alive but not holding: the stale cases, which never block anything).
    Raises OSError when the lock exists but cannot be probed — a caller must not read
    that as 'nobody'. Identity metadata is NOT consulted: whoever holds that flock is
    delivering on that store, and a locator swap would orphan it."""
    lock_path = Path(store_dir) / "daemon.lock"
    if not lock_path.exists():
        return None
    if not daemon_lock_is_held(lock_path):
        return None
    rec = parse_daemon_lock(lock_path.read_text())
    return {"pid": rec["pid"] if rec else None, "lock": str(lock_path)}


@contextmanager
def lifecycle_exclusion(*, inherited_fd=None):
    """Serialize product up/down with explicit registration, not daemon lease entry.

    Up passes the descriptor to its startup delegate, so parent-only death cannot
    release exclusion while that delegate can still launch services. Close each
    owner's descriptor without LOCK_UN: the shared flock lasts until all close.
    Daemon registration_exclusion remains separate so the child can take its lease.
    """
    root = locator_path().parent
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    directory = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    fd = None
    try:
        opened = os.fstat(directory)
        mode = stat.S_IMODE(opened.st_mode)
        if (not stat.S_ISDIR(opened.st_mode) or opened.st_uid != os.getuid()
                or (mode & 0o077 and mode != 0o755)):
            raise RegistrationBusy("lifecycle directory must be owned and private (0700)")
        # A legacy mkdir(parents=True) may have created ~/.orch at 0755. Tighten
        # only that owned, non-writable directory through its verified fd. The
        # candidate store's separate private-root admission is unchanged.
        if mode == 0o755:
            os.fchmod(directory, 0o700)

        def directory_unchanged():
            named = root.lstat()
            if (not stat.S_ISDIR(named.st_mode) or named.st_uid != os.getuid()
                    or stat.S_IMODE(named.st_mode) & 0o077
                    or (named.st_dev, named.st_ino) != (opened.st_dev, opened.st_ino)):
                raise RegistrationBusy("lifecycle directory changed during acquisition")

        directory_unchanged()
        if inherited_fd is not None and (type(inherited_fd) is not int or inherited_fd < 3):
            raise RegistrationBusy("invalid inherited lifecycle descriptor")
        fd = (os.open("first-run.lock", os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK,
                      0o600, dir_fd=directory) if inherited_fd is None else inherited_fd)
        # The startup delegate keeps this descriptor, but its services must not.
        os.set_inheritable(fd, False)
        info = os.fstat(fd)
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                or stat.S_IMODE(info.st_mode) != 0o600 or info.st_nlink != 1):
            raise RegistrationBusy("lifecycle lock must be an owned regular 0600 file")
        named = os.stat("first-run.lock", dir_fd=directory, follow_symlinks=False)
        if stat.S_ISLNK(named.st_mode) or (named.st_dev, named.st_ino) != (info.st_dev, info.st_ino):
            raise RegistrationBusy("lifecycle descriptor does not match the current lock")
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RegistrationBusy("another up/down or registration is in progress") from None
        named = os.stat("first-run.lock", dir_fd=directory, follow_symlinks=False)
        if (named.st_dev, named.st_ino) != (info.st_dev, info.st_ino):
            raise RegistrationBusy("lifecycle lock changed while acquiring exclusion")
        directory_unchanged()
        yield fd
    finally:
        if fd is not None:
            os.close(fd)
        os.close(directory)


def prepare_first_run_store(requested=None):
    """New product binding act; called while lifecycle_exclusion is held.

    Existing bindings remain authoritative; no implicit adoption of an existing
    directory, overwrite of a broken locator, or environment-selected bootstrap.
    """
    with registration_exclusion():
        loc = locator_path()
        if os.path.lexists(loc):
            bound = resolve_store_dir()
            if requested and not _same_dir(Path(requested).expanduser(), bound):
                raise ValueError("a different store is already registered; up never switches stores")
            return bound
        if product_identity.inherited_setting(STORE_ENV_OVERRIDE):
            raise ValueError(product_identity.diagnostic(
                "PSQR_STORE_DIR cannot select an unbound store; unset it and use up --store",
                "installation configuration cannot select an unbound store; use up --store"))
        if product_identity.inherited_setting('PSQR_OWNER') not in {None, '', 'local-operator'}:
            raise ValueError(product_identity.diagnostic(
                'new stores require the neutral local-operator; unset PSQR_OWNER before first up',
                'new stores require the neutral local operator'))
        target = Path(requested).expanduser() if requested else product_identity.state_root() / "store"
        if not target.is_absolute():
            raise ValueError("--store requires an absolute path")
        if os.path.lexists(target):
            raise ValueError(f"{target}: already exists but is unregistered; use store candidates/register explicitly")
        target = target.resolve()
        if not target.parent.is_dir():
            raise ValueError("new store parent directory must already exist")
        target.mkdir(mode=0o700, exist_ok=False)
        parent_fd = os.open(target.parent, os.O_RDONLY)
        try:
            os.fsync(parent_fd)
        finally:
            os.close(parent_fd)
        # One neutral human permits the explicit one-time token bootstrap. No
        # agent identity or credential is created; existing stores returned above.
        initial = {"local-operator": _participant_record(
            "local-operator", kind="human", family=None, channel="notify")}
        for name, content in (("log.jsonl", ""), ("participants.json", json.dumps(initial) + "\n")):
            fd = os.open(target / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            with os.fdopen(fd, "w") as stream:
                stream.write(content)
                stream.flush()
                os.fsync(stream.fileno())
        fd = os.open(target, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
        _register_store_locked(target, registrant="local-operator", measured=measure_store(target))
        return target


def register_store(path: Any, *, registrant: str) -> Dict[str, Any]:
    """The registration act (W0.2): write the locator (0600, atomic replace) and a ledger
    receipt INTO THE REGISTERED STORE's ``ledger.jsonl`` (path, ``log.jsonl`` SHA-256,
    line count, newest msg-id, registrant, ts). Refuses with ValueError unless ``path`` is
    absolute and names an existing directory containing ``log.jsonl`` — a typo must never
    be promoted into a store, and nothing here guesses. Refuses (ValueError) while a live
    daemon holds the CURRENTLY bound store's ``daemon.lock`` and ``path`` is a different
    store: the swap would orphan that daemon — ``{product_identity.command()} down`` first. Refuses
    (RegistrationBusy) while another registration or a starting daemon holds the
    locator-level exclusion: the whole sequence below runs under it, so a concurrent
    registration is never raced and never returns a success the locator does not hold
    (reviewer-P0-4). Choosing WHICH store is a decision taken elsewhere (DP-1); this only
    records it."""
    target = Path(os.path.normpath(os.path.expanduser(str(path))))
    if not target.is_absolute():
        raise ValueError(f"store path must be absolute: {path!r}")
    if not target.is_dir():
        raise ValueError(f"not a directory: {target}")
    info = target.stat()
    if info.st_uid != os.getuid():
        raise ValueError('store_root_owner_mismatch')
    if stat.S_IMODE(info.st_mode) != 0o700:
        raise ValueError('store_root_mode_unsafe')
    if not (target / "log.jsonl").is_file():
        raise ValueError(f"{target} has no log.jsonl — not a store (to register a NEW, empty "
                         "store, create an empty log.jsonl there first; nothing is created "
                         "for you)")
    if not PARTICIPANT_ID_RE.match(registrant or ""):
        raise ValueError(f"registrant must be a participant id: {registrant!r}")
    measured = measure_store(target)
    if measured.get("error"):
        raise ValueError(f"{target}/log.jsonl is {measured['error']}")
    with lifecycle_exclusion(), registration_exclusion():
        result = _register_store_locked(target, registrant=registrant, measured=measured)
    # The shell's override is REPORTED here (never resolved through) so the CLI can warn
    # that every command in that shell will refuse until it is unset or made equal — the
    # third and last reader of the override, all three in this module (G0.1). A RELATIVE
    # override is refused by the resolver whatever it happens to resolve to from some cwd,
    # so it is always reported; an absolute one only when it names a different directory.
    override = product_identity.inherited_setting(STORE_ENV_OVERRIDE)
    expanded = os.path.normpath(os.path.expanduser(override)) if override else None
    result["shell_override"] = override if override and (
        not os.path.isabs(expanded) or not _same_dir(Path(expanded), target)) else None
    return result


def _register_store_locked(target: Path, *, registrant: str,
                           measured: Dict[str, Any]) -> Dict[str, Any]:
    """The registration sequence proper — current-locator read, live-daemon check, prepare,
    commit, parent-dir fsync, completion receipt — run by ``register_store`` while it holds
    ``registration_exclusion`` (reviewer-P0-4). Never call it without the exclusion."""
    loc = locator_path()
    # A live daemon on the store being SUPERSEDED would be orphaned by the swap: once the
    # locator names the new store, `orch status`/`down` read only the NEW store's lock and
    # can neither see nor stop it, and `orch up` spawns a second daemon (Bugbot, round 5).
    # Nothing here stops a process — that is the operator's `{product_identity.command()} down` — so the
    # registration REFUSES, before anything is written. Re-registering the SAME store (a
    # receipt recovery, an fsync retry) is unaffected; a stale lock never blocks; a lock
    # that cannot be probed refuses too (it cannot be read as 'nobody').
    try:
        current, _ = read_locator(loc)
    except StoreUnbound:
        current = None                      # unbound, or a locator too broken to name a store
    if current is not None and not _same_dir(current, target):
        try:
            holder = daemon_lock_holder(current)
        except OSError as exc:
            raise ValueError(
                f"cannot probe {current / 'daemon.lock'} ({exc.strerror or exc}): a live "
                f"daemon on the currently bound store cannot be ruled out — refusing to swap "
                f"the locator; repair or remove that lock, then register {target}") from exc
        if holder is not None:
            who = f"pid {holder['pid']}" if holder["pid"] else "a process (pid unrecorded)"
            raise ValueError(
                f"a delivery daemon ({who}) holds {holder['lock']}: swapping the locator to "
                f"{target} would orphan it on the superseded store, where `{product_identity.command()} down` could "
                f"no longer see it — stop it first (`{product_identity.command()} down`), then register {target}")
    ts = now_iso()
    loc.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    import ledger
    # The prepare row's id is minted FIRST so the locator can carry it: a locator is later
    # matched to a prepare by this id alone — never by (ts, registrant, sha256), which an
    # unchanged store re-registered within the same second repeats byte for byte.
    prepared_id = ledger.new_event_id()
    # Crash-consistent ordering — the ledger may never report a completion the filesystem
    # does not hold, and no failure direction is silent:
    #   1. the new locator (path + `#registered … prepare <id>`) is fully written and
    #      fsynced to a TEMP file (every write-side failure — permissions, disk — surfaces
    #      before anything is recorded);
    #   2. a `store_registration_prepared` row goes into the REGISTERED store's ledger
    #      (named explicitly: this process may be unbound, or bound to the store being
    #      superseded) — a failed prepare leaves the previous binding intact;
    #   3. one atomic os.replace commits the binding, then the locator's PARENT DIRECTORY
    #      is fsynced (rename is a directory-metadata change; fsyncing the file alone does
    #      not make the new entry durable). A failed commit removes the temp file and
    #      appends a compensating `store_registration_failed` row, corr_id'd to the prepare;
    #   4. only then is the receipt — `store_registered`, corr_id'd to the prepare — written.
    # A process killed between 2 and 4 leaves a prepared row with no completion: visible,
    # never mistaken for a completion (registration_state() reports it), and the locator —
    # not the ledger — remains the binding of record.
    tmp = loc.with_name(f"{loc.name}.tmp.{os.getpid()}")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(f"{target}\n#registered {ts} by {registrant} from {measured['sha256']} "
                    f"prepare {prepared_id}\n")
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp, 0o600)
    except BaseException:
        try:
            tmp.unlink()
        except OSError:
            pass
        raise
    try:
        parts = json.loads((target / "participants.json").read_text(encoding="utf-8"))
        rec = parts.get(registrant) if isinstance(parts, dict) else None
    except (OSError, ValueError):
        rec = None
    role, _ = ledger.role_from_record(rec, actor_id=registrant)
    payload = {
        "mutation": "store_registered",
        "path": str(target),
        "log_sha256": measured["sha256"],
        "line_count": measured["lines"],
        "newest_msg_id": measured["newest_msg_id"],
        "registrant": registrant,
        "ts": ts,
        "locator": str(loc),
    }
    # Recovery of an earlier registration that committed but could not write its receipt
    # (StoreRegisteredWithoutReceipt): the new pair names that prepare, so the ledger
    # reads prepared → (no receipt) → prepared[recovers] → registered, never a bare hole.
    try:
        prior = registration_state(target)
    except (OSError, ValueError, TypeError):
        prior = {}
    if prior.get("state") == "committed_unreceipted":
        payload["recovers_prepared_id"] = prior["prepared_id"]
    ledger_file = target / "ledger.jsonl"
    try:
        prepared = ledger.emit("harness_mutation", actor_id=registrant, role=role,
                               payload={**payload, "mutation": "store_registration_prepared"},
                               ledger_file=ledger_file, event_id=prepared_id)
    except BaseException:
        try:
            tmp.unlink()
        except OSError:
            pass
        raise
    try:
        os.replace(tmp, loc)
    except BaseException as exc:
        try:
            tmp.unlink()
        except OSError:
            pass
        try:
            ledger.emit("harness_mutation", actor_id=registrant, role=role,
                        corr_id=prepared["id"], ledger_file=ledger_file,
                        payload={"mutation": "store_registration_failed",
                                 "path": str(target), "locator": str(loc),
                                 "prepared_id": prepared["id"], "error": repr(exc)})
        except Exception:
            pass                                    # best effort: the raise below is the record
        raise
    # From here the binding IS committed and visible; nothing below may call it failed.
    fsync_error = None
    try:
        _fsync_dir(loc.parent)
    except OSError as exc:
        fsync_error = f"{exc.strerror or exc}"
    # The completion receipt ITSELF carries the fsync outcome (reviewer-P0-3): it is the one
    # durable carrier a reader may rely on — the distinct row appended below is
    # corroboration that may never land, and a state derived without it still says
    # "unconfirmed".
    payload["durability"] = "confirmed" if fsync_error is None else "unconfirmed"
    if fsync_error is not None:
        payload["durability_error"] = fsync_error
    try:
        receipt = ledger.emit("harness_mutation", actor_id=registrant, role=role,
                              corr_id=prepared["id"], payload=payload, ledger_file=ledger_file)
    except Exception as exc:
        # NOT a refusal: the locator is committed. Say exactly that, with the recovery —
        # and never claim durability: nothing receipted the fsync, which may have failed.
        raise StoreRegisteredWithoutReceipt(
            store_dir=target, locator=loc, prepared_id=prepared["id"],
            error=f"{exc}", registrant=registrant, durability_error=fsync_error) from exc
    warning = None
    if fsync_error is not None:
        # committed, but not proven durable across a crash: the receipt says so (above); a
        # DISTINCT row corr_id'd to it repeats the fact for readers of the row stream; the
        # caller gets a warning, never a refusal, and re-registering retries the fsync
        warning = (f"locator committed, but the parent directory fsync failed — durability "
                   f"across a crash is unconfirmed: {fsync_error}")
        try:
            ledger.emit("harness_mutation", actor_id=registrant, role=role,
                        corr_id=receipt["id"], ledger_file=ledger_file,
                        payload={"mutation": "store_registration_durability_unconfirmed",
                                 "path": str(target), "locator": str(loc),
                                 "receipt_id": receipt["id"], "error": fsync_error})
        except Exception as exc:
            warning += (f" (and the durability row could not be written: {exc} — the "
                        f"completion receipt itself records the failure)")
    return {"locator": str(loc), "store_dir": str(target), "measurement": measured,
            "receipt": receipt, "prepared": prepared, "warning": warning}


def _fsync_dir(directory: Path) -> None:
    fd = os.open(directory, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


REGISTRATION_MUTATIONS = frozenset({"store_registration_prepared", "store_registered",
                                    "store_registration_failed",
                                    "store_registration_durability_unconfirmed"})


def _locator_matches_prepare(prepared_id: str, path: Any) -> bool:
    """Read-only measurement: does the CURRENT locator carry exactly the binding ONE
    prepare row announced — its path, and a `#registered … prepare <id>` line whose id is
    that row's? The id is the proof, never the (ts, registrant, sha256) triple: an
    unchanged store re-registered within the same second repeats the triple byte for
    byte, so a later prepare that died before its commit would otherwise inherit an
    earlier, already-receipted sequence's locator and read as committed. A locator with
    no prepare id, or any read failure, proves nothing."""
    try:
        store_dir, comment = read_locator()
    except StoreUnbound:
        return False
    m = LOCATOR_COMMENT_RE.fullmatch(comment)
    return m is not None and m.group("prepare_id") == prepared_id \
        and str(store_dir) == str(path)


def registration_state(path: Path) -> Dict[str, Any]:
    """Read-only: the LATEST registration sequence recorded in ``<path>/ledger.jsonl``
    (bounded to the ledger's tail, ``TAIL_READ_BYTES``), so a prepare that never completed
    — the process died between prepare and commit — is visible instead of silently
    resembling a completion. ``state`` is ``completed`` / ``failed`` / ``dangling`` /
    ``none``; nothing here decides anything."""
    ledger_file = Path(path) / "ledger.jsonl"
    rows = []
    malformed = 0
    for r in tail_jsonl(ledger_file, 100000):
        payload = r.get("payload")
        if r.get("kind") != "harness_mutation" or not isinstance(payload, dict) \
                or payload.get("mutation") not in REGISTRATION_MUTATIONS:
            continue
        if not isinstance(r.get("id"), str) or not isinstance(r.get("ts"), str) \
                or not isinstance(r.get("actor_id"), str):
            malformed += 1               # a foreign/hand-edited row: counted, never trusted
            continue
        rows.append(r)
    note_extra = f"; {malformed} malformed registration row(s) ignored" if malformed else ""
    if not rows:
        return {"state": "none", "note": "no registration rows in the ledger tail" + note_extra}
    prepared = [r for r in rows if r["payload"]["mutation"] == "store_registration_prepared"]
    if not prepared:
        last = rows[-1]                      # pre-protocol receipt (no prepare row)
        return {"state": "completed" if last["payload"]["mutation"] == "store_registered"
                else "failed", "id": last["id"], "ts": last["ts"],
                "registrant": last["actor_id"], "prepared_id": None,
                **({"note": note_extra[2:]} if malformed else {})}
    last_prep = prepared[-1]
    outcome = next((r for r in rows if r.get("corr_id") == last_prep["id"]
                    and r["payload"]["mutation"] in ("store_registered",
                                                     "store_registration_failed")), None)
    if outcome is None:
        # A prepare with no outcome row. Which side of the commit was reached is NOT
        # asserted from the ledger — it is MEASURED against the locator: a locator naming
        # this prepare's path whose `#registered … prepare <id>` line carries THIS row's id
        # proves the commit happened (receipt missing); anything else — including a locator
        # written by an earlier prepare with the same ts, registrant and hash — leaves it
        # unproven.
        pl = last_prep["payload"]
        if _locator_matches_prepare(last_prep["id"], pl.get("path")):
            return {"state": "committed_unreceipted", "prepared_id": last_prep["id"],
                    "ts": last_prep["ts"], "registrant": last_prep["actor_id"],
                    "note": "locator committed (it carries this prepare's id) but the "
                            "completion receipt is missing — the append failed after the "
                            "commit; durability across a crash is NOT proven either (no "
                            f"receipt records the directory fsync); re-run `{product_identity.command()} --as <you> "
                            f"store register {pl.get('path')}` to receipt it" + note_extra}
        return {"state": "dangling", "prepared_id": last_prep["id"], "ts": last_prep["ts"],
                "registrant": last_prep["actor_id"],
                "note": "prepared with no completion, failure, or locator carrying its id — "
                        "commit NOT proven: the process may have died before it, or the "
                        "binding was since superseded; the locator, not this ledger, is the "
                        "binding of record" + note_extra}
    out = {"state": "completed" if outcome["payload"]["mutation"] == "store_registered"
           else "failed", "id": outcome["id"], "ts": outcome["ts"],
           "registrant": outcome["actor_id"], "prepared_id": last_prep["id"]}
    pl = outcome["payload"]
    unconfirmed = next((r for r in rows if r.get("corr_id") == outcome["id"]
                        and r["payload"]["mutation"]
                        == "store_registration_durability_unconfirmed"), None)
    if out["state"] == "completed" and (pl.get("durability") == "unconfirmed"
                                        or unconfirmed is not None):
        # the receipt is the carrier (reviewer-P0-3); the distinct row only corroborates it
        error = pl.get("durability_error") or (unconfirmed["payload"].get("error")
                                               if unconfirmed is not None else None)
        out["durability"] = "unconfirmed"
        out["note"] = ("committed and visible, but the locator directory fsync failed — "
                       f"durability across a crash is unconfirmed: {error}"
                       + ("" if pl.get("durability") == "unconfirmed" else
                          " (recorded by a durability row only: the receipt predates the "
                          "fact being carried in it)") + note_extra)
    elif out["state"] == "completed" and pl.get("durability") == "confirmed":
        out["durability"] = "confirmed"
        if malformed:
            out["note"] = note_extra[2:]
    elif malformed:
        out["note"] = note_extra[2:]
    return out
