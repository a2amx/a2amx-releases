"""Product-owned Claude client interface and receipted compatibility policy.

The catalog pins client bytes, not the product's CLI/store implementation. Old
wire versions may remain accepted; old source bytes never inherit that grace.
No default policy is written by a client inspection or by a daemon read.
"""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import stat

SCHEMA = 'orch.claude-hook-interface.v1'
CLIENT_SOURCES = frozenset({'wake_hook_claude.py', 'wake_hook_client.py',
                            'wake_hook_core.py', 'harness_facts.py'})
ROOT = Path(__file__).resolve().parent
CATALOG = ROOT / 'claude_hook_interface.json'
POLICY_KIND = 'claude-hook-interface-policy'


class Refused(ValueError):
    """A stable, credential-free interface refusal reason."""


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     ensure_ascii=True, allow_nan=False).encode()).hexdigest()


def is_digest(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def read_bytes(path, limit=4 * 1024 * 1024):
    p = Path(path)
    if not p.is_absolute() or p.resolve() != p:
        raise Refused('hook_interface_noncanonical_file')
    fd = os.open(p, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as stream:
        info = os.fstat(stream.fileno())
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                or info.st_mode & 0o022 or info.st_size > limit):
            raise Refused('hook_interface_file_type_owner_or_bound')
        data = stream.read(limit + 1)
        if len(data) > limit:
            raise Refused('hook_interface_file_bound')
        return data


def validate_descriptor(value):
    if (not isinstance(value, dict) or set(value) != {'schema', 'version', 'sources'}
            or value['schema'] != SCHEMA or type(value['version']) is not int
            or not 1 <= value['version'] <= 1000000
            or not isinstance(value['sources'], dict)
            or set(value['sources']) != CLIENT_SOURCES
            or not all(is_digest(v) for v in value['sources'].values())):
        raise Refused('hook_interface_schema')


def deployed():
    """Verify the reviewed catalog against actual deployed client modules."""
    value = json.loads(read_bytes(CATALOG, 32768))
    validate_descriptor(value)
    for name, expected in value['sources'].items():
        if hashlib.sha256(read_bytes(ROOT / name)).hexdigest() != expected:
            raise Refused('hook_interface_deployed_source_mismatch')
    return value


def _expiry(value):
    if value is None:
        return None
    try:
        result = datetime.fromisoformat(value)
        if result.tzinfo is None:
            raise ValueError()
        return result
    except (ValueError, TypeError):
        raise Refused('hook_interface_policy_expiry') from None


def policy(catalog, *, rows=None):
    """Read a complete CAS chain; malformed policy evidence never rolls back."""
    import receipts
    rows = receipts.rows() if rows is None else rows
    current = None
    key = digest(catalog)
    fields = {'kind', 'event', 'catalog_digest', 'version', 'previous_version',
              'expires_at', 'previous_generation', 'generation', 'requester', 'ts', 'reason'}
    for row in rows:
        if row.get('kind') != POLICY_KIND:
            continue
        if not is_digest(row.get('catalog_digest')):
            raise Refused('hook_interface_policy_invalid')
        if row['catalog_digest'] != key:
            continue
        expected = current['generation'] if current else 'none'
        if (set(row) != fields or row.get('event') != 'recorded'
                or type(row.get('version')) is not int or row['version'] != catalog['version']
                or row.get('previous_generation') != expected
                or row.get('generation') != digest({k: v for k, v in row.items() if k != 'generation'})
                or not isinstance(row.get('requester'), str) or not row['requester']
                or not isinstance(row.get('reason'), str) or not row['reason']
                or not isinstance(row.get('ts'), str)):
            raise Refused('hook_interface_policy_invalid')
        older = row['previous_version']
        if older is not None and (type(older) is not int or older != catalog['version'] - 1 or older < 1):
            raise Refused('hook_interface_policy_invalid')
        _expiry(row['expires_at'])
        if older is None and row['expires_at'] is not None:
            raise Refused('hook_interface_policy_invalid')
        current = row
    return current


def _record(catalog, actor, previous, expires_at, expected_generation, reason):
    """Caller holds current-provisioner authentication and the nudge lock."""
    import receipts
    import store
    current = policy(catalog)
    if expected_generation != (current['generation'] if current else 'none'):
        raise Refused('hook_interface_stale_policy_generation')
    if previous not in {'until-cleared', 'disabled'}:
        raise Refused('hook_interface_policy_mode')
    deadline = _expiry(expires_at)
    if deadline is not None and deadline <= datetime.now(timezone.utc):
        raise Refused('hook_interface_policy_expired')
    older = catalog['version'] - 1 if previous == 'until-cleared' and catalog['version'] > 1 else None
    if deadline is not None and older is None:
        raise Refused('hook_interface_policy_expiry_without_previous')
    if (not isinstance(reason, str) or not 1 <= len(reason) <= 512
            or any(ord(c) < 32 for c in reason)):
        raise Refused('hook_interface_policy_reason')
    row = {'kind': POLICY_KIND, 'event': 'recorded', 'catalog_digest': digest(catalog),
           'version': catalog['version'], 'previous_version': older, 'expires_at': expires_at,
           'previous_generation': expected_generation, 'requester': actor,
           'ts': store.now_iso(), 'reason': reason}
    row['generation'] = digest(row)
    receipts._append(row)
    return row


def ensure_policy(catalog, actor):
    """The first v2 provisioning act receipts the commissioned default once."""
    current = policy(catalog)
    return current or _record(catalog, actor, 'until-cleared', None, 'none',
                              'Initial qualification: previous interface until provisioner clears it')


def set_policy(*, presented_token, previous, expected_generation, reason, expires_at=None):
    import receipts
    import store
    if expected_generation != 'none' and not is_digest(expected_generation):
        raise Refused('hook_interface_expected_policy_generation')
    def apply(actor):
        catalog = deployed()
        with receipts._nudge_lock():
            return _record(catalog, actor, previous, expires_at, expected_generation, reason)
    return store.authenticated_registry_act(presented_token, apply, provisioning=True)


def inspect(*, presented_token):
    """Authenticated metadata read, also usable before any seat has a v2 kit."""
    import receipts
    import store
    def apply(actor):
        catalog = deployed()
        with receipts._nudge_lock():
            return {'current': catalog, 'policy': policy(catalog)}
    return store.authenticated_registry_act(presented_token, apply)


def check(client, *, rows=None, now=None):
    """Check source integrity separately from the current migration window."""
    validate_descriptor(client)
    catalog = deployed()
    if client['sources'] != catalog['sources']:
        raise Refused('hook_interface_stale_sources')
    accepted = policy(catalog, rows=rows)
    if accepted is None:
        raise Refused('hook_interface_policy_unrecorded')
    version = client['version']
    if version != catalog['version']:
        if version != accepted['previous_version']:
            raise Refused('hook_interface_version_refused')
        expiry = _expiry(accepted['expires_at'])
        if expiry is not None and (now or datetime.now(timezone.utc)) >= expiry:
            raise Refused('hook_interface_previous_expired')
    return {'current': catalog, 'policy': accepted}
